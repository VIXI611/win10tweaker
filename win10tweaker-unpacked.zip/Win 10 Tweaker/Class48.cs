﻿using System;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000088 RID: 136
internal class Class48
{
	// Token: 0x17000036 RID: 54
	// (get) Token: 0x060006CE RID: 1742 RVA: 0x0001ED58 File Offset: 0x0001CF58
	public static Class48 Class48_0
	{
		get
		{
			if (Class48.class48_0 == null)
			{
				object obj = Class48.object_0;
				lock (obj)
				{
					if (Class48.class48_0 == null)
					{
						Class48.class48_0 = new Class48();
					}
				}
			}
			return Class48.class48_0;
		}
	}

	// Token: 0x060006CF RID: 1743 RVA: 0x0001EDB8 File Offset: 0x0001CFB8
	public void method_0()
	{
		RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey(Class48.string_0);
		registryKey.SetValue("", GClass2.GClass2_0.method_1("Firewall_Allow"));
		registryKey.SetValue("Icon", "netcenter.dll,10");
		Registry.ClassesRoot.CreateSubKey("exefile\\shell\\Firewall_Allow\\command").SetValue("", "netsh advfirewall firewall delete rule name=\"%1\"");
		RegistryKey registryKey2 = Registry.ClassesRoot.CreateSubKey(Class48.string_1);
		registryKey2.SetValue("", GClass2.GClass2_0.method_1("Firewall_Block"));
		registryKey2.SetValue("Icon", "netcenter.dll,5");
		Registry.ClassesRoot.CreateSubKey("exefile\\shell\\Firewall_Block\\command").SetValue("", "cmd /d /c \"netsh advfirewall firewall add rule name=\"%1\" dir=in action=block program=\"%1\" & netsh advfirewall firewall add rule name=\"%1\" dir=out action=block program=\"%1\"\"");
		using (RegistryKey registryKey3 = Registry.ClassesRoot.OpenSubKey(Class48.string_0, true))
		{
			if (registryKey3 != null && registryKey3.GetValue("Extended") != null)
			{
				registryKey3.DeleteValue("Extended");
			}
		}
		using (RegistryKey registryKey4 = Registry.ClassesRoot.OpenSubKey(Class48.string_1, true))
		{
			if (registryKey4 != null && registryKey4.GetValue("Extended") != null)
			{
				registryKey4.DeleteValue("Extended");
			}
		}
	}

	// Token: 0x060006D0 RID: 1744 RVA: 0x0000480B File Offset: 0x00002A0B
	public void method_1()
	{
		Registry.ClassesRoot.CreateSubKey(Class48.string_0).SetValue("Extended", "");
		Registry.ClassesRoot.CreateSubKey(Class48.string_1).SetValue("Extended", "");
	}

	// Token: 0x060006D1 RID: 1745 RVA: 0x00004849 File Offset: 0x00002A49
	public void method_2()
	{
		Registry.ClassesRoot.DeleteSubKeyTree(Class48.string_0, false);
		Registry.ClassesRoot.DeleteSubKeyTree(Class48.string_1, false);
	}

	// Token: 0x060006D4 RID: 1748 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060006D5 RID: 1749 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060006D6 RID: 1750 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_2)
	{
		return registryKey_0.CreateSubKey(string_2);
	}

	// Token: 0x060006D7 RID: 1751 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_3(RegistryKey registryKey_0, string string_2, object object_1)
	{
		registryKey_0.SetValue(string_2, object_1);
	}

	// Token: 0x060006D8 RID: 1752 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_4(RegistryKey registryKey_0, string string_2, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_2, bool_0);
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_5(RegistryKey registryKey_0, string string_2)
	{
		return registryKey_0.GetValue(string_2);
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_6(RegistryKey registryKey_0, string string_2)
	{
		registryKey_0.DeleteValue(string_2);
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_7(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060006DC RID: 1756 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_8(RegistryKey registryKey_0, string string_2, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_2, bool_0);
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_9()
	{
		return new object();
	}

	// Token: 0x040002A1 RID: 673
	private static volatile Class48 class48_0;

	// Token: 0x040002A2 RID: 674
	private static readonly object object_0 = new object();

	// Token: 0x040002A3 RID: 675
	private static readonly string string_0 = "exefile\\shell\\Firewall_Allow";

	// Token: 0x040002A4 RID: 676
	private static readonly string string_1 = "exefile\\shell\\Firewall_Block";
}
