﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.Win32;

// Token: 0x0200008B RID: 139
internal class Class50
{
	// Token: 0x17000038 RID: 56
	// (get) Token: 0x060006EE RID: 1774 RVA: 0x0001F010 File Offset: 0x0001D210
	public static Class50 Class50_0
	{
		get
		{
			if (Class50.class50_0 == null)
			{
				object obj = Class50.object_0;
				lock (obj)
				{
					if (Class50.class50_0 == null)
					{
						Class50.class50_0 = new Class50();
					}
				}
			}
			return Class50.class50_0;
		}
	}

	// Token: 0x060006EF RID: 1775 RVA: 0x0001F070 File Offset: 0x0001D270
	public void method_0()
	{
		byte[] value = new byte[]
		{
			245,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			144,
			1,
			0,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			84,
			0,
			97,
			0,
			104,
			0,
			111,
			0,
			109,
			0,
			97,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0
		};
		RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop\\WindowMetrics");
		registryKey.SetValue("CaptionFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("IconFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("MenuFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("MessageFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("SmCaptionFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("StatusFont", value, RegistryValueKind.Binary);
		RegistryKey registryKey2 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_1 + "\\Fonts");
		registryKey2.SetValue("Segoe UI (TrueType)", "");
		registryKey2.SetValue("Segoe UI Bold (TrueType)", "");
		registryKey2.SetValue("Segoe UI Bold Italic (TrueType)", "");
		registryKey2.SetValue("Segoe UI Italic (TrueType)", "");
		registryKey2.SetValue("Segoe UI Light (TrueType)", "");
		registryKey2.SetValue("Segoe UI Semibold (TrueType)", "");
		Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_1 + "\\FontSubstitutes").SetValue("Segoe UI", "MS Sans Serif");
		Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop").SetValue("FontSmoothingType", 1);
		Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Notepad").SetValue("lfFaceName", "Verdana");
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			RegistryKey registryKey3 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\RegEdit");
			registryKey3.SetValue("FontFace", "Tahoma");
			registryKey3.SetValue("FontSize", 80);
		}
	}

	// Token: 0x060006F0 RID: 1776 RVA: 0x0001F228 File Offset: 0x0001D428
	public void method_1()
	{
		byte[] value = new byte[]
		{
			244,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			144,
			1,
			0,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			5,
			0,
			83,
			0,
			101,
			0,
			103,
			0,
			111,
			0,
			101,
			0,
			32,
			0,
			85,
			0,
			73,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0
		};
		RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop\\WindowMetrics");
		registryKey.SetValue("CaptionFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("IconFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("MenuFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("MessageFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("SmCaptionFont", value, RegistryValueKind.Binary);
		registryKey.SetValue("StatusFont", value, RegistryValueKind.Binary);
		RegistryKey registryKey2 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_1 + "\\Fonts");
		registryKey2.SetValue("Segoe UI (TrueType)", "segoeui.ttf");
		registryKey2.SetValue("Segoe UI Bold (TrueType)", "segoeuib.ttf");
		registryKey2.SetValue("Segoe UI Bold Italic (TrueType)", "segoeuiz.ttf");
		registryKey2.SetValue("Segoe UI Italic (TrueType)", "segoeuii.ttf");
		registryKey2.SetValue("Segoe UI Light (TrueType)", "segoeuil.ttf");
		registryKey2.SetValue("Segoe UI Semibold (TrueType)", "seguisb.ttf");
		RegistryKey registryKey3;
		registryKey = (registryKey3 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_1 + "\\FontSubstitutes", true));
		try
		{
			if (registryKey != null && registryKey.GetValue("Segoe UI") != null)
			{
				registryKey.DeleteValue("Segoe UI");
			}
		}
		finally
		{
			if (registryKey3 != null)
			{
				((IDisposable)registryKey3).Dispose();
			}
		}
		Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop").SetValue("FontSmoothingType", 2);
		Registry.LocalMachine.DeleteSubKeyTree(GClass2.GClass2_0.String_0 + "\\RegEdit", false);
	}

	// Token: 0x060006F3 RID: 1779 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060006F4 RID: 1780 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x00002BF0 File Offset: 0x00000DF0
	static void smethod_2(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
	{
		RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_3(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x060006F7 RID: 1783 RVA: 0x00002EED File Offset: 0x000010ED
	static void smethod_4(RegistryKey registryKey_0, string string_0, object object_1, RegistryValueKind registryValueKind_0)
	{
		registryKey_0.SetValue(string_0, object_1, registryValueKind_0);
	}

	// Token: 0x060006F8 RID: 1784 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_5(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x060006F9 RID: 1785 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_6(RegistryKey registryKey_0, string string_0, object object_1)
	{
		registryKey_0.SetValue(string_0, object_1);
	}

	// Token: 0x060006FA RID: 1786 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_7(string string_0, string string_1)
	{
		return string_0.Contains(string_1);
	}

	// Token: 0x060006FB RID: 1787 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_8(RegistryKey registryKey_0, string string_0, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_0, bool_0);
	}

	// Token: 0x060006FC RID: 1788 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_9(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x060006FD RID: 1789 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_10(RegistryKey registryKey_0, string string_0)
	{
		registryKey_0.DeleteValue(string_0);
	}

	// Token: 0x060006FE RID: 1790 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_11(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060006FF RID: 1791 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_12(RegistryKey registryKey_0, string string_0, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_0, bool_0);
	}

	// Token: 0x06000700 RID: 1792 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_13()
	{
		return new object();
	}

	// Token: 0x040002AB RID: 683
	private static volatile Class50 class50_0;

	// Token: 0x040002AC RID: 684
	private static readonly object object_0 = new object();
}
