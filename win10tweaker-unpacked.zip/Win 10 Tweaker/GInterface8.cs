﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A5 RID: 421
[TypeIdentifier]
[Guid("286E6F1B-7113-4355-9562-96B7E9D64C54")]
[CompilerGenerated]
[ComImport]
public interface GInterface8 : GInterface7
{
	// Token: 0x06001444 RID: 5188
	void _VtblGap1_2();

	// Token: 0x06001445 RID: 5189
	[DispId(1610743810)]
	[MethodImpl(MethodImplOptions.InternalCall)]
	[return: MarshalAs(UnmanagedType.Interface)]
	GInterface1 imethod_0([MarshalAs(UnmanagedType.Struct)] [In] object object_0);
}
