﻿using System;

// Token: 0x02000053 RID: 83
public enum GEnum0
{
	// Token: 0x040001F8 RID: 504
	User = 1,
	// Token: 0x040001F9 RID: 505
	Machine
}
