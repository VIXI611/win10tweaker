﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Win_10_Tweaker;

// Token: 0x0200004C RID: 76
public partial class Copied : Form
{
	// Token: 0x060003B8 RID: 952
	[DllImport("dwmapi.dll")]
	public static extern int DwmExtendFrameIntoClientArea(IntPtr intptr_0, ref Copied.GStruct1 gstruct1_0);

	// Token: 0x060003B9 RID: 953
	[DllImport("dwmapi.dll")]
	public static extern int DwmSetWindowAttribute(IntPtr intptr_0, int int_0, ref int int_1, int int_2);

	// Token: 0x060003BA RID: 954
	[DllImport("dwmapi.dll")]
	public static extern int DwmIsCompositionEnabled(ref int int_0);

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x060003BB RID: 955 RVA: 0x00017BF4 File Offset: 0x00015DF4
	protected virtual CreateParams CreateParams
	{
		get
		{
			this.bool_0 = this.method_0();
			CreateParams createParams = base.CreateParams;
			createParams.Style |= 131072;
			createParams.ClassStyle |= 8;
			if (!this.bool_0)
			{
				createParams.ClassStyle |= 131072;
			}
			return createParams;
		}
	}

	// Token: 0x060003BC RID: 956 RVA: 0x00017C50 File Offset: 0x00015E50
	private bool method_0()
	{
		if (Environment.OSVersion.Version.Major >= 6)
		{
			int num = 0;
			Copied.DwmIsCompositionEnabled(ref num);
			return num == 1;
		}
		return false;
	}

	// Token: 0x060003BD RID: 957 RVA: 0x00017C80 File Offset: 0x00015E80
	protected virtual void WndProc(ref Message m)
	{
		if (m.Msg == 133 && this.bool_0)
		{
			int num = 2;
			Copied.DwmSetWindowAttribute(base.Handle, 2, ref num, 4);
			Copied.GStruct1 gstruct = new Copied.GStruct1
			{
				int_3 = 1,
				int_0 = 0,
				int_1 = 0,
				int_2 = 0
			};
			Copied.DwmExtendFrameIntoClientArea(base.Handle, ref gstruct);
		}
		base.WndProc(ref m);
		if (m.Msg == 132 && (int)m.Result == 1)
		{
			m.Result = (IntPtr)2;
		}
	}

	// Token: 0x060003BE RID: 958 RVA: 0x0000394C File Offset: 0x00001B4C
	public Copied(Form1 form1_1)
	{
		this.InitializeComponent();
		this.form1_0 = form1_1;
		this.BackColor = GClass2.GClass2_0.color_3;
	}

	// Token: 0x060003BF RID: 959 RVA: 0x00017D1C File Offset: 0x00015F1C
	private void Copied_Load(object sender, EventArgs e)
	{
		Copied.Struct32 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.copied_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Copied.Struct32>(ref @struct);
	}

	// Token: 0x060003C0 RID: 960 RVA: 0x00017D54 File Offset: 0x00015F54
	private void timer_0_Tick(object sender, EventArgs e)
	{
		Copied.Struct33 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.copied_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Copied.Struct33>(ref @struct);
	}

	// Token: 0x060003C1 RID: 961 RVA: 0x00003971 File Offset: 0x00001B71
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060003C3 RID: 963 RVA: 0x00003990 File Offset: 0x00001B90
	static int smethod_0(CreateParams createParams_0)
	{
		return createParams_0.Style;
	}

	// Token: 0x060003C4 RID: 964 RVA: 0x00003998 File Offset: 0x00001B98
	static void smethod_1(CreateParams createParams_0, int int_0)
	{
		createParams_0.Style = int_0;
	}

	// Token: 0x060003C5 RID: 965 RVA: 0x00002F78 File Offset: 0x00001178
	static int smethod_2(CreateParams createParams_0)
	{
		return createParams_0.ClassStyle;
	}

	// Token: 0x060003C6 RID: 966 RVA: 0x00002F80 File Offset: 0x00001180
	static void smethod_3(CreateParams createParams_0, int int_0)
	{
		createParams_0.ClassStyle = int_0;
	}

	// Token: 0x060003C7 RID: 967 RVA: 0x00002F89 File Offset: 0x00001189
	static OperatingSystem smethod_4()
	{
		return Environment.OSVersion;
	}

	// Token: 0x060003C8 RID: 968 RVA: 0x00002F90 File Offset: 0x00001190
	static Version smethod_5(OperatingSystem operatingSystem_0)
	{
		return operatingSystem_0.Version;
	}

	// Token: 0x060003C9 RID: 969 RVA: 0x00002F98 File Offset: 0x00001198
	static int smethod_6(Version version_0)
	{
		return version_0.Major;
	}

	// Token: 0x060003CA RID: 970 RVA: 0x00002BA7 File Offset: 0x00000DA7
	static void smethod_7(Control control_0, Color color_0)
	{
		control_0.BackColor = color_0;
	}

	// Token: 0x060003CB RID: 971 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_8(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060003CC RID: 972 RVA: 0x00002A4C File Offset: 0x00000C4C
	static Container smethod_9()
	{
		return new Container();
	}

	// Token: 0x060003CD RID: 973 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_10()
	{
		return new Label();
	}

	// Token: 0x060003CE RID: 974 RVA: 0x000039A1 File Offset: 0x00001BA1
	static Timer smethod_11(IContainer icontainer_1)
	{
		return new Timer(icontainer_1);
	}

	// Token: 0x060003CF RID: 975 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_12(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060003D0 RID: 976 RVA: 0x00002A9D File Offset: 0x00000C9D
	static void smethod_13(Control control_0, bool bool_1)
	{
		control_0.AutoSize = bool_1;
	}

	// Token: 0x060003D1 RID: 977 RVA: 0x000039A9 File Offset: 0x00001BA9
	static Font smethod_14(string string_0, float float_0, FontStyle fontStyle_0, GraphicsUnit graphicsUnit_0, byte byte_0)
	{
		return new Font(string_0, float_0, fontStyle_0, graphicsUnit_0, byte_0);
	}

	// Token: 0x060003D2 RID: 978 RVA: 0x000039B6 File Offset: 0x00001BB6
	static void smethod_15(Control control_0, Font font_0)
	{
		control_0.Font = font_0;
	}

	// Token: 0x060003D3 RID: 979 RVA: 0x00002B7F File Offset: 0x00000D7F
	static void smethod_16(Control control_0, Color color_0)
	{
		control_0.ForeColor = color_0;
	}

	// Token: 0x040001E3 RID: 483
	private bool bool_0;

	// Token: 0x040001E4 RID: 484
	private readonly Form1 form1_0;

	// Token: 0x0200004D RID: 77
	public struct GStruct1
	{
		// Token: 0x040001E8 RID: 488
		public int int_0;

		// Token: 0x040001E9 RID: 489
		public int int_1;

		// Token: 0x040001EA RID: 490
		public int int_2;

		// Token: 0x040001EB RID: 491
		public int int_3;
	}
}
