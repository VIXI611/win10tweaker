﻿// Token: 0x0200009F RID: 159
public partial class Settings_1 : global::GForm0
{
	// Token: 0x0600084C RID: 2124 RVA: 0x000249FC File Offset: 0x00022BFC
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Settings_1));
		this.Toggle10 = new global::System.Windows.Forms.PictureBox();
		this.Toggle9 = new global::System.Windows.Forms.PictureBox();
		this.Toggle8 = new global::System.Windows.Forms.PictureBox();
		this.Toggle7 = new global::System.Windows.Forms.PictureBox();
		this.Toggle6 = new global::System.Windows.Forms.PictureBox();
		this.Toggle5 = new global::System.Windows.Forms.PictureBox();
		this.Toggle4 = new global::System.Windows.Forms.PictureBox();
		this.Toggle3 = new global::System.Windows.Forms.PictureBox();
		this.Toggle2 = new global::System.Windows.Forms.PictureBox();
		this.Toggle1 = new global::System.Windows.Forms.PictureBox();
		this.SettingsItemlabel10 = new global::System.Windows.Forms.Label();
		this.SettingsItemlabel8 = new global::System.Windows.Forms.Label();
		this.SettingsItemlabel7 = new global::System.Windows.Forms.Label();
		this.SettingsItemlabel6 = new global::System.Windows.Forms.Label();
		this.SettingsItemlabel5 = new global::System.Windows.Forms.Label();
		this.SettingsItemlabel4 = new global::System.Windows.Forms.Label();
		this.SettingsItemlabel3 = new global::System.Windows.Forms.Label();
		this.SettingsItemlabel2 = new global::System.Windows.Forms.Label();
		this.SettingsItemlabel1 = new global::System.Windows.Forms.Label();
		this.Header = new global::System.Windows.Forms.Label();
		this.MenuLabel1 = new global::System.Windows.Forms.Label();
		this.MenuItem1 = new global::System.Windows.Forms.PictureBox();
		this.IconsPanel = new global::System.Windows.Forms.Panel();
		this.MenuLabel10 = new global::System.Windows.Forms.Label();
		this.MenuLabel9 = new global::System.Windows.Forms.Label();
		this.MenuLabel8 = new global::System.Windows.Forms.Label();
		this.MenuLabel7 = new global::System.Windows.Forms.Label();
		this.MenuLabel6 = new global::System.Windows.Forms.Label();
		this.MenuLabel5 = new global::System.Windows.Forms.Label();
		this.MenuLabel4 = new global::System.Windows.Forms.Label();
		this.MenuLabel3 = new global::System.Windows.Forms.Label();
		this.MenuLabel2 = new global::System.Windows.Forms.Label();
		this.MenuItem10 = new global::System.Windows.Forms.PictureBox();
		this.MenuItem9 = new global::System.Windows.Forms.PictureBox();
		this.MenuItem8 = new global::System.Windows.Forms.PictureBox();
		this.MenuItem7 = new global::System.Windows.Forms.PictureBox();
		this.MenuItem6 = new global::System.Windows.Forms.PictureBox();
		this.MenuItem5 = new global::System.Windows.Forms.PictureBox();
		this.MenuItem4 = new global::System.Windows.Forms.PictureBox();
		this.MenuItem3 = new global::System.Windows.Forms.PictureBox();
		this.MenuItem2 = new global::System.Windows.Forms.PictureBox();
		this.TogglesPanel = new global::System.Windows.Forms.Panel();
		this.SettingsItemlabel9 = new global::System.Windows.Forms.Label();
		this.SkinPanel = new global::System.Windows.Forms.Panel();
		this.SeaSkin = new global::System.Windows.Forms.PictureBox();
		this.DarkSkin = new global::System.Windows.Forms.PictureBox();
		this.SkySkin = new global::System.Windows.Forms.PictureBox();
		this.Toggle11 = new global::System.Windows.Forms.PictureBox();
		this.SettingsItemlabel11 = new global::System.Windows.Forms.Label();
		this.LangPanel = new global::System.Windows.Forms.Panel();
		this.Deutsch = new global::System.Windows.Forms.PictureBox();
		this.Ukrainian = new global::System.Windows.Forms.PictureBox();
		this.Russian = new global::System.Windows.Forms.PictureBox();
		this.English = new global::System.Windows.Forms.PictureBox();
		this.DaysLabel = new global::System.Windows.Forms.Label();
		this.Nud1 = new global::System.Windows.Forms.NumericUpDown();
		this.InvisPanel = new global::System.Windows.Forms.Panel();
		this.HeaderPanel = new global::System.Windows.Forms.Panel();
		this.CloseIcon = new global::System.Windows.Forms.Button();
		this.toolTip_0 = new global::System.Windows.Forms.ToolTip(this.icontainer_0);
		((global::System.ComponentModel.ISupportInitialize)this.Toggle10).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle9).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle8).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle7).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle6).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle5).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle4).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle3).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle2).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle1).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem1).BeginInit();
		this.IconsPanel.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem10).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem9).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem8).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem7).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem6).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem5).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem4).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem3).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem2).BeginInit();
		this.TogglesPanel.SuspendLayout();
		this.SkinPanel.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.SeaSkin).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.DarkSkin).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.SkySkin).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle11).BeginInit();
		this.LangPanel.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.Deutsch).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Ukrainian).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Russian).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.English).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Nud1).BeginInit();
		this.HeaderPanel.SuspendLayout();
		base.SuspendLayout();
		this.Toggle10.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle10.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("Toggle10.Image");
		this.Toggle10.Location = new global::System.Drawing.Point(17, 234);
		this.Toggle10.Name = "Toggle10";
		this.Toggle10.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle10.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle10.TabIndex = 180;
		this.Toggle10.TabStop = false;
		this.Toggle10.Click += new global::System.EventHandler(this.Toggle10_Click);
		this.Toggle9.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle9.Location = new global::System.Drawing.Point(17, 211);
		this.Toggle9.Name = "Toggle9";
		this.Toggle9.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle9.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle9.TabIndex = 189;
		this.Toggle9.TabStop = false;
		this.Toggle9.Click += new global::System.EventHandler(this.Toggle9_Click);
		this.Toggle8.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle8.Location = new global::System.Drawing.Point(17, 188);
		this.Toggle8.Name = "Toggle8";
		this.Toggle8.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle8.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle8.TabIndex = 179;
		this.Toggle8.TabStop = false;
		this.Toggle8.Click += new global::System.EventHandler(this.Toggle8_Click);
		this.Toggle7.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle7.Location = new global::System.Drawing.Point(17, 165);
		this.Toggle7.Name = "Toggle7";
		this.Toggle7.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle7.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle7.TabIndex = 178;
		this.Toggle7.TabStop = false;
		this.Toggle7.Click += new global::System.EventHandler(this.Toggle7_Click);
		this.Toggle6.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle6.Location = new global::System.Drawing.Point(17, 142);
		this.Toggle6.Name = "Toggle6";
		this.Toggle6.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle6.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle6.TabIndex = 177;
		this.Toggle6.TabStop = false;
		this.Toggle6.Click += new global::System.EventHandler(this.Toggle6_Click);
		this.Toggle5.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle5.Location = new global::System.Drawing.Point(17, 119);
		this.Toggle5.Name = "Toggle5";
		this.Toggle5.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle5.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle5.TabIndex = 176;
		this.Toggle5.TabStop = false;
		this.Toggle5.Click += new global::System.EventHandler(this.Toggle5_Click);
		this.Toggle4.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle4.Location = new global::System.Drawing.Point(17, 96);
		this.Toggle4.Name = "Toggle4";
		this.Toggle4.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle4.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle4.TabIndex = 175;
		this.Toggle4.TabStop = false;
		this.Toggle4.Click += new global::System.EventHandler(this.Toggle4_Click);
		this.Toggle3.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle3.Location = new global::System.Drawing.Point(17, 73);
		this.Toggle3.Name = "Toggle3";
		this.Toggle3.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle3.TabIndex = 174;
		this.Toggle3.TabStop = false;
		this.Toggle3.Click += new global::System.EventHandler(this.Toggle3_Click);
		this.Toggle2.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle2.Location = new global::System.Drawing.Point(17, 50);
		this.Toggle2.Name = "Toggle2";
		this.Toggle2.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle2.TabIndex = 173;
		this.Toggle2.TabStop = false;
		this.Toggle2.Click += new global::System.EventHandler(this.Toggle2_Click);
		this.Toggle1.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle1.Location = new global::System.Drawing.Point(17, 27);
		this.Toggle1.Name = "Toggle1";
		this.Toggle1.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle1.TabIndex = 172;
		this.Toggle1.TabStop = false;
		this.Toggle1.Click += new global::System.EventHandler(this.Toggle1_Click);
		this.SettingsItemlabel10.AutoSize = true;
		this.SettingsItemlabel10.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel10.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel10.Location = new global::System.Drawing.Point(48, 234);
		this.SettingsItemlabel10.Name = "SettingsItemlabel10";
		this.SettingsItemlabel10.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel10.TabIndex = 8;
		this.SettingsItemlabel8.AutoSize = true;
		this.SettingsItemlabel8.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel8.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel8.Location = new global::System.Drawing.Point(48, 188);
		this.SettingsItemlabel8.Name = "SettingsItemlabel8";
		this.SettingsItemlabel8.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel8.TabIndex = 7;
		this.SettingsItemlabel7.AutoSize = true;
		this.SettingsItemlabel7.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel7.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel7.Location = new global::System.Drawing.Point(48, 165);
		this.SettingsItemlabel7.Name = "SettingsItemlabel7";
		this.SettingsItemlabel7.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel7.TabIndex = 6;
		this.SettingsItemlabel6.AutoSize = true;
		this.SettingsItemlabel6.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel6.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel6.Location = new global::System.Drawing.Point(48, 142);
		this.SettingsItemlabel6.Name = "SettingsItemlabel6";
		this.SettingsItemlabel6.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel6.TabIndex = 5;
		this.SettingsItemlabel5.AutoSize = true;
		this.SettingsItemlabel5.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel5.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel5.Location = new global::System.Drawing.Point(48, 119);
		this.SettingsItemlabel5.Name = "SettingsItemlabel5";
		this.SettingsItemlabel5.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel5.TabIndex = 4;
		this.SettingsItemlabel4.AutoSize = true;
		this.SettingsItemlabel4.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel4.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel4.Location = new global::System.Drawing.Point(48, 96);
		this.SettingsItemlabel4.Name = "SettingsItemlabel4";
		this.SettingsItemlabel4.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel4.TabIndex = 3;
		this.SettingsItemlabel3.AutoSize = true;
		this.SettingsItemlabel3.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel3.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel3.Location = new global::System.Drawing.Point(48, 73);
		this.SettingsItemlabel3.Name = "SettingsItemlabel3";
		this.SettingsItemlabel3.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel3.TabIndex = 2;
		this.SettingsItemlabel2.AutoSize = true;
		this.SettingsItemlabel2.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel2.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel2.Location = new global::System.Drawing.Point(48, 50);
		this.SettingsItemlabel2.Name = "SettingsItemlabel2";
		this.SettingsItemlabel2.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel2.TabIndex = 1;
		this.SettingsItemlabel1.AutoSize = true;
		this.SettingsItemlabel1.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel1.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel1.Location = new global::System.Drawing.Point(48, 27);
		this.SettingsItemlabel1.Name = "SettingsItemlabel1";
		this.SettingsItemlabel1.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel1.TabIndex = 0;
		this.Header.AutoSize = true;
		this.Header.BackColor = global::System.Drawing.Color.Transparent;
		this.Header.Font = new global::System.Drawing.Font("Calibri", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.Header.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.Header.Location = new global::System.Drawing.Point(12, 9);
		this.Header.Name = "Header";
		this.Header.Size = new global::System.Drawing.Size(0, 15);
		this.Header.TabIndex = 30;
		this.MenuLabel1.AutoSize = true;
		this.MenuLabel1.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel1.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel1.Location = new global::System.Drawing.Point(13, 106);
		this.MenuLabel1.Name = "MenuLabel1";
		this.MenuLabel1.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel1.TabIndex = 183;
		this.MenuLabel1.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuItem1.Image = global::Class89.Bitmap_0;
		this.MenuItem1.Location = new global::System.Drawing.Point(15, 15);
		this.MenuItem1.Name = "MenuItem1";
		this.MenuItem1.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem1.TabIndex = 0;
		this.MenuItem1.TabStop = false;
		this.MenuItem1.Click += new global::System.EventHandler(this.MenuItem1_Click);
		this.IconsPanel.Controls.Add(this.MenuLabel10);
		this.IconsPanel.Controls.Add(this.MenuLabel9);
		this.IconsPanel.Controls.Add(this.MenuLabel8);
		this.IconsPanel.Controls.Add(this.MenuLabel7);
		this.IconsPanel.Controls.Add(this.MenuLabel6);
		this.IconsPanel.Controls.Add(this.MenuLabel5);
		this.IconsPanel.Controls.Add(this.MenuLabel4);
		this.IconsPanel.Controls.Add(this.MenuLabel3);
		this.IconsPanel.Controls.Add(this.MenuLabel2);
		this.IconsPanel.Controls.Add(this.MenuItem10);
		this.IconsPanel.Controls.Add(this.MenuItem9);
		this.IconsPanel.Controls.Add(this.MenuItem8);
		this.IconsPanel.Controls.Add(this.MenuItem7);
		this.IconsPanel.Controls.Add(this.MenuItem6);
		this.IconsPanel.Controls.Add(this.MenuItem5);
		this.IconsPanel.Controls.Add(this.MenuItem4);
		this.IconsPanel.Controls.Add(this.MenuItem3);
		this.IconsPanel.Controls.Add(this.MenuItem2);
		this.IconsPanel.Controls.Add(this.MenuItem1);
		this.IconsPanel.Controls.Add(this.MenuLabel1);
		this.IconsPanel.Location = new global::System.Drawing.Point(0, 312);
		this.IconsPanel.Name = "IconsPanel";
		this.IconsPanel.Size = new global::System.Drawing.Size(610, 310);
		this.IconsPanel.TabIndex = 191;
		this.IconsPanel.MouseEnter += new global::System.EventHandler(this.IconsPanel_MouseEnter);
		this.MenuLabel10.AutoSize = true;
		this.MenuLabel10.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel10.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel10.Location = new global::System.Drawing.Point(485, 232);
		this.MenuLabel10.Name = "MenuLabel10";
		this.MenuLabel10.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel10.TabIndex = 208;
		this.MenuLabel10.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuLabel9.AutoSize = true;
		this.MenuLabel9.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel9.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel9.Location = new global::System.Drawing.Point(485, 106);
		this.MenuLabel9.Name = "MenuLabel9";
		this.MenuLabel9.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel9.TabIndex = 207;
		this.MenuLabel9.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuLabel8.AutoSize = true;
		this.MenuLabel8.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel8.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel8.Location = new global::System.Drawing.Point(367, 232);
		this.MenuLabel8.Name = "MenuLabel8";
		this.MenuLabel8.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel8.TabIndex = 206;
		this.MenuLabel8.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuLabel7.AutoSize = true;
		this.MenuLabel7.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel7.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel7.Location = new global::System.Drawing.Point(367, 106);
		this.MenuLabel7.Name = "MenuLabel7";
		this.MenuLabel7.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel7.TabIndex = 205;
		this.MenuLabel7.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuLabel6.AutoSize = true;
		this.MenuLabel6.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel6.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel6.Location = new global::System.Drawing.Point(249, 232);
		this.MenuLabel6.Name = "MenuLabel6";
		this.MenuLabel6.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel6.TabIndex = 204;
		this.MenuLabel6.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuLabel5.AutoSize = true;
		this.MenuLabel5.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel5.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel5.Location = new global::System.Drawing.Point(249, 106);
		this.MenuLabel5.Name = "MenuLabel5";
		this.MenuLabel5.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel5.TabIndex = 203;
		this.MenuLabel5.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuLabel4.AutoSize = true;
		this.MenuLabel4.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel4.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel4.Location = new global::System.Drawing.Point(131, 232);
		this.MenuLabel4.Name = "MenuLabel4";
		this.MenuLabel4.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel4.TabIndex = 202;
		this.MenuLabel4.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuLabel3.AutoSize = true;
		this.MenuLabel3.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel3.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel3.Location = new global::System.Drawing.Point(131, 106);
		this.MenuLabel3.Name = "MenuLabel3";
		this.MenuLabel3.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel3.TabIndex = 201;
		this.MenuLabel3.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuLabel2.AutoSize = true;
		this.MenuLabel2.BackColor = global::System.Drawing.Color.Transparent;
		this.MenuLabel2.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.MenuLabel2.Location = new global::System.Drawing.Point(14, 232);
		this.MenuLabel2.Name = "MenuLabel2";
		this.MenuLabel2.Size = new global::System.Drawing.Size(0, 13);
		this.MenuLabel2.TabIndex = 200;
		this.MenuLabel2.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.MenuItem10.Image = global::Class89.Bitmap_1;
		this.MenuItem10.Location = new global::System.Drawing.Point(487, 140);
		this.MenuItem10.Name = "MenuItem10";
		this.MenuItem10.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem10.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem10.TabIndex = 199;
		this.MenuItem10.TabStop = false;
		this.MenuItem10.Click += new global::System.EventHandler(this.MenuItem10_Click);
		this.MenuItem9.Image = global::Class89.Bitmap_9;
		this.MenuItem9.Location = new global::System.Drawing.Point(487, 15);
		this.MenuItem9.Name = "MenuItem9";
		this.MenuItem9.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem9.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem9.TabIndex = 198;
		this.MenuItem9.TabStop = false;
		this.MenuItem9.Click += new global::System.EventHandler(this.MenuItem9_Click);
		this.MenuItem8.Image = global::Class89.Bitmap_8;
		this.MenuItem8.Location = new global::System.Drawing.Point(369, 140);
		this.MenuItem8.Name = "MenuItem8";
		this.MenuItem8.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem8.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem8.TabIndex = 197;
		this.MenuItem8.TabStop = false;
		this.MenuItem8.Click += new global::System.EventHandler(this.MenuItem8_Click);
		this.MenuItem7.Image = global::Class89.Bitmap_7;
		this.MenuItem7.Location = new global::System.Drawing.Point(369, 15);
		this.MenuItem7.Name = "MenuItem7";
		this.MenuItem7.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem7.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem7.TabIndex = 196;
		this.MenuItem7.TabStop = false;
		this.MenuItem7.Click += new global::System.EventHandler(this.MenuItem7_Click);
		this.MenuItem6.Image = global::Class89.Bitmap_6;
		this.MenuItem6.Location = new global::System.Drawing.Point(251, 140);
		this.MenuItem6.Name = "MenuItem6";
		this.MenuItem6.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem6.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem6.TabIndex = 195;
		this.MenuItem6.TabStop = false;
		this.MenuItem6.Click += new global::System.EventHandler(this.MenuItem6_Click);
		this.MenuItem5.Image = global::Class89.Bitmap_5;
		this.MenuItem5.Location = new global::System.Drawing.Point(251, 15);
		this.MenuItem5.Name = "MenuItem5";
		this.MenuItem5.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem5.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem5.TabIndex = 194;
		this.MenuItem5.TabStop = false;
		this.MenuItem5.Click += new global::System.EventHandler(this.MenuItem5_Click);
		this.MenuItem4.Image = global::Class89.Bitmap_4;
		this.MenuItem4.Location = new global::System.Drawing.Point(133, 140);
		this.MenuItem4.Name = "MenuItem4";
		this.MenuItem4.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem4.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem4.TabIndex = 193;
		this.MenuItem4.TabStop = false;
		this.MenuItem4.Click += new global::System.EventHandler(this.MenuItem4_Click);
		this.MenuItem3.Image = global::Class89.Bitmap_3;
		this.MenuItem3.Location = new global::System.Drawing.Point(133, 15);
		this.MenuItem3.Name = "MenuItem3";
		this.MenuItem3.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem3.TabIndex = 192;
		this.MenuItem3.TabStop = false;
		this.MenuItem3.Click += new global::System.EventHandler(this.MenuItem3_Click);
		this.MenuItem2.Image = global::Class89.Bitmap_2;
		this.MenuItem2.Location = new global::System.Drawing.Point(15, 140);
		this.MenuItem2.Name = "MenuItem2";
		this.MenuItem2.Size = new global::System.Drawing.Size(108, 88);
		this.MenuItem2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.MenuItem2.TabIndex = 191;
		this.MenuItem2.TabStop = false;
		this.MenuItem2.Click += new global::System.EventHandler(this.MenuItem2_Click);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel9);
		this.TogglesPanel.Controls.Add(this.Toggle9);
		this.TogglesPanel.Controls.Add(this.SkinPanel);
		this.TogglesPanel.Controls.Add(this.Toggle11);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel11);
		this.TogglesPanel.Controls.Add(this.LangPanel);
		this.TogglesPanel.Controls.Add(this.DaysLabel);
		this.TogglesPanel.Controls.Add(this.Nud1);
		this.TogglesPanel.Controls.Add(this.InvisPanel);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel1);
		this.TogglesPanel.Controls.Add(this.Toggle2);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel5);
		this.TogglesPanel.Controls.Add(this.Toggle10);
		this.TogglesPanel.Controls.Add(this.Toggle5);
		this.TogglesPanel.Controls.Add(this.Toggle6);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel8);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel4);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel7);
		this.TogglesPanel.Controls.Add(this.Toggle1);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel2);
		this.TogglesPanel.Controls.Add(this.Toggle8);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel6);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel3);
		this.TogglesPanel.Controls.Add(this.Toggle3);
		this.TogglesPanel.Controls.Add(this.SettingsItemlabel10);
		this.TogglesPanel.Controls.Add(this.Toggle7);
		this.TogglesPanel.Controls.Add(this.Toggle4);
		this.TogglesPanel.Location = new global::System.Drawing.Point(0, 34);
		this.TogglesPanel.Name = "TogglesPanel";
		this.TogglesPanel.Size = new global::System.Drawing.Size(610, 278);
		this.TogglesPanel.TabIndex = 192;
		this.SettingsItemlabel9.AutoSize = true;
		this.SettingsItemlabel9.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel9.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel9.Location = new global::System.Drawing.Point(48, 211);
		this.SettingsItemlabel9.Name = "SettingsItemlabel9";
		this.SettingsItemlabel9.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel9.TabIndex = 188;
		this.SkinPanel.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.SkinPanel.Controls.Add(this.SeaSkin);
		this.SkinPanel.Controls.Add(this.DarkSkin);
		this.SkinPanel.Controls.Add(this.SkySkin);
		this.SkinPanel.Location = new global::System.Drawing.Point(597, 164);
		this.SkinPanel.Name = "SkinPanel";
		this.SkinPanel.Size = new global::System.Drawing.Size(120, 85);
		this.SkinPanel.TabIndex = 186;
		this.SeaSkin.BackColor = global::System.Drawing.Color.FromArgb(16, 95, 112);
		this.SeaSkin.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.SeaSkin.Location = new global::System.Drawing.Point(19, 59);
		this.SeaSkin.Name = "SeaSkin";
		this.SeaSkin.Size = new global::System.Drawing.Size(23, 13);
		this.SeaSkin.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.SeaSkin.TabIndex = 185;
		this.SeaSkin.TabStop = false;
		this.toolTip_0.SetToolTip(this.SeaSkin, "Sea Skin");
		this.DarkSkin.BackColor = global::System.Drawing.Color.FromArgb(54, 64, 85);
		this.DarkSkin.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.DarkSkin.Location = new global::System.Drawing.Point(19, 13);
		this.DarkSkin.Name = "DarkSkin";
		this.DarkSkin.Size = new global::System.Drawing.Size(23, 13);
		this.DarkSkin.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.DarkSkin.TabIndex = 184;
		this.DarkSkin.TabStop = false;
		this.toolTip_0.SetToolTip(this.DarkSkin, "Dark Skin");
		this.SkySkin.BackColor = global::System.Drawing.Color.FromArgb(4, 80, 130);
		this.SkySkin.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.SkySkin.Location = new global::System.Drawing.Point(19, 36);
		this.SkySkin.Name = "SkySkin";
		this.SkySkin.Size = new global::System.Drawing.Size(23, 13);
		this.SkySkin.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.SkySkin.TabIndex = 183;
		this.SkySkin.TabStop = false;
		this.toolTip_0.SetToolTip(this.SkySkin, "Sky Skin");
		this.Toggle11.BackColor = global::System.Drawing.Color.Transparent;
		this.Toggle11.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("Toggle11.Image");
		this.Toggle11.Location = new global::System.Drawing.Point(17, 257);
		this.Toggle11.Name = "Toggle11";
		this.Toggle11.Size = new global::System.Drawing.Size(25, 15);
		this.Toggle11.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Toggle11.TabIndex = 187;
		this.Toggle11.TabStop = false;
		this.Toggle11.Click += new global::System.EventHandler(this.Toggle11_Click);
		this.SettingsItemlabel11.AutoSize = true;
		this.SettingsItemlabel11.BackColor = global::System.Drawing.Color.Transparent;
		this.SettingsItemlabel11.ForeColor = global::System.Drawing.Color.White;
		this.SettingsItemlabel11.Location = new global::System.Drawing.Point(48, 257);
		this.SettingsItemlabel11.Name = "SettingsItemlabel11";
		this.SettingsItemlabel11.Size = new global::System.Drawing.Size(0, 13);
		this.SettingsItemlabel11.TabIndex = 186;
		this.LangPanel.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.LangPanel.Controls.Add(this.Deutsch);
		this.LangPanel.Controls.Add(this.Ukrainian);
		this.LangPanel.Controls.Add(this.Russian);
		this.LangPanel.Controls.Add(this.English);
		this.LangPanel.Location = new global::System.Drawing.Point(524, 61);
		this.LangPanel.Name = "LangPanel";
		this.LangPanel.Size = new global::System.Drawing.Size(120, 85);
		this.LangPanel.TabIndex = 185;
		this.Deutsch.BackColor = global::System.Drawing.Color.Transparent;
		this.Deutsch.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.Deutsch.Image = global::Class89.Bitmap_26;
		this.Deutsch.Location = new global::System.Drawing.Point(20, 59);
		this.Deutsch.Name = "Deutsch";
		this.Deutsch.Size = new global::System.Drawing.Size(23, 13);
		this.Deutsch.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Deutsch.TabIndex = 186;
		this.Deutsch.TabStop = false;
		this.toolTip_0.SetToolTip(this.Deutsch, "Deutsch");
		this.Ukrainian.BackColor = global::System.Drawing.Color.Transparent;
		this.Ukrainian.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.Ukrainian.Image = global::Class89.Bitmap_29;
		this.Ukrainian.Location = new global::System.Drawing.Point(53, 13);
		this.Ukrainian.Name = "Ukrainian";
		this.Ukrainian.Size = new global::System.Drawing.Size(23, 13);
		this.Ukrainian.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Ukrainian.TabIndex = 185;
		this.Ukrainian.TabStop = false;
		this.toolTip_0.SetToolTip(this.Ukrainian, "Українська");
		this.Russian.BackColor = global::System.Drawing.Color.Transparent;
		this.Russian.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.Russian.Image = global::Class89.Bitmap_28;
		this.Russian.Location = new global::System.Drawing.Point(20, 13);
		this.Russian.Name = "Russian";
		this.Russian.Size = new global::System.Drawing.Size(23, 13);
		this.Russian.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Russian.TabIndex = 184;
		this.Russian.TabStop = false;
		this.toolTip_0.SetToolTip(this.Russian, "Русский");
		this.English.BackColor = global::System.Drawing.Color.Transparent;
		this.English.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.English.Image = global::Class89.Bitmap_27;
		this.English.Location = new global::System.Drawing.Point(20, 36);
		this.English.Name = "English";
		this.English.Size = new global::System.Drawing.Size(23, 13);
		this.English.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.English.TabIndex = 183;
		this.English.TabStop = false;
		this.toolTip_0.SetToolTip(this.English, "English");
		this.DaysLabel.BackColor = global::System.Drawing.Color.Transparent;
		this.DaysLabel.ForeColor = global::System.Drawing.Color.White;
		this.DaysLabel.Location = new global::System.Drawing.Point(409, 42);
		this.DaysLabel.Name = "DaysLabel";
		this.DaysLabel.Size = new global::System.Drawing.Size(71, 29);
		this.DaysLabel.TabIndex = 183;
		this.DaysLabel.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.Nud1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.Nud1.ForeColor = global::System.Drawing.Color.White;
		this.Nud1.Location = new global::System.Drawing.Point(362, 48);
		global::System.Windows.Forms.NumericUpDown nud = this.Nud1;
		int[] array = new int[4];
		array[0] = 31;
		nud.Maximum = new decimal(array);
		global::System.Windows.Forms.NumericUpDown nud2 = this.Nud1;
		int[] array2 = new int[4];
		array2[0] = 1;
		nud2.Minimum = new decimal(array2);
		this.Nud1.Name = "Nud1";
		this.Nud1.Size = new global::System.Drawing.Size(41, 17);
		this.Nud1.TabIndex = 184;
		this.Nud1.TabStop = false;
		this.Nud1.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
		global::System.Windows.Forms.NumericUpDown nud3 = this.Nud1;
		int[] array3 = new int[4];
		array3[0] = 1;
		nud3.Value = new decimal(array3);
		this.InvisPanel.Location = new global::System.Drawing.Point(0, 0);
		this.InvisPanel.Name = "InvisPanel";
		this.InvisPanel.Size = new global::System.Drawing.Size(610, 26);
		this.InvisPanel.TabIndex = 181;
		this.InvisPanel.Visible = false;
		this.InvisPanel.MouseEnter += new global::System.EventHandler(this.InvisPanel_MouseEnter);
		this.HeaderPanel.Controls.Add(this.CloseIcon);
		this.HeaderPanel.Controls.Add(this.Header);
		this.HeaderPanel.Location = new global::System.Drawing.Point(0, 0);
		this.HeaderPanel.Name = "HeaderPanel";
		this.HeaderPanel.Size = new global::System.Drawing.Size(610, 38);
		this.HeaderPanel.TabIndex = 182;
		this.CloseIcon.BackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.BackgroundImage = global::Class89.Bitmap_17;
		this.CloseIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.CloseIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
		this.CloseIcon.FlatAppearance.BorderSize = 0;
		this.CloseIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.CloseIcon.Location = new global::System.Drawing.Point(577, 6);
		this.CloseIcon.Name = "CloseIcon";
		this.CloseIcon.Size = new global::System.Drawing.Size(22, 22);
		this.CloseIcon.TabIndex = 31;
		this.CloseIcon.UseVisualStyleBackColor = false;
		this.toolTip_0.AutoPopDelay = 30000;
		this.toolTip_0.InitialDelay = 40;
		this.toolTip_0.ReshowDelay = 100;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
		this.AutoSize = true;
		this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
		base.ClientSize = new global::System.Drawing.Size(610, 370);
		base.Controls.Add(this.HeaderPanel);
		base.Controls.Add(this.IconsPanel);
		base.Controls.Add(this.TogglesPanel);
		this.DoubleBuffered = true;
		this.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		this.MaximumSize = new global::System.Drawing.Size(610, 370);
		base.Name = "Settings";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.Settings_1_Load);
		((global::System.ComponentModel.ISupportInitialize)this.Toggle10).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle9).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle8).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle7).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle6).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle5).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle4).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle3).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle2).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle1).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem1).EndInit();
		this.IconsPanel.ResumeLayout(false);
		this.IconsPanel.PerformLayout();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem10).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem9).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem8).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem7).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem6).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem5).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem4).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem3).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.MenuItem2).EndInit();
		this.TogglesPanel.ResumeLayout(false);
		this.TogglesPanel.PerformLayout();
		this.SkinPanel.ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.SeaSkin).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.DarkSkin).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.SkySkin).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Toggle11).EndInit();
		this.LangPanel.ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.Deutsch).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Ukrainian).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Russian).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.English).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Nud1).EndInit();
		this.HeaderPanel.ResumeLayout(false);
		this.HeaderPanel.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x04000308 RID: 776
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x04000309 RID: 777
	private global::System.Windows.Forms.Label Header;

	// Token: 0x0400030A RID: 778
	private global::System.Windows.Forms.Label SettingsItemlabel1;

	// Token: 0x0400030B RID: 779
	private global::System.Windows.Forms.Label SettingsItemlabel2;

	// Token: 0x0400030C RID: 780
	private global::System.Windows.Forms.Label SettingsItemlabel3;

	// Token: 0x0400030D RID: 781
	private global::System.Windows.Forms.Label SettingsItemlabel4;

	// Token: 0x0400030E RID: 782
	private global::System.Windows.Forms.Label SettingsItemlabel5;

	// Token: 0x0400030F RID: 783
	private global::System.Windows.Forms.Label SettingsItemlabel6;

	// Token: 0x04000310 RID: 784
	private global::System.Windows.Forms.Label SettingsItemlabel7;

	// Token: 0x04000311 RID: 785
	private global::System.Windows.Forms.Label SettingsItemlabel8;

	// Token: 0x04000312 RID: 786
	private global::System.Windows.Forms.Label SettingsItemlabel9;

	// Token: 0x04000313 RID: 787
	private global::System.Windows.Forms.Label SettingsItemlabel10;

	// Token: 0x04000314 RID: 788
	private global::System.Windows.Forms.Label SettingsItemlabel11;

	// Token: 0x04000315 RID: 789
	private global::System.Windows.Forms.PictureBox Toggle1;

	// Token: 0x04000316 RID: 790
	private global::System.Windows.Forms.PictureBox Toggle2;

	// Token: 0x04000317 RID: 791
	private global::System.Windows.Forms.PictureBox Toggle3;

	// Token: 0x04000318 RID: 792
	private global::System.Windows.Forms.PictureBox Toggle4;

	// Token: 0x04000319 RID: 793
	private global::System.Windows.Forms.PictureBox Toggle5;

	// Token: 0x0400031A RID: 794
	private global::System.Windows.Forms.PictureBox Toggle6;

	// Token: 0x0400031B RID: 795
	private global::System.Windows.Forms.PictureBox Toggle7;

	// Token: 0x0400031C RID: 796
	private global::System.Windows.Forms.PictureBox Toggle8;

	// Token: 0x0400031D RID: 797
	private global::System.Windows.Forms.PictureBox Toggle9;

	// Token: 0x0400031E RID: 798
	private global::System.Windows.Forms.PictureBox Toggle10;

	// Token: 0x0400031F RID: 799
	private global::System.Windows.Forms.PictureBox Toggle11;

	// Token: 0x04000320 RID: 800
	private global::System.Windows.Forms.PictureBox MenuItem1;

	// Token: 0x04000321 RID: 801
	private global::System.Windows.Forms.Label MenuLabel1;

	// Token: 0x04000322 RID: 802
	private global::System.Windows.Forms.Panel IconsPanel;

	// Token: 0x04000323 RID: 803
	private global::System.Windows.Forms.Panel TogglesPanel;

	// Token: 0x04000324 RID: 804
	private global::System.Windows.Forms.Panel InvisPanel;

	// Token: 0x04000325 RID: 805
	private global::System.Windows.Forms.Panel HeaderPanel;

	// Token: 0x04000326 RID: 806
	private global::System.Windows.Forms.Label DaysLabel;

	// Token: 0x04000327 RID: 807
	private global::System.Windows.Forms.NumericUpDown Nud1;

	// Token: 0x04000328 RID: 808
	private global::System.Windows.Forms.Panel LangPanel;

	// Token: 0x04000329 RID: 809
	private global::System.Windows.Forms.PictureBox English;

	// Token: 0x0400032A RID: 810
	private global::System.Windows.Forms.PictureBox Ukrainian;

	// Token: 0x0400032B RID: 811
	private global::System.Windows.Forms.PictureBox Russian;

	// Token: 0x0400032C RID: 812
	private global::System.Windows.Forms.ToolTip toolTip_0;

	// Token: 0x0400032D RID: 813
	private global::System.Windows.Forms.Button CloseIcon;

	// Token: 0x0400032E RID: 814
	private global::System.Windows.Forms.Panel SkinPanel;

	// Token: 0x0400032F RID: 815
	private global::System.Windows.Forms.PictureBox SeaSkin;

	// Token: 0x04000330 RID: 816
	private global::System.Windows.Forms.PictureBox DarkSkin;

	// Token: 0x04000331 RID: 817
	private global::System.Windows.Forms.PictureBox SkySkin;

	// Token: 0x04000332 RID: 818
	private global::System.Windows.Forms.PictureBox Deutsch;

	// Token: 0x04000333 RID: 819
	private global::System.Windows.Forms.PictureBox MenuItem10;

	// Token: 0x04000334 RID: 820
	private global::System.Windows.Forms.PictureBox MenuItem9;

	// Token: 0x04000335 RID: 821
	private global::System.Windows.Forms.PictureBox MenuItem8;

	// Token: 0x04000336 RID: 822
	private global::System.Windows.Forms.PictureBox MenuItem7;

	// Token: 0x04000337 RID: 823
	private global::System.Windows.Forms.PictureBox MenuItem6;

	// Token: 0x04000338 RID: 824
	private global::System.Windows.Forms.PictureBox MenuItem5;

	// Token: 0x04000339 RID: 825
	private global::System.Windows.Forms.PictureBox MenuItem4;

	// Token: 0x0400033A RID: 826
	private global::System.Windows.Forms.PictureBox MenuItem3;

	// Token: 0x0400033B RID: 827
	private global::System.Windows.Forms.PictureBox MenuItem2;

	// Token: 0x0400033C RID: 828
	private global::System.Windows.Forms.Label MenuLabel2;

	// Token: 0x0400033D RID: 829
	private global::System.Windows.Forms.Label MenuLabel4;

	// Token: 0x0400033E RID: 830
	private global::System.Windows.Forms.Label MenuLabel3;

	// Token: 0x0400033F RID: 831
	private global::System.Windows.Forms.Label MenuLabel10;

	// Token: 0x04000340 RID: 832
	private global::System.Windows.Forms.Label MenuLabel9;

	// Token: 0x04000341 RID: 833
	private global::System.Windows.Forms.Label MenuLabel8;

	// Token: 0x04000342 RID: 834
	private global::System.Windows.Forms.Label MenuLabel7;

	// Token: 0x04000343 RID: 835
	private global::System.Windows.Forms.Label MenuLabel6;

	// Token: 0x04000344 RID: 836
	private global::System.Windows.Forms.Label MenuLabel5;
}
