﻿// Token: 0x020000C2 RID: 194
public partial class GForm0 : global::System.Windows.Forms.Form
{
}
