﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Win32;

// Token: 0x020000D8 RID: 216
public static class GClass16
{
	// Token: 0x06000A80 RID: 2688 RVA: 0x00038310 File Offset: 0x00036510
	public static bool smethod_0(this RegistryKey registryKey_0, string string_0, string string_1, bool bool_0 = false)
	{
		if (registryKey_0 == null)
		{
			return bool_0;
		}
		object value = registryKey_0.GetValue(string_0);
		if (value == null)
		{
			return false;
		}
		if (registryKey_0.GetValueKind(string_0) != RegistryValueKind.Binary)
		{
			return value.ToString() == string_1;
		}
		byte[] array = value as byte[];
		if (array != null)
		{
			return string.Join("", array.Select(new Func<byte, string>(GClass16.<>c.<>9.method_0))) == string_1;
		}
		return false;
	}

	// Token: 0x06000A81 RID: 2689 RVA: 0x00005958 File Offset: 0x00003B58
	public static bool smethod_1(this RegistryKey registryKey_0, string string_0, bool bool_0 = false)
	{
		if (registryKey_0 != null)
		{
			return registryKey_0.GetValue(string_0) != null;
		}
		return bool_0;
	}

	// Token: 0x06000A82 RID: 2690 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_2(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x06000A83 RID: 2691 RVA: 0x00003E80 File Offset: 0x00002080
	static RegistryValueKind smethod_3(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValueKind(string_0);
	}

	// Token: 0x06000A84 RID: 2692 RVA: 0x00003E13 File Offset: 0x00002013
	static string smethod_4(string string_0, IEnumerable<string> ienumerable_0)
	{
		return string.Join(string_0, ienumerable_0);
	}

	// Token: 0x06000A85 RID: 2693 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_5(string string_0, string string_1)
	{
		return string_0 == string_1;
	}

	// Token: 0x06000A86 RID: 2694 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_6(object object_0)
	{
		return object_0.ToString();
	}
}
