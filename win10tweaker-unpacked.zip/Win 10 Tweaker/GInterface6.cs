﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A3 RID: 419
[TypeIdentifier]
[Guid("EFD84B2D-4BCF-4298-BE25-EB542A59FBDA")]
[CompilerGenerated]
[ComImport]
public interface GInterface6 : GInterface5
{
}
