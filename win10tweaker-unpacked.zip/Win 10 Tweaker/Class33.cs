﻿using System;
using System.Linq;
using System.Threading;

// Token: 0x02000073 RID: 115
internal class Class33
{
	// Token: 0x17000029 RID: 41
	// (get) Token: 0x0600058D RID: 1421 RVA: 0x0001B8A4 File Offset: 0x00019AA4
	public static Class33 Class33_0
	{
		get
		{
			if (Class33.class33_0 == null)
			{
				object obj = Class33.object_0;
				lock (obj)
				{
					if (Class33.class33_0 == null)
					{
						Class33.class33_0 = new Class33();
					}
				}
			}
			return Class33.class33_0;
		}
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x0001B904 File Offset: 0x00019B04
	public void method_0()
	{
		Class33.string_2.AsParallel<string>().ForAll(new Action<string>(Class33.<>c.<>9.method_0));
		string str = "\\command";
		new string[]
		{
			Class33.string_0 + ".jpg" + Class33.string_1 + str,
			Class33.string_0 + ".jpeg" + Class33.string_1 + str,
			Class33.string_0 + ".png" + Class33.string_1 + str,
			Class33.string_0 + ".gif" + Class33.string_1 + str,
			Class33.string_0 + ".bmp" + Class33.string_1 + str,
			Class33.string_0 + ".ico" + Class33.string_1 + str,
			Class33.string_0 + ".tiff" + Class33.string_1 + str
		}.AsParallel<string>().ForAll(new Action<string>(Class33.<>c.<>9.method_1));
	}

	// Token: 0x0600058F RID: 1423 RVA: 0x00004195 File Offset: 0x00002395
	public void method_1()
	{
		Class33.string_2.AsParallel<string>().ForAll(new Action<string>(Class33.<>c.<>9.method_2));
	}

	// Token: 0x06000590 RID: 1424 RVA: 0x000041C5 File Offset: 0x000023C5
	public void method_2()
	{
		Class33.string_2.ToList<string>().ForEach(new Action<string>(Class33.<>c.<>9.method_3));
	}

	// Token: 0x06000593 RID: 1427 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000594 RID: 1428 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000595 RID: 1429 RVA: 0x000033BD File Offset: 0x000015BD
	static string smethod_2(string string_3, string string_4, string string_5, string string_6)
	{
		return string_3 + string_4 + string_5 + string_6;
	}

	// Token: 0x06000596 RID: 1430 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_3()
	{
		return new object();
	}

	// Token: 0x06000597 RID: 1431 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_4(string string_3, string string_4, string string_5)
	{
		return string_3 + string_4 + string_5;
	}

	// Token: 0x0400025B RID: 603
	private static volatile Class33 class33_0;

	// Token: 0x0400025C RID: 604
	private static readonly object object_0 = new object();

	// Token: 0x0400025D RID: 605
	private static readonly string string_0 = "Software\\Classes\\SystemFileAssociations\\";

	// Token: 0x0400025E RID: 606
	private static readonly string string_1 = "\\shell\\CopyImageToClipboard";

	// Token: 0x0400025F RID: 607
	private static readonly string[] string_2 = new string[]
	{
		Class33.string_0 + ".jpg" + Class33.string_1,
		Class33.string_0 + ".jpeg" + Class33.string_1,
		Class33.string_0 + ".png" + Class33.string_1,
		Class33.string_0 + ".gif" + Class33.string_1,
		Class33.string_0 + ".bmp" + Class33.string_1,
		Class33.string_0 + ".ico" + Class33.string_1,
		Class33.string_0 + ".tiff" + Class33.string_1
	};
}
