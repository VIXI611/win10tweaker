﻿using System;
using System.Collections.Generic;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000089 RID: 137
internal class Class49
{
	// Token: 0x17000037 RID: 55
	// (get) Token: 0x060006DE RID: 1758 RVA: 0x0001EF00 File Offset: 0x0001D100
	public static Class49 Class49_0
	{
		get
		{
			if (Class49.class49_0 == null)
			{
				object obj = Class49.object_0;
				lock (obj)
				{
					if (Class49.class49_0 == null)
					{
						Class49.class49_0 = new Class49();
					}
				}
			}
			return Class49.class49_0;
		}
	}

	// Token: 0x060006DF RID: 1759 RVA: 0x0001EF60 File Offset: 0x0001D160
	public void method_0()
	{
		this.list_0.ForEach(new Action<string>(Class49.<>c.<>9.method_0));
		Registry.CurrentUser.CreateSubKey("Control Panel\\Colors").SetValue("InfoWindow", "246 253 255");
	}

	// Token: 0x060006E0 RID: 1760 RVA: 0x0001EFB8 File Offset: 0x0001D1B8
	public void method_1()
	{
		this.list_0.ForEach(new Action<string>(Class49.<>c.<>9.method_1));
		Registry.CurrentUser.CreateSubKey("Control Panel\\Colors").SetValue("InfoWindow", "255 255 225");
	}

	// Token: 0x060006E3 RID: 1763 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_3(RegistryKey registryKey_0, string string_0, object object_1)
	{
		registryKey_0.SetValue(string_0, object_1);
	}

	// Token: 0x060006E7 RID: 1767 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_4()
	{
		return new object();
	}

	// Token: 0x040002A5 RID: 677
	private static volatile Class49 class49_0;

	// Token: 0x040002A6 RID: 678
	private static readonly object object_0 = new object();

	// Token: 0x040002A7 RID: 679
	private readonly List<string> list_0 = new List<string>
	{
		".DEFAULT\\Control Panel\\Colors",
		"S-1-5-19\\Control Panel\\Colors",
		"S-1-5-20\\Control Panel\\Colors"
	};
}
