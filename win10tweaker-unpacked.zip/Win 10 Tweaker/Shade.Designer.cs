﻿// Token: 0x020000DB RID: 219
public partial class Shade : global::System.Windows.Forms.Form
{
	// Token: 0x06000B1F RID: 2847 RVA: 0x00038B28 File Offset: 0x00036D28
	private void InitializeComponent()
	{
		base.SuspendLayout();
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(80, 80);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Shade";
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		base.Load += new global::System.EventHandler(this.Shade_Load);
		base.ResumeLayout(false);
	}
}
