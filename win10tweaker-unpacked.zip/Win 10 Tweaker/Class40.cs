﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.Win32;

// Token: 0x0200007C RID: 124
internal class Class40
{
	// Token: 0x1700002F RID: 47
	// (get) Token: 0x060005FF RID: 1535 RVA: 0x0001C750 File Offset: 0x0001A950
	public static Class40 Class40_0
	{
		get
		{
			if (Class40.class40_0 == null)
			{
				object obj = Class40.object_0;
				lock (obj)
				{
					if (Class40.class40_0 == null)
					{
						Class40.class40_0 = new Class40();
					}
				}
			}
			return Class40.class40_0;
		}
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x0001C7B0 File Offset: 0x0001A9B0
	public void method_0()
	{
		using (RegistryKey registryKey = Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0))
		{
			registryKey.CreateSubKey("AdvertisingInfo").SetValue("Enabled", 0);
			registryKey.CreateSubKey("Search").SetValue("BingSearchEnabled", 0);
		}
		Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\Bluetooth").SetValue("AllowAdvertising", 0);
		using (RegistryKey registryKey2 = Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\ContentDeliveryManager"))
		{
			registryKey2.SetValue("SystemPaneSuggestionsEnabled", 0);
			registryKey2.SetValue("SilentInstalledAppsEnabled", 0);
			registryKey2.SetValue("SoftLandingEnabled", 0);
		}
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\AdvertisingInfo!DisabledByGroupPolicy", "1", RegistryValueKind.DWord);
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x0001C8C0 File Offset: 0x0001AAC0
	public void method_1()
	{
		Class40.string_2.AsParallel<string>().ForAll(new Action<string>(Class40.<>c.<>9.method_0));
		try
		{
			Class40.string_3.smethod_0();
			File.Move(Class40.string_3, Class40.string_3 + "_fucked");
		}
		catch
		{
		}
		try
		{
			Class40.string_4.smethod_0();
			File.Move(Class40.string_4, Class40.string_4 + "_fucked");
		}
		catch
		{
		}
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x0001C968 File Offset: 0x0001AB68
	public void method_2()
	{
		Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\AutoLogger-Diagtrack-Listener").SetValue("Start", 0);
		Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\Attachments").SetValue("SaveZoneInformation", 1);
		RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\DiagTrack", true);
		if (registryKey != null)
		{
			registryKey.SetValue("Start", 4);
		}
		RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\dmwappushservice", true);
		if (registryKey2 != null)
		{
			registryKey2.SetValue("Start", 4);
		}
		GClass6.GClass6_0.method_14("schtasks /change /tn \"\\Microsoft\\Office\\Office ClickToRun Service Monitor\" /disable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetry\\AgentFallBack2016\" /disable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetry\\AgentFallBack2016\" /disable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetry\\OfficeTelemetryAgentLogOn2016\" /disable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack2016\" /disable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn2016\" /disable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack\" /disable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn\" /disable &schtasks /change /tn \"\\Microsoft\\Office\\Office 15 Subscription Heartbeat\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Device Information\\Device\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Device Information\\Device User\" /disable");
		try
		{
			Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.string_12 + "\\CompatTelRunner.exe").SetValue("Debugger", GClass13.string_7 + "\\systray.exe");
		}
		catch
		{
		}
		Process.GetProcessesByName("CompatTelRunner").ToList<Process>().ForEach(new Action<Process>(Class40.<>c.<>9.method_1));
		RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\WOW6432Node\\Microsoft\\VSCommon\\16.0\\SQM", true);
		if (registryKey3 != null)
		{
			registryKey3.SetValue("OptIn", 0);
		}
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\DataCollection!**del.AllowTelemetry", "", RegistryValueKind.String);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\SQMClient!**del.CorporateSQMURL", "", RegistryValueKind.String);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\AppV\\CEIP!CEIPEnable", "0", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows NT\\CurrentVersion\\Software Protection Platform!NoGenTicket", "1", RegistryValueKind.DWord);
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x0001CB20 File Offset: 0x0001AD20
	public void method_3()
	{
		if (Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\NvTelemetryContainer") != null)
		{
			GClass6.GClass6_0.method_14("schtasks /change /tn NvTmRepOnLogon_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8} /disable &schtasks /change /tn NvTmRep_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8} /disable &schtasks /change /tn NvTmMon_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8} /disable &net stop NvTelemetryContainer & sc config NvTelemetryContainer start= disabled & sc stop NvTelemetryContainer");
			Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_2 + "\\NvTelemetryContainer").SetValue("Start", 4);
		}
	}

	// Token: 0x06000604 RID: 1540 RVA: 0x00004433 File Offset: 0x00002633
	public void method_4()
	{
		GClass6.GClass6_0.method_14("schtasks /change /tn \\Microsoft\\Windows\\Maintenance\\WinSAT /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Autochk\\Proxy\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\PcaPatchDbTask\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\PI\\Sqm-Tasks\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\NetTrace\\GatherNetworkInfo\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Feedback\\Siuf\\DmClient\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Feedback\\Siuf\\DmClientOnScenarioDownload\" /disable");
	}

	// Token: 0x06000605 RID: 1541 RVA: 0x00004444 File Offset: 0x00002644
	public void method_5()
	{
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\AppCompat!DisableInventory", "1", RegistryValueKind.DWord);
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x0001CB8C File Offset: 0x0001AD8C
	public void method_6()
	{
		Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\DataCollection").SetValue("AllowTelemetry", 0);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\AppCompat!AITEnable", "0", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\DataCollection!AllowDeviceNameInTelemetry", "0", RegistryValueKind.DWord);
		Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced").SetValue("Start_TrackProgs", 0);
	}

	// Token: 0x06000607 RID: 1543 RVA: 0x0001CC18 File Offset: 0x0001AE18
	public void method_7()
	{
		Registry.LocalMachine.CreateSubKey(this.string_0 + "\\TabletPC").SetValue("PreventHandwritingDataSharing", 1);
		Registry.LocalMachine.CreateSubKey(this.string_0 + "\\HandwritingErrorReports").SetValue("PreventHandwritingErrorReports", 1);
		Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Input\\TIPC").SetValue("Enabled", 0);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\InputPersonalization!RestrictImplicitInkCollection", "1", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\InputPersonalization!RestrictImplicitTextCollection", "1", RegistryValueKind.DWord);
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x00004456 File Offset: 0x00002656
	public void method_8()
	{
		GClass6.GClass6_0.method_7();
	}

	// Token: 0x06000609 RID: 1545 RVA: 0x0001CCB8 File Offset: 0x0001AEB8
	public void method_9()
	{
		using (RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(this.string_0 ?? ""))
		{
			registryKey.CreateSubKey("AppCompat").SetValue("DisableUAR", 1);
			registryKey.CreateSubKey("Personalization").SetValue("NoLockScreenCamera", 1);
			registryKey.CreateSubKey("System").SetValue("PublishUserActivities", 0);
			registryKey.CreateSubKey("System").SetValue("EnableActivityFeed", 0);
			registryKey.CreateSubKey("System").SetValue("UploadUserActivities", 0);
		}
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\SQMClient\\Windows!CEIPEnable", "0", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Internet Explorer\\SQM!DisableCustomerImprovementProgram", "0", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Messenger\\Client!CEIP", "2", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\AppCompat!DisableUAR", "1", RegistryValueKind.DWord);
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x0001CDC4 File Offset: 0x0001AFC4
	public void method_10()
	{
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\LocationAndSensors!DisableWindowsLocationProvider", "1", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\LocationAndSensors!DisableLocation", "1", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\Maps!AutoDownloadAndUpdateMapData", "0", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\FindMyDevice!AllowFindMyDevice", "0", RegistryValueKind.DWord);
		using (RegistryKey registryKey = Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_1 + "\\Sensor\\Permissions\\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}"))
		{
			registryKey.SetValue("SensorPermissionState", 0);
		}
	}

	// Token: 0x0600060B RID: 1547 RVA: 0x0001CE60 File Offset: 0x0001B060
	public void method_11()
	{
		using (RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Siuf\\Rules"))
		{
			registryKey.SetValue("NumberOfSIUFInPeriod", 0);
			registryKey.SetValue("PeriodInNanoSeconds", 0);
		}
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\DataCollection!DoNotShowFeedbackNotifications", "1", RegistryValueKind.DWord);
	}

	// Token: 0x0600060C RID: 1548 RVA: 0x00004462 File Offset: 0x00002662
	public void method_12()
	{
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Speech!AllowSpeechModelUpdate", "0", RegistryValueKind.DWord);
	}

	// Token: 0x0600060D RID: 1549 RVA: 0x0001CECC File Offset: 0x0001B0CC
	public void method_13()
	{
		RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\CDPUserSvc", true);
		if (registryKey != null)
		{
			registryKey.SetValue("Start", 4);
		}
		RegistryKey registryKey2 = Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced");
		if (registryKey2 != null)
		{
			registryKey2.SetValue("ShowTaskViewButton", 0);
			return;
		}
	}

	// Token: 0x0600060E RID: 1550 RVA: 0x00004474 File Offset: 0x00002674
	public void method_14()
	{
		Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System").SetValue("AllowExperimentation", 0);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\ScriptedDiagnosticsProvider\\Policy!DisableQueryRemoteServer", "0", RegistryValueKind.DWord);
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x0001CF44 File Offset: 0x0001B144
	public void method_15()
	{
		GClass6.GClass6_0.method_14("sc stop DiagTrack & sc delete DiagTrack & sc stop diagsvc & sc delete diagsvc & sc stop dmwappushservice & sc delete dmwappushservice");
		try
		{
			Registry.LocalMachine.DeleteSubKeyTree(GClass2.GClass2_0.String_2 + "\\DiagTrack");
		}
		catch
		{
		}
		try
		{
			Registry.LocalMachine.DeleteSubKeyTree(GClass2.GClass2_0.String_2 + "\\dmwappushservice");
		}
		catch
		{
		}
		this.method_2();
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x0001CFCC File Offset: 0x0001B1CC
	public void method_16()
	{
		RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\diagnosticshub.standardcollector.service", true);
		if (registryKey != null)
		{
			registryKey.SetValue("Start", 4);
		}
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting!Disabled", "1", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting!DontSendAdditionalData", "1", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\PCHealth\\ErrorReporting\\DW!DWNoFileCollection", "1", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\PCHealth\\ErrorReporting\\DW!DWNoSecondLevelCollection", "1", RegistryValueKind.DWord);
	}

	// Token: 0x06000611 RID: 1553 RVA: 0x0001D050 File Offset: 0x0001B250
	public void method_17()
	{
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\AdvertisingInfo", true))
		{
			if (registryKey != null && registryKey.GetValue("Enabled") != null)
			{
				registryKey.DeleteValue("Enabled");
			}
		}
		using (RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Search", true))
		{
			if (registryKey2 != null && registryKey2.GetValue("BingSearchEnabled") != null)
			{
				registryKey2.DeleteValue("BingSearchEnabled");
			}
		}
		using (RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\Bluetooth", true))
		{
			if (registryKey3 != null && registryKey3.GetValue("AllowAdvertising") != null)
			{
				registryKey3.DeleteValue("AllowAdvertising");
			}
		}
		using (RegistryKey registryKey4 = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\ContentDeliveryManager", true))
		{
			if (registryKey4 != null && registryKey4.GetValue("SystemPaneSuggestionsEnabled") != null)
			{
				registryKey4.DeleteValue("SystemPaneSuggestionsEnabled");
			}
			if (registryKey4 != null && registryKey4.GetValue("SilentInstalledAppsEnabled") != null)
			{
				registryKey4.DeleteValue("SilentInstalledAppsEnabled");
			}
			if (registryKey4 != null && registryKey4.GetValue("SoftLandingEnabled") != null)
			{
				registryKey4.DeleteValue("SoftLandingEnabled");
			}
		}
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\AdvertisingInfo!DisabledByGroupPolicy", null, RegistryValueKind.DWord);
	}

	// Token: 0x06000612 RID: 1554 RVA: 0x0001D1E0 File Offset: 0x0001B3E0
	public void method_18()
	{
		Class40.string_2.AsParallel<string>().ForAll(new Action<string>(Class40.<>c.<>9.method_2));
		try
		{
			File.Move(Class40.string_3 + "_fucked", Class40.string_3);
		}
		catch
		{
		}
		try
		{
			File.Move(Class40.string_4 + "_fucked", Class40.string_4);
		}
		catch
		{
		}
	}

	// Token: 0x06000613 RID: 1555 RVA: 0x0001D274 File Offset: 0x0001B474
	public void method_19()
	{
		Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\AutoLogger-Diagtrack-Listener").SetValue("Start", 1);
		using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\Attachments", true))
		{
			if (registryKey != null && registryKey.GetValue("SaveZoneInformation") != null)
			{
				registryKey.DeleteValue("SaveZoneInformation");
			}
		}
		GClass6.GClass6_0.method_14("schtasks /change /tn \"\\Microsoft\\Office\\Office ClickToRun Service Monitor\" /enable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetry\\AgentFallBack2016\" /enable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetry\\AgentFallBack2016\" /enable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetry\\OfficeTelemetryAgentLogOn2016\" /enable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack2016\" /enable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn2016\" /enable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack\" /enable &schtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn\" /enable &schtasks /change /tn \"\\Microsoft\\Office\\Office 15 Subscription Heartbeat\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Device Information\\Device\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Device Information\\Device User\" /enable");
		RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\DiagTrack", true);
		if (registryKey2 != null)
		{
			registryKey2.SetValue("Start", 2);
		}
		RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\dmwappushservice", true);
		if (registryKey3 != null)
		{
			registryKey3.SetValue("Start", 2);
		}
		Registry.LocalMachine.DeleteSubKeyTree(GClass2.GClass2_0.string_12 + "\\CompatTelRunner.exe", false);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\DataCollection!**del.AllowTelemetry", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\SQMClient!**del.CorporateSQMURL", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\AppV\\CEIP!CEIPEnable", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows NT\\CurrentVersion\\Software Protection Platform!NoGenTicket", null, RegistryValueKind.DWord);
	}

	// Token: 0x06000614 RID: 1556 RVA: 0x0001D3C0 File Offset: 0x0001B5C0
	public void method_20()
	{
		using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\NvTelemetryContainer", true))
		{
			if (registryKey != null)
			{
				registryKey.SetValue("Start", 2);
				GClass6.GClass6_0.method_14("schtasks /change /tn NvTmRepOnLogon_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8} /enable &schtasks /change /tn NvTmRep_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8} /enable &schtasks /change /tn NvTmMon_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8} /enable &net start NvTelemetryContainer & sc start NvTelemetryContainer");
			}
		}
	}

	// Token: 0x06000615 RID: 1557 RVA: 0x000044A5 File Offset: 0x000026A5
	public void method_21()
	{
		GClass6.GClass6_0.method_14("schtasks /change /tn \\Microsoft\\Windows\\Maintenance\\WinSAT /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Autochk\\Proxy\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\PcaPatchDbTask\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\PI\\Sqm-Tasks\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\NetTrace\\GatherNetworkInfo\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Feedback\\Siuf\\DmClient\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Feedback\\Siuf\\DmClientOnScenarioDownload\" /enable");
	}

	// Token: 0x06000616 RID: 1558 RVA: 0x0001D42C File Offset: 0x0001B62C
	public void method_22()
	{
		using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", true))
		{
			if (registryKey != null && registryKey.GetValue("DisableInventory") != null)
			{
				registryKey.DeleteValue("DisableInventory");
			}
		}
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\AppCompat!DisableInventory", null, RegistryValueKind.DWord);
	}

	// Token: 0x06000617 RID: 1559 RVA: 0x0001D490 File Offset: 0x0001B690
	public void method_23()
	{
		Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\DataCollection").SetValue("AllowTelemetry", 1);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\AppCompat!AITEnable", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\DataCollection!AllowDeviceNameInTelemetry", null, RegistryValueKind.DWord);
		Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced").SetValue("Start_TrackProgs", 1);
	}

	// Token: 0x06000618 RID: 1560 RVA: 0x0001D514 File Offset: 0x0001B714
	public void method_24()
	{
		using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\TabletPC", true))
		{
			if (registryKey != null && registryKey.GetValue("PreventHandwritingDataSharing") != null)
			{
				registryKey.DeleteValue("PreventHandwritingDataSharing");
			}
		}
		Registry.LocalMachine.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\HandwritingErrorReports").SetValue("PreventHandwritingErrorReports", 0);
		Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Input\\TIPC").SetValue("Enabled", 1);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\InputPersonalization!RestrictImplicitInkCollection", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\InputPersonalization!RestrictImplicitTextCollection", null, RegistryValueKind.DWord);
	}

	// Token: 0x06000619 RID: 1561 RVA: 0x0001D5C0 File Offset: 0x0001B7C0
	public void method_25()
	{
		if (File.Exists(GClass13.string_7 + "\\drivers\\etc\\hosts (Original)"))
		{
			try
			{
				File.Delete(GClass13.string_7 + "\\drivers\\etc\\hosts");
				File.Move(GClass13.string_7 + "\\drivers\\etc\\hosts (Original)", GClass13.string_7 + "\\drivers\\etc\\hosts");
			}
			catch
			{
			}
		}
		GClass6.GClass6_0.method_14("netsh advfirewall firewall delete rule name=\"" + GClass2.GClass2_0.String_17 + "\"");
	}

	// Token: 0x0600061A RID: 1562 RVA: 0x0001D654 File Offset: 0x0001B854
	public void method_26()
	{
		using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", true))
		{
			if (registryKey.GetValue("DisableUAR") != null)
			{
				registryKey.DeleteValue("DisableUAR");
			}
		}
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\SQMClient\\Windows!CEIPEnable", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Internet Explorer\\SQM!DisableCustomerImprovementProgram", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Messenger\\Client!CEIP", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\AppCompat!DisableUAR", null, RegistryValueKind.DWord);
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x000044B6 File Offset: 0x000026B6
	public void method_27()
	{
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\LocationAndSensors!DisableWindowsLocationProvider", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\LocationAndSensors!DisableLocation", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\Maps!AutoDownloadAndUpdateMapData", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\FindMyDevice!AllowFindMyDevice", null, RegistryValueKind.DWord);
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x0001D6D8 File Offset: 0x0001B8D8
	public void method_28()
	{
		Class40.Class41 @class = new Class40.Class41();
		@class.registryKey_0 = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Siuf\\Rules", true);
		try
		{
			new List<string>
			{
				"NumberOfSIUFInPeriod",
				"PeriodInNanoSeconds"
			}.Where(new Func<string, bool>(@class.method_0)).ToList<string>().ForEach(new Action<string>(@class.method_1));
		}
		finally
		{
			if (@class.registryKey_0 != null)
			{
				((IDisposable)@class.registryKey_0).Dispose();
			}
		}
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\DataCollection!DoNotShowFeedbackNotifications", null, RegistryValueKind.DWord);
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x000044E8 File Offset: 0x000026E8
	public void method_29()
	{
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Speech!AllowSpeechModelUpdate", null, RegistryValueKind.DWord);
	}

	// Token: 0x0600061E RID: 1566 RVA: 0x0001D778 File Offset: 0x0001B978
	public void method_30()
	{
		RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\CDPUserSvc", true);
		if (registryKey != null)
		{
			registryKey.SetValue("Start", 2);
		}
		Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced").SetValue("ShowTaskViewButton", 1);
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x0001D7E8 File Offset: 0x0001B9E8
	public void method_31()
	{
		using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System", true))
		{
			if (registryKey != null && registryKey.GetValue("AllowExperimentation") != null)
			{
				registryKey.DeleteValue("AllowExperimentation");
			}
		}
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\ScriptedDiagnosticsProvider\\Policy!DisableQueryRemoteServer", null, RegistryValueKind.DWord);
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x000044F6 File Offset: 0x000026F6
	public void method_32()
	{
		Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_2 + "\\DiagTrack");
		Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_2 + "\\dmwappushservice");
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x0001D84C File Offset: 0x0001BA4C
	public void method_33()
	{
		RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\diagnosticshub.standardcollector.service", true);
		if (registryKey != null)
		{
			registryKey.SetValue("Start", 3);
		}
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting!Disabled", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting!DontSendAdditionalData", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\PCHealth\\ErrorReporting\\DW!DWNoFileCollection", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\PCHealth\\ErrorReporting\\DW!DWNoSecondLevelCollection", null, RegistryValueKind.DWord);
	}

	// Token: 0x06000624 RID: 1572 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000625 RID: 1573 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000626 RID: 1574 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_5)
	{
		return registryKey_0.CreateSubKey(string_5);
	}

	// Token: 0x06000627 RID: 1575 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_3(RegistryKey registryKey_0, string string_5, object object_1)
	{
		registryKey_0.SetValue(string_5, object_1);
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_4(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000629 RID: 1577 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_5(string string_5, string string_6)
	{
		return string_5 + string_6;
	}

	// Token: 0x0600062A RID: 1578 RVA: 0x00003E1C File Offset: 0x0000201C
	static void smethod_6(string string_5, string string_6)
	{
		File.Move(string_5, string_6);
	}

	// Token: 0x0600062B RID: 1579 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_7(RegistryKey registryKey_0, string string_5, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_5, bool_0);
	}

	// Token: 0x0600062C RID: 1580 RVA: 0x000043D9 File Offset: 0x000025D9
	static void smethod_8(RegistryKey registryKey_0, string string_5, object object_1)
	{
		registryKey_0.SetValue(string_5, object_1);
	}

	// Token: 0x0600062D RID: 1581 RVA: 0x000033EC File Offset: 0x000015EC
	static Process[] smethod_9(string string_5)
	{
		return Process.GetProcessesByName(string_5);
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_10(RegistryKey registryKey_0, string string_5)
	{
		return registryKey_0.OpenSubKey(string_5);
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x00003021 File Offset: 0x00001221
	static void smethod_11(RegistryKey registryKey_0, string string_5)
	{
		registryKey_0.DeleteSubKeyTree(string_5);
	}

	// Token: 0x06000630 RID: 1584 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_12(RegistryKey registryKey_0, string string_5)
	{
		return registryKey_0.GetValue(string_5);
	}

	// Token: 0x06000631 RID: 1585 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_13(RegistryKey registryKey_0, string string_5)
	{
		registryKey_0.DeleteValue(string_5);
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_14(RegistryKey registryKey_0, string string_5, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_5, bool_0);
	}

	// Token: 0x06000633 RID: 1587 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_15(string string_5)
	{
		return File.Exists(string_5);
	}

	// Token: 0x06000634 RID: 1588 RVA: 0x00002F15 File Offset: 0x00001115
	static void smethod_16(string string_5)
	{
		File.Delete(string_5);
	}

	// Token: 0x06000635 RID: 1589 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_17(string string_5, string string_6, string string_7)
	{
		return string_5 + string_6 + string_7;
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_18(RegistryKey registryKey_0, string string_5)
	{
		return registryKey_0.GetValue(string_5);
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_19()
	{
		return new object();
	}

	// Token: 0x0400027E RID: 638
	private static volatile Class40 class40_0;

	// Token: 0x0400027F RID: 639
	private static readonly object object_0 = new object();

	// Token: 0x04000280 RID: 640
	public string string_0 = "SOFTWARE\\Policies\\Microsoft\\Windows";

	// Token: 0x04000281 RID: 641
	private static readonly string string_1 = GClass2.GClass2_0.String_0 + "\\SettingSync\\Groups";

	// Token: 0x04000282 RID: 642
	private static readonly string[] string_2 = new string[]
	{
		"Accessibility",
		"BrowserSettings",
		"Credentials",
		"Language",
		"Personalization",
		"Windows"
	};

	// Token: 0x04000283 RID: 643
	private static readonly string string_3 = GClass13.string_7 + "\\mobsync.exe";

	// Token: 0x04000284 RID: 644
	private static readonly string string_4 = GClass13.string_8 + "\\mobsync.exe";

	// Token: 0x0200007E RID: 126
	[CompilerGenerated]
	private sealed class Class41
	{
		// Token: 0x06000644 RID: 1604 RVA: 0x0000458B File Offset: 0x0000278B
		internal bool method_0(string string_0)
		{
			RegistryKey registryKey = this.registryKey_0;
			return ((registryKey != null) ? registryKey.GetValue(string_0) : null) != null;
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x000045A3 File Offset: 0x000027A3
		internal void method_1(string string_0)
		{
			this.registryKey_0.DeleteValue(string_0);
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x00002EDC File Offset: 0x000010DC
		static object smethod_0(RegistryKey registryKey_1, string string_0)
		{
			return registryKey_1.GetValue(string_0);
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x00003010 File Offset: 0x00001210
		static void smethod_1(RegistryKey registryKey_1, string string_0)
		{
			registryKey_1.DeleteValue(string_0);
		}

		// Token: 0x04000289 RID: 649
		public RegistryKey registryKey_0;
	}
}
