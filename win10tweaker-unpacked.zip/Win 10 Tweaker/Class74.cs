﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;

// Token: 0x020000E2 RID: 226
internal class Class74
{
	// Token: 0x17000095 RID: 149
	// (get) Token: 0x06000B38 RID: 2872 RVA: 0x00038BA0 File Offset: 0x00036DA0
	public static Class74 Class74_0
	{
		get
		{
			if (Class74.class74_0 == null)
			{
				object obj = Class74.object_0;
				lock (obj)
				{
					if (Class74.class74_0 == null)
					{
						Class74.class74_0 = new Class74();
					}
				}
			}
			return Class74.class74_0;
		}
	}

	// Token: 0x06000B39 RID: 2873 RVA: 0x00038C00 File Offset: 0x00036E00
	public void method_0()
	{
		this.method_2();
		using (FileStream fileStream = new FileStream(Path.Combine(GClass13.string_6, this.string_0 + ".ico"), FileMode.OpenOrCreate, FileAccess.Write))
		{
			Class89.Icon_1.Save(fileStream);
		}
		File.WriteAllText(this.string_0 + ".vbs", Class89.String_0);
		File.WriteAllBytes(GClass13.string_5 + "\\" + GClass2.GClass2_0.method_1("NormalReboot") + ".lnk", Class89.Byte_4);
		File.WriteAllBytes(GClass13.string_5 + "\\" + GClass2.GClass2_0.method_1("RefreshLnk") + ".lnk", Class89.Byte_3);
	}

	// Token: 0x06000B3A RID: 2874 RVA: 0x00038CD0 File Offset: 0x00036ED0
	public void method_1()
	{
		this.method_2();
		List<string> list = new List<string>();
		list.Add(GClass2.GClass2_0.method_1("RefreshLnk"));
		list.Add(GClass2.GClass2_0.method_1("NormalReboot"));
		list.Where(new Func<string, bool>(Class74.<>c.<>9.method_0)).ToList<string>().ForEach(new Action<string>(Class74.<>c.<>9.method_1));
	}

	// Token: 0x06000B3B RID: 2875 RVA: 0x00038D60 File Offset: 0x00036F60
	private void method_2()
	{
		List<string> list = new List<string>();
		list.Add(GClass13.string_6 + "\\Reboot.vbs");
		list.Add(GClass13.string_6 + "\\Refresh.vbs");
		list.Where(new Func<string, bool>(Class74.<>c.<>9.method_4)).ToList<string>().ForEach(new Action<string>(Class74.<>c.<>9.method_5));
	}

	// Token: 0x06000B3E RID: 2878 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000B3F RID: 2879 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000B40 RID: 2880 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_2(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x06000B41 RID: 2881 RVA: 0x000066FC File Offset: 0x000048FC
	static string smethod_3(string string_1, string string_2)
	{
		return Path.Combine(string_1, string_2);
	}

	// Token: 0x06000B42 RID: 2882 RVA: 0x00006705 File Offset: 0x00004905
	static FileStream smethod_4(string string_1, FileMode fileMode_0, FileAccess fileAccess_0)
	{
		return new FileStream(string_1, fileMode_0, fileAccess_0);
	}

	// Token: 0x06000B43 RID: 2883 RVA: 0x0000670F File Offset: 0x0000490F
	static void smethod_5(Icon icon_0, Stream stream_0)
	{
		icon_0.Save(stream_0);
	}

	// Token: 0x06000B44 RID: 2884 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_6(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000B45 RID: 2885 RVA: 0x00003D00 File Offset: 0x00001F00
	static void smethod_7(string string_1, string string_2)
	{
		File.WriteAllText(string_1, string_2);
	}

	// Token: 0x06000B46 RID: 2886 RVA: 0x000033BD File Offset: 0x000015BD
	static string smethod_8(string string_1, string string_2, string string_3, string string_4)
	{
		return string_1 + string_2 + string_3 + string_4;
	}

	// Token: 0x06000B47 RID: 2887 RVA: 0x00002DFB File Offset: 0x00000FFB
	static void smethod_9(string string_1, byte[] byte_0)
	{
		File.WriteAllBytes(string_1, byte_0);
	}

	// Token: 0x06000B48 RID: 2888 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_10()
	{
		return new object();
	}

	// Token: 0x04000486 RID: 1158
	private static volatile Class74 class74_0;

	// Token: 0x04000487 RID: 1159
	private static readonly object object_0 = new object();

	// Token: 0x04000488 RID: 1160
	private readonly string string_0 = GClass13.string_6 + "\\Rebofresh";
}
