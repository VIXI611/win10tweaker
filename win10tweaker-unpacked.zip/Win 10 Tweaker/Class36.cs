﻿using System;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000077 RID: 119
internal class Class36
{
	// Token: 0x1700002C RID: 44
	// (get) Token: 0x060005BE RID: 1470 RVA: 0x0001BD58 File Offset: 0x00019F58
	public static Class36 Class36_0
	{
		get
		{
			if (Class36.class36_0 == null)
			{
				object obj = Class36.object_0;
				lock (obj)
				{
					if (Class36.class36_0 == null)
					{
						Class36.class36_0 = new Class36();
					}
				}
			}
			return Class36.class36_0;
		}
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x000042D7 File Offset: 0x000024D7
	public void method_0(bool bool_0)
	{
		if (bool_0)
		{
			Registry.ClassesRoot.CreateSubKey(".cmd\\ShellNew").SetValue("Filename", "");
		}
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x000042FA File Offset: 0x000024FA
	public void method_1(bool bool_0)
	{
		if (bool_0)
		{
			Registry.ClassesRoot.CreateSubKey(".reg\\ShellNew").SetValue("Filename", "");
		}
	}

	// Token: 0x060005C1 RID: 1473 RVA: 0x0000431D File Offset: 0x0000251D
	public void method_2(bool bool_0)
	{
		if (bool_0)
		{
			Registry.ClassesRoot.CreateSubKey(".vbs\\ShellNew").SetValue("Filename", "");
		}
	}

	// Token: 0x060005C2 RID: 1474 RVA: 0x00004340 File Offset: 0x00002540
	public void method_3()
	{
		Registry.ClassesRoot.DeleteSubKeyTree(".cmd\\ShellNew", false);
		Registry.ClassesRoot.DeleteSubKeyTree(".reg\\ShellNew", false);
		Registry.ClassesRoot.DeleteSubKeyTree(".vbs\\ShellNew", false);
	}

	// Token: 0x060005C5 RID: 1477 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060005C6 RID: 1478 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060005C7 RID: 1479 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x060005C8 RID: 1480 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_3(RegistryKey registryKey_0, string string_0, object object_1)
	{
		registryKey_0.SetValue(string_0, object_1);
	}

	// Token: 0x060005C9 RID: 1481 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_4(RegistryKey registryKey_0, string string_0, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_0, bool_0);
	}

	// Token: 0x060005CA RID: 1482 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_5()
	{
		return new object();
	}

	// Token: 0x0400026B RID: 619
	private static volatile Class36 class36_0;

	// Token: 0x0400026C RID: 620
	private static readonly object object_0 = new object();
}
