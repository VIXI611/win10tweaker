﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000078 RID: 120
public partial class Dim : Form
{
	// Token: 0x060005CB RID: 1483 RVA: 0x0000437E File Offset: 0x0000257E
	public Dim()
	{
		this.InitializeComponent();
	}

	// Token: 0x060005CC RID: 1484 RVA: 0x0001BDB8 File Offset: 0x00019FB8
	private void Dim_Load(object sender, EventArgs e)
	{
		if (this.bool_0)
		{
			this.wait.Visible = true;
			this.wait.Text = GClass2.GClass2_0.method_1("DimText");
			this.wait.Location = new Point((Screen.PrimaryScreen.Bounds.Width - this.wait.Width) / 2, 50);
		}
		this.timer_0.Start();
	}

	// Token: 0x060005CD RID: 1485 RVA: 0x0001BE30 File Offset: 0x0001A030
	private void method_0(object sender, EventArgs e)
	{
		this.timer_0.Interval = 5;
		if (base.Opacity != 0.5)
		{
			base.Opacity += 0.02;
			if (base.Opacity >= 0.5)
			{
				this.timer_0.Stop();
				base.Opacity = 0.5;
			}
		}
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x0000438C File Offset: 0x0000258C
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060005D0 RID: 1488 RVA: 0x000029D4 File Offset: 0x00000BD4
	static void smethod_0(Control control_0, bool bool_1)
	{
		control_0.Visible = bool_1;
	}

	// Token: 0x060005D1 RID: 1489 RVA: 0x00002920 File Offset: 0x00000B20
	static void smethod_1(Control control_0, string string_0)
	{
		control_0.Text = string_0;
	}

	// Token: 0x060005D2 RID: 1490 RVA: 0x000040DF File Offset: 0x000022DF
	static Screen smethod_2()
	{
		return Screen.PrimaryScreen;
	}

	// Token: 0x060005D3 RID: 1491 RVA: 0x000040E6 File Offset: 0x000022E6
	static Rectangle smethod_3(Screen screen_0)
	{
		return screen_0.Bounds;
	}

	// Token: 0x060005D4 RID: 1492 RVA: 0x000043AB File Offset: 0x000025AB
	static void smethod_4(Timer timer_1, int int_0)
	{
		timer_1.Interval = int_0;
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x000043B4 File Offset: 0x000025B4
	static double smethod_5(Form form_0)
	{
		return form_0.Opacity;
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x00002ADC File Offset: 0x00000CDC
	static void smethod_6(Form form_0, double double_0)
	{
		form_0.Opacity = double_0;
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x000043BC File Offset: 0x000025BC
	static void smethod_7(Timer timer_1)
	{
		timer_1.Stop();
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_8(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x00002A4C File Offset: 0x00000C4C
	static Container smethod_9()
	{
		return new Container();
	}

	// Token: 0x060005DA RID: 1498 RVA: 0x000039A1 File Offset: 0x00001BA1
	static Timer smethod_10(IContainer icontainer_1)
	{
		return new Timer(icontainer_1);
	}

	// Token: 0x060005DB RID: 1499 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_11()
	{
		return new Label();
	}

	// Token: 0x060005DC RID: 1500 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_12(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060005DD RID: 1501 RVA: 0x000043C4 File Offset: 0x000025C4
	static void smethod_13(Timer timer_1, EventHandler eventHandler_0)
	{
		timer_1.Tick += eventHandler_0;
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x00002A9D File Offset: 0x00000C9D
	static void smethod_14(Control control_0, bool bool_1)
	{
		control_0.AutoSize = bool_1;
	}

	// Token: 0x0400026D RID: 621
	public bool bool_0;
}
