﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x0200002B RID: 43
public partial class BlockerMenu : Form
{
	// Token: 0x0600017D RID: 381
	[DllImport("dwmapi.dll")]
	public static extern int DwmExtendFrameIntoClientArea(IntPtr intptr_0, ref BlockerMenu.GStruct0 gstruct0_0);

	// Token: 0x0600017E RID: 382
	[DllImport("dwmapi.dll")]
	public static extern int DwmSetWindowAttribute(IntPtr intptr_0, int int_0, ref int int_1, int int_2);

	// Token: 0x0600017F RID: 383
	[DllImport("dwmapi.dll")]
	public static extern int DwmIsCompositionEnabled(ref int int_0);

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000180 RID: 384 RVA: 0x000109D4 File Offset: 0x0000EBD4
	protected virtual CreateParams CreateParams
	{
		get
		{
			this.bool_0 = this.method_0();
			CreateParams createParams = base.CreateParams;
			if (!this.bool_0)
			{
				createParams.ClassStyle |= 131072;
			}
			return createParams;
		}
	}

	// Token: 0x06000181 RID: 385 RVA: 0x00010A10 File Offset: 0x0000EC10
	private bool method_0()
	{
		if (Environment.OSVersion.Version.Major >= 6)
		{
			int num = 0;
			BlockerMenu.DwmIsCompositionEnabled(ref num);
			return num == 1;
		}
		return false;
	}

	// Token: 0x06000182 RID: 386 RVA: 0x00010A40 File Offset: 0x0000EC40
	protected virtual void WndProc(ref Message m)
	{
		if (m.Msg == 133 && this.bool_0)
		{
			int num = 2;
			BlockerMenu.DwmSetWindowAttribute(base.Handle, 2, ref num, 4);
			BlockerMenu.GStruct0 gstruct = new BlockerMenu.GStruct0
			{
				int_3 = 1,
				int_0 = 0,
				int_1 = 0,
				int_2 = 0
			};
			BlockerMenu.DwmExtendFrameIntoClientArea(base.Handle, ref gstruct);
		}
		base.WndProc(ref m);
		if (m.Msg == 132)
		{
			if ((int)m.Result == 1)
			{
				m.Result = (IntPtr)2;
			}
		}
	}

	// Token: 0x06000183 RID: 387 RVA: 0x00002F1D File Offset: 0x0000111D
	protected virtual bool ProcessCmdKey(ref Message msg, Keys keyData)
	{
		if (keyData == Keys.Escape)
		{
			this.method_1();
			return true;
		}
		return base.ProcessCmdKey(ref msg, keyData);
	}

	// Token: 0x06000184 RID: 388 RVA: 0x00010AE0 File Offset: 0x0000ECE0
	private void method_1()
	{
		BlockerMenu.Struct21 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.blockerMenu_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<BlockerMenu.Struct21>(ref @struct);
	}

	// Token: 0x06000185 RID: 389 RVA: 0x00010B18 File Offset: 0x0000ED18
	public BlockerMenu(Superform superform_1)
	{
		this.superform_0 = superform_1;
		this.InitializeComponent();
		this.CloseIcon.Click += this.method_2;
		if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "DarkSkin")
		{
			this.BackColor = GClass2.GClass2_0.color_5;
			this.Table.BackgroundColor = GClass2.GClass2_0.color_5;
			this.Table.RowTemplate.DefaultCellStyle.BackColor = GClass2.GClass2_0.color_5;
			this.Table.ColumnHeadersDefaultCellStyle.BackColor = GClass6.GClass6_0.method_10("293440");
			return;
		}
		if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SkySkin")
		{
			this.BackColor = GClass2.GClass2_0.color_6;
			this.Table.BackgroundColor = GClass2.GClass2_0.color_6;
			this.Table.RowTemplate.DefaultCellStyle.BackColor = GClass2.GClass2_0.color_6;
			this.Table.ColumnHeadersDefaultCellStyle.BackColor = GClass6.GClass6_0.method_10("0D3455");
			return;
		}
		if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SeaSkin")
		{
			this.BackColor = GClass2.GClass2_0.color_7;
			this.Table.BackgroundColor = GClass2.GClass2_0.color_7;
			this.Table.RowTemplate.DefaultCellStyle.BackColor = GClass2.GClass2_0.color_7;
			this.Table.ColumnHeadersDefaultCellStyle.BackColor = GClass6.GClass6_0.method_10("0D3B52");
		}
	}

	// Token: 0x06000186 RID: 390 RVA: 0x00010CF4 File Offset: 0x0000EEF4
	private void BlockerMenu_Load(object sender, EventArgs e)
	{
		BlockerMenu.Struct22 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.blockerMenu_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<BlockerMenu.Struct22>(ref @struct);
	}

	// Token: 0x06000187 RID: 391 RVA: 0x00010D2C File Offset: 0x0000EF2C
	private void Table_CellClick(object sender, DataGridViewCellEventArgs e)
	{
		if (e.ColumnIndex == 1 && this.Table.Rows.Count > 0 && e.RowIndex >= 0)
		{
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(string.Format("{0}\\{1}", BlockerMenu.string_0, this.Table[0, e.RowIndex].Value), true))
			{
				registryKey.DeleteValue("Debugger");
				if (registryKey.GetValueNames().Length == 0)
				{
					Registry.LocalMachine.DeleteSubKeyTree(string.Format("{0}\\{1}", BlockerMenu.string_0, this.Table[0, e.RowIndex].Value));
				}
				this.Table.Rows.RemoveAt(e.RowIndex);
				this.form1_0.Popup(GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("BlockexeSuccessDeleted"), 8000);
			}
		}
	}

	// Token: 0x06000188 RID: 392 RVA: 0x00002F34 File Offset: 0x00001134
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600018B RID: 395 RVA: 0x00002F64 File Offset: 0x00001164
	[CompilerGenerated]
	private void method_2(object sender, EventArgs e)
	{
		this.method_1();
		this.superform_0.WindowState = FormWindowState.Normal;
	}

	// Token: 0x0600018C RID: 396 RVA: 0x00002F78 File Offset: 0x00001178
	static int smethod_0(CreateParams createParams_0)
	{
		return createParams_0.ClassStyle;
	}

	// Token: 0x0600018D RID: 397 RVA: 0x00002F80 File Offset: 0x00001180
	static void smethod_1(CreateParams createParams_0, int int_0)
	{
		createParams_0.ClassStyle = int_0;
	}

	// Token: 0x0600018E RID: 398 RVA: 0x00002F89 File Offset: 0x00001189
	static OperatingSystem smethod_2()
	{
		return Environment.OSVersion;
	}

	// Token: 0x0600018F RID: 399 RVA: 0x00002F90 File Offset: 0x00001190
	static Version smethod_3(OperatingSystem operatingSystem_0)
	{
		return operatingSystem_0.Version;
	}

	// Token: 0x06000190 RID: 400 RVA: 0x00002F98 File Offset: 0x00001198
	static int smethod_4(Version version_0)
	{
		return version_0.Major;
	}

	// Token: 0x06000191 RID: 401 RVA: 0x00002951 File Offset: 0x00000B51
	static void smethod_5(Control control_0, EventHandler eventHandler_0)
	{
		control_0.Click += eventHandler_0;
	}

	// Token: 0x06000192 RID: 402 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_6(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.GetValue(string_1);
	}

	// Token: 0x06000193 RID: 403 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_7(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x06000194 RID: 404 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_8(string string_1, string string_2)
	{
		return string_1 == string_2;
	}

	// Token: 0x06000195 RID: 405 RVA: 0x00002BA7 File Offset: 0x00000DA7
	static void smethod_9(Control control_0, Color color_0)
	{
		control_0.BackColor = color_0;
	}

	// Token: 0x06000196 RID: 406 RVA: 0x00002FA0 File Offset: 0x000011A0
	static void smethod_10(DataGridView dataGridView_0, Color color_0)
	{
		dataGridView_0.BackgroundColor = color_0;
	}

	// Token: 0x06000197 RID: 407 RVA: 0x00002FA9 File Offset: 0x000011A9
	static DataGridViewRow smethod_11(DataGridView dataGridView_0)
	{
		return dataGridView_0.RowTemplate;
	}

	// Token: 0x06000198 RID: 408 RVA: 0x00002FB1 File Offset: 0x000011B1
	static DataGridViewCellStyle smethod_12(DataGridViewBand dataGridViewBand_0)
	{
		return dataGridViewBand_0.DefaultCellStyle;
	}

	// Token: 0x06000199 RID: 409 RVA: 0x00002FB9 File Offset: 0x000011B9
	static void smethod_13(DataGridViewCellStyle dataGridViewCellStyle_0, Color color_0)
	{
		dataGridViewCellStyle_0.BackColor = color_0;
	}

	// Token: 0x0600019A RID: 410 RVA: 0x00002FC2 File Offset: 0x000011C2
	static DataGridViewCellStyle smethod_14(DataGridView dataGridView_0)
	{
		return dataGridView_0.ColumnHeadersDefaultCellStyle;
	}

	// Token: 0x0600019B RID: 411 RVA: 0x00002FCA File Offset: 0x000011CA
	static int smethod_15(DataGridViewCellEventArgs dataGridViewCellEventArgs_0)
	{
		return dataGridViewCellEventArgs_0.ColumnIndex;
	}

	// Token: 0x0600019C RID: 412 RVA: 0x00002FD2 File Offset: 0x000011D2
	static DataGridViewRowCollection smethod_16(DataGridView dataGridView_0)
	{
		return dataGridView_0.Rows;
	}

	// Token: 0x0600019D RID: 413 RVA: 0x00002FDA File Offset: 0x000011DA
	static int smethod_17(DataGridViewRowCollection dataGridViewRowCollection_0)
	{
		return dataGridViewRowCollection_0.Count;
	}

	// Token: 0x0600019E RID: 414 RVA: 0x00002FE2 File Offset: 0x000011E2
	static int smethod_18(DataGridViewCellEventArgs dataGridViewCellEventArgs_0)
	{
		return dataGridViewCellEventArgs_0.RowIndex;
	}

	// Token: 0x0600019F RID: 415 RVA: 0x00002FEA File Offset: 0x000011EA
	static DataGridViewCell smethod_19(DataGridView dataGridView_0, int int_0, int int_1)
	{
		return dataGridView_0[int_0, int_1];
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x00002FF4 File Offset: 0x000011F4
	static object smethod_20(DataGridViewCell dataGridViewCell_0)
	{
		return dataGridViewCell_0.Value;
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x00002FFC File Offset: 0x000011FC
	static string smethod_21(string string_1, object object_0, object object_1)
	{
		return string.Format(string_1, object_0, object_1);
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_22(RegistryKey registryKey_0, string string_1, bool bool_1)
	{
		return registryKey_0.OpenSubKey(string_1, bool_1);
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_23(RegistryKey registryKey_0, string string_1)
	{
		registryKey_0.DeleteValue(string_1);
	}

	// Token: 0x060001A4 RID: 420 RVA: 0x00003019 File Offset: 0x00001219
	static string[] smethod_24(RegistryKey registryKey_0)
	{
		return registryKey_0.GetValueNames();
	}

	// Token: 0x060001A5 RID: 421 RVA: 0x00003021 File Offset: 0x00001221
	static void smethod_25(RegistryKey registryKey_0, string string_1)
	{
		registryKey_0.DeleteSubKeyTree(string_1);
	}

	// Token: 0x060001A6 RID: 422 RVA: 0x0000302A File Offset: 0x0000122A
	static void smethod_26(DataGridViewRowCollection dataGridViewRowCollection_0, int int_0)
	{
		dataGridViewRowCollection_0.RemoveAt(int_0);
	}

	// Token: 0x060001A7 RID: 423 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_27(string string_1, string string_2, string string_3)
	{
		return string_1 + string_2 + string_3;
	}

	// Token: 0x060001A8 RID: 424 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_28(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060001A9 RID: 425 RVA: 0x0000303D File Offset: 0x0000123D
	static DataGridViewCellStyle smethod_29()
	{
		return new DataGridViewCellStyle();
	}

	// Token: 0x060001AA RID: 426 RVA: 0x00002A77 File Offset: 0x00000C77
	static Panel smethod_30()
	{
		return new Panel();
	}

	// Token: 0x060001AB RID: 427 RVA: 0x00003044 File Offset: 0x00001244
	static DataGridView smethod_31()
	{
		return new DataGridView();
	}

	// Token: 0x060001AC RID: 428 RVA: 0x0000304B File Offset: 0x0000124B
	static DataGridViewTextBoxColumn smethod_32()
	{
		return new DataGridViewTextBoxColumn();
	}

	// Token: 0x060001AD RID: 429 RVA: 0x00002A69 File Offset: 0x00000C69
	static Button smethod_33()
	{
		return new Button();
	}

	// Token: 0x060001AE RID: 430 RVA: 0x00002A8D File Offset: 0x00000C8D
	static void smethod_34(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060001AF RID: 431 RVA: 0x00002A85 File Offset: 0x00000C85
	static void smethod_35(ISupportInitialize isupportInitialize_0)
	{
		isupportInitialize_0.BeginInit();
	}

	// Token: 0x060001B0 RID: 432 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_36(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060001B1 RID: 433 RVA: 0x00003052 File Offset: 0x00001252
	static void smethod_37(ScrollableControl scrollableControl_0, bool bool_1)
	{
		scrollableControl_0.AutoScroll = bool_1;
	}

	// Token: 0x060001B2 RID: 434 RVA: 0x0000295A File Offset: 0x00000B5A
	static Control.ControlCollection smethod_38(Control control_0)
	{
		return control_0.Controls;
	}

	// Token: 0x060001B3 RID: 435 RVA: 0x0000305B File Offset: 0x0000125B
	static void smethod_39(Control.ControlCollection controlCollection_0, Control control_0)
	{
		controlCollection_0.Add(control_0);
	}

	// Token: 0x060001B4 RID: 436 RVA: 0x00003064 File Offset: 0x00001264
	static void smethod_40(Form form_0, FormWindowState formWindowState_0)
	{
		form_0.WindowState = formWindowState_0;
	}

	// Token: 0x040000C5 RID: 197
	private bool bool_0;

	// Token: 0x040000C6 RID: 198
	private readonly Superform superform_0;

	// Token: 0x040000C7 RID: 199
	private readonly Form1 form1_0 = new Form1();

	// Token: 0x040000C8 RID: 200
	private static readonly string string_0 = GClass2.GClass2_0.string_12;

	// Token: 0x040000C9 RID: 201
	private IContainer icontainer_0;

	// Token: 0x0200002C RID: 44
	public struct GStruct0
	{
		// Token: 0x040000CF RID: 207
		public int int_0;

		// Token: 0x040000D0 RID: 208
		public int int_1;

		// Token: 0x040000D1 RID: 209
		public int int_2;

		// Token: 0x040000D2 RID: 210
		public int int_3;
	}

	// Token: 0x0200002E RID: 46
	[CompilerGenerated]
	private sealed class Class13
	{
		// Token: 0x060001BB RID: 443 RVA: 0x0001144C File Offset: 0x0000F64C
		internal void method_0(string string_0)
		{
			try
			{
				if (this.registryKey_0.OpenSubKey(string_0).GetValue("Debugger") != null)
				{
					this.blockerMenu_0.Table.Rows.Add(new object[]
					{
						string_0,
						"×"
					});
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001BC RID: 444 RVA: 0x0000307B File Offset: 0x0000127B
		static RegistryKey smethod_0(RegistryKey registryKey_1, string string_0)
		{
			return registryKey_1.OpenSubKey(string_0);
		}

		// Token: 0x060001BD RID: 445 RVA: 0x000029DD File Offset: 0x00000BDD
		static object smethod_1(RegistryKey registryKey_1, string string_0)
		{
			return registryKey_1.GetValue(string_0);
		}

		// Token: 0x060001BE RID: 446 RVA: 0x00002FD2 File Offset: 0x000011D2
		static DataGridViewRowCollection smethod_2(DataGridView dataGridView_0)
		{
			return dataGridView_0.Rows;
		}

		// Token: 0x060001BF RID: 447 RVA: 0x00003084 File Offset: 0x00001284
		static int smethod_3(DataGridViewRowCollection dataGridViewRowCollection_0, object[] object_0)
		{
			return dataGridViewRowCollection_0.Add(object_0);
		}

		// Token: 0x040000D7 RID: 215
		public BlockerMenu blockerMenu_0;

		// Token: 0x040000D8 RID: 216
		public RegistryKey registryKey_0;
	}
}
