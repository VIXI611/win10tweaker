﻿using System;
using System.Windows.Forms;

// Token: 0x02000070 RID: 112
public class GClass11 : Panel
{
	// Token: 0x17000027 RID: 39
	// (get) Token: 0x0600056A RID: 1386 RVA: 0x00004130 File Offset: 0x00002330
	protected virtual CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ExStyle |= 32;
			return createParams;
		}
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x0000414F File Offset: 0x0000234F
	static int smethod_0(CreateParams createParams_0)
	{
		return createParams_0.ExStyle;
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x00004157 File Offset: 0x00002357
	static void smethod_1(CreateParams createParams_0, int int_0)
	{
		createParams_0.ExStyle = int_0;
	}
}
