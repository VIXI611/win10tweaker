﻿using System;

// Token: 0x02000055 RID: 85
public class GClass5
{
	// Token: 0x0600040F RID: 1039 RVA: 0x00003A9E File Offset: 0x00001C9E
	public GClass5(bool bool_2 = true, bool bool_3 = false)
	{
		this.bool_0 = bool_2;
		this.bool_1 = bool_3;
	}

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x06000410 RID: 1040 RVA: 0x0001863C File Offset: 0x0001683C
	internal uint UInt32_0
	{
		get
		{
			uint num = 0U;
			if (this.bool_0)
			{
				num |= 1U;
			}
			if (this.bool_1)
			{
				num |= 2U;
			}
			return num;
		}
	}

	// Token: 0x040001FD RID: 509
	public readonly bool bool_0;

	// Token: 0x040001FE RID: 510
	public readonly bool bool_1;

	// Token: 0x040001FF RID: 511
	private const uint uint_0 = 1U;

	// Token: 0x04000200 RID: 512
	private const uint uint_1 = 2U;
}
