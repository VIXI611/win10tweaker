﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;

// Token: 0x020000C0 RID: 192
public static class GClass12
{
	// Token: 0x060009C2 RID: 2498 RVA: 0x0002B030 File Offset: 0x00029230
	public static string smethod_0<T>(T gparam_0)
	{
		string @string;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			DataContractJsonSerializerSettings settings = new DataContractJsonSerializerSettings
			{
				UseSimpleDictionaryFormat = true
			};
			new DataContractJsonSerializer(typeof(T), settings).WriteObject(memoryStream, gparam_0);
			@string = Encoding.UTF8.GetString(memoryStream.ToArray());
		}
		return @string;
	}

	// Token: 0x060009C3 RID: 2499 RVA: 0x0002B09C File Offset: 0x0002929C
	public static T smethod_1<T>(string string_0)
	{
		T result;
		using (MemoryStream memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(string_0)))
		{
			DataContractJsonSerializerSettings settings = new DataContractJsonSerializerSettings
			{
				UseSimpleDictionaryFormat = true
			};
			result = (T)((object)new DataContractJsonSerializer(typeof(T), settings).ReadObject(memoryStream));
		}
		return result;
	}

	// Token: 0x060009C4 RID: 2500 RVA: 0x0000567A File Offset: 0x0000387A
	static MemoryStream smethod_2()
	{
		return new MemoryStream();
	}

	// Token: 0x060009C5 RID: 2501 RVA: 0x00005681 File Offset: 0x00003881
	static DataContractJsonSerializerSettings smethod_3()
	{
		return new DataContractJsonSerializerSettings();
	}

	// Token: 0x060009C6 RID: 2502 RVA: 0x00005688 File Offset: 0x00003888
	static void smethod_4(DataContractJsonSerializerSettings dataContractJsonSerializerSettings_0, bool bool_0)
	{
		dataContractJsonSerializerSettings_0.UseSimpleDictionaryFormat = bool_0;
	}

	// Token: 0x060009C7 RID: 2503 RVA: 0x000025CE File Offset: 0x000007CE
	static Type smethod_5(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x060009C8 RID: 2504 RVA: 0x00005691 File Offset: 0x00003891
	static DataContractJsonSerializer smethod_6(Type type_0, DataContractJsonSerializerSettings dataContractJsonSerializerSettings_0)
	{
		return new DataContractJsonSerializer(type_0, dataContractJsonSerializerSettings_0);
	}

	// Token: 0x060009C9 RID: 2505 RVA: 0x0000569A File Offset: 0x0000389A
	static void smethod_7(XmlObjectSerializer xmlObjectSerializer_0, Stream stream_0, object object_0)
	{
		xmlObjectSerializer_0.WriteObject(stream_0, object_0);
	}

	// Token: 0x060009CA RID: 2506 RVA: 0x000056A4 File Offset: 0x000038A4
	static Encoding smethod_8()
	{
		return Encoding.UTF8;
	}

	// Token: 0x060009CB RID: 2507 RVA: 0x000056AB File Offset: 0x000038AB
	static byte[] smethod_9(MemoryStream memoryStream_0)
	{
		return memoryStream_0.ToArray();
	}

	// Token: 0x060009CC RID: 2508 RVA: 0x000056B3 File Offset: 0x000038B3
	static string smethod_10(Encoding encoding_0, byte[] byte_0)
	{
		return encoding_0.GetString(byte_0);
	}

	// Token: 0x060009CD RID: 2509 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_11(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060009CE RID: 2510 RVA: 0x000056BC File Offset: 0x000038BC
	static byte[] smethod_12(Encoding encoding_0, string string_0)
	{
		return encoding_0.GetBytes(string_0);
	}

	// Token: 0x060009CF RID: 2511 RVA: 0x00003D3C File Offset: 0x00001F3C
	static MemoryStream smethod_13(byte[] byte_0)
	{
		return new MemoryStream(byte_0);
	}

	// Token: 0x060009D0 RID: 2512 RVA: 0x000056C5 File Offset: 0x000038C5
	static object smethod_14(XmlObjectSerializer xmlObjectSerializer_0, Stream stream_0)
	{
		return xmlObjectSerializer_0.ReadObject(stream_0);
	}
}
