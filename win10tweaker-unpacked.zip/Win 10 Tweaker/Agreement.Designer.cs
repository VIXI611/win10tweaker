﻿// Token: 0x02000021 RID: 33
public partial class Agreement : global::GForm0
{
	// Token: 0x0600012A RID: 298 RVA: 0x0000F4FC File Offset: 0x0000D6FC
	private void InitializeComponent()
	{
		this.AgreementText = new global::System.Windows.Forms.RichTextBox();
		this.Deutsch = new global::System.Windows.Forms.PictureBox();
		this.Ukrainian = new global::System.Windows.Forms.PictureBox();
		this.Russian = new global::System.Windows.Forms.PictureBox();
		this.English = new global::System.Windows.Forms.PictureBox();
		this.CloseIcon = new global::System.Windows.Forms.Button();
		this.Header = new global::System.Windows.Forms.Label();
		this.DisagreeButton = new global::System.Windows.Forms.Button();
		this.AgreeButton = new global::System.Windows.Forms.Button();
		((global::System.ComponentModel.ISupportInitialize)this.Deutsch).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Ukrainian).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Russian).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.English).BeginInit();
		base.SuspendLayout();
		this.AgreementText.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.AgreementText.Cursor = global::System.Windows.Forms.Cursors.Default;
		this.AgreementText.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
		this.AgreementText.Location = new global::System.Drawing.Point(14, 41);
		this.AgreementText.Name = "AgreementText";
		this.AgreementText.ReadOnly = true;
		this.AgreementText.Size = new global::System.Drawing.Size(432, 236);
		this.AgreementText.TabIndex = 1;
		this.AgreementText.TabStop = false;
		this.AgreementText.Text = "";
		this.Deutsch.BackColor = global::System.Drawing.Color.Transparent;
		this.Deutsch.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.Deutsch.Image = global::Class89.Bitmap_26;
		this.Deutsch.Location = new global::System.Drawing.Point(60, 310);
		this.Deutsch.Name = "Deutsch";
		this.Deutsch.Size = new global::System.Drawing.Size(23, 13);
		this.Deutsch.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Deutsch.TabIndex = 189;
		this.Deutsch.TabStop = false;
		this.Ukrainian.BackColor = global::System.Drawing.Color.Transparent;
		this.Ukrainian.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.Ukrainian.Image = global::Class89.Bitmap_29;
		this.Ukrainian.Location = new global::System.Drawing.Point(60, 291);
		this.Ukrainian.Name = "Ukrainian";
		this.Ukrainian.Size = new global::System.Drawing.Size(23, 13);
		this.Ukrainian.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Ukrainian.TabIndex = 188;
		this.Ukrainian.TabStop = false;
		this.Russian.BackColor = global::System.Drawing.Color.Transparent;
		this.Russian.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.Russian.Image = global::Class89.Bitmap_28;
		this.Russian.Location = new global::System.Drawing.Point(31, 291);
		this.Russian.Name = "Russian";
		this.Russian.Size = new global::System.Drawing.Size(23, 13);
		this.Russian.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Russian.TabIndex = 187;
		this.Russian.TabStop = false;
		this.English.BackColor = global::System.Drawing.Color.Transparent;
		this.English.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.English.Image = global::Class89.Bitmap_27;
		this.English.Location = new global::System.Drawing.Point(31, 310);
		this.English.Name = "English";
		this.English.Size = new global::System.Drawing.Size(23, 13);
		this.English.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.English.TabIndex = 186;
		this.English.TabStop = false;
		this.CloseIcon.BackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.BackgroundImage = global::Class89.Bitmap_17;
		this.CloseIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.CloseIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
		this.CloseIcon.FlatAppearance.BorderSize = 0;
		this.CloseIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.CloseIcon.Location = new global::System.Drawing.Point(427, 5);
		this.CloseIcon.Name = "CloseIcon";
		this.CloseIcon.Size = new global::System.Drawing.Size(22, 22);
		this.CloseIcon.TabIndex = 31;
		this.CloseIcon.UseVisualStyleBackColor = false;
		this.Header.AutoSize = true;
		this.Header.BackColor = global::System.Drawing.Color.Transparent;
		this.Header.Font = new global::System.Drawing.Font("Calibri", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.Header.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.Header.Location = new global::System.Drawing.Point(12, 9);
		this.Header.Name = "Header";
		this.Header.Size = new global::System.Drawing.Size(0, 15);
		this.Header.TabIndex = 30;
		this.DisagreeButton.BackColor = global::System.Drawing.SystemColors.Control;
		this.DisagreeButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.DisagreeButton.Location = new global::System.Drawing.Point(233, 295);
		this.DisagreeButton.Name = "DisagreeButton";
		this.DisagreeButton.Size = new global::System.Drawing.Size(100, 25);
		this.DisagreeButton.TabIndex = 2;
		this.DisagreeButton.TabStop = false;
		this.DisagreeButton.UseVisualStyleBackColor = false;
		this.AgreeButton.BackColor = global::System.Drawing.SystemColors.Control;
		this.AgreeButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.AgreeButton.Location = new global::System.Drawing.Point(127, 295);
		this.AgreeButton.Name = "AgreeButton";
		this.AgreeButton.Size = new global::System.Drawing.Size(100, 25);
		this.AgreeButton.TabIndex = 0;
		this.AgreeButton.TabStop = false;
		this.AgreeButton.UseVisualStyleBackColor = false;
		this.AgreeButton.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.AgreeButton_MouseUp);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
		base.ClientSize = new global::System.Drawing.Size(460, 340);
		base.Controls.Add(this.AgreementText);
		base.Controls.Add(this.Deutsch);
		base.Controls.Add(this.Ukrainian);
		base.Controls.Add(this.Russian);
		base.Controls.Add(this.English);
		base.Controls.Add(this.CloseIcon);
		base.Controls.Add(this.Header);
		base.Controls.Add(this.DisagreeButton);
		base.Controls.Add(this.AgreeButton);
		this.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Agreement";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.Agreement_Load);
		((global::System.ComponentModel.ISupportInitialize)this.Deutsch).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Ukrainian).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Russian).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.English).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040000A0 RID: 160
	private global::System.Windows.Forms.Button AgreeButton;

	// Token: 0x040000A1 RID: 161
	private global::System.Windows.Forms.Button DisagreeButton;

	// Token: 0x040000A2 RID: 162
	private global::System.Windows.Forms.Label Header;

	// Token: 0x040000A3 RID: 163
	private global::System.Windows.Forms.Button CloseIcon;

	// Token: 0x040000A4 RID: 164
	private global::System.Windows.Forms.PictureBox Ukrainian;

	// Token: 0x040000A5 RID: 165
	private global::System.Windows.Forms.PictureBox Russian;

	// Token: 0x040000A6 RID: 166
	private global::System.Windows.Forms.PictureBox English;

	// Token: 0x040000A7 RID: 167
	private global::System.Windows.Forms.PictureBox Deutsch;

	// Token: 0x040000A8 RID: 168
	private global::System.Windows.Forms.RichTextBox AgreementText;
}
