﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("17.3.0.0")]
[assembly: AssemblyTrademark("XpucT")]
[assembly: ComVisible(false)]
[assembly: AssemblyProduct("Win 10 Tweaker")]
[assembly: AssemblyCopyright("Copyright © XpucT")]
[assembly: NeutralResourcesLanguage("")]
[assembly: Guid("8a13e46b-25cc-44dc-9bab-6e178b515c1f")]
[assembly: AssemblyFileVersion("17.3")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("JailbreakVideo")]
[assembly: AssemblyTitle("Win 10 Tweaker")]
[assembly: AssemblyDescription("Win 10 Tweaker")]
