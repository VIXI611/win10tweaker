﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace Win_10_Tweaker.Properties
{
	// Token: 0x02000196 RID: 406
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.4.0.0")]
	[CompilerGenerated]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x0600143B RID: 5179 RVA: 0x00009DDC File Offset: 0x00007FDC
		static SettingsBase smethod_0(SettingsBase settingsBase_0)
		{
			return SettingsBase.Synchronized(settingsBase_0);
		}
	}
}
