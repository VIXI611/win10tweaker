﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace Win_10_Tweaker.Properties
{
	// Token: 0x02000196 RID: 406
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.4.0.0")]
	[CompilerGenerated]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x17000103 RID: 259
		// (get) Token: 0x06001438 RID: 5176 RVA: 0x00009DB7 File Offset: 0x00007FB7
		public static Settings Default
		{
			get
			{
				return Settings.settings_0;
			}
		}

		// Token: 0x04000973 RID: 2419
		private static Settings settings_0 = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
