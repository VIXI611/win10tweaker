﻿using System;
using System.Collections.ObjectModel;
using System.Deps;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Management;
using System.Management.Automation;
using System.Media;
using System.Net;
using System.Net.Security;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

// Token: 0x02000058 RID: 88
public class GClass6
{
	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000425 RID: 1061 RVA: 0x000187FC File Offset: 0x000169FC
	public static GClass6 GClass6_0
	{
		get
		{
			if (GClass6.gclass6_0 == null)
			{
				object obj = GClass6.object_0;
				lock (obj)
				{
					if (GClass6.gclass6_0 == null)
					{
						GClass6.gclass6_0 = new GClass6();
					}
				}
			}
			return GClass6.gclass6_0;
		}
	}

	// Token: 0x06000426 RID: 1062
	[DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
	public static extern bool AdjustTokenPrivileges(IntPtr intptr_0, bool bool_0, ref GClass6.GStruct2 gstruct2_0, int int_0, IntPtr intptr_1, IntPtr intptr_2);

	// Token: 0x06000427 RID: 1063
	[DllImport("kernel32.dll", ExactSpelling = true)]
	public static extern IntPtr GetCurrentProcess();

	// Token: 0x06000428 RID: 1064
	[DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
	public static extern bool OpenProcessToken(IntPtr intptr_0, int int_0, ref IntPtr intptr_1);

	// Token: 0x06000429 RID: 1065
	[DllImport("advapi32.dll", SetLastError = true)]
	public static extern bool LookupPrivilegeValue(string string_1, string string_2, ref long long_0);

	// Token: 0x0600042A RID: 1066
	[DllImport("user32.dll")]
	public static extern IntPtr FindWindowEx(IntPtr intptr_0, IntPtr intptr_1, string string_1, string string_2);

	// Token: 0x0600042B RID: 1067
	[DllImport("User32.dll")]
	public static extern int SendMessage(IntPtr intptr_0, int int_0, int int_1, string string_1);

	// Token: 0x0600042C RID: 1068
	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
	private static extern IntPtr LoadLibrary([MarshalAs(UnmanagedType.LPStr)] string string_1);

	// Token: 0x0600042D RID: 1069
	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern int LoadString(IntPtr intptr_0, int int_0, StringBuilder stringBuilder_0, int int_1);

	// Token: 0x0600042E RID: 1070
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool FreeLibrary(IntPtr intptr_0);

	// Token: 0x0600042F RID: 1071 RVA: 0x0001885C File Offset: 0x00016A5C
	public string method_0(string string_1, int int_0)
	{
		IntPtr intptr_ = GClass6.LoadLibrary(string_1);
		StringBuilder stringBuilder = new StringBuilder(2048);
		GClass6.LoadString(intptr_, int_0, stringBuilder, stringBuilder.Capacity);
		GClass6.FreeLibrary(intptr_);
		return stringBuilder.ToString();
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x06000430 RID: 1072 RVA: 0x00018898 File Offset: 0x00016A98
	public string String_0
	{
		get
		{
			string result;
			if ((result = this.string_0) == null)
			{
				result = (this.string_0 = GClass6.GClass6_0.method_1());
			}
			return result;
		}
	}

	// Token: 0x06000431 RID: 1073 RVA: 0x000188C4 File Offset: 0x00016AC4
	private string method_1()
	{
		foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM  Win32_BaseBoard").Get())
		{
			ManagementObject managementObject = (ManagementObject)managementBaseObject;
			this.string_0 = managementObject.GetPropertyValue("Manufacturer").ToString() + " " + managementObject.GetPropertyValue("Product").ToString();
		}
		return this.string_0;
	}

	// Token: 0x06000432 RID: 1074 RVA: 0x00003B25 File Offset: 0x00001D25
	private void method_2()
	{
		this.method_18();
		this.method_14(string.Format("taskkill /f /pid \"{0}\"", Process.GetCurrentProcess().Id));
	}

	// Token: 0x06000433 RID: 1075 RVA: 0x00003B4C File Offset: 0x00001D4C
	private bool method_3()
	{
		return AppDomain.CurrentDomain.FriendlyName.Contains("е");
	}

	// Token: 0x06000434 RID: 1076 RVA: 0x00018954 File Offset: 0x00016B54
	public string method_4()
	{
		RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_1);
		DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
		long num = Convert.ToInt64(registryKey.GetValue("InstallDate").ToString());
		return dateTime.AddSeconds((double)num).ToLocalTime().ToString();
	}

	// Token: 0x06000435 RID: 1077 RVA: 0x000189B8 File Offset: 0x00016BB8
	public void method_5()
	{
		GClass6.Struct34 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<GClass6.Struct34>(ref @struct);
	}

	// Token: 0x06000436 RID: 1078 RVA: 0x000189E8 File Offset: 0x00016BE8
	public string method_6(double double_0)
	{
		string text = GClass2.GClass2_0.method_1("ByteSize");
		string text2 = GClass2.GClass2_0.method_1("KBSize");
		string text3 = GClass2.GClass2_0.method_1("MBSize");
		string text4 = GClass2.GClass2_0.method_1("GBSize");
		string[] array = new string[]
		{
			text,
			text2,
			text3,
			text4
		};
		if (double_0 == 0.0)
		{
			return "0 " + array[0];
		}
		double num = Math.Abs(double_0);
		int num2 = Convert.ToInt32(Math.Floor(Math.Log(num, 1024.0)));
		double num3 = Math.Round(num / Math.Pow(1024.0, (double)num2), 1);
		return string.Format("{0} {1}", (double)Math.Sign(double_0) * num3, array[num2]);
	}

	// Token: 0x06000437 RID: 1079 RVA: 0x00018AC4 File Offset: 0x00016CC4
	public void method_7()
	{
		try
		{
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
			ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(GClass6.<>c.<>9.method_2);
			string text = GClass13.string_7 + "\\drivers\\etc\\hosts";
			try
			{
				File.SetAttributes(text, File.GetAttributes(text) & ~FileAttributes.ReadOnly);
			}
			catch
			{
			}
			if (!File.Exists(text))
			{
				File.Create(text).Close();
			}
			try
			{
				if (!File.ReadAllText(text).Contains("telemetry"))
				{
					File.Copy(text, text + " (Original)", true);
				}
			}
			catch
			{
			}
			string[] first = File.ReadAllLines(text);
			Antispy.Set();
			string[] array;
			using (WebClient webClient = new WebClient())
			{
				array = webClient.DownloadString("https://raw.githubusercontent.com/crazy-max/WindowsSpyBlocker/master/data/hosts/spy.txt").Split(new char[]
				{
					'\r',
					'\n'
				}, StringSplitOptions.RemoveEmptyEntries);
			}
			array = array.Where(new Func<string, bool>(GClass6.<>c.<>9.method_3)).ToArray<string>();
			string[] array2 = first.Concat(array).ToArray<string>().Distinct<string>().ToArray<string>();
			File.WriteAllText(text, "");
			using (FileStream fileStream = new FileStream(text, FileMode.Append))
			{
				using (StreamWriter streamWriter = new StreamWriter(fileStream))
				{
					foreach (string value in array2)
					{
						streamWriter.WriteLine(value);
					}
				}
			}
			using (WebClient webClient2 = new WebClient())
			{
				GClass6.GClass6_0.method_14("netsh advfirewall firewall delete rule name=\"" + GClass2.GClass2_0.String_17 + "\"");
				string[] array4 = webClient2.DownloadString("https://raw.githubusercontent.com/crazy-max/WindowsSpyBlocker/master/data/firewall/spy.txt").Split(new char[]
				{
					'\r',
					'\n'
				}, StringSplitOptions.RemoveEmptyEntries);
				array4 = array4.Where(new Func<string, bool>(GClass6.<>c.<>9.method_4)).ToArray<string>();
				GClass6.GClass6_0.method_14("netsh advfirewall firewall add rule name=\"" + GClass2.GClass2_0.String_17 + "\" action=block dir=out remoteip=" + string.Join(",", array4));
			}
		}
		catch
		{
			GClass6.GClass6_0.method_9();
		}
	}

	// Token: 0x06000438 RID: 1080 RVA: 0x00018DB8 File Offset: 0x00016FB8
	public Task<string> method_8(string string_1)
	{
		GClass6.Struct35 @struct;
		@struct.asyncTaskMethodBuilder_0 = AsyncTaskMethodBuilder<string>.Create();
		@struct.string_0 = string_1;
		@struct.int_0 = -1;
		@struct.asyncTaskMethodBuilder_0.Start<GClass6.Struct35>(ref @struct);
		return @struct.asyncTaskMethodBuilder_0.Task;
	}

	// Token: 0x06000439 RID: 1081 RVA: 0x00003B62 File Offset: 0x00001D62
	public void method_9()
	{
		WMessageBox.smethod_3(GClass2.GClass2_0.method_1("NetworkError"), "", WMessageBox.GEnum2.OK, false, "", null);
	}

	// Token: 0x0600043A RID: 1082 RVA: 0x00003B86 File Offset: 0x00001D86
	public Color method_10(string string_1)
	{
		return ColorTranslator.FromHtml("#" + string_1);
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x00018DFC File Offset: 0x00016FFC
	public void method_11()
	{
		GClass6.Struct36 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<GClass6.Struct36>(ref @struct);
	}

	// Token: 0x0600043C RID: 1084 RVA: 0x00003B98 File Offset: 0x00001D98
	public void method_12(string string_1)
	{
		Process process = Process.Start("notepad.exe");
		process.WaitForInputIdle();
		GClass6.SendMessage(GClass6.FindWindowEx(process.MainWindowHandle, new IntPtr(0), "Edit", null), 12, 0, string_1);
	}

	// Token: 0x0600043D RID: 1085 RVA: 0x00018E2C File Offset: 0x0001702C
	public void method_13()
	{
		using (MemoryStream memoryStream = new MemoryStream(Class89.Byte_1))
		{
			using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Decompress))
			{
				new SoundPlayer(gzipStream).Play();
			}
		}
		if (this.method_3())
		{
			this.method_2();
		}
	}

	// Token: 0x0600043E RID: 1086 RVA: 0x00003BCB File Offset: 0x00001DCB
	public void method_14(string string_1)
	{
		Process.Start(new ProcessStartInfo
		{
			FileName = "cmd",
			Arguments = "/c " + string_1,
			WindowStyle = ProcessWindowStyle.Hidden
		});
	}

	// Token: 0x0600043F RID: 1087 RVA: 0x00003BFB File Offset: 0x00001DFB
	public void method_15(string string_1)
	{
		Process.Start(new ProcessStartInfo
		{
			FileName = "cmd",
			Arguments = "/c " + string_1,
			WindowStyle = ProcessWindowStyle.Hidden
		}).WaitForExit();
	}

	// Token: 0x06000440 RID: 1088 RVA: 0x00018E98 File Offset: 0x00017098
	public void method_16(string string_1)
	{
		using (PowerShell powerShell = PowerShell.Create())
		{
			powerShell.AddScript(string_1);
			powerShell.Invoke();
		}
	}

	// Token: 0x06000441 RID: 1089 RVA: 0x00018ED8 File Offset: 0x000170D8
	public void method_17(RegistryKey registryKey_0, bool bool_0 = true)
	{
		GClass6.Class27 @class = new GClass6.Class27();
		@class.gclass6_0 = this;
		@class.registryKey_0 = registryKey_0;
		foreach (string string_ in new string[]
		{
			"SeRestorePrivilege",
			"SeBackupPrivilege",
			"SeTakeOwnershipPrivilege"
		})
		{
			IntPtr zero = IntPtr.Zero;
			GClass6.OpenProcessToken(GClass6.GetCurrentProcess(), 40, ref zero);
			GClass6.GStruct2 gstruct;
			gstruct.int_0 = 1;
			gstruct.long_0 = 0L;
			gstruct.int_1 = 2;
			GClass6.LookupPrivilegeValue(null, string_, ref gstruct.long_0);
			GClass6.AdjustTokenPrivileges(zero, false, ref gstruct, 0, IntPtr.Zero, IntPtr.Zero);
		}
		try
		{
			RegistryKey registryKey = @class.registryKey_0.OpenSubKey("", RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.TakeOwnership);
			RegistrySecurity accessControl = registryKey.GetAccessControl();
			accessControl.SetOwner(new NTAccount(GClass2.GClass2_0.String_9));
			registryKey.SetAccessControl(accessControl);
			RegistryKey registryKey2 = @class.registryKey_0.OpenSubKey("", RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.ChangePermissions);
			RegistryAccessRule registryAccessRule = new RegistryAccessRule(GClass2.GClass2_0.String_9, RegistryRights.FullControl, AccessControlType.Allow);
			accessControl.SetAccessRule(registryAccessRule);
			RegistrySecurity registrySecurity = new RegistrySecurity();
			registrySecurity.AddAccessRule(registryAccessRule);
			registryKey2.SetAccessControl(registrySecurity);
		}
		catch
		{
		}
		if (bool_0)
		{
			RegistryKey registryKey_ = @class.registryKey_0;
			if (registryKey_ == null)
			{
				return;
			}
			registryKey_.GetSubKeyNames().ToList<string>().ForEach(new Action<string>(@class.method_0));
		}
	}

	// Token: 0x06000442 RID: 1090 RVA: 0x00019050 File Offset: 0x00017250
	public void method_18()
	{
		foreach (string string_ in new string[]
		{
			"SeRestorePrivilege",
			"SeBackupPrivilege",
			"SeTakeOwnershipPrivilege"
		})
		{
			IntPtr zero = IntPtr.Zero;
			GClass6.OpenProcessToken(GClass6.GetCurrentProcess(), 40, ref zero);
			GClass6.GStruct2 gstruct;
			gstruct.int_0 = 1;
			gstruct.long_0 = 0L;
			gstruct.int_1 = 2;
			GClass6.LookupPrivilegeValue(null, string_, ref gstruct.long_0);
			GClass6.AdjustTokenPrivileges(zero, false, ref gstruct, 0, IntPtr.Zero, IntPtr.Zero);
		}
		try
		{
			RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Win 10 Tweaker", RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.TakeOwnership);
			RegistrySecurity accessControl = registryKey.GetAccessControl();
			accessControl.SetOwner(new NTAccount(GClass2.GClass2_0.String_9));
			registryKey.SetAccessControl(accessControl);
			RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("Software\\Win 10 Tweaker", RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.ChangePermissions);
			RegistryAccessRule registryAccessRule = new RegistryAccessRule(GClass2.GClass2_0.String_9, RegistryRights.FullControl, AccessControlType.Deny);
			accessControl.SetAccessRule(registryAccessRule);
			RegistrySecurity registrySecurity = new RegistrySecurity();
			registrySecurity.AddAccessRule(registryAccessRule);
			registryKey2.SetAccessControl(registrySecurity);
		}
		catch
		{
		}
	}

	// Token: 0x06000445 RID: 1093 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000446 RID: 1094 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000447 RID: 1095 RVA: 0x00003B15 File Offset: 0x00001D15
	static StringBuilder smethod_2(int int_0)
	{
		return new StringBuilder(int_0);
	}

	// Token: 0x06000448 RID: 1096 RVA: 0x00003C3B File Offset: 0x00001E3B
	static int smethod_3(StringBuilder stringBuilder_0)
	{
		return stringBuilder_0.Capacity;
	}

	// Token: 0x06000449 RID: 1097 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_4(object object_1)
	{
		return object_1.ToString();
	}

	// Token: 0x0600044A RID: 1098 RVA: 0x00003C43 File Offset: 0x00001E43
	static ManagementObjectSearcher smethod_5(string string_1, string string_2)
	{
		return new ManagementObjectSearcher(string_1, string_2);
	}

	// Token: 0x0600044B RID: 1099 RVA: 0x00003C4C File Offset: 0x00001E4C
	static ManagementObjectCollection smethod_6(ManagementObjectSearcher managementObjectSearcher_0)
	{
		return managementObjectSearcher_0.Get();
	}

	// Token: 0x0600044C RID: 1100 RVA: 0x00003C54 File Offset: 0x00001E54
	static ManagementObjectCollection.ManagementObjectEnumerator smethod_7(ManagementObjectCollection managementObjectCollection_0)
	{
		return managementObjectCollection_0.GetEnumerator();
	}

	// Token: 0x0600044D RID: 1101 RVA: 0x00003C5C File Offset: 0x00001E5C
	static ManagementBaseObject smethod_8(ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator_0)
	{
		return managementObjectEnumerator_0.Current;
	}

	// Token: 0x0600044E RID: 1102 RVA: 0x00003C64 File Offset: 0x00001E64
	static object smethod_9(ManagementBaseObject managementBaseObject_0, string string_1)
	{
		return managementBaseObject_0.GetPropertyValue(string_1);
	}

	// Token: 0x0600044F RID: 1103 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_10(string string_1, string string_2, string string_3)
	{
		return string_1 + string_2 + string_3;
	}

	// Token: 0x06000450 RID: 1104 RVA: 0x00003C6D File Offset: 0x00001E6D
	static bool smethod_11(ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator_0)
	{
		return managementObjectEnumerator_0.MoveNext();
	}

	// Token: 0x06000451 RID: 1105 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_12(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000452 RID: 1106 RVA: 0x00003C75 File Offset: 0x00001E75
	static Process smethod_13()
	{
		return Process.GetCurrentProcess();
	}

	// Token: 0x06000453 RID: 1107 RVA: 0x00003C7C File Offset: 0x00001E7C
	static int smethod_14(Process process_0)
	{
		return process_0.Id;
	}

	// Token: 0x06000454 RID: 1108 RVA: 0x000033C8 File Offset: 0x000015C8
	static string smethod_15(string string_1, object object_1)
	{
		return string.Format(string_1, object_1);
	}

	// Token: 0x06000455 RID: 1109 RVA: 0x00003917 File Offset: 0x00001B17
	static AppDomain smethod_16()
	{
		return AppDomain.CurrentDomain;
	}

	// Token: 0x06000456 RID: 1110 RVA: 0x0000391E File Offset: 0x00001B1E
	static string smethod_17(AppDomain appDomain_0)
	{
		return appDomain_0.FriendlyName;
	}

	// Token: 0x06000457 RID: 1111 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_18(string string_1, string string_2)
	{
		return string_1.Contains(string_2);
	}

	// Token: 0x06000458 RID: 1112 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_19(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.OpenSubKey(string_1);
	}

	// Token: 0x06000459 RID: 1113 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_20(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.GetValue(string_1);
	}

	// Token: 0x0600045A RID: 1114 RVA: 0x00003C84 File Offset: 0x00001E84
	static long smethod_21(string string_1)
	{
		return Convert.ToInt64(string_1);
	}

	// Token: 0x0600045B RID: 1115 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_22(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x0600045C RID: 1116 RVA: 0x00003C8C File Offset: 0x00001E8C
	static double smethod_23(double double_0)
	{
		return Math.Abs(double_0);
	}

	// Token: 0x0600045D RID: 1117 RVA: 0x00003C94 File Offset: 0x00001E94
	static double smethod_24(double double_0, double double_1)
	{
		return Math.Log(double_0, double_1);
	}

	// Token: 0x0600045E RID: 1118 RVA: 0x00003C9D File Offset: 0x00001E9D
	static double smethod_25(double double_0)
	{
		return Math.Floor(double_0);
	}

	// Token: 0x0600045F RID: 1119 RVA: 0x00003CA5 File Offset: 0x00001EA5
	static int smethod_26(double double_0)
	{
		return Convert.ToInt32(double_0);
	}

	// Token: 0x06000460 RID: 1120 RVA: 0x00003CAD File Offset: 0x00001EAD
	static double smethod_27(double double_0, double double_1)
	{
		return Math.Pow(double_0, double_1);
	}

	// Token: 0x06000461 RID: 1121 RVA: 0x00003CB6 File Offset: 0x00001EB6
	static double smethod_28(double double_0, int int_0)
	{
		return Math.Round(double_0, int_0);
	}

	// Token: 0x06000462 RID: 1122 RVA: 0x00003CBF File Offset: 0x00001EBF
	static int smethod_29(double double_0)
	{
		return Math.Sign(double_0);
	}

	// Token: 0x06000463 RID: 1123 RVA: 0x00002FFC File Offset: 0x000011FC
	static string smethod_30(string string_1, object object_1, object object_2)
	{
		return string.Format(string_1, object_1, object_2);
	}

	// Token: 0x06000464 RID: 1124 RVA: 0x00003CC7 File Offset: 0x00001EC7
	static void smethod_31(SecurityProtocolType securityProtocolType_0)
	{
		ServicePointManager.SecurityProtocol = securityProtocolType_0;
	}

	// Token: 0x06000465 RID: 1125 RVA: 0x00003CCF File Offset: 0x00001ECF
	static void smethod_32(RemoteCertificateValidationCallback remoteCertificateValidationCallback_0)
	{
		ServicePointManager.ServerCertificateValidationCallback = remoteCertificateValidationCallback_0;
	}

	// Token: 0x06000466 RID: 1126 RVA: 0x000036D1 File Offset: 0x000018D1
	static FileAttributes smethod_33(string string_1)
	{
		return File.GetAttributes(string_1);
	}

	// Token: 0x06000467 RID: 1127 RVA: 0x000036D9 File Offset: 0x000018D9
	static void smethod_34(string string_1, FileAttributes fileAttributes_0)
	{
		File.SetAttributes(string_1, fileAttributes_0);
	}

	// Token: 0x06000468 RID: 1128 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_35(string string_1)
	{
		return File.Exists(string_1);
	}

	// Token: 0x06000469 RID: 1129 RVA: 0x00003CD7 File Offset: 0x00001ED7
	static FileStream smethod_36(string string_1)
	{
		return File.Create(string_1);
	}

	// Token: 0x0600046A RID: 1130 RVA: 0x00003CDF File Offset: 0x00001EDF
	static void smethod_37(Stream stream_0)
	{
		stream_0.Close();
	}

	// Token: 0x0600046B RID: 1131 RVA: 0x00003CE7 File Offset: 0x00001EE7
	static string smethod_38(string string_1)
	{
		return File.ReadAllText(string_1);
	}

	// Token: 0x0600046C RID: 1132 RVA: 0x00003CEF File Offset: 0x00001EEF
	static void smethod_39(string string_1, string string_2, bool bool_0)
	{
		File.Copy(string_1, string_2, bool_0);
	}

	// Token: 0x0600046D RID: 1133 RVA: 0x000033DB File Offset: 0x000015DB
	static string[] smethod_40(string string_1)
	{
		return File.ReadAllLines(string_1);
	}

	// Token: 0x0600046E RID: 1134 RVA: 0x00003CF9 File Offset: 0x00001EF9
	static void smethod_41()
	{
		Antispy.Set();
	}

	// Token: 0x0600046F RID: 1135 RVA: 0x00002994 File Offset: 0x00000B94
	static WebClient smethod_42()
	{
		return new WebClient();
	}

	// Token: 0x06000470 RID: 1136 RVA: 0x0000299B File Offset: 0x00000B9B
	static string smethod_43(WebClient webClient_0, string string_1)
	{
		return webClient_0.DownloadString(string_1);
	}

	// Token: 0x06000471 RID: 1137 RVA: 0x00002C70 File Offset: 0x00000E70
	static string[] smethod_44(string string_1, char[] char_0, StringSplitOptions stringSplitOptions_0)
	{
		return string_1.Split(char_0, stringSplitOptions_0);
	}

	// Token: 0x06000472 RID: 1138 RVA: 0x00003D00 File Offset: 0x00001F00
	static void smethod_45(string string_1, string string_2)
	{
		File.WriteAllText(string_1, string_2);
	}

	// Token: 0x06000473 RID: 1139 RVA: 0x00003D09 File Offset: 0x00001F09
	static FileStream smethod_46(string string_1, FileMode fileMode_0)
	{
		return new FileStream(string_1, fileMode_0);
	}

	// Token: 0x06000474 RID: 1140 RVA: 0x00003D12 File Offset: 0x00001F12
	static StreamWriter smethod_47(Stream stream_0)
	{
		return new StreamWriter(stream_0);
	}

	// Token: 0x06000475 RID: 1141 RVA: 0x00003D1A File Offset: 0x00001F1A
	static void smethod_48(TextWriter textWriter_0, string string_1)
	{
		textWriter_0.WriteLine(string_1);
	}

	// Token: 0x06000476 RID: 1142 RVA: 0x00003D23 File Offset: 0x00001F23
	static string smethod_49(string string_1, string[] string_2)
	{
		return string.Join(string_1, string_2);
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x000033BD File Offset: 0x000015BD
	static string smethod_50(string string_1, string string_2, string string_3, string string_4)
	{
		return string_1 + string_2 + string_3 + string_4;
	}

	// Token: 0x06000478 RID: 1144 RVA: 0x00003270 File Offset: 0x00001470
	static Color smethod_51(string string_1)
	{
		return ColorTranslator.FromHtml(string_1);
	}

	// Token: 0x06000479 RID: 1145 RVA: 0x00002AA6 File Offset: 0x00000CA6
	static Process smethod_52(string string_1)
	{
		return Process.Start(string_1);
	}

	// Token: 0x0600047A RID: 1146 RVA: 0x00003D2C File Offset: 0x00001F2C
	static bool smethod_53(Process process_0)
	{
		return process_0.WaitForInputIdle();
	}

	// Token: 0x0600047B RID: 1147 RVA: 0x00003D34 File Offset: 0x00001F34
	static IntPtr smethod_54(Process process_0)
	{
		return process_0.MainWindowHandle;
	}

	// Token: 0x0600047C RID: 1148 RVA: 0x00003D3C File Offset: 0x00001F3C
	static MemoryStream smethod_55(byte[] byte_0)
	{
		return new MemoryStream(byte_0);
	}

	// Token: 0x0600047D RID: 1149 RVA: 0x00003D44 File Offset: 0x00001F44
	static GZipStream smethod_56(Stream stream_0, CompressionMode compressionMode_0)
	{
		return new GZipStream(stream_0, compressionMode_0);
	}

	// Token: 0x0600047E RID: 1150 RVA: 0x00003D4D File Offset: 0x00001F4D
	static SoundPlayer smethod_57(Stream stream_0)
	{
		return new SoundPlayer(stream_0);
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x00003D55 File Offset: 0x00001F55
	static void smethod_58(SoundPlayer soundPlayer_0)
	{
		soundPlayer_0.Play();
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x00003100 File Offset: 0x00001300
	static ProcessStartInfo smethod_59()
	{
		return new ProcessStartInfo();
	}

	// Token: 0x06000481 RID: 1153 RVA: 0x00003107 File Offset: 0x00001307
	static void smethod_60(ProcessStartInfo processStartInfo_0, string string_1)
	{
		processStartInfo_0.FileName = string_1;
	}

	// Token: 0x06000482 RID: 1154 RVA: 0x00003110 File Offset: 0x00001310
	static void smethod_61(ProcessStartInfo processStartInfo_0, string string_1)
	{
		processStartInfo_0.Arguments = string_1;
	}

	// Token: 0x06000483 RID: 1155 RVA: 0x00003119 File Offset: 0x00001319
	static void smethod_62(ProcessStartInfo processStartInfo_0, ProcessWindowStyle processWindowStyle_0)
	{
		processStartInfo_0.WindowStyle = processWindowStyle_0;
	}

	// Token: 0x06000484 RID: 1156 RVA: 0x00003122 File Offset: 0x00001322
	static Process smethod_63(ProcessStartInfo processStartInfo_0)
	{
		return Process.Start(processStartInfo_0);
	}

	// Token: 0x06000485 RID: 1157 RVA: 0x00003D5D File Offset: 0x00001F5D
	static void smethod_64(Process process_0)
	{
		process_0.WaitForExit();
	}

	// Token: 0x06000486 RID: 1158 RVA: 0x00003454 File Offset: 0x00001654
	static PowerShell smethod_65()
	{
		return PowerShell.Create();
	}

	// Token: 0x06000487 RID: 1159 RVA: 0x0000345B File Offset: 0x0000165B
	static PowerShell smethod_66(PowerShell powerShell_0, string string_1)
	{
		return powerShell_0.AddScript(string_1);
	}

	// Token: 0x06000488 RID: 1160 RVA: 0x00003464 File Offset: 0x00001664
	static Collection<PSObject> smethod_67(PowerShell powerShell_0)
	{
		return powerShell_0.Invoke();
	}

	// Token: 0x06000489 RID: 1161 RVA: 0x00003D65 File Offset: 0x00001F65
	static RegistryKey smethod_68(RegistryKey registryKey_0, string string_1, RegistryKeyPermissionCheck registryKeyPermissionCheck_0, RegistryRights registryRights_0)
	{
		return registryKey_0.OpenSubKey(string_1, registryKeyPermissionCheck_0, registryRights_0);
	}

	// Token: 0x0600048A RID: 1162 RVA: 0x00003D70 File Offset: 0x00001F70
	static RegistrySecurity smethod_69(RegistryKey registryKey_0)
	{
		return registryKey_0.GetAccessControl();
	}

	// Token: 0x0600048B RID: 1163 RVA: 0x00003D78 File Offset: 0x00001F78
	static NTAccount smethod_70(string string_1)
	{
		return new NTAccount(string_1);
	}

	// Token: 0x0600048C RID: 1164 RVA: 0x00003D80 File Offset: 0x00001F80
	static void smethod_71(ObjectSecurity objectSecurity_0, IdentityReference identityReference_0)
	{
		objectSecurity_0.SetOwner(identityReference_0);
	}

	// Token: 0x0600048D RID: 1165 RVA: 0x00003D89 File Offset: 0x00001F89
	static void smethod_72(RegistryKey registryKey_0, RegistrySecurity registrySecurity_0)
	{
		registryKey_0.SetAccessControl(registrySecurity_0);
	}

	// Token: 0x0600048E RID: 1166 RVA: 0x00003D92 File Offset: 0x00001F92
	static RegistryAccessRule smethod_73(string string_1, RegistryRights registryRights_0, AccessControlType accessControlType_0)
	{
		return new RegistryAccessRule(string_1, registryRights_0, accessControlType_0);
	}

	// Token: 0x0600048F RID: 1167 RVA: 0x00003D9C File Offset: 0x00001F9C
	static void smethod_74(RegistrySecurity registrySecurity_0, RegistryAccessRule registryAccessRule_0)
	{
		registrySecurity_0.SetAccessRule(registryAccessRule_0);
	}

	// Token: 0x06000490 RID: 1168 RVA: 0x00003DA5 File Offset: 0x00001FA5
	static RegistrySecurity smethod_75()
	{
		return new RegistrySecurity();
	}

	// Token: 0x06000491 RID: 1169 RVA: 0x00003DAC File Offset: 0x00001FAC
	static void smethod_76(RegistrySecurity registrySecurity_0, RegistryAccessRule registryAccessRule_0)
	{
		registrySecurity_0.AddAccessRule(registryAccessRule_0);
	}

	// Token: 0x06000492 RID: 1170 RVA: 0x00003429 File Offset: 0x00001629
	static string[] smethod_77(RegistryKey registryKey_0)
	{
		return registryKey_0.GetSubKeyNames();
	}

	// Token: 0x06000493 RID: 1171 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_78()
	{
		return new object();
	}

	// Token: 0x04000202 RID: 514
	private static volatile GClass6 gclass6_0;

	// Token: 0x04000203 RID: 515
	private static readonly object object_0 = new object();

	// Token: 0x04000204 RID: 516
	public string string_0;

	// Token: 0x02000059 RID: 89
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct GStruct2
	{
		// Token: 0x04000205 RID: 517
		public int int_0;

		// Token: 0x04000206 RID: 518
		public long long_0;

		// Token: 0x04000207 RID: 519
		public int int_1;
	}

	// Token: 0x0200005E RID: 94
	[CompilerGenerated]
	private sealed class Class27
	{
		// Token: 0x060004C0 RID: 1216 RVA: 0x00003E5F File Offset: 0x0000205F
		internal void method_0(string string_0)
		{
			this.gclass6_0.method_17(this.registryKey_0.OpenSubKey(string_0), true);
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x0000307B File Offset: 0x0000127B
		static RegistryKey smethod_0(RegistryKey registryKey_1, string string_0)
		{
			return registryKey_1.OpenSubKey(string_0);
		}

		// Token: 0x0400021A RID: 538
		public GClass6 gclass6_0;

		// Token: 0x0400021B RID: 539
		public RegistryKey registryKey_0;
	}
}
