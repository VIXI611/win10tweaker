﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000068 RID: 104
[DesignerCategory("Code")]
public class GClass10 : Panel
{
	// Token: 0x06000506 RID: 1286 RVA: 0x00004015 File Offset: 0x00002215
	public GClass10()
	{
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, true);
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x00019BFC File Offset: 0x00017DFC
	protected virtual void OnPaint(PaintEventArgs e)
	{
		using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
		{
			e.Graphics.FillRectangle(solidBrush, base.ClientRectangle);
		}
		e.Graphics.DrawRectangle(new Pen(Color.FromArgb(52, 64, 82)), 0, 0, base.ClientSize.Width - 1, base.ClientSize.Height - 1);
	}

	// Token: 0x06000508 RID: 1288 RVA: 0x00004029 File Offset: 0x00002229
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x00004048 File Offset: 0x00002248
	private void method_0()
	{
		this.icontainer_0 = new Container();
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x000032E3 File Offset: 0x000014E3
	static Color smethod_0(Control control_0)
	{
		return control_0.BackColor;
	}

	// Token: 0x0600050B RID: 1291 RVA: 0x0000329B File Offset: 0x0000149B
	static SolidBrush smethod_1(Color color_0)
	{
		return new SolidBrush(color_0);
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x00002B88 File Offset: 0x00000D88
	static Graphics smethod_2(PaintEventArgs paintEventArgs_0)
	{
		return paintEventArgs_0.Graphics;
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x000032EB File Offset: 0x000014EB
	static Rectangle smethod_3(Control control_0)
	{
		return control_0.ClientRectangle;
	}

	// Token: 0x0600050E RID: 1294 RVA: 0x00002C0B File Offset: 0x00000E0B
	static void smethod_4(Graphics graphics_0, Brush brush_0, Rectangle rectangle_0)
	{
		graphics_0.FillRectangle(brush_0, rectangle_0);
	}

	// Token: 0x0600050F RID: 1295 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_5(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000510 RID: 1296 RVA: 0x000032F3 File Offset: 0x000014F3
	static Pen smethod_6(Color color_0)
	{
		return new Pen(color_0);
	}

	// Token: 0x06000511 RID: 1297 RVA: 0x000032FB File Offset: 0x000014FB
	static Size smethod_7(Control control_0)
	{
		return control_0.ClientSize;
	}

	// Token: 0x06000512 RID: 1298 RVA: 0x00002A4C File Offset: 0x00000C4C
	static Container smethod_8()
	{
		return new Container();
	}

	// Token: 0x04000230 RID: 560
	private IContainer icontainer_0;
}
