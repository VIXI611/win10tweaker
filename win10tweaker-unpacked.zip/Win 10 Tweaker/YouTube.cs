﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Win_10_Tweaker;

// Token: 0x0200018E RID: 398
public partial class YouTube : GForm0
{
	// Token: 0x0600138C RID: 5004 RVA: 0x0006CA04 File Offset: 0x0006AC04
	private void method_1()
	{
		YouTube.Struct85 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.youTube_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<YouTube.Struct85>(ref @struct);
	}

	// Token: 0x0600138D RID: 5005 RVA: 0x0006CA3C File Offset: 0x0006AC3C
	public YouTube(Form1 form1_1)
	{
		this.InitializeComponent();
		this.form1_0 = form1_1;
		this.CloseIcon.Click += this.method_5;
		new List<Control>
		{
			this.HeaderPanel,
			this.Header
		}.ForEach(new Action<Control>(this.method_6));
		base.Controls.OfType<Panel>().ToList<Panel>().ForEach(new Action<Panel>(YouTube.<>c.<>9.method_0));
		base.Controls.OfType<Control>().Where(new Func<Control, bool>(YouTube.<>c.<>9.method_1)).ToList<Control>().ForEach(new Action<Control>(this.method_8));
	}

	// Token: 0x0600138E RID: 5006 RVA: 0x0006CB1C File Offset: 0x0006AD1C
	private void YouTube_Load(object sender, EventArgs e)
	{
		YouTube.Struct86 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.youTube_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<YouTube.Struct86>(ref @struct);
	}

	// Token: 0x0600138F RID: 5007 RVA: 0x0006CB54 File Offset: 0x0006AD54
	public void method_2(Color color_0, Color color_1, Color color_2)
	{
		YouTube.Class88 @class = new YouTube.Class88();
		@class.youTube_0 = this;
		@class.color_0 = color_0;
		@class.color_1 = color_1;
		@class.color_2 = color_2;
		this.HeaderPanel.Paint += @class.method_0;
		this.HeaderPanel.Invalidate();
	}

	// Token: 0x06001390 RID: 5008 RVA: 0x000028C8 File Offset: 0x00000AC8
	private string method_3(string string_0)
	{
		return GClass2.GClass2_0.method_1(string_0);
	}

	// Token: 0x06001391 RID: 5009 RVA: 0x00009331 File Offset: 0x00007531
	private void method_4()
	{
		this.Header.Text = this.method_3("YouTubeHeader");
		base.Controls.OfType<LinkLabel>().ToList<LinkLabel>().ForEach(new Action<LinkLabel>(this.method_9));
	}

	// Token: 0x06001392 RID: 5010 RVA: 0x0000936A File Offset: 0x0000756A
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001394 RID: 5012 RVA: 0x00009389 File Offset: 0x00007589
	[CompilerGenerated]
	private void method_5(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x06001395 RID: 5013 RVA: 0x0006D8A4 File Offset: 0x0006BAA4
	[CompilerGenerated]
	private void method_6(Control control_0)
	{
		YouTube.Class86 @class = new YouTube.Class86();
		@class.youTube_0 = this;
		@class.control_0 = control_0;
		@class.control_0.MouseDown += @class.method_0;
	}

	// Token: 0x06001396 RID: 5014 RVA: 0x000028FC File Offset: 0x00000AFC
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_7(ref Message message_0)
	{
		base.System.Windows.Forms.Form.WndProc(ref message_0);
	}

	// Token: 0x06001397 RID: 5015 RVA: 0x0006D8DC File Offset: 0x0006BADC
	[CompilerGenerated]
	internal static void smethod_3(Panel panel_0)
	{
		typeof(Panel).method_10("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.SetProperty, null, panel_0, new object[]
		{
			true
		});
	}

	// Token: 0x06001398 RID: 5016 RVA: 0x0006D914 File Offset: 0x0006BB14
	[CompilerGenerated]
	private void method_8(Control control_0)
	{
		YouTube.Class87 @class = new YouTube.Class87();
		@class.youTube_0 = this;
		@class.control_0 = control_0;
		@class.control_0.Click += @class.method_0;
	}

	// Token: 0x06001399 RID: 5017 RVA: 0x00009391 File Offset: 0x00007591
	[CompilerGenerated]
	private void method_9(LinkLabel linkLabel_0)
	{
		linkLabel_0.Text = this.method_3(linkLabel_0.Name);
	}

	// Token: 0x0600139A RID: 5018 RVA: 0x00002951 File Offset: 0x00000B51
	static void smethod_4(Control control_0, EventHandler eventHandler_0)
	{
		control_0.Click += eventHandler_0;
	}

	// Token: 0x0600139B RID: 5019 RVA: 0x00002984 File Offset: 0x00000B84
	static Control.ControlCollection smethod_5(Control control_0)
	{
		return control_0.Controls;
	}

	// Token: 0x0600139C RID: 5020 RVA: 0x00002A0F File Offset: 0x00000C0F
	static void smethod_6(Control control_0, PaintEventHandler paintEventHandler_0)
	{
		control_0.Paint += paintEventHandler_0;
	}

	// Token: 0x0600139D RID: 5021 RVA: 0x00002929 File Offset: 0x00000B29
	static void smethod_7(Control control_0)
	{
		control_0.Invalidate();
	}

	// Token: 0x0600139E RID: 5022 RVA: 0x00002920 File Offset: 0x00000B20
	static void smethod_8(Control control_0, string string_0)
	{
		control_0.Text = string_0;
	}

	// Token: 0x0600139F RID: 5023 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_9(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060013A0 RID: 5024 RVA: 0x00002A77 File Offset: 0x00000C77
	static Panel smethod_10()
	{
		return new Panel();
	}

	// Token: 0x060013A1 RID: 5025 RVA: 0x00002A69 File Offset: 0x00000C69
	static Button smethod_11()
	{
		return new Button();
	}

	// Token: 0x060013A2 RID: 5026 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_12()
	{
		return new Label();
	}

	// Token: 0x060013A3 RID: 5027 RVA: 0x00002A5A File Offset: 0x00000C5A
	static PictureBox smethod_13()
	{
		return new PictureBox();
	}

	// Token: 0x060013A4 RID: 5028 RVA: 0x00002A70 File Offset: 0x00000C70
	static LinkLabel smethod_14()
	{
		return new LinkLabel();
	}

	// Token: 0x060013A5 RID: 5029 RVA: 0x00002A8D File Offset: 0x00000C8D
	static void smethod_15(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060013A6 RID: 5030 RVA: 0x00002A85 File Offset: 0x00000C85
	static void smethod_16(ISupportInitialize isupportInitialize_0)
	{
		isupportInitialize_0.BeginInit();
	}

	// Token: 0x060013A7 RID: 5031 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_17(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060013A8 RID: 5032 RVA: 0x0000295A File Offset: 0x00000B5A
	static Control.ControlCollection smethod_18(Control control_0)
	{
		return control_0.Controls;
	}

	// Token: 0x060013A9 RID: 5033 RVA: 0x0000305B File Offset: 0x0000125B
	static void smethod_19(Control.ControlCollection controlCollection_0, Control control_0)
	{
		controlCollection_0.Add(control_0);
	}

	// Token: 0x060013AA RID: 5034 RVA: 0x00002AAE File Offset: 0x00000CAE
	static void smethod_20(Control control_0, MouseEventHandler mouseEventHandler_0)
	{
		control_0.MouseDown += mouseEventHandler_0;
	}

	// Token: 0x060013AB RID: 5035 RVA: 0x000025CE File Offset: 0x000007CE
	static Type smethod_21(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x060013AC RID: 5036 RVA: 0x00002ABF File Offset: 0x00000CBF
	object method_10(string string_0, BindingFlags bindingFlags_0, Binder binder_0, object object_0, object[] object_1)
	{
		return base.InvokeMember(string_0, bindingFlags_0, binder_0, object_0, object_1);
	}

	// Token: 0x060013AD RID: 5037 RVA: 0x00002C23 File Offset: 0x00000E23
	static string smethod_22(Control control_0)
	{
		return control_0.Name;
	}

	// Token: 0x0400094D RID: 2381
	private readonly Form1 form1_0;

	// Token: 0x0400094E RID: 2382
	private IContainer icontainer_0;

	// Token: 0x02000190 RID: 400
	[CompilerGenerated]
	private sealed class Class86
	{
		// Token: 0x060013B4 RID: 5044 RVA: 0x0006DA40 File Offset: 0x0006BC40
		internal void method_0(object sender, MouseEventArgs e)
		{
			this.control_0.Capture = false;
			this.youTube_0.Capture = false;
			Message message = Message.Create(this.youTube_0.method_1(), 161, new IntPtr(2), IntPtr.Zero);
			this.youTube_0.method_7(ref message);
		}

		// Token: 0x060013B5 RID: 5045 RVA: 0x00002AF5 File Offset: 0x00000CF5
		static void smethod_0(Control control_1, bool bool_0)
		{
			control_1.Capture = bool_0;
		}

		// Token: 0x060013B6 RID: 5046 RVA: 0x00002AFE File Offset: 0x00000CFE
		static void smethod_1(Control control_1, bool bool_0)
		{
			control_1.Capture = bool_0;
		}

		// Token: 0x060013B7 RID: 5047 RVA: 0x00002B07 File Offset: 0x00000D07
		IntPtr method_1()
		{
			return base.Handle;
		}

		// Token: 0x04000962 RID: 2402
		public Control control_0;

		// Token: 0x04000963 RID: 2403
		public YouTube youTube_0;
	}

	// Token: 0x02000191 RID: 401
	[CompilerGenerated]
	private sealed class Class87
	{
		// Token: 0x060013B9 RID: 5049 RVA: 0x0006DA94 File Offset: 0x0006BC94
		internal void method_0(object sender, EventArgs e)
		{
			if (this.control_0.Name.EndsWith("1"))
			{
				Process.Start("https://win10tweaker.pro/W10TVideoNotes");
				return;
			}
			if (this.control_0.Name.EndsWith("2"))
			{
				Process.Start(GClass2.GClass2_0.String_5.StartsWith("ru-") ? "https://win10tweaker.pro/W10TArgsRu" : "https://win10tweaker.pro/W10TArgsEn");
				return;
			}
			if (this.control_0.Name.EndsWith("3"))
			{
				Process.Start(GClass2.GClass2_0.String_5.StartsWith("ru-") ? "https://win10tweaker.pro/W10TServicesRu" : "https://win10tweaker.pro/W10TServicesEn");
				return;
			}
			this.youTube_0.form1_0.APIVideo();
		}

		// Token: 0x060013BA RID: 5050 RVA: 0x00002C23 File Offset: 0x00000E23
		static string smethod_0(Control control_1)
		{
			return control_1.Name;
		}

		// Token: 0x060013BB RID: 5051 RVA: 0x00002A29 File Offset: 0x00000C29
		static bool smethod_1(string string_0, string string_1)
		{
			return string_0.EndsWith(string_1);
		}

		// Token: 0x060013BC RID: 5052 RVA: 0x00002AA6 File Offset: 0x00000CA6
		static Process smethod_2(string string_0)
		{
			return Process.Start(string_0);
		}

		// Token: 0x060013BD RID: 5053 RVA: 0x000036C8 File Offset: 0x000018C8
		static bool smethod_3(string string_0, string string_1)
		{
			return string_0.StartsWith(string_1);
		}

		// Token: 0x04000964 RID: 2404
		public Control control_0;

		// Token: 0x04000965 RID: 2405
		public YouTube youTube_0;
	}

	// Token: 0x02000194 RID: 404
	[CompilerGenerated]
	private sealed class Class88
	{
		// Token: 0x060013CC RID: 5068 RVA: 0x0006DD70 File Offset: 0x0006BF70
		internal void method_0(object sender, PaintEventArgs e)
		{
			LinearGradientBrush linearGradientBrush = new LinearGradientBrush(this.youTube_0.HeaderPanel.ClientRectangle, Color.Empty, Color.Empty, 90f);
			ColorBlend interpolationColors = new ColorBlend(5)
			{
				Colors = new Color[]
				{
					this.color_0,
					this.color_0,
					this.color_1,
					this.color_2,
					this.color_2
				},
				Positions = new float[]
				{
					0f,
					0.82f,
					0.82f,
					1f,
					1f
				}
			};
			linearGradientBrush.InterpolationColors = interpolationColors;
			e.Graphics.FillRectangle(linearGradientBrush, this.youTube_0.HeaderPanel.ClientRectangle);
		}

		// Token: 0x060013CD RID: 5069 RVA: 0x00002BCC File Offset: 0x00000DCC
		static Rectangle smethod_0(Control control_0)
		{
			return control_0.ClientRectangle;
		}

		// Token: 0x060013CE RID: 5070 RVA: 0x00002BD4 File Offset: 0x00000DD4
		static LinearGradientBrush smethod_1(Rectangle rectangle_0, Color color_3, Color color_4, float float_0)
		{
			return new LinearGradientBrush(rectangle_0, color_3, color_4, float_0);
		}

		// Token: 0x060013CF RID: 5071 RVA: 0x00002BDF File Offset: 0x00000DDF
		static ColorBlend smethod_2(int int_0)
		{
			return new ColorBlend(int_0);
		}

		// Token: 0x060013D0 RID: 5072 RVA: 0x00002BE7 File Offset: 0x00000DE7
		static void smethod_3(ColorBlend colorBlend_0, Color[] color_3)
		{
			colorBlend_0.Colors = color_3;
		}

		// Token: 0x060013D1 RID: 5073 RVA: 0x00002BF0 File Offset: 0x00000DF0
		static void smethod_4(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x060013D2 RID: 5074 RVA: 0x00002BF9 File Offset: 0x00000DF9
		static void smethod_5(ColorBlend colorBlend_0, float[] float_0)
		{
			colorBlend_0.Positions = float_0;
		}

		// Token: 0x060013D3 RID: 5075 RVA: 0x00002C02 File Offset: 0x00000E02
		static void smethod_6(LinearGradientBrush linearGradientBrush_0, ColorBlend colorBlend_0)
		{
			linearGradientBrush_0.InterpolationColors = colorBlend_0;
		}

		// Token: 0x060013D4 RID: 5076 RVA: 0x00002B88 File Offset: 0x00000D88
		static Graphics smethod_7(PaintEventArgs paintEventArgs_0)
		{
			return paintEventArgs_0.Graphics;
		}

		// Token: 0x060013D5 RID: 5077 RVA: 0x00002C0B File Offset: 0x00000E0B
		static void smethod_8(Graphics graphics_0, Brush brush_0, Rectangle rectangle_0)
		{
			graphics_0.FillRectangle(brush_0, rectangle_0);
		}

		// Token: 0x0400096D RID: 2413
		public YouTube youTube_0;

		// Token: 0x0400096E RID: 2414
		public Color color_0;

		// Token: 0x0400096F RID: 2415
		public Color color_1;

		// Token: 0x04000970 RID: 2416
		public Color color_2;
	}
}
