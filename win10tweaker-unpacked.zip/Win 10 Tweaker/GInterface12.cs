﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A9 RID: 425
[CoClass(typeof(object))]
[TypeIdentifier]
[CompilerGenerated]
[Guid("317EE249-F12E-11D2-B1E4-00C04F8EEB3E")]
[ComImport]
public interface GInterface12 : GInterface10
{
}
