﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000083 RID: 131
internal class Class44
{
	// Token: 0x17000032 RID: 50
	// (get) Token: 0x0600066E RID: 1646 RVA: 0x0001DE3C File Offset: 0x0001C03C
	public static Class44 Class44_0
	{
		get
		{
			if (Class44.class44_0 == null)
			{
				object obj = Class44.object_0;
				lock (obj)
				{
					if (Class44.class44_0 == null)
					{
						Class44.class44_0 = new Class44();
					}
				}
			}
			return Class44.class44_0;
		}
	}

	// Token: 0x0600066F RID: 1647 RVA: 0x0001DE9C File Offset: 0x0001C09C
	public void method_0(bool bool_0)
	{
		if (bool_0)
		{
			byte[] value = new byte[]
			{
				173,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				99,
				4,
				0,
				0
			};
			Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Modules\\GlobalSettings\\Sizer").SetValue("PageSpaceControlSizer", value, RegistryValueKind.Binary);
		}
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x00004661 File Offset: 0x00002861
	public void method_1(bool bool_0)
	{
		if (bool_0)
		{
			Registry.CurrentUser.CreateSubKey(Class44.string_0).SetValue("HideFileExt", 0);
		}
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x00004685 File Offset: 0x00002885
	public void method_2(bool bool_0)
	{
		if (bool_0)
		{
			Registry.CurrentUser.CreateSubKey(Class44.string_0).SetValue("LaunchTo", 1);
		}
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x000046A9 File Offset: 0x000028A9
	public void method_3(bool bool_0)
	{
		if (bool_0)
		{
			Registry.CurrentUser.CreateSubKey(Class44.string_0).SetValue("HideDrivesWithNoMedia", 0);
		}
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x000046CD File Offset: 0x000028CD
	public void method_4(bool bool_0)
	{
		if (bool_0)
		{
			Registry.CurrentUser.CreateSubKey(Class44.string_0).SetValue("HideMergeConflicts", 0);
		}
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x000046F1 File Offset: 0x000028F1
	public void method_5(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Notepad");
			registryKey.SetValue("fWrap", 1);
			registryKey.SetValue("StatusBar", 1);
		}
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x00004726 File Offset: 0x00002926
	public void method_6(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Classes\\SystemFileAssociations\\video");
			registryKey.SetValue("Treatment", 0);
			registryKey.SetValue("TypeOverlay", "");
		}
	}

	// Token: 0x06000676 RID: 1654 RVA: 0x0000475A File Offset: 0x0000295A
	public void method_7(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\FileSystem").SetValue("LongPathsEnabled", 1);
		}
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x0001DEEC File Offset: 0x0001C0EC
	public void method_8(bool bool_0)
	{
		if (bool_0)
		{
			string text = GClass13.string_7 + "\\InputSwitch.dll";
			GClass0 gclass = new GClass0(text);
			text.smethod_0();
			Process.Start(new ProcessStartInfo
			{
				FileName = "taskkill",
				Arguments = "/f /im explorer.exe",
				WindowStyle = ProcessWindowStyle.Hidden
			}).WaitForExit();
			if (!File.Exists(text + "_bak"))
			{
				File.Copy(text, text + "_bak");
			}
			int[] int_ = new int[]
			{
				116,
				31,
				72,
				99,
				208,
				72,
				141,
				13,
				-1,
				-1,
				3,
				0,
				72,
				193,
				226,
				4,
				72,
				3,
				209,
				72,
				139,
				207,
				72,
				137,
				87,
				88,
				139,
				208,
				232,
				36,
				2,
				0,
				0
			};
			byte[] byte_ = new byte[]
			{
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144,
				144
			};
			try
			{
				gclass.method_0(int_, byte_);
				text.smethod_0();
				Thread.Sleep(100);
				gclass.method_1(text);
				Process.Start("explorer");
			}
			catch
			{
				Process.Start("explorer");
			}
		}
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x0000477E File Offset: 0x0000297E
	public void method_9(bool bool_0)
	{
		if (bool_0)
		{
			Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer").SetValue("EnableAutoTray", 0);
		}
	}

	// Token: 0x06000679 RID: 1657 RVA: 0x0001DFD8 File Offset: 0x0001C1D8
	public void method_10()
	{
		Registry.CurrentUser.DeleteSubKeyTree(GClass2.GClass2_0.String_0 + "\\Explorer\\Modules\\GlobalSettings\\Sizer", false);
		Registry.CurrentUser.CreateSubKey(Class44.string_0).SetValue("HideFileExt", 1);
		if (!GClass2.GClass2_0.String_3.Contains("7") || !GClass2.GClass2_0.String_3.Contains("8"))
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(Class44.string_0, true))
			{
				if (registryKey != null && registryKey.GetValue("LaunchTo") != null)
				{
					registryKey.DeleteValue("LaunchTo");
				}
			}
		}
		using (RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey(Class44.string_0, true))
		{
			if (registryKey2.GetValue("HideDrivesWithNoMedia") != null)
			{
				registryKey2.DeleteValue("HideDrivesWithNoMedia");
			}
		}
		using (RegistryKey registryKey3 = Registry.CurrentUser.OpenSubKey(Class44.string_0, true))
		{
			if (registryKey3.GetValue("HideMergeConflicts") != null)
			{
				registryKey3.DeleteValue("HideMergeConflicts");
			}
		}
		using (RegistryKey registryKey4 = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Notepad", true))
		{
			if (registryKey4 != null && registryKey4.GetValue("fWrap") != null)
			{
				registryKey4.DeleteValue("fWrap");
			}
			if (registryKey4 != null && registryKey4.GetValue("StatusBar") != null)
			{
				registryKey4.DeleteValue("StatusBar");
			}
		}
		using (RegistryKey registryKey5 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\SystemFileAssociations\\video", true))
		{
			registryKey5.SetValue("Treatment", 3);
			if (registryKey5 != null && registryKey5.GetValue("TypeOverlay") != null)
			{
				registryKey5.DeleteValue("TypeOverlay");
			}
		}
		Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\FileSystem").SetValue("LongPathsEnabled", 0);
		using (RegistryKey registryKey6 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Input\\Settings", true))
		{
			if (registryKey6 != null && registryKey6.GetValue("EnableExpressiveInputShellHotkey") != null)
			{
				registryKey6.DeleteValue("EnableExpressiveInputShellHotkey");
			}
		}
		string text = GClass13.string_7 + "\\InputSwitch.dll";
		if (File.Exists(text + "_bak"))
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "taskkill",
				Arguments = "/f /im explorer.exe",
				WindowStyle = ProcessWindowStyle.Hidden
			}).WaitForExit();
			text.smethod_0();
			Thread.Sleep(100);
			File.Delete(text);
			Thread.Sleep(100);
			File.Move(text + "_bak", text);
			Process.Start("explorer");
		}
		using (RegistryKey registryKey7 = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer", true))
		{
			if (registryKey7.GetValue("EnableAutoTray") != null)
			{
				registryKey7.DeleteValue("EnableAutoTray");
			}
		}
	}

	// Token: 0x0600067C RID: 1660 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x0600067D RID: 1661 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x00002BF0 File Offset: 0x00000DF0
	static void smethod_2(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
	{
		RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_3(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x06000680 RID: 1664 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_4(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x06000681 RID: 1665 RVA: 0x00002EED File Offset: 0x000010ED
	static void smethod_5(RegistryKey registryKey_0, string string_1, object object_1, RegistryValueKind registryValueKind_0)
	{
		registryKey_0.SetValue(string_1, object_1, registryValueKind_0);
	}

	// Token: 0x06000682 RID: 1666 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_6(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x06000683 RID: 1667 RVA: 0x00003100 File Offset: 0x00001300
	static ProcessStartInfo smethod_7()
	{
		return new ProcessStartInfo();
	}

	// Token: 0x06000684 RID: 1668 RVA: 0x00003107 File Offset: 0x00001307
	static void smethod_8(ProcessStartInfo processStartInfo_0, string string_1)
	{
		processStartInfo_0.FileName = string_1;
	}

	// Token: 0x06000685 RID: 1669 RVA: 0x00003110 File Offset: 0x00001310
	static void smethod_9(ProcessStartInfo processStartInfo_0, string string_1)
	{
		processStartInfo_0.Arguments = string_1;
	}

	// Token: 0x06000686 RID: 1670 RVA: 0x00003119 File Offset: 0x00001319
	static void smethod_10(ProcessStartInfo processStartInfo_0, ProcessWindowStyle processWindowStyle_0)
	{
		processStartInfo_0.WindowStyle = processWindowStyle_0;
	}

	// Token: 0x06000687 RID: 1671 RVA: 0x00003122 File Offset: 0x00001322
	static Process smethod_11(ProcessStartInfo processStartInfo_0)
	{
		return Process.Start(processStartInfo_0);
	}

	// Token: 0x06000688 RID: 1672 RVA: 0x00003D5D File Offset: 0x00001F5D
	static void smethod_12(Process process_0)
	{
		process_0.WaitForExit();
	}

	// Token: 0x06000689 RID: 1673 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_13(string string_1)
	{
		return File.Exists(string_1);
	}

	// Token: 0x0600068A RID: 1674 RVA: 0x000047D6 File Offset: 0x000029D6
	static void smethod_14(string string_1, string string_2)
	{
		File.Copy(string_1, string_2);
	}

	// Token: 0x0600068B RID: 1675 RVA: 0x00002625 File Offset: 0x00000825
	static void smethod_15(int int_0)
	{
		Thread.Sleep(int_0);
	}

	// Token: 0x0600068C RID: 1676 RVA: 0x00002AA6 File Offset: 0x00000CA6
	static Process smethod_16(string string_1)
	{
		return Process.Start(string_1);
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_17(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_1, bool_0);
	}

	// Token: 0x0600068E RID: 1678 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_18(string string_1, string string_2)
	{
		return string_1.Contains(string_2);
	}

	// Token: 0x0600068F RID: 1679 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_19(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_1, bool_0);
	}

	// Token: 0x06000690 RID: 1680 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_20(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.GetValue(string_1);
	}

	// Token: 0x06000691 RID: 1681 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_21(RegistryKey registryKey_0, string string_1)
	{
		registryKey_0.DeleteValue(string_1);
	}

	// Token: 0x06000692 RID: 1682 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_22(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000693 RID: 1683 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_23(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.GetValue(string_1);
	}

	// Token: 0x06000694 RID: 1684 RVA: 0x00002F15 File Offset: 0x00001115
	static void smethod_24(string string_1)
	{
		File.Delete(string_1);
	}

	// Token: 0x06000695 RID: 1685 RVA: 0x00003E1C File Offset: 0x0000201C
	static void smethod_25(string string_1, string string_2)
	{
		File.Move(string_1, string_2);
	}

	// Token: 0x06000696 RID: 1686 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_26()
	{
		return new object();
	}

	// Token: 0x04000295 RID: 661
	private static volatile Class44 class44_0;

	// Token: 0x04000296 RID: 662
	private static readonly object object_0 = new object();

	// Token: 0x04000297 RID: 663
	private static readonly string string_0 = GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced";
}
