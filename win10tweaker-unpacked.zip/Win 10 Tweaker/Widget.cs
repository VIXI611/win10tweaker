﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.Devices;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x020000E9 RID: 233
public partial class Widget : Form
{
	// Token: 0x06000B9D RID: 2973
	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern bool DestroyIcon(IntPtr intptr_0);

	// Token: 0x17000099 RID: 153
	// (get) Token: 0x06000B9E RID: 2974 RVA: 0x00006974 File Offset: 0x00004B74
	protected virtual CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ExStyle |= 128;
			return createParams;
		}
	}

	// Token: 0x1700009A RID: 154
	// (get) Token: 0x06000B9F RID: 2975 RVA: 0x0000698E File Offset: 0x00004B8E
	private List<ToolStripMenuItem> List_0
	{
		get
		{
			return this.toolStripMenuItem_10.DropDownItems.OfType<ToolStripMenuItem>().ToList<ToolStripMenuItem>();
		}
	}

	// Token: 0x1700009B RID: 155
	// (get) Token: 0x06000BA0 RID: 2976 RVA: 0x000069A5 File Offset: 0x00004BA5
	private List<ToolStripMenuItem> List_1
	{
		get
		{
			return this.toolStripMenuItem_11.DropDownItems.OfType<ToolStripMenuItem>().ToList<ToolStripMenuItem>();
		}
	}

	// Token: 0x06000BA1 RID: 2977 RVA: 0x00039530 File Offset: 0x00037730
	public Widget(Form1 form1_1)
	{
		this.InitializeComponent();
		this.form1_0 = form1_1;
		base.MouseWheel += this.method_0;
		this.toolStripMenuItem_10.DropDownItems.OfType<ToolStripMenuItem>().ToList<ToolStripMenuItem>();
		this.List_0.ForEach(new Action<ToolStripMenuItem>(this.method_2));
		this.List_1.ForEach(new Action<ToolStripMenuItem>(this.method_3));
	}

	// Token: 0x06000BA2 RID: 2978 RVA: 0x000395A8 File Offset: 0x000377A8
	private void method_0(object sender, MouseEventArgs e)
	{
		if (e.Delta > 0)
		{
			base.Opacity += 0.05;
			return;
		}
		if (base.Opacity > 0.4)
		{
			base.Opacity -= 0.05;
		}
	}

	// Token: 0x06000BA3 RID: 2979 RVA: 0x000395FC File Offset: 0x000377FC
	private void Widget_Load(object sender, EventArgs e)
	{
		Widget.Struct75 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.widget_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Widget.Struct75>(ref @struct);
	}

	// Token: 0x06000BA4 RID: 2980 RVA: 0x00039634 File Offset: 0x00037834
	private void ProgressBar_MouseDown(object sender, MouseEventArgs e)
	{
		this.ProgressBar.Capture = false;
		base.Capture = false;
		Message message = Message.Create(this.method_5(), 161, new IntPtr(2), IntPtr.Zero);
		base.WndProc(ref message);
		if (e.Button == MouseButtons.Left && e.Clicks == 2)
		{
			GClass6.GClass6_0.method_14(string.Concat(new string[]
			{
				"Taskkill /f /im \"",
				GClass2.GClass2_0.String_10,
				"\" && \"",
				GClass2.GClass2_0.String_11,
				"\""
			}));
		}
		if (e.Button == MouseButtons.Middle)
		{
			this.method_1();
		}
	}

	// Token: 0x06000BA5 RID: 2981 RVA: 0x000396EC File Offset: 0x000378EC
	private void Widget_LocationChanged(object sender, EventArgs e)
	{
		Form form = Application.OpenForms["Shade"];
		try
		{
			form.Location = base.Location;
			form.TopMost = true;
		}
		catch
		{
		}
	}

	// Token: 0x06000BA6 RID: 2982 RVA: 0x00039734 File Offset: 0x00037934
	private void toolStripMenuItem_8_Click(object sender, EventArgs e)
	{
		GClass2.GClass2_0.RegistryKey_0.SetValue("RAM Cache Cleaner", "false");
		this.toolStripMenuItem_8.Checked = true;
		this.toolStripMenuItem_9.Checked = false;
		this.toolStripMenuItem_6.Checked = true;
		this.toolStripMenuItem_7.Checked = false;
	}

	// Token: 0x06000BA7 RID: 2983 RVA: 0x0003978C File Offset: 0x0003798C
	private void toolStripMenuItem_9_Click(object sender, EventArgs e)
	{
		GClass2.GClass2_0.RegistryKey_0.SetValue("RAM Cache Cleaner", "true");
		this.toolStripMenuItem_8.Checked = false;
		this.toolStripMenuItem_9.Checked = true;
		this.toolStripMenuItem_6.Checked = false;
		this.toolStripMenuItem_7.Checked = true;
	}

	// Token: 0x06000BA8 RID: 2984 RVA: 0x000069BC File Offset: 0x00004BBC
	private void toolStripMenuItem_0_Click(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x06000BA9 RID: 2985 RVA: 0x000397E4 File Offset: 0x000379E4
	public void toolStripMenuItem_1_Click(object sender, EventArgs e)
	{
		Widget.Struct76 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.widget_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Widget.Struct76>(ref @struct);
	}

	// Token: 0x06000BAA RID: 2986 RVA: 0x000069C4 File Offset: 0x00004BC4
	private void toolStripMenuItem_2_Click(object sender, EventArgs e)
	{
		Application.Exit();
	}

	// Token: 0x06000BAB RID: 2987 RVA: 0x0003981C File Offset: 0x00037A1C
	private void notifyIcon_0_MouseDown(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.notifyIcon_0.Visible = false;
			GClass6.GClass6_0.method_14(string.Concat(new string[]
			{
				"Taskkill /f /im \"",
				GClass2.GClass2_0.String_10,
				"\" && \"",
				GClass2.GClass2_0.String_11,
				"\""
			}));
		}
		if (e.Button == MouseButtons.Middle)
		{
			this.method_1();
		}
	}

	// Token: 0x06000BAC RID: 2988 RVA: 0x000069CB File Offset: 0x00004BCB
	private void toolStripMenuItem_6_Click(object sender, EventArgs e)
	{
		GClass2.GClass2_0.RegistryKey_0.SetValue("RAM Cache Cleaner", "false");
		this.toolStripMenuItem_6.Checked = true;
		this.toolStripMenuItem_7.Checked = false;
	}

	// Token: 0x06000BAD RID: 2989 RVA: 0x000069FE File Offset: 0x00004BFE
	private void toolStripMenuItem_7_Click(object sender, EventArgs e)
	{
		GClass2.GClass2_0.RegistryKey_0.SetValue("RAM Cache Cleaner", "true");
		this.toolStripMenuItem_6.Checked = false;
		this.toolStripMenuItem_7.Checked = true;
	}

	// Token: 0x06000BAE RID: 2990 RVA: 0x000398A0 File Offset: 0x00037AA0
	private void toolStripMenuItem_5_Click(object sender, EventArgs e)
	{
		this.notifyIcon_0.Visible = false;
		GClass6.GClass6_0.method_14(string.Concat(new string[]
		{
			"Taskkill /f /im \"",
			GClass2.GClass2_0.String_10,
			"\" && \"",
			GClass2.GClass2_0.String_10,
			"\" widget"
		}));
	}

	// Token: 0x06000BAF RID: 2991 RVA: 0x000069BC File Offset: 0x00004BBC
	private void toolStripMenuItem_3_Click(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x06000BB0 RID: 2992 RVA: 0x00006A31 File Offset: 0x00004C31
	private void toolStripMenuItem_4_Click(object sender, EventArgs e)
	{
		this.notifyIcon_0.Visible = false;
		Application.Exit();
	}

	// Token: 0x06000BB1 RID: 2993 RVA: 0x00039900 File Offset: 0x00037B00
	private void method_1()
	{
		Widget.Struct77 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.widget_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Widget.Struct77>(ref @struct);
	}

	// Token: 0x06000BB2 RID: 2994 RVA: 0x00006A44 File Offset: 0x00004C44
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06000BB4 RID: 2996 RVA: 0x00006A63 File Offset: 0x00004C63
	[CompilerGenerated]
	internal static void smethod_0(List<ToolStripMenuItem> list_0)
	{
		list_0.ForEach(new Action<ToolStripMenuItem>(Widget.<>c.<>9.method_0));
	}

	// Token: 0x06000BB5 RID: 2997 RVA: 0x0003A398 File Offset: 0x00038598
	[CompilerGenerated]
	private void method_2(ToolStripMenuItem toolStripMenuItem_12)
	{
		Widget.Class78 @class = new Widget.Class78();
		@class.widget_0 = this;
		@class.toolStripMenuItem_0 = toolStripMenuItem_12;
		@class.toolStripMenuItem_0.Click += @class.method_0;
	}

	// Token: 0x06000BB6 RID: 2998 RVA: 0x0003A3D0 File Offset: 0x000385D0
	[CompilerGenerated]
	private void method_3(ToolStripMenuItem toolStripMenuItem_12)
	{
		Widget.Class79 @class = new Widget.Class79();
		@class.widget_0 = this;
		@class.toolStripMenuItem_0 = toolStripMenuItem_12;
		@class.toolStripMenuItem_0.Click += @class.method_0;
	}

	// Token: 0x06000BB7 RID: 2999 RVA: 0x0003A408 File Offset: 0x00038608
	[CompilerGenerated]
	private void method_4()
	{
		ulong num = new ComputerInfo().TotalPhysicalMemory / 1048576UL;
		ulong num2 = new ComputerInfo().AvailablePhysicalMemory / 1048576UL;
		int num3 = (int)(100UL - num2 * 100UL / num);
		this.ProgressBar.method_0(num3);
		if (num3 >= this.int_0)
		{
			Form0.smethod_303();
		}
	}

	// Token: 0x06000BB8 RID: 3000 RVA: 0x0003A474 File Offset: 0x00038674
	[CompilerGenerated]
	internal static Color smethod_1()
	{
		if (!GClass2.GClass2_0.String_3.Contains("10"))
		{
			return Color.Black;
		}
		Color result;
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize"))
		{
			object value = registryKey.GetValue("SystemUsesLightTheme");
			result = ((!(((value != null) ? value.ToString() : null) == "1")) ? Color.Black : Color.White);
		}
		return result;
	}

	// Token: 0x06000BB9 RID: 3001 RVA: 0x0000414F File Offset: 0x0000234F
	static int smethod_2(CreateParams createParams_0)
	{
		return createParams_0.ExStyle;
	}

	// Token: 0x06000BBA RID: 3002 RVA: 0x00004157 File Offset: 0x00002357
	static void smethod_3(CreateParams createParams_0, int int_1)
	{
		createParams_0.ExStyle = int_1;
	}

	// Token: 0x06000BBB RID: 3003 RVA: 0x00006A8A File Offset: 0x00004C8A
	static ToolStripItemCollection smethod_4(ToolStripDropDownItem toolStripDropDownItem_0)
	{
		return toolStripDropDownItem_0.DropDownItems;
	}

	// Token: 0x06000BBC RID: 3004 RVA: 0x00005299 File Offset: 0x00003499
	static void smethod_5(Control control_0, MouseEventHandler mouseEventHandler_0)
	{
		control_0.MouseWheel += mouseEventHandler_0;
	}

	// Token: 0x06000BBD RID: 3005 RVA: 0x000052A2 File Offset: 0x000034A2
	static int smethod_6(MouseEventArgs mouseEventArgs_0)
	{
		return mouseEventArgs_0.Delta;
	}

	// Token: 0x06000BBE RID: 3006 RVA: 0x000043B4 File Offset: 0x000025B4
	static double smethod_7(Form form_0)
	{
		return form_0.Opacity;
	}

	// Token: 0x06000BBF RID: 3007 RVA: 0x00002ADC File Offset: 0x00000CDC
	static void smethod_8(Form form_0, double double_0)
	{
		form_0.Opacity = double_0;
	}

	// Token: 0x06000BC0 RID: 3008 RVA: 0x00002AF5 File Offset: 0x00000CF5
	static void smethod_9(Control control_0, bool bool_1)
	{
		control_0.Capture = bool_1;
	}

	// Token: 0x06000BC1 RID: 3009 RVA: 0x00002AFE File Offset: 0x00000CFE
	static void smethod_10(Control control_0, bool bool_1)
	{
		control_0.Capture = bool_1;
	}

	// Token: 0x06000BC2 RID: 3010 RVA: 0x00002B07 File Offset: 0x00000D07
	IntPtr method_5()
	{
		return base.Handle;
	}

	// Token: 0x06000BC3 RID: 3011 RVA: 0x000029CD File Offset: 0x00000BCD
	static FormCollection smethod_11()
	{
		return Application.OpenForms;
	}

	// Token: 0x06000BC4 RID: 3012 RVA: 0x000057C2 File Offset: 0x000039C2
	static Form smethod_12(FormCollection formCollection_0, string string_0)
	{
		return formCollection_0[string_0];
	}

	// Token: 0x06000BC5 RID: 3013 RVA: 0x00006A92 File Offset: 0x00004C92
	static Point smethod_13(Form form_0)
	{
		return form_0.Location;
	}

	// Token: 0x06000BC6 RID: 3014 RVA: 0x00006A9A File Offset: 0x00004C9A
	static void smethod_14(Form form_0, Point point_0)
	{
		form_0.Location = point_0;
	}

	// Token: 0x06000BC7 RID: 3015 RVA: 0x00006AA3 File Offset: 0x00004CA3
	static void smethod_15(Form form_0, bool bool_1)
	{
		form_0.TopMost = bool_1;
	}

	// Token: 0x06000BC8 RID: 3016 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_16(RegistryKey registryKey_0, string string_0, object object_0)
	{
		registryKey_0.SetValue(string_0, object_0);
	}

	// Token: 0x06000BC9 RID: 3017 RVA: 0x00006AAC File Offset: 0x00004CAC
	static void smethod_17(ToolStripMenuItem toolStripMenuItem_12, bool bool_1)
	{
		toolStripMenuItem_12.Checked = bool_1;
	}

	// Token: 0x06000BCA RID: 3018 RVA: 0x000069C4 File Offset: 0x00004BC4
	static void smethod_18()
	{
		Application.Exit();
	}

	// Token: 0x06000BCB RID: 3019 RVA: 0x00002D75 File Offset: 0x00000F75
	static MouseButtons smethod_19(MouseEventArgs mouseEventArgs_0)
	{
		return mouseEventArgs_0.Button;
	}

	// Token: 0x06000BCC RID: 3020 RVA: 0x00006AB5 File Offset: 0x00004CB5
	static void smethod_20(NotifyIcon notifyIcon_1, bool bool_1)
	{
		notifyIcon_1.Visible = bool_1;
	}

	// Token: 0x06000BCD RID: 3021 RVA: 0x0000298C File Offset: 0x00000B8C
	static string smethod_21(string[] string_0)
	{
		return string.Concat(string_0);
	}

	// Token: 0x06000BCE RID: 3022 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_22(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000BCF RID: 3023 RVA: 0x00002A4C File Offset: 0x00000C4C
	static Container smethod_23()
	{
		return new Container();
	}

	// Token: 0x06000BD0 RID: 3024 RVA: 0x00006ABE File Offset: 0x00004CBE
	static ContextMenuStrip smethod_24(IContainer icontainer_1)
	{
		return new ContextMenuStrip(icontainer_1);
	}

	// Token: 0x06000BD1 RID: 3025 RVA: 0x00006AC6 File Offset: 0x00004CC6
	static ToolStripMenuItem smethod_25()
	{
		return new ToolStripMenuItem();
	}

	// Token: 0x06000BD2 RID: 3026 RVA: 0x00006ACD File Offset: 0x00004CCD
	static ToolStripSeparator smethod_26()
	{
		return new ToolStripSeparator();
	}

	// Token: 0x06000BD3 RID: 3027 RVA: 0x00006AD4 File Offset: 0x00004CD4
	static NotifyIcon smethod_27(IContainer icontainer_1)
	{
		return new NotifyIcon(icontainer_1);
	}

	// Token: 0x06000BD4 RID: 3028 RVA: 0x00002A8D File Offset: 0x00000C8D
	static void smethod_28(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x06000BD5 RID: 3029 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_29(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x06000BD6 RID: 3030 RVA: 0x00006ADC File Offset: 0x00004CDC
	static ToolStripItemCollection smethod_30(ToolStrip toolStrip_0)
	{
		return toolStrip_0.Items;
	}

	// Token: 0x06000BD7 RID: 3031 RVA: 0x00006AE4 File Offset: 0x00004CE4
	static void smethod_31(ToolStripItemCollection toolStripItemCollection_0, ToolStripItem[] toolStripItem_0)
	{
		toolStripItemCollection_0.AddRange(toolStripItem_0);
	}

	// Token: 0x06000BD8 RID: 3032 RVA: 0x00006AED File Offset: 0x00004CED
	static void smethod_32(Control control_0, string string_0)
	{
		control_0.Name = string_0;
	}

	// Token: 0x06000BD9 RID: 3033 RVA: 0x00006AF6 File Offset: 0x00004CF6
	static void smethod_33(ToolStripItem toolStripItem_0, EventHandler eventHandler_0)
	{
		toolStripItem_0.Click += eventHandler_0;
	}

	// Token: 0x06000BDA RID: 3034 RVA: 0x00006AFF File Offset: 0x00004CFF
	static ComputerInfo smethod_34()
	{
		return new ComputerInfo();
	}

	// Token: 0x06000BDB RID: 3035 RVA: 0x00006B06 File Offset: 0x00004D06
	static ulong smethod_35(ComputerInfo computerInfo_0)
	{
		return computerInfo_0.TotalPhysicalMemory;
	}

	// Token: 0x06000BDC RID: 3036 RVA: 0x00006B0E File Offset: 0x00004D0E
	static ulong smethod_36(ComputerInfo computerInfo_0)
	{
		return computerInfo_0.AvailablePhysicalMemory;
	}

	// Token: 0x06000BDD RID: 3037 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_37(string string_0, string string_1)
	{
		return string_0.Contains(string_1);
	}

	// Token: 0x06000BDE RID: 3038 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_38(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.OpenSubKey(string_0);
	}

	// Token: 0x06000BDF RID: 3039 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_39(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x06000BE0 RID: 3040 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_40(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x06000BE1 RID: 3041 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_41(string string_0, string string_1)
	{
		return string_0 == string_1;
	}

	// Token: 0x040004A1 RID: 1185
	private readonly Form1 form1_0;

	// Token: 0x040004A2 RID: 1186
	public bool bool_0;

	// Token: 0x040004A3 RID: 1187
	private int int_0;

	// Token: 0x020000EA RID: 234
	[CompilerGenerated]
	private sealed class Class78
	{
		// Token: 0x06000BE3 RID: 3043 RVA: 0x0003A4FC File Offset: 0x000386FC
		internal void method_0(object sender, EventArgs e)
		{
			Widget.smethod_0(this.widget_0.List_0);
			this.toolStripMenuItem_0.Checked = true;
			string value = this.toolStripMenuItem_0.Name.Replace("Ram", "");
			GClass2.GClass2_0.RegistryKey_0.SetValue("RAM Auto Cleaner", value);
			this.widget_0.int_0 = Convert.ToInt32(value);
		}

		// Token: 0x06000BE4 RID: 3044 RVA: 0x00006AAC File Offset: 0x00004CAC
		static void smethod_0(ToolStripMenuItem toolStripMenuItem_1, bool bool_0)
		{
			toolStripMenuItem_1.Checked = bool_0;
		}

		// Token: 0x06000BE5 RID: 3045 RVA: 0x00006B16 File Offset: 0x00004D16
		static string smethod_1(ToolStripItem toolStripItem_0)
		{
			return toolStripItem_0.Name;
		}

		// Token: 0x06000BE6 RID: 3046 RVA: 0x000033D1 File Offset: 0x000015D1
		static string smethod_2(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000BE7 RID: 3047 RVA: 0x00002C41 File Offset: 0x00000E41
		static void smethod_3(RegistryKey registryKey_0, string string_0, object object_0)
		{
			registryKey_0.SetValue(string_0, object_0);
		}

		// Token: 0x06000BE8 RID: 3048 RVA: 0x00006B1E File Offset: 0x00004D1E
		static int smethod_4(string string_0)
		{
			return Convert.ToInt32(string_0);
		}

		// Token: 0x040004C8 RID: 1224
		public ToolStripMenuItem toolStripMenuItem_0;

		// Token: 0x040004C9 RID: 1225
		public Widget widget_0;
	}

	// Token: 0x020000EB RID: 235
	[CompilerGenerated]
	private sealed class Class79
	{
		// Token: 0x06000BEA RID: 3050 RVA: 0x0003A568 File Offset: 0x00038768
		internal void method_0(object sender, EventArgs e)
		{
			Widget.smethod_0(this.widget_0.List_1);
			this.toolStripMenuItem_0.Checked = true;
			string value = this.toolStripMenuItem_0.Name.Replace("Ram", "").Replace("00", "0");
			GClass2.GClass2_0.RegistryKey_0.SetValue("RAM Auto Cleaner", value);
			this.widget_0.int_0 = Convert.ToInt32(value);
		}

		// Token: 0x06000BEB RID: 3051 RVA: 0x00006AAC File Offset: 0x00004CAC
		static void smethod_0(ToolStripMenuItem toolStripMenuItem_1, bool bool_0)
		{
			toolStripMenuItem_1.Checked = bool_0;
		}

		// Token: 0x06000BEC RID: 3052 RVA: 0x00006B16 File Offset: 0x00004D16
		static string smethod_1(ToolStripItem toolStripItem_0)
		{
			return toolStripItem_0.Name;
		}

		// Token: 0x06000BED RID: 3053 RVA: 0x000033D1 File Offset: 0x000015D1
		static string smethod_2(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000BEE RID: 3054 RVA: 0x00002C41 File Offset: 0x00000E41
		static void smethod_3(RegistryKey registryKey_0, string string_0, object object_0)
		{
			registryKey_0.SetValue(string_0, object_0);
		}

		// Token: 0x06000BEF RID: 3055 RVA: 0x00006B1E File Offset: 0x00004D1E
		static int smethod_4(string string_0)
		{
			return Convert.ToInt32(string_0);
		}

		// Token: 0x040004CA RID: 1226
		public ToolStripMenuItem toolStripMenuItem_0;

		// Token: 0x040004CB RID: 1227
		public Widget widget_0;
	}

	// Token: 0x020000ED RID: 237
	[CompilerGenerated]
	private sealed class Class80
	{
		// Token: 0x06000BFA RID: 3066 RVA: 0x0003A5E4 File Offset: 0x000387E4
		internal bool method_0(ToolStripMenuItem toolStripMenuItem_0)
		{
			return toolStripMenuItem_0.Checked = toolStripMenuItem_0.Name.Contains(this.string_0);
		}

		// Token: 0x06000BFB RID: 3067 RVA: 0x0003A5E4 File Offset: 0x000387E4
		internal bool method_1(ToolStripMenuItem toolStripMenuItem_0)
		{
			return toolStripMenuItem_0.Checked = toolStripMenuItem_0.Name.Contains(this.string_0);
		}

		// Token: 0x06000BFC RID: 3068 RVA: 0x00006B16 File Offset: 0x00004D16
		static string smethod_0(ToolStripItem toolStripItem_0)
		{
			return toolStripItem_0.Name;
		}

		// Token: 0x06000BFD RID: 3069 RVA: 0x00002A20 File Offset: 0x00000C20
		static bool smethod_1(string string_1, string string_2)
		{
			return string_1.Contains(string_2);
		}

		// Token: 0x06000BFE RID: 3070 RVA: 0x00006AAC File Offset: 0x00004CAC
		static void smethod_2(ToolStripMenuItem toolStripMenuItem_0, bool bool_0)
		{
			toolStripMenuItem_0.Checked = bool_0;
		}

		// Token: 0x040004D0 RID: 1232
		public string string_0;
	}
}
