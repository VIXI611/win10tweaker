﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;

namespace Win_10_Tweaker
{
	// Token: 0x020000BF RID: 191
	[DataContract]
	public class ExtensionGroup
	{
		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060009B9 RID: 2489 RVA: 0x00005636 File Offset: 0x00003836
		// (set) Token: 0x060009BA RID: 2490 RVA: 0x0000563E File Offset: 0x0000383E
		[DataMember]
		public string Extension { get; set; }

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060009BB RID: 2491 RVA: 0x00005647 File Offset: 0x00003847
		// (set) Token: 0x060009BC RID: 2492 RVA: 0x0000564F File Offset: 0x0000384F
		[DataMember]
		public string ExtensionClass { get; set; }

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060009BD RID: 2493 RVA: 0x00005658 File Offset: 0x00003858
		// (set) Token: 0x060009BE RID: 2494 RVA: 0x00005660 File Offset: 0x00003860
		[DataMember]
		public string ExtensionIcon { get; set; }

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060009BF RID: 2495 RVA: 0x00005669 File Offset: 0x00003869
		// (set) Token: 0x060009C0 RID: 2496 RVA: 0x00005671 File Offset: 0x00003871
		[DataMember]
		public string ExecutablePath { get; set; }

		// Token: 0x040003D1 RID: 977
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040003D2 RID: 978
		[CompilerGenerated]
		private string string_1;

		// Token: 0x040003D3 RID: 979
		[CompilerGenerated]
		private string string_2;

		// Token: 0x040003D4 RID: 980
		[CompilerGenerated]
		private string string_3;
	}
}
