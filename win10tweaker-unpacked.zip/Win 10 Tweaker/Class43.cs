﻿using System;
using System.Linq;
using System.Threading;

// Token: 0x02000081 RID: 129
internal class Class43
{
	// Token: 0x17000031 RID: 49
	// (get) Token: 0x0600065C RID: 1628 RVA: 0x0001DC98 File Offset: 0x0001BE98
	public static Class43 Class43_0
	{
		get
		{
			if (Class43.class43_0 == null)
			{
				object obj = Class43.object_0;
				lock (obj)
				{
					if (Class43.class43_0 == null)
					{
						Class43.class43_0 = new Class43();
					}
				}
			}
			return Class43.class43_0;
		}
	}

	// Token: 0x0600065D RID: 1629 RVA: 0x000045CB File Offset: 0x000027CB
	public void method_0()
	{
		this.string_0.ToList<string>().ForEach(new Action<string>(Class43.<>c.<>9.method_0));
	}

	// Token: 0x0600065E RID: 1630 RVA: 0x000045FC File Offset: 0x000027FC
	public void method_1()
	{
		this.string_0.ToList<string>().ForEach(new Action<string>(Class43.<>c.<>9.method_1));
	}

	// Token: 0x06000661 RID: 1633 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_2()
	{
		return new object();
	}

	// Token: 0x0400028F RID: 655
	private static volatile Class43 class43_0;

	// Token: 0x04000290 RID: 656
	private static readonly object object_0 = new object();

	// Token: 0x04000291 RID: 657
	private readonly string[] string_0 = new string[]
	{
		"SOFTWARE\\Classes\\AudioCD\\shell\\play",
		"SOFTWARE\\Classes\\SystemFileAssociations\\audio\\shell\\Enqueue",
		"SOFTWARE\\Classes\\SystemFileAssociations\\audio\\shell\\Play",
		"SOFTWARE\\Classes\\SystemFileAssociations\\video\\shell\\Enqueue",
		"SOFTWARE\\Classes\\SystemFileAssociations\\video\\shell\\Play",
		"SOFTWARE\\Classes\\SystemFileAssociations\\Directory.Audio\\shell\\Enqueue",
		"SOFTWARE\\Classes\\SystemFileAssociations\\Directory.Audio\\shell\\Play",
		"SOFTWARE\\Classes\\SystemFileAssociations\\Directory.Image\\shell\\Enqueue",
		"SOFTWARE\\Classes\\SystemFileAssociations\\Directory.Image\\shell\\Play",
		"SOFTWARE\\Classes\\SystemFileAssociations\\Directory.Video\\shell\\Enqueue",
		"SOFTWARE\\Classes\\SystemFileAssociations\\Directory.Video\\shell\\Play",
		"SOFTWARE\\Classes\\WMP11.AssocFile.MP3\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.WAV\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.MPEG\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.AVI\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.3GP\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.MKA\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.MKV\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.MP4\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.MOV\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.M2TS\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.M4A\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.WMA\\shell\\Enqueue",
		"SOFTWARE\\Classes\\WMP11.AssocFile.WMV\\shell\\Enqueue"
	};
}
