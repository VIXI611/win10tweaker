﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000085 RID: 133
internal class Class46
{
	// Token: 0x17000034 RID: 52
	// (get) Token: 0x060006A8 RID: 1704 RVA: 0x0001E638 File Offset: 0x0001C838
	public static Class46 Class46_0
	{
		get
		{
			if (Class46.class46_0 == null)
			{
				object obj = Class46.object_0;
				lock (obj)
				{
					if (Class46.class46_0 == null)
					{
						Class46.class46_0 = new Class46();
					}
				}
			}
			return Class46.class46_0;
		}
	}

	// Token: 0x060006A9 RID: 1705 RVA: 0x0001E698 File Offset: 0x0001C898
	public void method_0()
	{
		try
		{
			if (GClass2.GClass2_0.String_3.Contains("10"))
			{
				GClass6.GClass6_0.method_14("taskkill /f /im OneDrive.exe & %systemroot%\\" + ((!GClass2.GClass2_0.Boolean_0) ? "System32" : "SysWOW64") + "\\OneDriveSetup.exe /uninstall");
				if (Directory.Exists(GClass13.string_2 + "\\OneDrive"))
				{
					GClass6.GClass6_0.method_14("rd \"%userprofile%\\OneDrive\" /s /q");
				}
				string path = GClass13.string_11 + "\\Microsoft OneDrive";
				if (Directory.Exists(path))
				{
					Directory.Delete(path, true);
				}
				string path2 = GClass13.string_12 + "\\OneDrive";
				if (Directory.Exists(path2))
				{
					Directory.Delete(path2, true);
				}
				Registry.ClassesRoot.DeleteSubKeyTree("CLSID\\{018D5C66-4533-4307-9B53-224DE2ED1FE6}", false);
				Registry.ClassesRoot.DeleteSubKeyTree("Wow6432Node\\CLSID\\{018D5C66-4533-4307-9B53-224DE2ED1FE6}", false);
				GClass6.GClass6_0.method_14("del %systemroot%\\system32\\tasks\\OneDrive* /q /f");
				using (RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Run"))
				{
					if (registryKey != null && registryKey.GetValue("OneDrive") != null)
					{
						registryKey.DeleteValue("OneDrive");
					}
					if (registryKey != null && registryKey.GetValue("OneDriveSetup") != null)
					{
						registryKey.DeleteValue("OneDriveSetup");
					}
				}
				GClass4.smethod_9("HKLM\\SOFTWARE\\Microsoft\\OneDrive!PreventNetworkTrafficPreUserSignIn", "1", RegistryValueKind.DWord);
			}
			else
			{
				string text = GClass13.string_7 + "\\SkyDrive.exe";
				text.smethod_0();
				Process.GetProcessesByName("SkyDrive").ToList<Process>().ForEach(new Action<Process>(Class46.<>c.<>9.method_0));
				File.Move(text, text + "_fucked");
				GClass14.smethod_0("cmd.exe /c reg delete HKEY_CLASSES_ROOT\\CLSID\\{8E74D236-7F35-4720-B138-1FED0B85EA75} /f", false);
			}
		}
		catch
		{
		}
	}

	// Token: 0x060006AA RID: 1706 RVA: 0x0001E890 File Offset: 0x0001CA90
	public void method_1()
	{
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			GClass6.GClass6_0.method_14("taskkill /f /im OneDrive.exe & %systemroot%\\" + (GClass2.GClass2_0.Boolean_0 ? "SysWOW64" : "System32") + "\\OneDriveSetup.exe");
			return;
		}
		try
		{
			GClass6.GClass6_0.method_14("reg add \"HKCR\\CLSID\\{8E74D236-7F35-4720-B138-1FED0B85EA75}\\ShellFolder\" /v Attributes /t REG_DWORD /d 0xf080004d");
		}
		catch
		{
		}
		try
		{
			GClass6.GClass6_0.method_14("reg add \"HKCR\\CLSID\\{8E74D236-7F35-4720-B138-1FED0B85EA75}\\ShellFolder\" /v FolderValueFlags /t REG_DWORD /d 0x00000028");
		}
		catch
		{
		}
		try
		{
			GClass6.GClass6_0.method_14("ren %systemroot%\\System32\\SkyDrive.exe_fucked SkyDrive.exe");
		}
		catch
		{
		}
	}

	// Token: 0x060006AD RID: 1709 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060006AE RID: 1710 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060006AF RID: 1711 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_2(string string_0, string string_1)
	{
		return string_0.Contains(string_1);
	}

	// Token: 0x060006B0 RID: 1712 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_3(string string_0, string string_1, string string_2)
	{
		return string_0 + string_1 + string_2;
	}

	// Token: 0x060006B1 RID: 1713 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_4(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x00002EE5 File Offset: 0x000010E5
	static bool smethod_5(string string_0)
	{
		return Directory.Exists(string_0);
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x000036B7 File Offset: 0x000018B7
	static void smethod_6(string string_0, bool bool_0)
	{
		Directory.Delete(string_0, bool_0);
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_7(RegistryKey registryKey_0, string string_0, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_0, bool_0);
	}

	// Token: 0x060006B5 RID: 1717 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_8(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.OpenSubKey(string_0);
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_9(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_10(RegistryKey registryKey_0, string string_0)
	{
		registryKey_0.DeleteValue(string_0);
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_11(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x000033EC File Offset: 0x000015EC
	static Process[] smethod_12(string string_0)
	{
		return Process.GetProcessesByName(string_0);
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x00003E1C File Offset: 0x0000201C
	static void smethod_13(string string_0, string string_1)
	{
		File.Move(string_0, string_1);
	}

	// Token: 0x060006BB RID: 1723 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_14()
	{
		return new object();
	}

	// Token: 0x0400029A RID: 666
	private static volatile Class46 class46_0;

	// Token: 0x0400029B RID: 667
	private static readonly object object_0 = new object();
}
