﻿using System;
using System.Text;
using Microsoft.Win32;

// Token: 0x02000056 RID: 86
public class GClass4 : GClass3
{
	// Token: 0x06000411 RID: 1041 RVA: 0x00003AB4 File Offset: 0x00001CB4
	public GClass4(GClass5 gclass5_0 = null)
	{
		gclass5_0 = (gclass5_0 ?? new GClass5(true, false));
		if (this.ginterface0_0.OpenLocalMachineGPO(gclass5_0.UInt32_0) != 0U)
		{
			throw new Exception("Unable to open local machine GPO");
		}
		this.bool_0 = true;
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x00018664 File Offset: 0x00016864
	public static void smethod_9(string string_0, string string_1, RegistryValueKind registryValueKind_0 = RegistryValueKind.DWord)
	{
		string name;
		GEnum0 genum0_;
		string text = GClass4.smethod_10(string_0, out name, out genum0_);
		try
		{
			GClass4 gclass = new GClass4(null);
			using (RegistryKey registryKey = gclass.method_1(genum0_))
			{
				if (string_1 == null)
				{
					using (RegistryKey registryKey2 = registryKey.OpenSubKey(text, true))
					{
						if (registryKey2 != null)
						{
							registryKey2.DeleteValue(name);
						}
						goto IL_65;
					}
				}
				using (RegistryKey registryKey3 = registryKey.CreateSubKey(text))
				{
					registryKey3.SetValue(name, string_1, registryValueKind_0);
				}
				IL_65:;
			}
			gclass.method_0();
		}
		catch
		{
		}
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x00018724 File Offset: 0x00016924
	private static string smethod_10(string string_0, out string string_1, out GEnum0 genum0_0)
	{
		string[] array = string_0.Split(new char[]
		{
			'!'
		});
		string text = array[0];
		string text2 = text.Substring(0, text.IndexOf('\\'));
		text = text.Substring(text.IndexOf('\\') + 1);
		string_1 = array[1];
		if (!text2.Equals("HKLM", StringComparison.OrdinalIgnoreCase) && !text2.Equals("HKEY_LOCAL_MACHINE", StringComparison.OrdinalIgnoreCase))
		{
			genum0_0 = GEnum0.User;
		}
		else
		{
			genum0_0 = GEnum0.Machine;
		}
		return text;
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x00018794 File Offset: 0x00016994
	public override string \u206F\u206B\u206B\u202B\u202E\u206B\u200C\u200B\u202B\u206C\u202D\u202C\u206A\u200F\u202A\u200C\u200C\u206E\u200C\u206C\u200D\u202E\u202B\u200C\u200E\u206C\u206D\u200D\u200C\u200D\u200F\u200D\u200D\u200C\u202B\u206A\u200F\u200E\u206E\u206E\u202E(GEnum0 genum0_0)
	{
		StringBuilder stringBuilder = new StringBuilder(1024);
		this.ginterface0_0.GetFileSysPath((uint)genum0_0, stringBuilder, 1024);
		return stringBuilder.ToString();
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x00003A84 File Offset: 0x00001C84
	static Exception smethod_11(string string_0)
	{
		return new Exception(string_0);
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_12(RegistryKey registryKey_0, string string_0, bool bool_1)
	{
		return registryKey_0.OpenSubKey(string_0, bool_1);
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_13(RegistryKey registryKey_0, string string_0)
	{
		registryKey_0.DeleteValue(string_0);
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_14(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_15(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x00002EED File Offset: 0x000010ED
	static void smethod_16(RegistryKey registryKey_0, string string_0, object object_0, RegistryValueKind registryValueKind_0)
	{
		registryKey_0.SetValue(string_0, object_0, registryValueKind_0);
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x00003AEF File Offset: 0x00001CEF
	static string[] smethod_17(string string_0, char[] char_0)
	{
		return string_0.Split(char_0);
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x00003AF8 File Offset: 0x00001CF8
	static int smethod_18(string string_0, char char_0)
	{
		return string_0.IndexOf(char_0);
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x00003B01 File Offset: 0x00001D01
	static string smethod_19(string string_0, int int_0, int int_1)
	{
		return string_0.Substring(int_0, int_1);
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x00002C7A File Offset: 0x00000E7A
	static string smethod_20(string string_0, int int_0)
	{
		return string_0.Substring(int_0);
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x00003B0B File Offset: 0x00001D0B
	static bool smethod_21(string string_0, string string_1, StringComparison stringComparison_0)
	{
		return string_0.Equals(string_1, stringComparison_0);
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x00003B15 File Offset: 0x00001D15
	static StringBuilder smethod_22(int int_0)
	{
		return new StringBuilder(int_0);
	}

	// Token: 0x06000421 RID: 1057 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_23(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x04000201 RID: 513
	public readonly bool bool_0;
}
