﻿// Token: 0x020000E9 RID: 233
public partial class Widget : global::System.Windows.Forms.Form
{
	// Token: 0x06000BB3 RID: 2995 RVA: 0x00039938 File Offset: 0x00037B38
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.contextMenuStrip_0 = new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem_8 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_9 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_10 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram20 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram30 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram40 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram50 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram60 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram70 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram80 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram90 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator2 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_0 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_1 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_2 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.notifyIcon_0 = new global::System.Windows.Forms.NotifyIcon(this.icontainer_0);
		this.contextMenuStrip1 = new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem_6 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_7 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_11 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram200 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram300 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram400 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram500 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram600 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram700 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram800 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram900 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator1 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_5 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_3 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_4 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.Ram101 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.ProgressBar = new global::GControl0();
		this.contextMenuStrip_0.SuspendLayout();
		this.contextMenuStrip1.SuspendLayout();
		base.SuspendLayout();
		this.contextMenuStrip_0.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_8,
			this.toolStripMenuItem_9,
			this.toolStripMenuItem_10,
			this.toolStripSeparator2,
			this.toolStripMenuItem_0,
			this.toolStripMenuItem_1,
			this.toolStripMenuItem_2
		});
		this.contextMenuStrip_0.Name = "contextMenuStrip1";
		this.contextMenuStrip_0.Size = new global::System.Drawing.Size(68, 142);
		this.toolStripMenuItem_8.Name = "ВиджетChoice1";
		this.toolStripMenuItem_8.Size = new global::System.Drawing.Size(67, 22);
		this.toolStripMenuItem_8.Click += new global::System.EventHandler(this.toolStripMenuItem_8_Click);
		this.toolStripMenuItem_9.Name = "ВиджетChoice2";
		this.toolStripMenuItem_9.Size = new global::System.Drawing.Size(67, 22);
		this.toolStripMenuItem_9.Click += new global::System.EventHandler(this.toolStripMenuItem_9_Click);
		this.toolStripMenuItem_10.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.Ram20,
			this.Ram30,
			this.Ram40,
			this.Ram50,
			this.Ram60,
			this.Ram70,
			this.Ram80,
			this.Ram90
		});
		this.toolStripMenuItem_10.Name = "ВиджетChoice3";
		this.toolStripMenuItem_10.Size = new global::System.Drawing.Size(67, 22);
		this.Ram20.Name = "Ram20";
		this.Ram20.Size = new global::System.Drawing.Size(180, 22);
		this.Ram30.Name = "Ram30";
		this.Ram30.Size = new global::System.Drawing.Size(180, 22);
		this.Ram40.Name = "Ram40";
		this.Ram40.Size = new global::System.Drawing.Size(180, 22);
		this.Ram50.Name = "Ram50";
		this.Ram50.Size = new global::System.Drawing.Size(180, 22);
		this.Ram60.Name = "Ram60";
		this.Ram60.Size = new global::System.Drawing.Size(180, 22);
		this.Ram70.Name = "Ram70";
		this.Ram70.Size = new global::System.Drawing.Size(180, 22);
		this.Ram80.Name = "Ram80";
		this.Ram80.Size = new global::System.Drawing.Size(180, 22);
		this.Ram90.Name = "Ram90";
		this.Ram90.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripSeparator2.Name = "toolStripSeparator2";
		this.toolStripSeparator2.Size = new global::System.Drawing.Size(64, 6);
		this.toolStripMenuItem_0.Name = "ВиджетОчистить";
		this.toolStripMenuItem_0.Size = new global::System.Drawing.Size(67, 22);
		this.toolStripMenuItem_0.Click += new global::System.EventHandler(this.toolStripMenuItem_0_Click);
		this.toolStripMenuItem_1.Name = "ВиджетСвернуть";
		this.toolStripMenuItem_1.Size = new global::System.Drawing.Size(67, 22);
		this.toolStripMenuItem_1.Click += new global::System.EventHandler(this.toolStripMenuItem_1_Click);
		this.toolStripMenuItem_2.Name = "ВиджетЗакрыть";
		this.toolStripMenuItem_2.Size = new global::System.Drawing.Size(67, 22);
		this.toolStripMenuItem_2.Click += new global::System.EventHandler(this.toolStripMenuItem_2_Click);
		this.notifyIcon_0.ContextMenuStrip = this.contextMenuStrip1;
		this.notifyIcon_0.Visible = true;
		this.notifyIcon_0.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.notifyIcon_0_MouseDown);
		this.contextMenuStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_6,
			this.toolStripMenuItem_7,
			this.toolStripMenuItem_11,
			this.toolStripSeparator1,
			this.toolStripMenuItem_5,
			this.toolStripMenuItem_3,
			this.toolStripMenuItem_4
		});
		this.contextMenuStrip1.Name = "contextMenuStrip1";
		this.contextMenuStrip1.Size = new global::System.Drawing.Size(181, 164);
		this.toolStripMenuItem_6.Name = "ТрейChoice1";
		this.toolStripMenuItem_6.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_6.Click += new global::System.EventHandler(this.toolStripMenuItem_6_Click);
		this.toolStripMenuItem_7.Name = "ТрейChoice2";
		this.toolStripMenuItem_7.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_7.Click += new global::System.EventHandler(this.toolStripMenuItem_7_Click);
		this.toolStripMenuItem_11.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.Ram200,
			this.Ram300,
			this.Ram400,
			this.Ram500,
			this.Ram600,
			this.Ram700,
			this.Ram800,
			this.Ram900
		});
		this.toolStripMenuItem_11.Name = "ТрейChoice3";
		this.toolStripMenuItem_11.Size = new global::System.Drawing.Size(180, 22);
		this.Ram200.Name = "Ram200";
		this.Ram200.Size = new global::System.Drawing.Size(180, 22);
		this.Ram300.Name = "Ram300";
		this.Ram300.Size = new global::System.Drawing.Size(180, 22);
		this.Ram400.Name = "Ram400";
		this.Ram400.Size = new global::System.Drawing.Size(180, 22);
		this.Ram500.Name = "Ram500";
		this.Ram500.Size = new global::System.Drawing.Size(180, 22);
		this.Ram600.Name = "Ram600";
		this.Ram600.Size = new global::System.Drawing.Size(180, 22);
		this.Ram700.Name = "Ram700";
		this.Ram700.Size = new global::System.Drawing.Size(180, 22);
		this.Ram800.Name = "Ram800";
		this.Ram800.Size = new global::System.Drawing.Size(180, 22);
		this.Ram900.Name = "Ram900";
		this.Ram900.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripSeparator1.Name = "toolStripSeparator1";
		this.toolStripSeparator1.Size = new global::System.Drawing.Size(177, 6);
		this.toolStripMenuItem_5.Name = "ТрейВиджет";
		this.toolStripMenuItem_5.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_5.Click += new global::System.EventHandler(this.toolStripMenuItem_5_Click);
		this.toolStripMenuItem_3.Name = "ТрейОчистить";
		this.toolStripMenuItem_3.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_3.Click += new global::System.EventHandler(this.toolStripMenuItem_3_Click);
		this.toolStripMenuItem_4.Name = "ТрейЗакрыть";
		this.toolStripMenuItem_4.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_4.Click += new global::System.EventHandler(this.toolStripMenuItem_4_Click);
		this.Ram101.Name = "Ram101";
		this.Ram101.Size = new global::System.Drawing.Size(180, 22);
		this.ProgressBar.BackColor = global::System.Drawing.Color.Transparent;
		this.ProgressBar.Location = new global::System.Drawing.Point(-1, -1);
		this.ProgressBar.Name = "ProgressBar";
		this.ProgressBar.Size = new global::System.Drawing.Size(80, 80);
		this.ProgressBar.TabIndex = 0;
		this.ProgressBar.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.ProgressBar_MouseDown);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.None;
		this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Center;
		base.ClientSize = new global::System.Drawing.Size(79, 79);
		this.ContextMenuStrip = this.contextMenuStrip_0;
		base.Controls.Add(this.ProgressBar);
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Widget";
		base.Opacity = 0.8;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.Widget_Load);
		base.LocationChanged += new global::System.EventHandler(this.Widget_LocationChanged);
		this.contextMenuStrip_0.ResumeLayout(false);
		this.contextMenuStrip1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040004A4 RID: 1188
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x040004A5 RID: 1189
	private global::System.Windows.Forms.ContextMenuStrip contextMenuStrip_0;

	// Token: 0x040004A6 RID: 1190
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x040004A7 RID: 1191
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x040004A8 RID: 1192
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x040004A9 RID: 1193
	private global::System.Windows.Forms.NotifyIcon notifyIcon_0;

	// Token: 0x040004AA RID: 1194
	private global::System.Windows.Forms.ContextMenuStrip contextMenuStrip1;

	// Token: 0x040004AB RID: 1195
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x040004AC RID: 1196
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x040004AD RID: 1197
	private global::GControl0 ProgressBar;

	// Token: 0x040004AE RID: 1198
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x040004AF RID: 1199
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator1;

	// Token: 0x040004B0 RID: 1200
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x040004B1 RID: 1201
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x040004B2 RID: 1202
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator2;

	// Token: 0x040004B3 RID: 1203
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_8;

	// Token: 0x040004B4 RID: 1204
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_9;

	// Token: 0x040004B5 RID: 1205
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_10;

	// Token: 0x040004B6 RID: 1206
	private global::System.Windows.Forms.ToolStripMenuItem Ram20;

	// Token: 0x040004B7 RID: 1207
	private global::System.Windows.Forms.ToolStripMenuItem Ram30;

	// Token: 0x040004B8 RID: 1208
	private global::System.Windows.Forms.ToolStripMenuItem Ram40;

	// Token: 0x040004B9 RID: 1209
	private global::System.Windows.Forms.ToolStripMenuItem Ram50;

	// Token: 0x040004BA RID: 1210
	private global::System.Windows.Forms.ToolStripMenuItem Ram60;

	// Token: 0x040004BB RID: 1211
	private global::System.Windows.Forms.ToolStripMenuItem Ram70;

	// Token: 0x040004BC RID: 1212
	private global::System.Windows.Forms.ToolStripMenuItem Ram80;

	// Token: 0x040004BD RID: 1213
	private global::System.Windows.Forms.ToolStripMenuItem Ram90;

	// Token: 0x040004BE RID: 1214
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_11;

	// Token: 0x040004BF RID: 1215
	private global::System.Windows.Forms.ToolStripMenuItem Ram101;

	// Token: 0x040004C0 RID: 1216
	private global::System.Windows.Forms.ToolStripMenuItem Ram200;

	// Token: 0x040004C1 RID: 1217
	private global::System.Windows.Forms.ToolStripMenuItem Ram300;

	// Token: 0x040004C2 RID: 1218
	private global::System.Windows.Forms.ToolStripMenuItem Ram400;

	// Token: 0x040004C3 RID: 1219
	private global::System.Windows.Forms.ToolStripMenuItem Ram500;

	// Token: 0x040004C4 RID: 1220
	private global::System.Windows.Forms.ToolStripMenuItem Ram600;

	// Token: 0x040004C5 RID: 1221
	private global::System.Windows.Forms.ToolStripMenuItem Ram700;

	// Token: 0x040004C6 RID: 1222
	private global::System.Windows.Forms.ToolStripMenuItem Ram800;

	// Token: 0x040004C7 RID: 1223
	private global::System.Windows.Forms.ToolStripMenuItem Ram900;
}
