﻿using System;
using System.Linq;
using System.Threading;
using Microsoft.Win32;

// Token: 0x020000E5 RID: 229
internal class Class76
{
	// Token: 0x17000097 RID: 151
	// (get) Token: 0x06000B67 RID: 2919 RVA: 0x00038F7C File Offset: 0x0003717C
	public static Class76 Class76_0
	{
		get
		{
			if (Class76.class76_0 == null)
			{
				object obj = Class76.object_0;
				lock (obj)
				{
					if (Class76.class76_0 == null)
					{
						Class76.class76_0 = new Class76();
					}
				}
			}
			return Class76.class76_0;
		}
	}

	// Token: 0x06000B68 RID: 2920 RVA: 0x00038FDC File Offset: 0x000371DC
	public void method_0()
	{
		string value = GClass2.GClass2_0.method_1("TakeOwnerShip");
		string str = "*S-1-5-32-544";
		RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey("*\\shell\\runas");
		registryKey.SetValue("", value);
		registryKey.SetValue("Icon", "imageres.dll,101");
		registryKey.SetValue("NoWorkingDirectory", "");
		RegistryKey registryKey2 = Registry.ClassesRoot.CreateSubKey("*\\shell\\runas\\command");
		registryKey2.SetValue("", "cmd.exe /c takeown /f \"%1\" && icacls \"%1\" /grant " + str + ":F");
		registryKey2.SetValue("IsolatedCommand", "cmd.exe /c takeown /f \"%1\" && icacls \"%1\" /grant " + str + ":F");
		RegistryKey registryKey3 = Registry.ClassesRoot.CreateSubKey("Directory\\shell\\runas");
		registryKey3.SetValue("", value);
		registryKey3.SetValue("Icon", "imageres.dll,101");
		registryKey3.SetValue("NoWorkingDirectory", "");
		RegistryKey registryKey4 = Registry.ClassesRoot.CreateSubKey("Directory\\shell\\runas\\command");
		registryKey4.SetValue("", "cmd.exe /c takeown /f \"%1\" /r /d y && icacls \"%1\" /grant " + str + ":F /t");
		registryKey4.SetValue("IsolatedCommand", "cmd.exe /c takeown /f \"%1\" /r /d y && icacls \"%1\" /grant " + str + ":F /t");
		RegistryKey registryKey5 = Registry.ClassesRoot.CreateSubKey("dllfile\\shell\\runas");
		registryKey5.SetValue("", value);
		registryKey5.SetValue("HasLUAShield", "");
		registryKey5.SetValue("NoWorkingDirectory", "");
		registryKey5.SetValue("Icon", "imageres.dll,101");
		RegistryKey registryKey6 = Registry.ClassesRoot.CreateSubKey("dllfile\\shell\\runas\\command");
		registryKey6.SetValue("", "cmd.exe /c takeown /f \"%1\" && icacls \"%1\" /grant " + str + ":F");
		registryKey6.SetValue("IsolatedCommand", "cmd.exe /c takeown /f \"%1\" && icacls \"%1\" /grant " + str + ":F");
		RegistryKey registryKey7 = Registry.ClassesRoot.CreateSubKey("exefile\\shell\\runas2");
		registryKey7.SetValue("", value);
		registryKey7.SetValue("HasLUAShield", "");
		registryKey7.SetValue("NoWorkingDirectory", "");
		registryKey7.SetValue("Icon", "imageres.dll,101");
		RegistryKey registryKey8 = Registry.ClassesRoot.CreateSubKey("exefile\\shell\\runas2\\command");
		registryKey8.SetValue("", "cmd.exe /c takeown /f \"%1\" && icacls \"%1\" /grant " + str + ":F");
		registryKey8.SetValue("IsolatedCommand", "cmd.exe /c takeown /f \"%1\" && icacls \"%1\" /grant " + str + ":F");
		Class76.string_0.Where(new Func<string, bool>(Class76.<>c.<>9.method_0)).ToList<string>().ForEach(new Action<string>(Class76.<>c.<>9.method_1));
	}

	// Token: 0x06000B69 RID: 2921 RVA: 0x000067B9 File Offset: 0x000049B9
	public void method_1()
	{
		Class76.string_0.ToList<string>().ForEach(new Action<string>(Class76.<>c.<>9.method_2));
	}

	// Token: 0x06000B6A RID: 2922 RVA: 0x000067E9 File Offset: 0x000049E9
	public void method_2()
	{
		Class76.string_0.ToList<string>().ForEach(new Action<string>(Class76.<>c.<>9.method_3));
	}

	// Token: 0x06000B6D RID: 2925 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000B6E RID: 2926 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000B6F RID: 2927 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x06000B70 RID: 2928 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_3(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x06000B71 RID: 2929 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_4(string string_1, string string_2, string string_3)
	{
		return string_1 + string_2 + string_3;
	}

	// Token: 0x06000B72 RID: 2930 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_5()
	{
		return new object();
	}

	// Token: 0x04000494 RID: 1172
	private static volatile Class76 class76_0;

	// Token: 0x04000495 RID: 1173
	private static readonly object object_0 = new object();

	// Token: 0x04000496 RID: 1174
	private static readonly string[] string_0 = new string[]
	{
		"*\\shell\\runas",
		"Directory\\shell\\runas",
		"dllfile\\shell\\runas",
		"exefile\\shell\\runas2"
	};
}
