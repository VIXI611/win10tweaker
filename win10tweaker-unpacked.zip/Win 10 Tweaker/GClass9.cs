﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

// Token: 0x02000064 RID: 100
public static class GClass9
{
	// Token: 0x060004E9 RID: 1257
	[DllImport("kernel32.dll")]
	private static extern IntPtr OpenThread(GClass9.GEnum1 genum1_0, bool bool_0, uint uint_0);

	// Token: 0x060004EA RID: 1258
	[DllImport("kernel32.dll")]
	private static extern uint SuspendThread(IntPtr intptr_0);

	// Token: 0x060004EB RID: 1259
	[DllImport("kernel32.dll")]
	private static extern int ResumeThread(IntPtr intptr_0);

	// Token: 0x060004EC RID: 1260 RVA: 0x00003F5B File Offset: 0x0000215B
	public static void smethod_0(this string string_0)
	{
		Process.GetProcessesByName(string_0 ?? "").ToList<Process>().ForEach(new Action<Process>(GClass9.<>c.<>9.method_0));
	}

	// Token: 0x060004ED RID: 1261 RVA: 0x00003F95 File Offset: 0x00002195
	public static void smethod_1(this string string_0)
	{
		Process.GetProcessesByName(string_0 ?? "").ToList<Process>().ForEach(new Action<Process>(GClass9.<>c.<>9.method_1));
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x000033EC File Offset: 0x000015EC
	static Process[] smethod_2(string string_0)
	{
		return Process.GetProcessesByName(string_0);
	}

	// Token: 0x02000065 RID: 101
	[Flags]
	public enum GEnum1
	{
		// Token: 0x04000223 RID: 547
		TERMINATE = 1,
		// Token: 0x04000224 RID: 548
		SUSPEND_RESUME = 2,
		// Token: 0x04000225 RID: 549
		GET_CONTEXT = 8,
		// Token: 0x04000226 RID: 550
		SET_CONTEXT = 16,
		// Token: 0x04000227 RID: 551
		SET_INFORMATION = 32,
		// Token: 0x04000228 RID: 552
		QUERY_INFORMATION = 64,
		// Token: 0x04000229 RID: 553
		SET_THREAD_TOKEN = 128,
		// Token: 0x0400022A RID: 554
		IMPERSONATE = 256,
		// Token: 0x0400022B RID: 555
		DIRECT_IMPERSONATION = 512
	}
}
