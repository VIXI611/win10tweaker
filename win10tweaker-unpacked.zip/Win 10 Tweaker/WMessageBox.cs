﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.Win32;

// Token: 0x02000188 RID: 392
public partial class WMessageBox : GForm0
{
	// Token: 0x06001343 RID: 4931 RVA: 0x0006B5F8 File Offset: 0x000697F8
	public WMessageBox()
	{
		this.InitializeComponent();
		this.method_9(this.MessageLabel);
		new List<Control>
		{
			this.HeaderPanel,
			this.Header
		}.ForEach(new Action<Control>(this.method_3));
		this.ButtonsPanel.Controls.OfType<Button>().ToList<Button>().ForEach(new Action<Button>(this.method_6));
		this.CloseIcon.MouseDown += this.method_8;
	}

	// Token: 0x06001344 RID: 4932 RVA: 0x0006B688 File Offset: 0x00069888
	private void WMessageBox_Load(object sender, EventArgs e)
	{
		WMessageBox.Struct84 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.wmessageBox_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<WMessageBox.Struct84>(ref @struct);
	}

	// Token: 0x06001345 RID: 4933 RVA: 0x0006B6C0 File Offset: 0x000698C0
	public static DialogResult smethod_3(string string_3 = "", string string_4 = "", WMessageBox.GEnum2 genum2_1 = WMessageBox.GEnum2.OK, bool bool_2 = false, string string_5 = "", Form form_0 = null)
	{
		return new WMessageBox
		{
			string_0 = string_3,
			string_1 = ((string_4 == "") ? GClass2.GClass2_0.String_6 : string_4),
			bool_1 = bool_2,
			genum2_0 = genum2_1,
			string_2 = string_5,
			Owner = (form_0 ?? Application.OpenForms.OfType<Form>().FirstOrDefault<Form>())
		}.ShowDialog();
	}

	// Token: 0x06001346 RID: 4934 RVA: 0x0006B730 File Offset: 0x00069930
	public void method_1(Color color_0, Color color_1, Color color_2)
	{
		WMessageBox.Class84 @class = new WMessageBox.Class84();
		@class.wmessageBox_0 = this;
		@class.color_0 = color_0;
		@class.color_1 = color_1;
		@class.color_2 = color_2;
		this.HeaderPanel.Paint += @class.method_0;
		this.HeaderPanel.Invalidate();
	}

	// Token: 0x06001347 RID: 4935 RVA: 0x0006B784 File Offset: 0x00069984
	public void method_2(Color color_0, Color color_1)
	{
		WMessageBox.Class85 @class = new WMessageBox.Class85();
		@class.wmessageBox_0 = this;
		@class.color_0 = color_0;
		@class.color_1 = color_1;
		this.ButtonsPanel.Paint += @class.method_0;
		this.ButtonsPanel.Invalidate();
	}

	// Token: 0x06001348 RID: 4936 RVA: 0x0000929D File Offset: 0x0000749D
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600134A RID: 4938 RVA: 0x0006C040 File Offset: 0x0006A240
	[CompilerGenerated]
	private void method_3(Control control_0)
	{
		WMessageBox.Class83 @class = new WMessageBox.Class83();
		@class.wmessageBox_0 = this;
		@class.control_0 = control_0;
		@class.control_0.MouseDown += @class.method_0;
	}

	// Token: 0x0600134B RID: 4939 RVA: 0x000092BC File Offset: 0x000074BC
	[DebuggerHidden]
	[CompilerGenerated]
	private IntPtr method_4()
	{
		return this.method_10();
	}

	// Token: 0x0600134C RID: 4940 RVA: 0x000028FC File Offset: 0x00000AFC
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_5(ref Message message_0)
	{
		base.System.Windows.Forms.Form.WndProc(ref message_0);
	}

	// Token: 0x0600134D RID: 4941 RVA: 0x000092C4 File Offset: 0x000074C4
	[CompilerGenerated]
	private void method_6(Button button_0)
	{
		button_0.Click += this.method_7;
	}

	// Token: 0x0600134E RID: 4942 RVA: 0x000092D8 File Offset: 0x000074D8
	[CompilerGenerated]
	private void method_7(object sender, EventArgs e)
	{
		if (this.DontShowAgain.Checked)
		{
			GClass2.GClass2_0.RegistryKey_0.SetValue(this.string_2, "true");
		}
	}

	// Token: 0x0600134F RID: 4943 RVA: 0x0006C078 File Offset: 0x0006A278
	[CompilerGenerated]
	private void method_8(object sender, MouseEventArgs e)
	{
		if (Control.ModifierKeys == Keys.Control)
		{
			if (e.Button == MouseButtons.Right)
			{
				if (GClass2.GClass2_0.RegistryKey_0.GetValue("email") != null)
				{
					GClass2.GClass2_0.RegistryKey_0.DeleteValue("email");
					base.Close();
				}
			}
		}
	}

	// Token: 0x06001350 RID: 4944 RVA: 0x00009301 File Offset: 0x00007501
	void method_9(Control control_0)
	{
		base.ActiveControl = control_0;
	}

	// Token: 0x06001351 RID: 4945 RVA: 0x0000295A File Offset: 0x00000B5A
	static Control.ControlCollection smethod_4(Control control_0)
	{
		return control_0.Controls;
	}

	// Token: 0x06001352 RID: 4946 RVA: 0x00002AAE File Offset: 0x00000CAE
	static void smethod_5(Control control_0, MouseEventHandler mouseEventHandler_0)
	{
		control_0.MouseDown += mouseEventHandler_0;
	}

	// Token: 0x06001353 RID: 4947 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_6(string string_3, string string_4)
	{
		return string_3 == string_4;
	}

	// Token: 0x06001354 RID: 4948 RVA: 0x000029CD File Offset: 0x00000BCD
	static FormCollection smethod_7()
	{
		return Application.OpenForms;
	}

	// Token: 0x06001355 RID: 4949 RVA: 0x0000930A File Offset: 0x0000750A
	static void smethod_8(Form form_0, Form form_1)
	{
		form_0.Owner = form_1;
	}

	// Token: 0x06001356 RID: 4950 RVA: 0x000080DE File Offset: 0x000062DE
	static DialogResult smethod_9(Form form_0)
	{
		return form_0.ShowDialog();
	}

	// Token: 0x06001357 RID: 4951 RVA: 0x00002A0F File Offset: 0x00000C0F
	static void smethod_10(Control control_0, PaintEventHandler paintEventHandler_0)
	{
		control_0.Paint += paintEventHandler_0;
	}

	// Token: 0x06001358 RID: 4952 RVA: 0x00002929 File Offset: 0x00000B29
	static void smethod_11(Control control_0)
	{
		control_0.Invalidate();
	}

	// Token: 0x06001359 RID: 4953 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_12(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x0600135A RID: 4954 RVA: 0x00002A77 File Offset: 0x00000C77
	static Panel smethod_13()
	{
		return new Panel();
	}

	// Token: 0x0600135B RID: 4955 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_14()
	{
		return new Label();
	}

	// Token: 0x0600135C RID: 4956 RVA: 0x00002A69 File Offset: 0x00000C69
	static Button smethod_15()
	{
		return new Button();
	}

	// Token: 0x0600135D RID: 4957 RVA: 0x0000812C File Offset: 0x0000632C
	static CheckBox smethod_16()
	{
		return new CheckBox();
	}

	// Token: 0x0600135E RID: 4958 RVA: 0x00002A8D File Offset: 0x00000C8D
	static void smethod_17(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x0600135F RID: 4959 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_18(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x06001360 RID: 4960 RVA: 0x0000305B File Offset: 0x0000125B
	static void smethod_19(Control.ControlCollection controlCollection_0, Control control_0)
	{
		controlCollection_0.Add(control_0);
	}

	// Token: 0x06001361 RID: 4961 RVA: 0x00002B07 File Offset: 0x00000D07
	IntPtr method_10()
	{
		return base.Handle;
	}

	// Token: 0x06001362 RID: 4962 RVA: 0x00002951 File Offset: 0x00000B51
	static void smethod_20(Control control_0, EventHandler eventHandler_0)
	{
		control_0.Click += eventHandler_0;
	}

	// Token: 0x06001363 RID: 4963 RVA: 0x00007FC3 File Offset: 0x000061C3
	static bool smethod_21(CheckBox checkBox_0)
	{
		return checkBox_0.Checked;
	}

	// Token: 0x06001364 RID: 4964 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_22(RegistryKey registryKey_0, string string_3, object object_0)
	{
		registryKey_0.SetValue(string_3, object_0);
	}

	// Token: 0x06001365 RID: 4965 RVA: 0x00009313 File Offset: 0x00007513
	static Keys smethod_23()
	{
		return Control.ModifierKeys;
	}

	// Token: 0x06001366 RID: 4966 RVA: 0x00002D75 File Offset: 0x00000F75
	static MouseButtons smethod_24(MouseEventArgs mouseEventArgs_0)
	{
		return mouseEventArgs_0.Button;
	}

	// Token: 0x06001367 RID: 4967 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_25(RegistryKey registryKey_0, string string_3)
	{
		return registryKey_0.GetValue(string_3);
	}

	// Token: 0x06001368 RID: 4968 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_26(RegistryKey registryKey_0, string string_3)
	{
		registryKey_0.DeleteValue(string_3);
	}

	// Token: 0x06001369 RID: 4969 RVA: 0x00002C39 File Offset: 0x00000E39
	static void smethod_27(Form form_0)
	{
		form_0.Close();
	}

	// Token: 0x0400092B RID: 2347
	public string string_0;

	// Token: 0x0400092C RID: 2348
	public string string_1;

	// Token: 0x0400092D RID: 2349
	public bool bool_1;

	// Token: 0x0400092E RID: 2350
	public string string_2;

	// Token: 0x0400092F RID: 2351
	public WMessageBox.GEnum2 genum2_0;

	// Token: 0x04000930 RID: 2352
	private IContainer icontainer_0;

	// Token: 0x02000189 RID: 393
	public enum GEnum2
	{
		// Token: 0x0400093C RID: 2364
		OK,
		// Token: 0x0400093D RID: 2365
		OKCancel,
		// Token: 0x0400093E RID: 2366
		YesNo,
		// Token: 0x0400093F RID: 2367
		YesNoCancel
	}

	// Token: 0x0200018A RID: 394
	[CompilerGenerated]
	private sealed class Class83
	{
		// Token: 0x0600136B RID: 4971 RVA: 0x0006C0D0 File Offset: 0x0006A2D0
		internal void method_0(object sender, MouseEventArgs e)
		{
			this.control_0.Capture = false;
			this.wmessageBox_0.Capture = false;
			Message message = Message.Create(this.wmessageBox_0.method_4(), 161, new IntPtr(2), IntPtr.Zero);
			this.wmessageBox_0.method_5(ref message);
		}

		// Token: 0x0600136C RID: 4972 RVA: 0x00002AF5 File Offset: 0x00000CF5
		static void smethod_0(Control control_1, bool bool_0)
		{
			control_1.Capture = bool_0;
		}

		// Token: 0x0600136D RID: 4973 RVA: 0x00002AFE File Offset: 0x00000CFE
		static void smethod_1(Control control_1, bool bool_0)
		{
			control_1.Capture = bool_0;
		}

		// Token: 0x04000940 RID: 2368
		public Control control_0;

		// Token: 0x04000941 RID: 2369
		public WMessageBox wmessageBox_0;
	}

	// Token: 0x0200018C RID: 396
	[CompilerGenerated]
	private sealed class Class84
	{
		// Token: 0x06001378 RID: 4984 RVA: 0x0006C894 File Offset: 0x0006AA94
		internal void method_0(object sender, PaintEventArgs e)
		{
			LinearGradientBrush linearGradientBrush = new LinearGradientBrush(this.wmessageBox_0.HeaderPanel.ClientRectangle, Color.Empty, Color.Empty, 90f);
			ColorBlend interpolationColors = new ColorBlend
			{
				Colors = new Color[]
				{
					this.color_0,
					this.color_0,
					this.color_1,
					this.color_2,
					this.color_2
				},
				Positions = new float[]
				{
					0f,
					0.82f,
					0.82f,
					1f,
					1f
				}
			};
			linearGradientBrush.InterpolationColors = interpolationColors;
			e.Graphics.FillRectangle(linearGradientBrush, this.wmessageBox_0.HeaderPanel.ClientRectangle);
		}

		// Token: 0x06001379 RID: 4985 RVA: 0x00002BCC File Offset: 0x00000DCC
		static Rectangle smethod_0(Control control_0)
		{
			return control_0.ClientRectangle;
		}

		// Token: 0x0600137A RID: 4986 RVA: 0x00002BD4 File Offset: 0x00000DD4
		static LinearGradientBrush smethod_1(Rectangle rectangle_0, Color color_3, Color color_4, float float_0)
		{
			return new LinearGradientBrush(rectangle_0, color_3, color_4, float_0);
		}

		// Token: 0x0600137B RID: 4987 RVA: 0x000055F7 File Offset: 0x000037F7
		static ColorBlend smethod_2()
		{
			return new ColorBlend();
		}

		// Token: 0x0600137C RID: 4988 RVA: 0x00002BE7 File Offset: 0x00000DE7
		static void smethod_3(ColorBlend colorBlend_0, Color[] color_3)
		{
			colorBlend_0.Colors = color_3;
		}

		// Token: 0x0600137D RID: 4989 RVA: 0x00002BF0 File Offset: 0x00000DF0
		static void smethod_4(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x0600137E RID: 4990 RVA: 0x00002BF9 File Offset: 0x00000DF9
		static void smethod_5(ColorBlend colorBlend_0, float[] float_0)
		{
			colorBlend_0.Positions = float_0;
		}

		// Token: 0x0600137F RID: 4991 RVA: 0x00002C02 File Offset: 0x00000E02
		static void smethod_6(LinearGradientBrush linearGradientBrush_0, ColorBlend colorBlend_0)
		{
			linearGradientBrush_0.InterpolationColors = colorBlend_0;
		}

		// Token: 0x06001380 RID: 4992 RVA: 0x00002B88 File Offset: 0x00000D88
		static Graphics smethod_7(PaintEventArgs paintEventArgs_0)
		{
			return paintEventArgs_0.Graphics;
		}

		// Token: 0x06001381 RID: 4993 RVA: 0x00002C0B File Offset: 0x00000E0B
		static void smethod_8(Graphics graphics_0, Brush brush_0, Rectangle rectangle_0)
		{
			graphics_0.FillRectangle(brush_0, rectangle_0);
		}

		// Token: 0x04000946 RID: 2374
		public WMessageBox wmessageBox_0;

		// Token: 0x04000947 RID: 2375
		public Color color_0;

		// Token: 0x04000948 RID: 2376
		public Color color_1;

		// Token: 0x04000949 RID: 2377
		public Color color_2;
	}

	// Token: 0x0200018D RID: 397
	[CompilerGenerated]
	private sealed class Class85
	{
		// Token: 0x06001383 RID: 4995 RVA: 0x0006C958 File Offset: 0x0006AB58
		internal void method_0(object sender, PaintEventArgs e)
		{
			LinearGradientBrush linearGradientBrush = new LinearGradientBrush(this.wmessageBox_0.ButtonsPanel.ClientRectangle, Color.Empty, Color.Empty, 90f);
			ColorBlend interpolationColors = new ColorBlend
			{
				Colors = new Color[]
				{
					this.color_0,
					this.color_1,
					this.color_1
				},
				Positions = new float[]
				{
					0f,
					0.5f,
					1f
				}
			};
			linearGradientBrush.InterpolationColors = interpolationColors;
			e.Graphics.FillRectangle(linearGradientBrush, this.wmessageBox_0.ButtonsPanel.ClientRectangle);
		}

		// Token: 0x06001384 RID: 4996 RVA: 0x00002BCC File Offset: 0x00000DCC
		static Rectangle smethod_0(Control control_0)
		{
			return control_0.ClientRectangle;
		}

		// Token: 0x06001385 RID: 4997 RVA: 0x00002BD4 File Offset: 0x00000DD4
		static LinearGradientBrush smethod_1(Rectangle rectangle_0, Color color_2, Color color_3, float float_0)
		{
			return new LinearGradientBrush(rectangle_0, color_2, color_3, float_0);
		}

		// Token: 0x06001386 RID: 4998 RVA: 0x000055F7 File Offset: 0x000037F7
		static ColorBlend smethod_2()
		{
			return new ColorBlend();
		}

		// Token: 0x06001387 RID: 4999 RVA: 0x00002BE7 File Offset: 0x00000DE7
		static void smethod_3(ColorBlend colorBlend_0, Color[] color_2)
		{
			colorBlend_0.Colors = color_2;
		}

		// Token: 0x06001388 RID: 5000 RVA: 0x00002BF9 File Offset: 0x00000DF9
		static void smethod_4(ColorBlend colorBlend_0, float[] float_0)
		{
			colorBlend_0.Positions = float_0;
		}

		// Token: 0x06001389 RID: 5001 RVA: 0x00002C02 File Offset: 0x00000E02
		static void smethod_5(LinearGradientBrush linearGradientBrush_0, ColorBlend colorBlend_0)
		{
			linearGradientBrush_0.InterpolationColors = colorBlend_0;
		}

		// Token: 0x0600138A RID: 5002 RVA: 0x00002B88 File Offset: 0x00000D88
		static Graphics smethod_6(PaintEventArgs paintEventArgs_0)
		{
			return paintEventArgs_0.Graphics;
		}

		// Token: 0x0600138B RID: 5003 RVA: 0x00002C0B File Offset: 0x00000E0B
		static void smethod_7(Graphics graphics_0, Brush brush_0, Rectangle rectangle_0)
		{
			graphics_0.FillRectangle(brush_0, rectangle_0);
		}

		// Token: 0x0400094A RID: 2378
		public WMessageBox wmessageBox_0;

		// Token: 0x0400094B RID: 2379
		public Color color_0;

		// Token: 0x0400094C RID: 2380
		public Color color_1;
	}
}
