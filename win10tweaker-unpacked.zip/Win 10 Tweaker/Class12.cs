﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000028 RID: 40
internal class Class12
{
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000160 RID: 352 RVA: 0x000102AC File Offset: 0x0000E4AC
	public static Class12 Class12_0
	{
		get
		{
			if (Class12.class12_0 == null)
			{
				object obj = Class12.object_0;
				lock (obj)
				{
					if (Class12.class12_0 == null)
					{
						Class12.class12_0 = new Class12();
					}
				}
			}
			return Class12.class12_0;
		}
	}

	// Token: 0x06000161 RID: 353
	[DllImport("user32.dll")]
	public static extern bool SystemParametersInfo(uint uint_0, uint uint_1, uint uint_2, uint uint_3);

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000162 RID: 354 RVA: 0x00002E73 File Offset: 0x00001073
	private RegistryKey RegistryKey_0
	{
		get
		{
			return Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
		}
	}

	// Token: 0x06000163 RID: 355 RVA: 0x0001030C File Offset: 0x0000E50C
	public void method_0()
	{
		Class12.Struct19 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.class12_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Class12.Struct19>(ref @struct);
	}

	// Token: 0x06000164 RID: 356 RVA: 0x00010344 File Offset: 0x0000E544
	public void method_1()
	{
		Class12.Struct20 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.class12_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Class12.Struct20>(ref @struct);
	}

	// Token: 0x06000167 RID: 359 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000168 RID: 360 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000169 RID: 361 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x0600016A RID: 362 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_3(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x0600016B RID: 363 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_4()
	{
		return new object();
	}

	// Token: 0x040000B8 RID: 184
	private static volatile Class12 class12_0;

	// Token: 0x040000B9 RID: 185
	private static readonly object object_0 = new object();

	// Token: 0x040000BA RID: 186
	private readonly string string_0 = GClass13.string_6 + "\\Cursors\\Inspired by Adobe by XpucT";
}
