﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x02000197 RID: 407
[CompilerGenerated]
internal sealed class Class90
{
	// Token: 0x04000974 RID: 2420 RVA: 0x000023D0 File Offset: 0x000005D0
	internal static readonly Class90.Struct91 struct91_0;

	// Token: 0x04000975 RID: 2421 RVA: 0x00002430 File Offset: 0x00000630
	internal static readonly Class90.Struct88 struct88_0;

	// Token: 0x04000976 RID: 2422 RVA: 0x00002448 File Offset: 0x00000648
	internal static readonly Class90.Struct91 struct91_1;

	// Token: 0x04000977 RID: 2423 RVA: 0x000024A8 File Offset: 0x000006A8
	internal static readonly Class90.Struct92 struct92_0;

	// Token: 0x04000978 RID: 2424 RVA: 0x00002530 File Offset: 0x00000730
	internal static readonly Class90.Struct87 struct87_0;

	// Token: 0x04000979 RID: 2425 RVA: 0x00002540 File Offset: 0x00000740
	internal static readonly Class90.Struct89 struct89_0;

	// Token: 0x0400097A RID: 2426 RVA: 0x00002558 File Offset: 0x00000758
	internal static readonly Class90.Struct87 struct87_1;

	// Token: 0x0400097B RID: 2427 RVA: 0x00002568 File Offset: 0x00000768
	internal static readonly Class90.Struct87 struct87_2;

	// Token: 0x0400097C RID: 2428 RVA: 0x00002578 File Offset: 0x00000778
	internal static readonly Class90.Struct88 struct88_1;

	// Token: 0x0400097D RID: 2429 RVA: 0x00002590 File Offset: 0x00000790
	internal static readonly long BA4EFD301995A0BDF77479068D7554F1DC86A0485BC37F45A4DD7F9CE7A86046;

	// Token: 0x0400097E RID: 2430 RVA: 0x00002598 File Offset: 0x00000798
	internal static readonly Class90.Struct90 CA553C34B1E6D14652185F6E6B47A6F022E4174B868FE9C41809FDB6CBE1F858;

	// Token: 0x02000198 RID: 408
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 16)]
	private struct Struct87
	{
	}

	// Token: 0x02000199 RID: 409
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 20)]
	private struct Struct88
	{
	}

	// Token: 0x0200019A RID: 410
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 22)]
	private struct Struct89
	{
	}

	// Token: 0x0200019B RID: 411
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 33)]
	private struct Struct90
	{
	}

	// Token: 0x0200019C RID: 412
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 92)]
	private struct Struct91
	{
	}

	// Token: 0x0200019D RID: 413
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 132)]
	private struct Struct92
	{
	}
}
