﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// Token: 0x020000CA RID: 202
public static class GClass14
{
	// Token: 0x06000A51 RID: 2641 RVA: 0x000058ED File Offset: 0x00003AED
	public static void smethod_0(string string_0, bool bool_1 = true)
	{
		GClass14.smethod_2();
		GClass14.bool_0 = false;
		GClass14.smethod_3("winlogon.exe", true, "/supertoken /command:\"" + string_0 + "\"" + (bool_1 ? "" : " /hidden"));
	}

	// Token: 0x06000A52 RID: 2642 RVA: 0x0002CDD8 File Offset: 0x0002AFD8
	public static bool smethod_1(string string_0, out string string_1, out string string_2, out bool bool_1)
	{
		bool_1 = true;
		string_1 = "";
		string_2 = "";
		string[] array = string_0.Split(new char[]
		{
			' '
		});
		if (array.Length == 1)
		{
			string_1 = string_0;
			return true;
		}
		string text = "";
		int num = 0;
		if (array[array.Length - 1] == "/hidden")
		{
			bool_1 = false;
			Array.Resize<string>(ref array, array.Length - 1);
		}
		for (;;)
		{
			int num2 = num;
			if (!bool_1)
			{
				if (num2 >= array.Length - 1)
				{
					return true;
				}
			}
			else if (num2 >= array.Length)
			{
				return true;
			}
			string text2 = array[num];
			text = text + ((text.Length > 0) ? " " : "") + text2;
			if (text2.ToLower().EndsWith(".exe") || text2.ToLower().EndsWith(".cmd") || text2.ToLower().EndsWith(".bat"))
			{
				break;
			}
			num++;
		}
		string_1 = text;
		if (num + 1 <= array.Length - 1)
		{
			for (int i = num + 1; i < array.Length; i++)
			{
				string_2 = string_2 + ((string_2.Length > 0) ? " " : "") + array[i];
			}
		}
		return true;
	}

	// Token: 0x06000A53 RID: 2643
	[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern IntPtr OpenSCManager(string string_0, string string_1, uint uint_0);

	// Token: 0x06000A54 RID: 2644
	[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern IntPtr OpenService(IntPtr intptr_4, string string_0, uint uint_0);

	// Token: 0x06000A55 RID: 2645
	[DllImport("advapi32.dll")]
	private static extern int CloseServiceHandle(IntPtr intptr_4);

	// Token: 0x06000A56 RID: 2646
	[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern bool ChangeServiceConfig(IntPtr intptr_4, uint uint_0, GClass14.Enum2 enum2_0, uint uint_1, string string_0, string string_1, IntPtr intptr_5, [In] char[] char_0, string string_2, string string_3, string string_4);

	// Token: 0x06000A57 RID: 2647
	[DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool QueryServiceConfig(IntPtr intptr_4, IntPtr intptr_5, uint uint_0, out uint uint_1);

	// Token: 0x06000A58 RID: 2648
	[DllImport("advapi32", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool StartService(IntPtr intptr_4, int int_0, string[] string_0);

	// Token: 0x06000A59 RID: 2649 RVA: 0x0002CEF8 File Offset: 0x0002B0F8
	public static bool smethod_2()
	{
		GClass14.Class72 @class = new GClass14.Class72();
		IntPtr intptr_ = GClass14.OpenSCManager(null, null, 1U);
		IntPtr intptr_2 = GClass14.OpenService(intptr_, "TrustedInstaller", 23U);
		IntPtr intPtr = Marshal.AllocHGlobal(4096);
		uint num;
		if (!GClass14.QueryServiceConfig(intptr_2, intPtr, 4096U, out num))
		{
			return false;
		}
		Marshal.PtrToStructure<GClass14.Class72>(intPtr, @class);
		Marshal.FreeHGlobal(intPtr);
		bool flag;
		if ((flag = (@class.enum2_0 == GClass14.Enum2.Disabled)) && !GClass14.ChangeServiceConfig(intptr_2, 4294967295U, GClass14.Enum2.Manual, 4294967295U, null, null, IntPtr.Zero, null, null, null, null))
		{
			return false;
		}
		GClass14.StartService(intptr_2, 0, null);
		if (flag && !GClass14.ChangeServiceConfig(intptr_2, 4294967295U, GClass14.Enum2.Disabled, 4294967295U, null, null, IntPtr.Zero, null, null, null, null))
		{
			return false;
		}
		GClass14.CloseServiceHandle(intptr_2);
		GClass14.CloseServiceHandle(intptr_);
		return true;
	}

	// Token: 0x06000A5A RID: 2650
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool CloseHandle(IntPtr intptr_4);

	// Token: 0x06000A5B RID: 2651
	[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern IntPtr GetCurrentProcess();

	// Token: 0x06000A5C RID: 2652
	[DllImport("kernel32.dll")]
	private static extern uint WTSGetActiveConsoleSessionId();

	// Token: 0x06000A5D RID: 2653
	[DllImport("advapi32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool AdjustTokenPrivileges(IntPtr intptr_4, bool bool_1, [MarshalAs(UnmanagedType.Struct)] ref GClass14.Struct66 struct66_0, uint uint_0, IntPtr intptr_5, IntPtr intptr_6);

	// Token: 0x06000A5E RID: 2654
	[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool LookupPrivilegeValue(string string_0, string string_1, out GClass14.Struct67 struct67_0);

	// Token: 0x06000A5F RID: 2655
	[DllImport("kernel32.dll")]
	private static extern IntPtr OpenProcess(GClass14.Enum3 enum3_0, bool bool_1, int int_0);

	// Token: 0x06000A60 RID: 2656
	[DllImport("advapi32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool OpenProcessToken(IntPtr intptr_4, uint uint_0, out IntPtr intptr_5);

	// Token: 0x06000A61 RID: 2657
	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool SetTokenInformation(IntPtr intptr_4, uint uint_0, ref uint uint_1, uint uint_2);

	// Token: 0x06000A62 RID: 2658
	[DllImport("userenv.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool CreateEnvironmentBlock(out IntPtr intptr_4, IntPtr intptr_5, bool bool_1);

	// Token: 0x06000A63 RID: 2659
	[DllImport("userenv.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool DestroyEnvironmentBlock(IntPtr intptr_4);

	// Token: 0x06000A64 RID: 2660
	[DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool CreateProcessAsUserW(IntPtr intptr_4, string string_0, string string_1, ref GClass14.Struct68 struct68_0, ref GClass14.Struct68 struct68_1, bool bool_1, uint uint_0, IntPtr intptr_5, string string_2, ref GClass14.Struct69 struct69_0, out GClass14.Struct70 struct70_0);

	// Token: 0x06000A65 RID: 2661
	[DllImport("advapi32", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool CreateProcessWithTokenW(IntPtr intptr_4, GClass14.Enum5 enum5_0, string string_0, string string_1, uint uint_0, IntPtr intptr_5, string string_2, [In] ref GClass14.Struct69 struct69_0, out GClass14.Struct70 struct70_0);

	// Token: 0x06000A66 RID: 2662
	[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern bool DuplicateTokenEx(IntPtr intptr_4, uint uint_0, ref GClass14.Struct68 struct68_0, GClass14.Enum6 enum6_0, GClass14.Enum7 enum7_0, out IntPtr intptr_5);

	// Token: 0x06000A67 RID: 2663 RVA: 0x0002CFA8 File Offset: 0x0002B1A8
	public static void smethod_3(string string_0, bool bool_1, string string_1)
	{
		List<int> list = new List<int>();
		foreach (Process process in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(string_0)))
		{
			if (bool_1)
			{
				if ((long)process.SessionId == (long)((ulong)GClass14.WTSGetActiveConsoleSessionId()))
				{
					list.Add(process.Id);
				}
			}
			else
			{
				list.Add(process.Id);
			}
		}
		if (list.Count != 0)
		{
			GClass14.Struct68 @struct = default(GClass14.Struct68);
			try
			{
				string text = Application.ExecutablePath;
				string directoryName = Path.GetDirectoryName(text);
				text = (text.Contains(" ") ? ("\"" + text + "\"") : text);
				string text2 = "SeDebugPrivilege";
				GClass14.OpenProcessToken(GClass14.GetCurrentProcess(), 983551U, out GClass14.intptr_1);
				foreach (string string_2 in text2.Split(new char[]
				{
					','
				}))
				{
					GClass14.Struct67 struct67_;
					GClass14.LookupPrivilegeValue("", string_2, out struct67_);
					GClass14.Struct66 struct2 = default(GClass14.Struct66);
					struct2.uint_0 = 1U;
					struct2.struct67_0 = struct67_;
					struct2.uint_1 = 2U;
					GClass14.AdjustTokenPrivileges(GClass14.intptr_1, false, ref struct2, 0U, IntPtr.Zero, IntPtr.Zero);
				}
				GClass14.CloseHandle(GClass14.intptr_1);
				GClass14.intptr_0 = GClass14.OpenProcess(GClass14.Enum3.All, false, list[0]);
				GClass14.OpenProcessToken(GClass14.intptr_0, 10U, out GClass14.intptr_1);
				GClass14.DuplicateTokenEx(GClass14.intptr_1, 983551U, ref @struct, GClass14.Enum6.SecurityIdentification, GClass14.Enum7.TokenPrimary, out GClass14.intptr_2);
				if (GClass14.bool_0)
				{
					uint num = GClass14.WTSGetActiveConsoleSessionId();
					GClass14.SetTokenInformation(GClass14.intptr_2, 12U, ref num, 4U);
				}
				GClass14.CreateEnvironmentBlock(out GClass14.intptr_3, GClass14.intptr_1, true);
				uint uint_ = 1072U;
				GClass14.Struct69 struct3 = default(GClass14.Struct69);
				struct3.int_0 = Marshal.SizeOf<GClass14.Struct69>(struct3);
				struct3.string_1 = "winsta0\\default";
				GClass14.Struct70 struct4;
				if (!GClass14.CreateProcessWithTokenW(GClass14.intptr_2, GClass14.Enum5.WithProfile, Application.ExecutablePath, string_1, 134218800U, GClass14.intptr_3, directoryName, ref struct3, out struct4))
				{
					GClass14.CreateProcessAsUserW(GClass14.intptr_2, text, string_1, ref @struct, ref @struct, false, uint_, GClass14.intptr_3, directoryName, ref struct3, out struct4);
				}
				GClass14.CloseHandle(struct3.intptr_3);
				struct3.intptr_3 = IntPtr.Zero;
				GClass14.CloseHandle(struct3.intptr_1);
				struct3.intptr_1 = IntPtr.Zero;
				GClass14.CloseHandle(struct3.intptr_2);
				struct3.intptr_2 = IntPtr.Zero;
				GClass14.CloseHandle(struct4.intptr_1);
				struct4.intptr_1 = IntPtr.Zero;
				GClass14.CloseHandle(struct4.intptr_0);
				struct4.intptr_1 = IntPtr.Zero;
				GClass14.DestroyEnvironmentBlock(GClass14.intptr_3);
				GClass14.intptr_3 = IntPtr.Zero;
				GClass14.CloseHandle(GClass14.intptr_2);
				GClass14.intptr_2 = IntPtr.Zero;
				GClass14.CloseHandle(GClass14.intptr_1);
				GClass14.intptr_1 = IntPtr.Zero;
			}
			catch
			{
			}
			return;
		}
	}

	// Token: 0x06000A68 RID: 2664 RVA: 0x000033BD File Offset: 0x000015BD
	static string smethod_4(string string_0, string string_1, string string_2, string string_3)
	{
		return string_0 + string_1 + string_2 + string_3;
	}

	// Token: 0x06000A69 RID: 2665 RVA: 0x00003AEF File Offset: 0x00001CEF
	static string[] smethod_5(string string_0, char[] char_0)
	{
		return string_0.Split(char_0);
	}

	// Token: 0x06000A6A RID: 2666 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_6(string string_0, string string_1)
	{
		return string_0 == string_1;
	}

	// Token: 0x06000A6B RID: 2667 RVA: 0x00002A44 File Offset: 0x00000C44
	static int smethod_7(string string_0)
	{
		return string_0.Length;
	}

	// Token: 0x06000A6C RID: 2668 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_8(string string_0, string string_1, string string_2)
	{
		return string_0 + string_1 + string_2;
	}

	// Token: 0x06000A6D RID: 2669 RVA: 0x000036AF File Offset: 0x000018AF
	static string smethod_9(string string_0)
	{
		return string_0.ToLower();
	}

	// Token: 0x06000A6E RID: 2670 RVA: 0x00002A29 File Offset: 0x00000C29
	static bool smethod_10(string string_0, string string_1)
	{
		return string_0.EndsWith(string_1);
	}

	// Token: 0x06000A6F RID: 2671 RVA: 0x00005925 File Offset: 0x00003B25
	static IntPtr smethod_11(int int_0)
	{
		return Marshal.AllocHGlobal(int_0);
	}

	// Token: 0x06000A70 RID: 2672 RVA: 0x0000592D File Offset: 0x00003B2D
	static void smethod_12(IntPtr intptr_4)
	{
		Marshal.FreeHGlobal(intptr_4);
	}

	// Token: 0x06000A71 RID: 2673 RVA: 0x00005935 File Offset: 0x00003B35
	static string smethod_13(string string_0)
	{
		return Path.GetFileNameWithoutExtension(string_0);
	}

	// Token: 0x06000A72 RID: 2674 RVA: 0x000033EC File Offset: 0x000015EC
	static Process[] smethod_14(string string_0)
	{
		return Process.GetProcessesByName(string_0);
	}

	// Token: 0x06000A73 RID: 2675 RVA: 0x0000593D File Offset: 0x00003B3D
	static int smethod_15(Process process_0)
	{
		return process_0.SessionId;
	}

	// Token: 0x06000A74 RID: 2676 RVA: 0x00003C7C File Offset: 0x00001E7C
	static int smethod_16(Process process_0)
	{
		return process_0.Id;
	}

	// Token: 0x06000A75 RID: 2677 RVA: 0x00005945 File Offset: 0x00003B45
	static string smethod_17()
	{
		return Application.ExecutablePath;
	}

	// Token: 0x06000A76 RID: 2678 RVA: 0x000031C3 File Offset: 0x000013C3
	static string smethod_18(string string_0)
	{
		return Path.GetDirectoryName(string_0);
	}

	// Token: 0x06000A77 RID: 2679 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_19(string string_0, string string_1)
	{
		return string_0.Contains(string_1);
	}

	// Token: 0x0400040F RID: 1039
	private static IntPtr intptr_0;

	// Token: 0x04000410 RID: 1040
	private static IntPtr intptr_1;

	// Token: 0x04000411 RID: 1041
	private static IntPtr intptr_2;

	// Token: 0x04000412 RID: 1042
	private static IntPtr intptr_3;

	// Token: 0x04000413 RID: 1043
	public static bool bool_0;

	// Token: 0x020000CB RID: 203
	private enum Enum2 : uint
	{
		// Token: 0x04000415 RID: 1045
		BootStart,
		// Token: 0x04000416 RID: 1046
		SystemStart,
		// Token: 0x04000417 RID: 1047
		Automatic,
		// Token: 0x04000418 RID: 1048
		Manual,
		// Token: 0x04000419 RID: 1049
		Disabled
	}

	// Token: 0x020000CC RID: 204
	[StructLayout(LayoutKind.Sequential)]
	private class Class72
	{
		// Token: 0x0400041A RID: 1050
		[MarshalAs(UnmanagedType.U4)]
		public uint uint_0;

		// Token: 0x0400041B RID: 1051
		[MarshalAs(UnmanagedType.U4)]
		public GClass14.Enum2 enum2_0;

		// Token: 0x0400041C RID: 1052
		[MarshalAs(UnmanagedType.U4)]
		public uint uint_1;

		// Token: 0x0400041D RID: 1053
		[MarshalAs(UnmanagedType.LPWStr)]
		public string string_0;

		// Token: 0x0400041E RID: 1054
		[MarshalAs(UnmanagedType.LPWStr)]
		public string string_1;

		// Token: 0x0400041F RID: 1055
		[MarshalAs(UnmanagedType.U4)]
		public uint uint_2;

		// Token: 0x04000420 RID: 1056
		[MarshalAs(UnmanagedType.LPWStr)]
		public string string_2;

		// Token: 0x04000421 RID: 1057
		[MarshalAs(UnmanagedType.LPWStr)]
		public string string_3;

		// Token: 0x04000422 RID: 1058
		[MarshalAs(UnmanagedType.LPWStr)]
		public string string_4;
	}

	// Token: 0x020000CD RID: 205
	private struct Struct66
	{
		// Token: 0x04000423 RID: 1059
		internal uint uint_0;

		// Token: 0x04000424 RID: 1060
		internal GClass14.Struct67 struct67_0;

		// Token: 0x04000425 RID: 1061
		internal uint uint_1;
	}

	// Token: 0x020000CE RID: 206
	private struct Struct67
	{
		// Token: 0x04000426 RID: 1062
		internal int int_0;

		// Token: 0x04000427 RID: 1063
		internal uint uint_0;
	}

	// Token: 0x020000CF RID: 207
	[Flags]
	private enum Enum3 : uint
	{
		// Token: 0x04000429 RID: 1065
		All = 2035711U,
		// Token: 0x0400042A RID: 1066
		Terminate = 1U,
		// Token: 0x0400042B RID: 1067
		CreateThread = 2U,
		// Token: 0x0400042C RID: 1068
		VirtualMemoryOperation = 8U,
		// Token: 0x0400042D RID: 1069
		VirtualMemoryRead = 16U,
		// Token: 0x0400042E RID: 1070
		VirtualMemoryWrite = 32U,
		// Token: 0x0400042F RID: 1071
		DuplicateHandle = 64U,
		// Token: 0x04000430 RID: 1072
		CreateProcess = 128U,
		// Token: 0x04000431 RID: 1073
		SetQuota = 256U,
		// Token: 0x04000432 RID: 1074
		SetInformation = 512U,
		// Token: 0x04000433 RID: 1075
		QueryInformation = 1024U,
		// Token: 0x04000434 RID: 1076
		QueryLimitedInformation = 4096U,
		// Token: 0x04000435 RID: 1077
		Synchronize = 1048576U
	}

	// Token: 0x020000D0 RID: 208
	[Flags]
	private enum Enum4 : uint
	{
		// Token: 0x04000437 RID: 1079
		CREATE_BREAKAWAY_FROM_JOB = 16777216U,
		// Token: 0x04000438 RID: 1080
		CREATE_DEFAULT_ERROR_MODE = 67108864U,
		// Token: 0x04000439 RID: 1081
		CREATE_NEW_CONSOLE = 16U,
		// Token: 0x0400043A RID: 1082
		CREATE_NEW_PROCESS_GROUP = 512U,
		// Token: 0x0400043B RID: 1083
		CREATE_NO_WINDOW = 134217728U,
		// Token: 0x0400043C RID: 1084
		CREATE_PROTECTED_PROCESS = 262144U,
		// Token: 0x0400043D RID: 1085
		CREATE_PRESERVE_CODE_AUTHZ_LEVEL = 33554432U,
		// Token: 0x0400043E RID: 1086
		CREATE_SECURE_PROCESS = 4194304U,
		// Token: 0x0400043F RID: 1087
		CREATE_SEPARATE_WOW_VDM = 2048U,
		// Token: 0x04000440 RID: 1088
		CREATE_SHARED_WOW_VDM = 4096U,
		// Token: 0x04000441 RID: 1089
		CREATE_SUSPENDED = 4U,
		// Token: 0x04000442 RID: 1090
		CREATE_UNICODE_ENVIRONMENT = 1024U,
		// Token: 0x04000443 RID: 1091
		DEBUG_ONLY_THIS_PROCESS = 2U,
		// Token: 0x04000444 RID: 1092
		DEBUG_PROCESS = 1U
	}

	// Token: 0x020000D1 RID: 209
	private struct Struct68
	{
		// Token: 0x04000445 RID: 1093
		public int int_0;

		// Token: 0x04000446 RID: 1094
		public IntPtr intptr_0;

		// Token: 0x04000447 RID: 1095
		public int int_1;
	}

	// Token: 0x020000D2 RID: 210
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
	private struct Struct69
	{
		// Token: 0x04000448 RID: 1096
		public int int_0;

		// Token: 0x04000449 RID: 1097
		public string string_0;

		// Token: 0x0400044A RID: 1098
		public string string_1;

		// Token: 0x0400044B RID: 1099
		public string string_2;

		// Token: 0x0400044C RID: 1100
		public int int_1;

		// Token: 0x0400044D RID: 1101
		public int int_2;

		// Token: 0x0400044E RID: 1102
		public int int_3;

		// Token: 0x0400044F RID: 1103
		public int int_4;

		// Token: 0x04000450 RID: 1104
		public int int_5;

		// Token: 0x04000451 RID: 1105
		public int int_6;

		// Token: 0x04000452 RID: 1106
		public int int_7;

		// Token: 0x04000453 RID: 1107
		public int int_8;

		// Token: 0x04000454 RID: 1108
		public short short_0;

		// Token: 0x04000455 RID: 1109
		public short short_1;

		// Token: 0x04000456 RID: 1110
		public IntPtr intptr_0;

		// Token: 0x04000457 RID: 1111
		public IntPtr intptr_1;

		// Token: 0x04000458 RID: 1112
		public IntPtr intptr_2;

		// Token: 0x04000459 RID: 1113
		public IntPtr intptr_3;
	}

	// Token: 0x020000D3 RID: 211
	private struct Struct70
	{
		// Token: 0x0400045A RID: 1114
		public IntPtr intptr_0;

		// Token: 0x0400045B RID: 1115
		public IntPtr intptr_1;

		// Token: 0x0400045C RID: 1116
		public int int_0;

		// Token: 0x0400045D RID: 1117
		public int int_1;
	}

	// Token: 0x020000D4 RID: 212
	private enum Enum5
	{
		// Token: 0x0400045F RID: 1119
		WithProfile = 1,
		// Token: 0x04000460 RID: 1120
		NetCredentialsOnly
	}

	// Token: 0x020000D5 RID: 213
	private enum Enum6
	{
		// Token: 0x04000462 RID: 1122
		SecurityAnonymous,
		// Token: 0x04000463 RID: 1123
		SecurityIdentification,
		// Token: 0x04000464 RID: 1124
		SecurityImpersonation,
		// Token: 0x04000465 RID: 1125
		SecurityDelegation
	}

	// Token: 0x020000D6 RID: 214
	private enum Enum7
	{
		// Token: 0x04000467 RID: 1127
		TokenPrimary = 1,
		// Token: 0x04000468 RID: 1128
		TokenImpersonation
	}
}
