﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000079 RID: 121
internal class Class37
{
	// Token: 0x1700002D RID: 45
	// (get) Token: 0x060005DF RID: 1503 RVA: 0x0001C03C File Offset: 0x0001A23C
	public static Class37 Class37_0
	{
		get
		{
			if (Class37.class37_0 == null)
			{
				object obj = Class37.object_0;
				lock (obj)
				{
					if (Class37.class37_0 == null)
					{
						Class37.class37_0 = new Class37();
					}
				}
			}
			return Class37.class37_0;
		}
	}

	// Token: 0x060005E0 RID: 1504 RVA: 0x0001C09C File Offset: 0x0001A29C
	public void method_0()
	{
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search!AllowCortana", "0", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search!DisableWebSearch", "1", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search!ConnectedSearchUseWeb", "0", RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search!AllowCloudSearch", "0", RegistryValueKind.DWord);
		Registry.LocalMachine.CreateSubKey(this.string_0).SetValue("ModelDownloadAllowed", 0);
		RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(this.string_1);
		registryKey.SetValue("AllowCloudSearch", 0);
		registryKey.SetValue("AllowSearchToUseLocation", 0);
		registryKey.SetValue("ConnectedSearchUseWeb", 0);
		registryKey.SetValue("DisableWebSearch", 1);
		Registry.CurrentUser.CreateSubKey(this.string_2).SetValue("CortanaConsent", 0);
		Registry.CurrentUser.CreateSubKey(this.string_3).SetValue("HarvestContacts", 0);
		RegistryKey registryKey2 = Registry.CurrentUser.CreateSubKey(this.string_4);
		registryKey2.SetValue("RestrictImplicitInkCollection", 1);
		registryKey2.SetValue("RestrictImplicitTextCollection", 1);
		Registry.CurrentUser.CreateSubKey(this.string_5).SetValue("AcceptedPrivacyPolicy", 0);
		using (RegistryKey registryKey3 = Registry.CurrentUser.OpenSubKey(this.string_6, true))
		{
			if (registryKey3 != null)
			{
				registryKey3.SetValue("Value", "Deny");
			}
		}
		using (RegistryKey registryKey4 = Registry.CurrentUser.OpenSubKey(this.string_7, true))
		{
			if (registryKey4 != null)
			{
				registryKey4.SetValue("DisabledByUser", 1);
				registryKey4.SetValue("Disabled", 1);
			}
		}
		using (RegistryKey registryKey5 = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", true))
		{
			if (registryKey5 != null && registryKey5.GetValue("ShowCortanaButton") != null)
			{
				if (registryKey5 != null)
				{
					registryKey5.SetValue("ShowCortanaButton", 0);
				}
			}
		}
		string text = GClass13.string_6 + "\\SystemApps\\Microsoft.Windows.Cortana_cw5n1h2txyewy\\SearchUI.exe";
		if (File.Exists(text))
		{
			GClass6.GClass6_0.method_14("netsh advfirewall firewall add rule name=\"Win 10 Tweaker – Cortana \ud83d\udd0e\" dir=out action=block program=\"" + text + "\" enable=yes");
		}
		GClass6.GClass6_0.method_14("schtasks /change /tn \"\\Microsoft\\Windows\\Speech\\SpeechModelDownloadTask\" /disable");
	}

	// Token: 0x060005E1 RID: 1505 RVA: 0x0001C310 File Offset: 0x0001A510
	public void method_1()
	{
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search!AllowCortana", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search!DisableWebSearch", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search!ConnectedSearchUseWeb", null, RegistryValueKind.DWord);
		GClass4.smethod_9("HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search!AllowCloudSearch", null, RegistryValueKind.DWord);
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(this.string_0, true))
		{
			if (registryKey != null && registryKey.GetValue("ModelDownloadAllowed") != null)
			{
				registryKey.DeleteValue("ModelDownloadAllowed");
			}
		}
		Class37.Class38 @class = new Class37.Class38();
		@class.registryKey_0 = Registry.CurrentUser.OpenSubKey(this.string_1, true);
		try
		{
			new List<string>
			{
				"AllowCloudSearch",
				"AllowSearchToUseLocation",
				"ConnectedSearchUseWeb",
				"DisableWebSearch"
			}.ForEach(new Action<string>(@class.method_0));
		}
		finally
		{
			if (@class.registryKey_0 != null)
			{
				((IDisposable)@class.registryKey_0).Dispose();
			}
		}
		using (RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey(this.string_2, true))
		{
			if (registryKey2 != null && registryKey2.GetValue("CortanaConsent") != null)
			{
				registryKey2.DeleteValue("CortanaConsent");
			}
		}
		using (RegistryKey registryKey3 = Registry.CurrentUser.OpenSubKey(this.string_3, true))
		{
			if (registryKey3 != null && registryKey3.GetValue("HarvestContacts") != null)
			{
				registryKey3.DeleteValue("HarvestContacts");
			}
		}
		using (RegistryKey registryKey4 = Registry.CurrentUser.OpenSubKey(this.string_4, true))
		{
			if (registryKey4 != null && registryKey4.GetValue("RestrictImplicitInkCollection") != null)
			{
				registryKey4.DeleteValue("RestrictImplicitInkCollection");
			}
		}
		using (RegistryKey registryKey5 = Registry.CurrentUser.OpenSubKey(this.string_4, true))
		{
			if (registryKey5 != null && registryKey5.GetValue("RestrictImplicitTextCollection") != null)
			{
				registryKey5.DeleteValue("RestrictImplicitTextCollection");
			}
		}
		using (RegistryKey registryKey6 = Registry.CurrentUser.OpenSubKey(this.string_5, true))
		{
			if (registryKey6 != null && registryKey6.GetValue("AcceptedPrivacyPolicy") != null)
			{
				registryKey6.DeleteValue("AcceptedPrivacyPolicy");
			}
		}
		using (RegistryKey registryKey7 = Registry.CurrentUser.OpenSubKey(this.string_6, true))
		{
			string a;
			if (registryKey7 != null)
			{
				object value = registryKey7.GetValue("Value");
				a = ((value != null) ? value.ToString() : null);
			}
			else
			{
				a = null;
			}
			if (a == "Deny")
			{
				registryKey7.SetValue("Value", "Allow");
			}
		}
		using (RegistryKey registryKey8 = Registry.CurrentUser.OpenSubKey(this.string_7, true))
		{
			if (registryKey8 != null && registryKey8.GetValue("DisabledByUser") != null)
			{
				registryKey8.DeleteValue("DisabledByUser");
			}
			if (registryKey8 != null && registryKey8.GetValue("Disabled") != null)
			{
				registryKey8.DeleteValue("Disabled");
			}
		}
		GClass6.GClass6_0.method_14("netsh advfirewall firewall delete rule name=\"Win 10 Tweaker – Cortana \ud83d\udd0e\"");
		GClass6.GClass6_0.method_14("schtasks /change /tn \"\\Microsoft\\Windows\\Speech\\SpeechModelDownloadTask\" /enable");
	}

	// Token: 0x060005E4 RID: 1508 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060005E5 RID: 1509 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060005E6 RID: 1510 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_8)
	{
		return registryKey_0.CreateSubKey(string_8);
	}

	// Token: 0x060005E7 RID: 1511 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_3(RegistryKey registryKey_0, string string_8, object object_1)
	{
		registryKey_0.SetValue(string_8, object_1);
	}

	// Token: 0x060005E8 RID: 1512 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_4(RegistryKey registryKey_0, string string_8, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_8, bool_0);
	}

	// Token: 0x060005E9 RID: 1513 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_5(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060005EA RID: 1514 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_6(RegistryKey registryKey_0, string string_8)
	{
		return registryKey_0.GetValue(string_8);
	}

	// Token: 0x060005EB RID: 1515 RVA: 0x000043D9 File Offset: 0x000025D9
	static void smethod_7(RegistryKey registryKey_0, string string_8, object object_1)
	{
		registryKey_0.SetValue(string_8, object_1);
	}

	// Token: 0x060005EC RID: 1516 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_8(string string_8, string string_9)
	{
		return string_8 + string_9;
	}

	// Token: 0x060005ED RID: 1517 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_9(string string_8)
	{
		return File.Exists(string_8);
	}

	// Token: 0x060005EE RID: 1518 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_10(string string_8, string string_9, string string_10)
	{
		return string_8 + string_9 + string_10;
	}

	// Token: 0x060005EF RID: 1519 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_11(RegistryKey registryKey_0, string string_8)
	{
		registryKey_0.DeleteValue(string_8);
	}

	// Token: 0x060005F0 RID: 1520 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_12(object object_1)
	{
		return object_1.ToString();
	}

	// Token: 0x060005F1 RID: 1521 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_13(string string_8, string string_9)
	{
		return string_8 == string_9;
	}

	// Token: 0x060005F2 RID: 1522 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_14()
	{
		return new object();
	}

	// Token: 0x04000271 RID: 625
	private static volatile Class37 class37_0;

	// Token: 0x04000272 RID: 626
	private static readonly object object_0 = new object();

	// Token: 0x04000273 RID: 627
	private readonly string string_0 = "SOFTWARE\\Microsoft\\Speech_OneCore\\Preferences";

	// Token: 0x04000274 RID: 628
	private readonly string string_1 = "SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search";

	// Token: 0x04000275 RID: 629
	private readonly string string_2 = GClass2.GClass2_0.String_0 + "\\Windows Search";

	// Token: 0x04000276 RID: 630
	private readonly string string_3 = "Software\\Microsoft\\InputPersonalization\\TrainedDataStore";

	// Token: 0x04000277 RID: 631
	private readonly string string_4 = "Software\\Microsoft\\InputPersonalization";

	// Token: 0x04000278 RID: 632
	private readonly string string_5 = "Software\\Microsoft\\Personalization\\Settings";

	// Token: 0x04000279 RID: 633
	private readonly string string_6 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\microphone\\Microsoft.549981C3F5F10_8wekyb3d8bbwe";

	// Token: 0x0400027A RID: 634
	private readonly string string_7 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications\\Microsoft.549981C3F5F10_8wekyb3d8bbwe";

	// Token: 0x0200007A RID: 122
	[CompilerGenerated]
	private sealed class Class38
	{
		// Token: 0x060005F4 RID: 1524 RVA: 0x000043E3 File Offset: 0x000025E3
		internal void method_0(string string_0)
		{
			RegistryKey registryKey = this.registryKey_0;
			if (registryKey != null)
			{
				if (registryKey.GetValue(string_0) != null)
				{
					this.registryKey_0.DeleteValue(string_0);
				}
			}
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x00002EDC File Offset: 0x000010DC
		static object smethod_0(RegistryKey registryKey_1, string string_0)
		{
			return registryKey_1.GetValue(string_0);
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x00003010 File Offset: 0x00001210
		static void smethod_1(RegistryKey registryKey_1, string string_0)
		{
			registryKey_1.DeleteValue(string_0);
		}

		// Token: 0x0400027B RID: 635
		public RegistryKey registryKey_0;
	}
}
