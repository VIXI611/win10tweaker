﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x0200019F RID: 415
[DefaultMember("Name")]
[TypeIdentifier]
[CompilerGenerated]
[Guid("FAC32C80-CBE4-11CE-8350-444553540000")]
[ComImport]
public interface GInterface2
{
	// Token: 0x0600143F RID: 5183
	void _VtblGap1_2();

	// Token: 0x17000105 RID: 261
	// (get) Token: 0x06001440 RID: 5184
	// (set) Token: 0x06001441 RID: 5185
	[DispId(0)]
	string String_0 { [DispId(0)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.BStr)] get; [DispId(0)] [MethodImpl(MethodImplOptions.InternalCall)] [param: MarshalAs(UnmanagedType.BStr)] [param: In] set; }

	// Token: 0x06001442 RID: 5186
	void _VtblGap2_1();

	// Token: 0x17000106 RID: 262
	// (get) Token: 0x06001443 RID: 5187
	[DispId(1610743813)]
	object Object_0 { [DispId(1610743813)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.IDispatch)] get; }
}
