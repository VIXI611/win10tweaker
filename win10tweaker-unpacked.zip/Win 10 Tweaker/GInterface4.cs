﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A1 RID: 417
[TypeIdentifier]
[Guid("A4C6892C-3BA9-11D2-9DEA-00C04FB16162")]
[CompilerGenerated]
[ComImport]
public interface GInterface4 : GInterface3
{
}
