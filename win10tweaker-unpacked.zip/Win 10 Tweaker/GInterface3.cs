﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A0 RID: 416
[TypeIdentifier]
[Guid("D8F015C0-C278-11CE-A49E-444553540000")]
[CompilerGenerated]
[ComImport]
public interface GInterface3
{
}
