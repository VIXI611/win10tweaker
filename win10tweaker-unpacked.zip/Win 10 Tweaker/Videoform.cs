﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x020000E8 RID: 232
public partial class Videoform : Form
{
	// Token: 0x06000B96 RID: 2966 RVA: 0x00006937 File Offset: 0x00004B37
	public Videoform()
	{
		this.InitializeComponent();
	}

	// Token: 0x06000B97 RID: 2967 RVA: 0x00006945 File Offset: 0x00004B45
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06000B99 RID: 2969 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_0(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000B9A RID: 2970 RVA: 0x00006964 File Offset: 0x00004B64
	static WebBrowser smethod_1()
	{
		return new WebBrowser();
	}

	// Token: 0x06000B9B RID: 2971 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_2(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x06000B9C RID: 2972 RVA: 0x0000696B File Offset: 0x00004B6B
	static void smethod_3(Control control_0, DockStyle dockStyle_0)
	{
		control_0.Dock = dockStyle_0;
	}

	// Token: 0x0400049F RID: 1183
	private IContainer icontainer_0;
}
