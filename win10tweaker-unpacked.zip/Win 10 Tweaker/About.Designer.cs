﻿// Token: 0x0200000C RID: 12
public partial class About : global::GForm0
{
	// Token: 0x0600006C RID: 108 RVA: 0x0000C1B8 File Offset: 0x0000A3B8
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.AboutDescription = new global::System.Windows.Forms.Label();
		this.AboutDonate2 = new global::System.Windows.Forms.PictureBox();
		this.AboutDonate3 = new global::System.Windows.Forms.PictureBox();
		this.AboutDonate1 = new global::System.Windows.Forms.PictureBox();
		this.toolTip_0 = new global::System.Windows.Forms.ToolTip(this.icontainer_0);
		this.AboutGetPro = new global::System.Windows.Forms.Button();
		this.CheckForUpdates = new global::System.Windows.Forms.LinkLabel();
		this.AboutGetBeta = new global::System.Windows.Forms.LinkLabel();
		this.ActivateLink = new global::System.Windows.Forms.LinkLabel();
		this.MainPanel2 = new global::System.Windows.Forms.Panel();
		this.AboutActivatePro = new global::System.Windows.Forms.Button();
		this.AboutFeatures = new global::System.Windows.Forms.Label();
		this.AboutVersionLabel = new global::System.Windows.Forms.Label();
		this.AboutAuthor = new global::System.Windows.Forms.Label();
		this.Coffee = new global::System.Windows.Forms.Label();
		this.MainPanel1 = new global::System.Windows.Forms.Panel();
		this.ChangeLog = new global::System.Windows.Forms.LinkLabel();
		this.GoToWebSite = new global::System.Windows.Forms.LinkLabel();
		this.HeaderPanel = new global::System.Windows.Forms.Panel();
		this.Header = new global::System.Windows.Forms.Label();
		this.CloseIcon = new global::System.Windows.Forms.Button();
		this.MainPanel3 = new global::System.Windows.Forms.Panel();
		this.PNotice = new global::System.Windows.Forms.Label();
		this.LabelTextBox = new global::System.Windows.Forms.Label();
		this.TextBoxMain = new global::System.Windows.Forms.TextBox();
		this.ButtonEmail = new global::System.Windows.Forms.Button();
		this.Price = new global::GClass11();
		((global::System.ComponentModel.ISupportInitialize)this.AboutDonate2).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.AboutDonate3).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.AboutDonate1).BeginInit();
		this.MainPanel2.SuspendLayout();
		this.MainPanel1.SuspendLayout();
		this.HeaderPanel.SuspendLayout();
		this.MainPanel3.SuspendLayout();
		base.SuspendLayout();
		this.AboutDescription.AutoSize = true;
		this.AboutDescription.Location = new global::System.Drawing.Point(4, 11);
		this.AboutDescription.Name = "AboutDescription";
		this.AboutDescription.Size = new global::System.Drawing.Size(0, 13);
		this.AboutDescription.TabIndex = 31;
		this.AboutDonate2.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.AboutDonate2.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.AboutDonate2.Image = global::Class89.Bitmap_69;
		this.AboutDonate2.Location = new global::System.Drawing.Point(118, 151);
		this.AboutDonate2.Name = "AboutDonate2";
		this.AboutDonate2.Size = new global::System.Drawing.Size(108, 55);
		this.AboutDonate2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.AboutDonate2.TabIndex = 36;
		this.AboutDonate2.TabStop = false;
		this.AboutDonate3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.AboutDonate3.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.AboutDonate3.Image = global::Class89.Bitmap_15;
		this.AboutDonate3.Location = new global::System.Drawing.Point(234, 151);
		this.AboutDonate3.Name = "AboutDonate3";
		this.AboutDonate3.Size = new global::System.Drawing.Size(108, 55);
		this.AboutDonate3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.AboutDonate3.TabIndex = 37;
		this.AboutDonate3.TabStop = false;
		this.AboutDonate1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.AboutDonate1.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.AboutDonate1.Image = global::Class89.Bitmap_45;
		this.AboutDonate1.Location = new global::System.Drawing.Point(2, 151);
		this.AboutDonate1.Name = "AboutDonate1";
		this.AboutDonate1.Size = new global::System.Drawing.Size(108, 55);
		this.AboutDonate1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.AboutDonate1.TabIndex = 35;
		this.AboutDonate1.TabStop = false;
		this.toolTip_0.AutoPopDelay = 30000;
		this.toolTip_0.InitialDelay = 40;
		this.toolTip_0.ReshowDelay = 100;
		this.AboutGetPro.BackColor = global::System.Drawing.SystemColors.InactiveBorder;
		this.AboutGetPro.FlatAppearance.BorderSize = 0;
		this.AboutGetPro.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.AboutGetPro.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.AboutGetPro.ForeColor = global::System.Drawing.SystemColors.ControlText;
		this.AboutGetPro.Location = new global::System.Drawing.Point(19, 137);
		this.AboutGetPro.Name = "AboutGetPro";
		this.AboutGetPro.Size = new global::System.Drawing.Size(328, 26);
		this.AboutGetPro.TabIndex = 35;
		this.AboutGetPro.UseVisualStyleBackColor = false;
		this.AboutGetPro.Click += new global::System.EventHandler(this.AboutGetPro_Click);
		this.CheckForUpdates.ActiveLinkColor = global::System.Drawing.Color.Transparent;
		this.CheckForUpdates.AutoSize = true;
		this.CheckForUpdates.LinkColor = global::System.Drawing.Color.AliceBlue;
		this.CheckForUpdates.Location = new global::System.Drawing.Point(4, 76);
		this.CheckForUpdates.Name = "CheckForUpdates";
		this.CheckForUpdates.Size = new global::System.Drawing.Size(0, 13);
		this.CheckForUpdates.TabIndex = 34;
		this.CheckForUpdates.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CheckForUpdates_LinkClicked);
		this.AboutGetBeta.ActiveLinkColor = global::System.Drawing.Color.Transparent;
		this.AboutGetBeta.AutoSize = true;
		this.AboutGetBeta.LinkColor = global::System.Drawing.Color.AliceBlue;
		this.AboutGetBeta.Location = new global::System.Drawing.Point(137, 76);
		this.AboutGetBeta.Name = "AboutGetBeta";
		this.AboutGetBeta.Size = new global::System.Drawing.Size(0, 13);
		this.AboutGetBeta.TabIndex = 41;
		this.AboutGetBeta.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.AboutGetBeta_LinkClicked);
		this.ActivateLink.ActiveLinkColor = global::System.Drawing.Color.Transparent;
		this.ActivateLink.AutoSize = true;
		this.ActivateLink.LinkColor = global::System.Drawing.Color.FromArgb(131, 173, 229);
		this.ActivateLink.Location = new global::System.Drawing.Point(73, 63);
		this.ActivateLink.Name = "ActivateLink";
		this.ActivateLink.Size = new global::System.Drawing.Size(0, 13);
		this.ActivateLink.TabIndex = 42;
		this.ActivateLink.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ActivateLink_LinkClicked);
		this.MainPanel2.AllowDrop = true;
		this.MainPanel2.BackColor = global::System.Drawing.Color.Transparent;
		this.MainPanel2.Controls.Add(this.AboutActivatePro);
		this.MainPanel2.Controls.Add(this.AboutGetPro);
		this.MainPanel2.Controls.Add(this.AboutFeatures);
		this.MainPanel2.Location = new global::System.Drawing.Point(0, 34);
		this.MainPanel2.Name = "MainPanel2";
		this.MainPanel2.Size = new global::System.Drawing.Size(360, 222);
		this.MainPanel2.TabIndex = 165;
		this.MainPanel2.Visible = false;
		this.AboutActivatePro.BackColor = global::System.Drawing.SystemColors.InactiveBorder;
		this.AboutActivatePro.FlatAppearance.BorderSize = 0;
		this.AboutActivatePro.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.AboutActivatePro.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.AboutActivatePro.ForeColor = global::System.Drawing.SystemColors.ControlText;
		this.AboutActivatePro.Location = new global::System.Drawing.Point(19, 169);
		this.AboutActivatePro.Name = "AboutActivatePro";
		this.AboutActivatePro.Size = new global::System.Drawing.Size(328, 26);
		this.AboutActivatePro.TabIndex = 36;
		this.AboutActivatePro.UseVisualStyleBackColor = false;
		this.AboutActivatePro.Click += new global::System.EventHandler(this.AboutActivatePro_Click);
		this.AboutFeatures.AutoSize = true;
		this.AboutFeatures.ForeColor = global::System.Drawing.Color.AliceBlue;
		this.AboutFeatures.Location = new global::System.Drawing.Point(16, 10);
		this.AboutFeatures.Name = "AboutFeatures";
		this.AboutFeatures.Size = new global::System.Drawing.Size(0, 13);
		this.AboutFeatures.TabIndex = 32;
		this.AboutVersionLabel.AutoSize = true;
		this.AboutVersionLabel.Location = new global::System.Drawing.Point(4, 63);
		this.AboutVersionLabel.Name = "AboutVersionLabel";
		this.AboutVersionLabel.Size = new global::System.Drawing.Size(0, 13);
		this.AboutVersionLabel.TabIndex = 167;
		this.AboutAuthor.AutoSize = true;
		this.AboutAuthor.Location = new global::System.Drawing.Point(4, 89);
		this.AboutAuthor.Name = "AboutAuthor";
		this.AboutAuthor.Size = new global::System.Drawing.Size(0, 13);
		this.AboutAuthor.TabIndex = 168;
		this.Coffee.AutoSize = true;
		this.Coffee.BackColor = global::System.Drawing.Color.Transparent;
		this.Coffee.Location = new global::System.Drawing.Point(8, 129);
		this.Coffee.Name = "Coffee";
		this.Coffee.Size = new global::System.Drawing.Size(0, 13);
		this.Coffee.TabIndex = 169;
		this.MainPanel1.BackColor = global::System.Drawing.Color.Transparent;
		this.MainPanel1.Controls.Add(this.ChangeLog);
		this.MainPanel1.Controls.Add(this.ActivateLink);
		this.MainPanel1.Controls.Add(this.AboutDescription);
		this.MainPanel1.Controls.Add(this.AboutVersionLabel);
		this.MainPanel1.Controls.Add(this.AboutAuthor);
		this.MainPanel1.Controls.Add(this.CheckForUpdates);
		this.MainPanel1.Controls.Add(this.Coffee);
		this.MainPanel1.Controls.Add(this.AboutDonate2);
		this.MainPanel1.Controls.Add(this.AboutDonate3);
		this.MainPanel1.Controls.Add(this.AboutGetBeta);
		this.MainPanel1.Controls.Add(this.AboutDonate1);
		this.MainPanel1.Controls.Add(this.GoToWebSite);
		this.MainPanel1.Location = new global::System.Drawing.Point(8, 34);
		this.MainPanel1.Name = "MainPanel1";
		this.MainPanel1.Size = new global::System.Drawing.Size(344, 210);
		this.MainPanel1.TabIndex = 171;
		this.ChangeLog.ActiveLinkColor = global::System.Drawing.Color.Transparent;
		this.ChangeLog.AutoSize = true;
		this.ChangeLog.LinkColor = global::System.Drawing.Color.FromArgb(211, 224, 229);
		this.ChangeLog.Location = new global::System.Drawing.Point(97, 63);
		this.ChangeLog.Name = "ChangeLog";
		this.ChangeLog.Size = new global::System.Drawing.Size(0, 13);
		this.ChangeLog.TabIndex = 170;
		this.GoToWebSite.ActiveLinkColor = global::System.Drawing.Color.Transparent;
		this.GoToWebSite.AutoSize = true;
		this.GoToWebSite.LinkColor = global::System.Drawing.Color.AliceBlue;
		this.GoToWebSite.Location = new global::System.Drawing.Point(4, 102);
		this.GoToWebSite.Name = "GoToWebSite";
		this.GoToWebSite.Size = new global::System.Drawing.Size(0, 13);
		this.GoToWebSite.TabIndex = 39;
		this.HeaderPanel.Controls.Add(this.Header);
		this.HeaderPanel.Controls.Add(this.CloseIcon);
		this.HeaderPanel.Location = new global::System.Drawing.Point(0, 0);
		this.HeaderPanel.Margin = new global::System.Windows.Forms.Padding(0);
		this.HeaderPanel.Name = "HeaderPanel";
		this.HeaderPanel.Size = new global::System.Drawing.Size(360, 38);
		this.HeaderPanel.TabIndex = 180;
		this.Header.AutoSize = true;
		this.Header.BackColor = global::System.Drawing.Color.Transparent;
		this.Header.Font = new global::System.Drawing.Font("Calibri", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.Header.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.Header.Location = new global::System.Drawing.Point(12, 9);
		this.Header.Name = "Header";
		this.Header.Size = new global::System.Drawing.Size(0, 15);
		this.Header.TabIndex = 31;
		this.CloseIcon.BackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.BackgroundImage = global::Class89.Bitmap_17;
		this.CloseIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.CloseIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
		this.CloseIcon.FlatAppearance.BorderSize = 0;
		this.CloseIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.CloseIcon.Location = new global::System.Drawing.Point(327, 5);
		this.CloseIcon.Name = "CloseIcon";
		this.CloseIcon.Size = new global::System.Drawing.Size(22, 22);
		this.CloseIcon.TabIndex = 18;
		this.CloseIcon.TabStop = false;
		this.CloseIcon.UseVisualStyleBackColor = false;
		this.MainPanel3.Controls.Add(this.PNotice);
		this.MainPanel3.Controls.Add(this.LabelTextBox);
		this.MainPanel3.Controls.Add(this.TextBoxMain);
		this.MainPanel3.Controls.Add(this.ButtonEmail);
		this.MainPanel3.Location = new global::System.Drawing.Point(0, 34);
		this.MainPanel3.Name = "MainPanel3";
		this.MainPanel3.Size = new global::System.Drawing.Size(360, 222);
		this.MainPanel3.TabIndex = 181;
		this.MainPanel3.Visible = false;
		this.PNotice.AutoSize = true;
		this.PNotice.Location = new global::System.Drawing.Point(18, 29);
		this.PNotice.Name = "PNotice";
		this.PNotice.Size = new global::System.Drawing.Size(0, 13);
		this.PNotice.TabIndex = 39;
		this.LabelTextBox.AutoSize = true;
		this.LabelTextBox.Location = new global::System.Drawing.Point(49, 99);
		this.LabelTextBox.Name = "LabelTextBox";
		this.LabelTextBox.Size = new global::System.Drawing.Size(0, 13);
		this.LabelTextBox.TabIndex = 38;
		this.TextBoxMain.Location = new global::System.Drawing.Point(49, 121);
		this.TextBoxMain.Name = "TextBoxMain";
		this.TextBoxMain.Size = new global::System.Drawing.Size(262, 21);
		this.TextBoxMain.TabIndex = 37;
		this.ButtonEmail.BackColor = global::System.Drawing.SystemColors.InactiveBorder;
		this.ButtonEmail.FlatAppearance.BorderSize = 0;
		this.ButtonEmail.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.ButtonEmail.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.ButtonEmail.ForeColor = global::System.Drawing.SystemColors.ControlText;
		this.ButtonEmail.Location = new global::System.Drawing.Point(49, 151);
		this.ButtonEmail.Name = "ButtonEmail";
		this.ButtonEmail.Size = new global::System.Drawing.Size(262, 26);
		this.ButtonEmail.TabIndex = 36;
		this.ButtonEmail.UseVisualStyleBackColor = false;
		this.ButtonEmail.Click += new global::System.EventHandler(this.ButtonEmail_Click);
		this.Price.Location = new global::System.Drawing.Point(200, -10);
		this.Price.Name = "Price";
		this.Price.Size = new global::System.Drawing.Size(26, 51);
		this.Price.TabIndex = 37;
		this.Price.Visible = false;
		this.Price.MouseEnter += new global::System.EventHandler(this.Price_MouseEnter);
		this.Price.MouseLeave += new global::System.EventHandler(this.Price_MouseLeave);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
		base.ClientSize = new global::System.Drawing.Size(360, 256);
		base.Controls.Add(this.Price);
		base.Controls.Add(this.MainPanel3);
		base.Controls.Add(this.HeaderPanel);
		base.Controls.Add(this.MainPanel2);
		base.Controls.Add(this.MainPanel1);
		this.DoubleBuffered = true;
		this.Font = new global::System.Drawing.Font("Tahoma", 8.25f);
		this.ForeColor = global::System.Drawing.Color.AliceBlue;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		this.MaximumSize = new global::System.Drawing.Size(360, 256);
		base.Name = "About";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		base.TopMost = true;
		base.TransparencyKey = global::System.Drawing.Color.FromArgb(9, 0, 125);
		base.Load += new global::System.EventHandler(this.About_Load);
		((global::System.ComponentModel.ISupportInitialize)this.AboutDonate2).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.AboutDonate3).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.AboutDonate1).EndInit();
		this.MainPanel2.ResumeLayout(false);
		this.MainPanel2.PerformLayout();
		this.MainPanel1.ResumeLayout(false);
		this.MainPanel1.PerformLayout();
		this.HeaderPanel.ResumeLayout(false);
		this.HeaderPanel.PerformLayout();
		this.MainPanel3.ResumeLayout(false);
		this.MainPanel3.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x04000032 RID: 50
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x04000033 RID: 51
	private global::System.Windows.Forms.Label AboutDescription;

	// Token: 0x04000034 RID: 52
	private global::System.Windows.Forms.PictureBox AboutDonate2;

	// Token: 0x04000035 RID: 53
	private global::System.Windows.Forms.PictureBox AboutDonate3;

	// Token: 0x04000036 RID: 54
	private global::System.Windows.Forms.PictureBox AboutDonate1;

	// Token: 0x04000037 RID: 55
	private global::System.Windows.Forms.ToolTip toolTip_0;

	// Token: 0x04000038 RID: 56
	private global::System.Windows.Forms.LinkLabel CheckForUpdates;

	// Token: 0x04000039 RID: 57
	private global::System.Windows.Forms.LinkLabel AboutGetBeta;

	// Token: 0x0400003A RID: 58
	private global::System.Windows.Forms.Panel MainPanel2;

	// Token: 0x0400003B RID: 59
	private global::System.Windows.Forms.Label AboutFeatures;

	// Token: 0x0400003C RID: 60
	public global::System.Windows.Forms.Button AboutGetPro;

	// Token: 0x0400003D RID: 61
	private global::System.Windows.Forms.Button AboutActivatePro;

	// Token: 0x0400003E RID: 62
	public global::System.Windows.Forms.LinkLabel ActivateLink;

	// Token: 0x0400003F RID: 63
	private global::System.Windows.Forms.Label AboutVersionLabel;

	// Token: 0x04000040 RID: 64
	private global::System.Windows.Forms.Label AboutAuthor;

	// Token: 0x04000041 RID: 65
	private global::System.Windows.Forms.Label Coffee;

	// Token: 0x04000042 RID: 66
	private global::System.Windows.Forms.Panel MainPanel1;

	// Token: 0x04000043 RID: 67
	private global::System.Windows.Forms.LinkLabel GoToWebSite;

	// Token: 0x04000044 RID: 68
	private global::System.Windows.Forms.Panel HeaderPanel;

	// Token: 0x04000045 RID: 69
	private global::System.Windows.Forms.Label Header;

	// Token: 0x04000046 RID: 70
	private global::System.Windows.Forms.Button CloseIcon;

	// Token: 0x04000047 RID: 71
	private global::System.Windows.Forms.Panel MainPanel3;

	// Token: 0x04000048 RID: 72
	private global::System.Windows.Forms.Button ButtonEmail;

	// Token: 0x04000049 RID: 73
	private global::GClass11 Price;

	// Token: 0x0400004A RID: 74
	private global::System.Windows.Forms.TextBox TextBoxMain;

	// Token: 0x0400004B RID: 75
	private global::System.Windows.Forms.Label LabelTextBox;

	// Token: 0x0400004C RID: 76
	private global::System.Windows.Forms.Label PNotice;

	// Token: 0x0400004D RID: 77
	public global::System.Windows.Forms.LinkLabel ChangeLog;
}
