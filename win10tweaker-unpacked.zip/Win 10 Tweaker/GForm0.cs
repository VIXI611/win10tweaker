﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// Token: 0x020000C2 RID: 194
public partial class GForm0 : Form
{
	// Token: 0x060009D5 RID: 2517
	[DllImport("dwmapi.dll")]
	public static extern int DwmExtendFrameIntoClientArea(IntPtr intptr_0, ref GForm0.GStruct3 gstruct3_0);

	// Token: 0x060009D6 RID: 2518
	[DllImport("dwmapi.dll")]
	public static extern int DwmSetWindowAttribute(IntPtr intptr_0, int int_0, ref int int_1, int int_2);

	// Token: 0x060009D7 RID: 2519
	[DllImport("dwmapi.dll")]
	public static extern int DwmIsCompositionEnabled(ref int int_0);

	// Token: 0x060009D8 RID: 2520 RVA: 0x000056D6 File Offset: 0x000038D6
	public GForm0()
	{
		this.bool_0 = this.method_0();
	}

	// Token: 0x060009D9 RID: 2521 RVA: 0x0002B1C4 File Offset: 0x000293C4
	private bool method_0()
	{
		if (Environment.OSVersion.Version.Major >= 6)
		{
			int num = 0;
			GForm0.DwmIsCompositionEnabled(ref num);
			return num == 1;
		}
		return false;
	}

	// Token: 0x060009DA RID: 2522 RVA: 0x0002B1F4 File Offset: 0x000293F4
	protected virtual void WndProc(ref Message m)
	{
		base.WndProc(ref m);
		switch (m.Msg)
		{
		case 131:
			m.Result = (IntPtr)0;
			return;
		case 132:
			if ((int)m.Result == 1)
			{
				m.Result = (IntPtr)2;
			}
			break;
		case 133:
			if (this.bool_0)
			{
				int num = 2;
				GForm0.DwmSetWindowAttribute(base.Handle, 2, ref num, 4);
				GForm0.GStruct3 gstruct = new GForm0.GStruct3
				{
					int_3 = 1,
					int_0 = 0,
					int_1 = 0,
					int_2 = 0
				};
				GForm0.DwmExtendFrameIntoClientArea(base.Handle, ref gstruct);
				return;
			}
			break;
		default:
			return;
		}
	}

	// Token: 0x060009DB RID: 2523 RVA: 0x00002F89 File Offset: 0x00001189
	static OperatingSystem smethod_0()
	{
		return Environment.OSVersion;
	}

	// Token: 0x060009DC RID: 2524 RVA: 0x00002F90 File Offset: 0x00001190
	static Version smethod_1(OperatingSystem operatingSystem_0)
	{
		return operatingSystem_0.Version;
	}

	// Token: 0x060009DD RID: 2525 RVA: 0x00002F98 File Offset: 0x00001198
	static int smethod_2(Version version_0)
	{
		return version_0.Major;
	}

	// Token: 0x040003E2 RID: 994
	private readonly bool bool_0;

	// Token: 0x020000C3 RID: 195
	public struct GStruct3
	{
		// Token: 0x040003E3 RID: 995
		public int int_0;

		// Token: 0x040003E4 RID: 996
		public int int_1;

		// Token: 0x040003E5 RID: 997
		public int int_2;

		// Token: 0x040003E6 RID: 998
		public int int_3;
	}
}
