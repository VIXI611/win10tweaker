﻿using System;
using System.Collections.Generic;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000095 RID: 149
internal class Class57
{
	// Token: 0x17000045 RID: 69
	// (get) Token: 0x0600075D RID: 1885 RVA: 0x00020290 File Offset: 0x0001E490
	public static Class57 Class57_0
	{
		get
		{
			if (Class57.class57_0 == null)
			{
				object obj = Class57.object_0;
				lock (obj)
				{
					if (Class57.class57_0 == null)
					{
						Class57.class57_0 = new Class57();
					}
				}
			}
			return Class57.class57_0;
		}
	}

	// Token: 0x0600075E RID: 1886 RVA: 0x000202F0 File Offset: 0x0001E4F0
	public void method_0(bool bool_0)
	{
		if (bool_0)
		{
			string text = "CLSID\\\\{596AB062-B4D2-4215-9F74-E9109B0A8153}";
			GClass6.GClass6_0.method_17(Registry.ClassesRoot.OpenSubKey(text), true);
			Registry.ClassesRoot.DeleteSubKeyTree(text, false);
		}
	}

	// Token: 0x0600075F RID: 1887 RVA: 0x00004A54 File Offset: 0x00002C54
	public void method_1(bool bool_0)
	{
		if (bool_0)
		{
			this.list_0.ForEach(new Action<string>(Class57.<>c.<>9.method_0));
		}
	}

	// Token: 0x06000760 RID: 1888 RVA: 0x00020328 File Offset: 0x0001E528
	public void method_2(bool bool_0)
	{
		if (bool_0)
		{
			string text = "CLSID\\\\{470C0EBD-5D73-4d58-9CED-E91E22E23282}";
			GClass6.GClass6_0.method_17(Registry.ClassesRoot.OpenSubKey(text), true);
			Registry.ClassesRoot.DeleteSubKeyTree(text, false);
		}
	}

	// Token: 0x06000761 RID: 1889 RVA: 0x00004A83 File Offset: 0x00002C83
	public void method_3(bool bool_0)
	{
		if (bool_0)
		{
			Registry.ClassesRoot.DeleteSubKeyTree("Folder\\shell\\pintohome", false);
		}
	}

	// Token: 0x06000762 RID: 1890 RVA: 0x00004A98 File Offset: 0x00002C98
	public void method_4(bool bool_0)
	{
		if (bool_0)
		{
			Registry.ClassesRoot.DeleteSubKeyTree("SystemFileAssociations\\Directory.Audio\\shellex\\ContextMenuHandlers\\WMPShopMusic", false);
		}
	}

	// Token: 0x06000763 RID: 1891 RVA: 0x00004AAD File Offset: 0x00002CAD
	public void method_5(bool bool_0)
	{
		if (bool_0)
		{
			Registry.ClassesRoot.DeleteSubKeyTree("*\\shellex\\ContextMenuHandlers\\ModernSharing", false);
		}
	}

	// Token: 0x06000764 RID: 1892 RVA: 0x00004AC2 File Offset: 0x00002CC2
	public void method_6(bool bool_0)
	{
		if (bool_0)
		{
			GClass6.GClass6_0.method_17(Registry.ClassesRoot.OpenSubKey(this.string_0), true);
			Registry.ClassesRoot.DeleteSubKeyTree(this.string_0, false);
		}
	}

	// Token: 0x06000765 RID: 1893 RVA: 0x00004AF3 File Offset: 0x00002CF3
	public void method_7(bool bool_0)
	{
		if (bool_0)
		{
			Registry.ClassesRoot.DeleteSubKeyTree("Folder\\shellex\\ContextMenuHandlers\\Library Location", false);
		}
	}

	// Token: 0x06000766 RID: 1894 RVA: 0x00020360 File Offset: 0x0001E560
	public void method_8()
	{
		RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey("CLSID\\{596AB062-B4D2-4215-9F74-E9109B0A8153}");
		registryKey.SetValue("", "Previous Versions Property Page");
		registryKey.SetValue("PageTitle", "@%SystemRoot%\\system32\\twext.dll,-1024", RegistryValueKind.ExpandString);
		RegistryKey registryKey2 = Registry.ClassesRoot.CreateSubKey("CLSID\\{596AB062-B4D2-4215-9F74-E9109B0A8153}\\InProcServer32");
		registryKey2.SetValue("", "%SystemRoot%\\system32\\twext.dll", RegistryValueKind.ExpandString);
		registryKey2.SetValue("ThreadingModel", "Apartment");
		this.list_0.ForEach(new Action<string>(Class57.<>c.<>9.method_2));
		this.list_1.ForEach(new Action<string>(Class57.<>c.<>9.method_3));
		Registry.ClassesRoot.CreateSubKey("CLSID\\{470C0EBD-5D73-4d58-9CED-E91E22E23282}").SetValue("", "Pin To Start Screen verb handler");
		RegistryKey registryKey3 = Registry.ClassesRoot.CreateSubKey("CLSID\\{470C0EBD-5D73-4d58-9CED-E91E22E23282}\\InProcServer32");
		registryKey3.SetValue("", "C:\\Windows\\System32\\appresolver.dll");
		registryKey3.SetValue("ThreadingModel", "Both");
		RegistryKey registryKey4 = Registry.ClassesRoot.CreateSubKey("Folder\\shell\\pintohome");
		registryKey4.SetValue("AppliesTo", "System.ParsingName:<>\"::{679f85cb-0220-4080-b29b-5540cc05aab6}\" AND System.ParsingName:<>\"::{645FF040-5081-101B-9F08-00AA002F954E}\" AND System.IsFolder:=System.StructuredQueryType.Boolean#True");
		registryKey4.SetValue("MUIVerb", "@shell32.dll,-51377");
		Registry.ClassesRoot.CreateSubKey("Folder\\shell\\pintohome\\command").SetValue("DelegateExecute", "{b455f46e-e4af-4035-b0a4-cf18d2f6f28e}");
		Registry.ClassesRoot.CreateSubKey("SystemFileAssociations\\Directory.Audio\\shellex\\ContextMenuHandlers\\WMPShopMusic").SetValue("", "{8A734961-C4AA-4741-AC1E-791ACEBF5B39}");
		Registry.ClassesRoot.CreateSubKey("*\\shellex\\ContextMenuHandlers\\ModernSharing").SetValue("", "{e2bf9676-5f8f-435c-97eb-11607a5bedf7}");
		RegistryKey registryKey5 = Registry.ClassesRoot.CreateSubKey(this.string_0);
		registryKey5.SetValue("", "Play To menu");
		registryKey5.SetValue("ContextMenuOptIn", "");
		RegistryKey registryKey6 = Registry.ClassesRoot.CreateSubKey("CLSID\\{7AD84985-87B4-4a16-BE58-8B72A5B390F7}\\InProcServer32");
		registryKey6.SetValue("", GClass2.GClass2_0.String_3.Contains("10") ? "C:\\Windows\\System32\\playtomenu.dll" : "C:\\Windows\\System32\\Windows.Media.Streaming.dll");
		registryKey6.SetValue("ThreadingModel", "Apartment");
		Registry.ClassesRoot.CreateSubKey("Folder\\shellex\\ContextMenuHandlers\\Library Location").SetValue("", "{3dad6c5d-2167-4cae-9914-f99e41c12cfa}");
	}

	// Token: 0x06000769 RID: 1897 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x0600076A RID: 1898 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x0600076B RID: 1899 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.OpenSubKey(string_1);
	}

	// Token: 0x0600076C RID: 1900 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_3(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_1, bool_0);
	}

	// Token: 0x0600076D RID: 1901 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_4(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x0600076E RID: 1902 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_5(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x0600076F RID: 1903 RVA: 0x00002EED File Offset: 0x000010ED
	static void smethod_6(RegistryKey registryKey_0, string string_1, object object_1, RegistryValueKind registryValueKind_0)
	{
		registryKey_0.SetValue(string_1, object_1, registryValueKind_0);
	}

	// Token: 0x06000770 RID: 1904 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_7(string string_1, string string_2)
	{
		return string_1.Contains(string_2);
	}

	// Token: 0x06000771 RID: 1905 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_8()
	{
		return new object();
	}

	// Token: 0x040002C7 RID: 711
	private static volatile Class57 class57_0;

	// Token: 0x040002C8 RID: 712
	private static readonly object object_0 = new object();

	// Token: 0x040002C9 RID: 713
	public string string_0 = "CLSID\\{7AD84985-87B4-4a16-BE58-8B72A5B390F7}";

	// Token: 0x040002CA RID: 714
	private readonly List<string> list_0 = new List<string>
	{
		".3ds",
		".3mf",
		".bmp",
		".fbx",
		".gif",
		".glb",
		".jfif",
		".jpeg",
		".jpe",
		".jpg",
		".obj",
		".ply",
		".png",
		".stl",
		".tif",
		".tiff",
		".wrl"
	};

	// Token: 0x040002CB RID: 715
	private readonly List<string> list_1 = new List<string>
	{
		".3ds",
		".3mf",
		".dae",
		".dxf",
		".obj",
		".ply",
		".stl",
		".wrl"
	};
}
