﻿// Token: 0x0200006B RID: 107
public partial class Popup : global::System.Windows.Forms.Form
{
	// Token: 0x06000532 RID: 1330 RVA: 0x0001A640 File Offset: 0x00018840
	private void InitializeComponent()
	{
		this.Message = new global::System.Windows.Forms.Label();
		this.Logo = new global::System.Windows.Forms.PictureBox();
		this.CloseIcon = new global::System.Windows.Forms.Label();
		this.MainPanel = new global::System.Windows.Forms.Panel();
		((global::System.ComponentModel.ISupportInitialize)this.Logo).BeginInit();
		this.MainPanel.SuspendLayout();
		base.SuspendLayout();
		this.Message.AutoSize = true;
		this.Message.Font = new global::System.Drawing.Font("Tahoma", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.Message.ForeColor = global::System.Drawing.Color.AliceBlue;
		this.Message.Location = new global::System.Drawing.Point(81, 13);
		this.Message.MaximumSize = new global::System.Drawing.Size(280, 0);
		this.Message.Name = "Message";
		this.Message.Size = new global::System.Drawing.Size(0, 16);
		this.Message.TabIndex = 17;
		this.Message.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.Message_MouseDown);
		this.Logo.Image = global::Class89.Bitmap_35;
		this.Logo.Location = new global::System.Drawing.Point(7, 9);
		this.Logo.Name = "Logo";
		this.Logo.Size = new global::System.Drawing.Size(65, 65);
		this.Logo.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Logo.TabIndex = 16;
		this.Logo.TabStop = false;
		this.CloseIcon.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 15.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.CloseIcon.ForeColor = global::System.Drawing.Color.Gainsboro;
		this.CloseIcon.Location = new global::System.Drawing.Point(353, 0);
		this.CloseIcon.Name = "CloseIcon";
		this.CloseIcon.Size = new global::System.Drawing.Size(24, 25);
		this.CloseIcon.TabIndex = 0;
		this.CloseIcon.Text = "×";
		this.MainPanel.Controls.Add(this.Message);
		this.MainPanel.Controls.Add(this.CloseIcon);
		this.MainPanel.Controls.Add(this.Logo);
		this.MainPanel.Location = new global::System.Drawing.Point(1, 1);
		this.MainPanel.Name = "MainPanel";
		this.MainPanel.Size = new global::System.Drawing.Size(378, 88);
		this.MainPanel.TabIndex = 18;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(380, 90);
		base.Controls.Add(this.MainPanel);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Popup";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.TopMost = true;
		base.WindowState = global::System.Windows.Forms.FormWindowState.Minimized;
		base.Load += new global::System.EventHandler(this.Popup_Load);
		((global::System.ComponentModel.ISupportInitialize)this.Logo).EndInit();
		this.MainPanel.ResumeLayout(false);
		this.MainPanel.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x04000242 RID: 578
	private global::System.Windows.Forms.Label Message;

	// Token: 0x04000243 RID: 579
	private global::System.Windows.Forms.PictureBox Logo;

	// Token: 0x04000244 RID: 580
	private global::System.Windows.Forms.Label CloseIcon;

	// Token: 0x04000245 RID: 581
	private global::System.Windows.Forms.Panel MainPanel;
}
