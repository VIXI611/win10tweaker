﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A4 RID: 420
[TypeIdentifier]
[Guid("866738B9-6CF2-4DE8-8767-F794EBE74F4E")]
[CompilerGenerated]
[ComImport]
public interface GInterface7 : GInterface6
{
}
