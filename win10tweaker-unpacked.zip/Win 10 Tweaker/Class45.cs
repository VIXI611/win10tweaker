﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000084 RID: 132
internal class Class45
{
	// Token: 0x17000033 RID: 51
	// (get) Token: 0x06000697 RID: 1687 RVA: 0x0001E31C File Offset: 0x0001C51C
	public static Class45 Class45_0
	{
		get
		{
			if (Class45.class45_0 == null)
			{
				object obj = Class45.object_0;
				lock (obj)
				{
					if (Class45.class45_0 == null)
					{
						Class45.class45_0 = new Class45();
					}
				}
			}
			return Class45.class45_0;
		}
	}

	// Token: 0x06000698 RID: 1688 RVA: 0x0001E37C File Offset: 0x0001C57C
	public void method_0()
	{
		try
		{
			byte[] value = new byte[]
			{
				218,
				145,
				156,
				248,
				86,
				161,
				211,
				1
			};
			byte[] value2 = new byte[1];
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Internet Explorer\\Main");
			registryKey.SetValue("DisableFirstRunCustomize", 1);
			registryKey.SetValue("IE10RecommendedSettingsNo", 1);
			registryKey.SetValue("IE10RunOnceCompletionTime", value, RegistryValueKind.Binary);
			registryKey.SetValue("IE10RunOnceLastShown_TIMESTAMP", value2, RegistryValueKind.Binary);
			registryKey.SetValue("IE10RunOncePerInstallCompleted", 1);
			registryKey.SetValue("IE10TourNoShow", 1);
			registryKey.SetValue("IE10TourShown", 1);
			registryKey.SetValue("IE10TourShownTime", value2, RegistryValueKind.Binary);
			registryKey.SetValue("Start Page", "https://google.com");
			RegistryKey registryKey2 = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Internet Explorer\\SearchScopes\\{ACD2BEB0-17F5-4FF1-8A1C-60606069FB98}");
			registryKey2.SetValue("DisplayName", "Google");
			registryKey2.SetValue("FaviconURL", "http://www.google.com/favicon.ico");
			registryKey2.SetValue("OSDFileURL", "https://www.microsoft.com/en-us/IEGallery/GoogleAddOns");
			registryKey2.SetValue("ShowSearchSuggestions", 1);
			registryKey2.SetValue("SuggestionsURL_JSON", "http://suggestqueries.google.com/complete/search?output=firefox&client=firefox&qu={searchTerms}");
			registryKey2.SetValue("URL", "http://www.google.com/search?hl=ru&q={searchTerms}");
			Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Internet Explorer\\SearchScopes").SetValue("DefaultScope", "{ACD2BEB0-17F5-4FF1-8A1C-60606069FB98}");
			Registry.LocalMachine.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\Internet Explorer\\Suggested Sites").SetValue("Enabled", 0);
			Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\Associations").SetValue("ModRiskFileTypes", ".bat;.exe;.reg;.vbs;.chm;.msi;.js;.cmd");
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Internet Explorer\\Safety\\PrivacIE!DisableLogging", "1", RegistryValueKind.DWord);
		}
		catch
		{
		}
	}

	// Token: 0x06000699 RID: 1689 RVA: 0x0001E548 File Offset: 0x0001C748
	public void method_1()
	{
		Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Internet Explorer\\Main").SetValue("Start Page", "http://go.microsoft.com/fwlink/p/?LinkId=255141");
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Internet Settings", true))
		{
			if (registryKey != null && registryKey.GetValue("AutoConfigURL") != null)
			{
				registryKey.DeleteValue("AutoConfigURL");
			}
		}
		Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Internet Settings\\ZoneMap").SetValue("ProxyBypass", 1);
		Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Internet Settings\\Zones\\1").SetValue("Flags", 219);
		GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Internet Explorer\\Safety\\PrivacIE!DisableLogging", null, RegistryValueKind.DWord);
	}

	// Token: 0x0600069C RID: 1692 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x0600069D RID: 1693 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x0600069E RID: 1694 RVA: 0x00002BF0 File Offset: 0x00000DF0
	static void smethod_2(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
	{
		RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
	}

	// Token: 0x0600069F RID: 1695 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_3(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x060006A0 RID: 1696 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_4(RegistryKey registryKey_0, string string_0, object object_1)
	{
		registryKey_0.SetValue(string_0, object_1);
	}

	// Token: 0x060006A1 RID: 1697 RVA: 0x00002EED File Offset: 0x000010ED
	static void smethod_5(RegistryKey registryKey_0, string string_0, object object_1, RegistryValueKind registryValueKind_0)
	{
		registryKey_0.SetValue(string_0, object_1, registryValueKind_0);
	}

	// Token: 0x060006A2 RID: 1698 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_6(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x060006A3 RID: 1699 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_7(RegistryKey registryKey_0, string string_0, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_0, bool_0);
	}

	// Token: 0x060006A4 RID: 1700 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_8(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x060006A5 RID: 1701 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_9(RegistryKey registryKey_0, string string_0)
	{
		registryKey_0.DeleteValue(string_0);
	}

	// Token: 0x060006A6 RID: 1702 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_10(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060006A7 RID: 1703 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_11()
	{
		return new object();
	}

	// Token: 0x04000298 RID: 664
	private static volatile Class45 class45_0;

	// Token: 0x04000299 RID: 665
	private static readonly object object_0 = new object();
}
