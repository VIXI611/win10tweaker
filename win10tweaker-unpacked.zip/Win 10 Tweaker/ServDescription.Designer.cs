﻿// Token: 0x02000098 RID: 152
public partial class ServDescription : global::GForm0
{
	// Token: 0x060007B2 RID: 1970 RVA: 0x00021A24 File Offset: 0x0001FC24
	private void InitializeComponent()
	{
		this.ServListLabel = new global::System.Windows.Forms.LinkLabel();
		this.ServTooltip = new global::System.Windows.Forms.Label();
		this.MainPanel = new global::GClass10();
		this.MainPanel.SuspendLayout();
		base.SuspendLayout();
		this.ServListLabel.ActiveLinkColor = global::System.Drawing.Color.FromArgb(116, 178, 229);
		this.ServListLabel.AutoEllipsis = true;
		this.ServListLabel.AutoSize = true;
		this.ServListLabel.ForeColor = global::System.Drawing.Color.FromArgb(175, 201, 211);
		this.ServListLabel.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
		this.ServListLabel.LinkColor = global::System.Drawing.Color.FromArgb(134, 198, 253);
		this.ServListLabel.Location = new global::System.Drawing.Point(18, 36);
		this.ServListLabel.Margin = new global::System.Windows.Forms.Padding(3, 0, 3, 12);
		this.ServListLabel.MaximumSize = new global::System.Drawing.Size(320, 0);
		this.ServListLabel.Name = "ServListLabel";
		this.ServListLabel.Size = new global::System.Drawing.Size(0, 13);
		this.ServListLabel.TabIndex = 195;
		this.ServListLabel.VisitedLinkColor = global::System.Drawing.Color.FromArgb(134, 198, 253);
		this.ServTooltip.AutoSize = true;
		this.ServTooltip.ForeColor = global::System.Drawing.Color.FromArgb(175, 201, 211);
		this.ServTooltip.Location = new global::System.Drawing.Point(18, 14);
		this.ServTooltip.Name = "ServTooltip";
		this.ServTooltip.Size = new global::System.Drawing.Size(0, 13);
		this.ServTooltip.TabIndex = 0;
		this.MainPanel.AutoSize = true;
		this.MainPanel.BackColor = global::System.Drawing.Color.Transparent;
		this.MainPanel.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.MainPanel.Controls.Add(this.ServTooltip);
		this.MainPanel.Controls.Add(this.ServListLabel);
		this.MainPanel.Location = new global::System.Drawing.Point(0, 0);
		this.MainPanel.Margin = new global::System.Windows.Forms.Padding(0, 0, 0, 1);
		this.MainPanel.Name = "MainPanel";
		this.MainPanel.Size = new global::System.Drawing.Size(360, 62);
		this.MainPanel.TabIndex = 196;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
		this.AutoSize = true;
		this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		base.ClientSize = new global::System.Drawing.Size(360, 62);
		base.Controls.Add(this.MainPanel);
		this.DoubleBuffered = true;
		this.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "ServDescription";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.ServDescription_Load);
		this.MainPanel.ResumeLayout(false);
		this.MainPanel.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040002D8 RID: 728
	private global::System.Windows.Forms.Label ServTooltip;

	// Token: 0x040002D9 RID: 729
	private global::System.Windows.Forms.LinkLabel ServListLabel;

	// Token: 0x040002DA RID: 730
	private global::GClass10 MainPanel;
}
