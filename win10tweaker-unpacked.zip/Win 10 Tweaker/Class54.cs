﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

// Token: 0x02000090 RID: 144
internal static class Class54
{
	// Token: 0x0600072D RID: 1837
	[DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
	public static extern int RegLoadMUIString(IntPtr intptr_0, string string_0, StringBuilder stringBuilder_0, int int_0, out int int_1, Class54.Enum1 enum1_0, string string_1);

	// Token: 0x0600072E RID: 1838 RVA: 0x0001F760 File Offset: 0x0001D960
	public static string smethod_0(this RegistryKey registryKey_0, string string_0)
	{
		StringBuilder stringBuilder = new StringBuilder(1024);
		IntPtr intptr_ = registryKey_0.Handle.DangerousGetHandle();
		int capacity;
		Class54.Enum0 @enum = (Class54.Enum0)Class54.RegLoadMUIString(intptr_, string_0, stringBuilder, stringBuilder.Capacity, out capacity, Class54.Enum1.None, null);
		if (@enum == Class54.Enum0.MoreData)
		{
			stringBuilder.EnsureCapacity(capacity);
			int num;
			@enum = (Class54.Enum0)Class54.RegLoadMUIString(intptr_, string_0, stringBuilder, stringBuilder.Capacity, out num, Class54.Enum1.None, null);
		}
		if (@enum != Class54.Enum0.Success)
		{
			return null;
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0600072F RID: 1839 RVA: 0x00003B15 File Offset: 0x00001D15
	static StringBuilder smethod_1(int int_0)
	{
		return new StringBuilder(int_0);
	}

	// Token: 0x06000730 RID: 1840 RVA: 0x000049E7 File Offset: 0x00002BE7
	static SafeRegistryHandle smethod_2(RegistryKey registryKey_0)
	{
		return registryKey_0.Handle;
	}

	// Token: 0x06000731 RID: 1841 RVA: 0x000049EF File Offset: 0x00002BEF
	static IntPtr smethod_3(SafeHandle safeHandle_0)
	{
		return safeHandle_0.DangerousGetHandle();
	}

	// Token: 0x06000732 RID: 1842 RVA: 0x00003C3B File Offset: 0x00001E3B
	static int smethod_4(StringBuilder stringBuilder_0)
	{
		return stringBuilder_0.Capacity;
	}

	// Token: 0x06000733 RID: 1843 RVA: 0x000049F7 File Offset: 0x00002BF7
	static int smethod_5(StringBuilder stringBuilder_0, int int_0)
	{
		return stringBuilder_0.EnsureCapacity(int_0);
	}

	// Token: 0x06000734 RID: 1844 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_6(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x02000091 RID: 145
	private enum Enum0
	{
		// Token: 0x040002BB RID: 699
		Success,
		// Token: 0x040002BC RID: 700
		MoreData = 234
	}

	// Token: 0x02000092 RID: 146
	[Flags]
	internal enum Enum1 : uint
	{
		// Token: 0x040002BE RID: 702
		None = 0U,
		// Token: 0x040002BF RID: 703
		Truncate = 1U
	}
}
