﻿using System;
using System.Deps;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using Microsoft.Win32;

// Token: 0x0200008E RID: 142
internal class Class53
{
	// Token: 0x1700003A RID: 58
	// (get) Token: 0x0600070E RID: 1806 RVA: 0x0001F4DC File Offset: 0x0001D6DC
	public static Class53 Class53_0
	{
		get
		{
			if (Class53.class53_0 == null)
			{
				object obj = Class53.object_0;
				lock (obj)
				{
					if (Class53.class53_0 == null)
					{
						Class53.class53_0 = new Class53();
					}
				}
			}
			return Class53.class53_0;
		}
	}

	// Token: 0x0600070F RID: 1807 RVA: 0x0001F53C File Offset: 0x0001D73C
	public void method_0()
	{
		if (!Class26.smethod_0())
		{
			GClass6.GClass6_0.method_9();
			return;
		}
		if (!File.Exists(this.string_2))
		{
			using (WebClient webClient = new WebClient())
			{
				webClient.DownloadFile("https://win10tweaker.pro/files/imgurUp.jpg", this.string_2);
				Imgur.Tweak();
			}
			foreach (string text in Class53.string_3)
			{
				RegistryKey registryKey = Registry.CurrentUser.CreateSubKey(text);
				registryKey.SetValue("", GClass2.GClass2_0.method_1("UploadOnImgur"));
				registryKey.SetValue("Icon", GClass13.string_6 + "\\imgurUp.exe");
				Registry.CurrentUser.CreateSubKey(text + "\\command").SetValue("", "\"" + GClass13.string_6 + "\\imgurUp.exe\" \"%1\"");
			}
			Class53.string_3.ToList<string>().ForEach(new Action<string>(Class53.<>c.<>9.method_0));
			return;
		}
	}

	// Token: 0x06000710 RID: 1808 RVA: 0x0000494C File Offset: 0x00002B4C
	public void method_1()
	{
		Class53.string_3.ToList<string>().ForEach(new Action<string>(Class53.<>c.<>9.method_1));
	}

	// Token: 0x06000711 RID: 1809 RVA: 0x0000497C File Offset: 0x00002B7C
	public void method_2()
	{
		File.Delete(this.string_2);
		Class53.string_3.ToList<string>().ForEach(new Action<string>(Class53.<>c.<>9.method_2));
	}

	// Token: 0x06000714 RID: 1812 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000715 RID: 1813 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000716 RID: 1814 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_2(string string_4)
	{
		return File.Exists(string_4);
	}

	// Token: 0x06000717 RID: 1815 RVA: 0x00002994 File Offset: 0x00000B94
	static WebClient smethod_3()
	{
		return new WebClient();
	}

	// Token: 0x06000718 RID: 1816 RVA: 0x000029C3 File Offset: 0x00000BC3
	static void smethod_4(WebClient webClient_0, string string_4, string string_5)
	{
		webClient_0.DownloadFile(string_4, string_5);
	}

	// Token: 0x06000719 RID: 1817 RVA: 0x000049D4 File Offset: 0x00002BD4
	static void smethod_5()
	{
		Imgur.Tweak();
	}

	// Token: 0x0600071A RID: 1818 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_6(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x0600071B RID: 1819 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_7(RegistryKey registryKey_0, string string_4)
	{
		return registryKey_0.CreateSubKey(string_4);
	}

	// Token: 0x0600071C RID: 1820 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_8(RegistryKey registryKey_0, string string_4, object object_1)
	{
		registryKey_0.SetValue(string_4, object_1);
	}

	// Token: 0x0600071D RID: 1821 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_9(string string_4, string string_5)
	{
		return string_4 + string_5;
	}

	// Token: 0x0600071E RID: 1822 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_10(string string_4, string string_5, string string_6)
	{
		return string_4 + string_5 + string_6;
	}

	// Token: 0x0600071F RID: 1823 RVA: 0x00002F15 File Offset: 0x00001115
	static void smethod_11(string string_4)
	{
		File.Delete(string_4);
	}

	// Token: 0x06000720 RID: 1824 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_12()
	{
		return new object();
	}

	// Token: 0x040002B0 RID: 688
	private static volatile Class53 class53_0;

	// Token: 0x040002B1 RID: 689
	private static readonly object object_0 = new object();

	// Token: 0x040002B2 RID: 690
	private static readonly string string_0 = "Software\\Classes\\SystemFileAssociations\\";

	// Token: 0x040002B3 RID: 691
	private static readonly string string_1 = "\\shell\\UploadOnImgur";

	// Token: 0x040002B4 RID: 692
	private readonly string string_2 = GClass13.string_6 + "\\imgurUp.exe";

	// Token: 0x040002B5 RID: 693
	private static readonly string[] string_3 = new string[]
	{
		Class53.string_0 + ".jpg" + Class53.string_1,
		Class53.string_0 + ".jpeg" + Class53.string_1,
		Class53.string_0 + ".png" + Class53.string_1,
		Class53.string_0 + ".gif" + Class53.string_1,
		Class53.string_0 + ".bmp" + Class53.string_1
	};
}
