﻿// Token: 0x0200004C RID: 76
public partial class Copied : global::System.Windows.Forms.Form
{
	// Token: 0x060003C2 RID: 962 RVA: 0x00017D8C File Offset: 0x00015F8C
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.name = new global::System.Windows.Forms.Label();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		base.SuspendLayout();
		this.name.AutoSize = true;
		this.name.BackColor = global::System.Drawing.Color.Transparent;
		this.name.Font = new global::System.Drawing.Font("Calibri", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.name.ForeColor = global::System.Drawing.Color.AliceBlue;
		this.name.Location = new global::System.Drawing.Point(9, 8);
		this.name.Name = "name";
		this.name.Size = new global::System.Drawing.Size(93, 18);
		this.name.TabIndex = 30;
		this.name.Text = "Скопировано";
		this.name.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.timer_0.Interval = 10;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.FromArgb(41, 46, 69);
		base.ClientSize = new global::System.Drawing.Size(111, 35);
		base.Controls.Add(this.name);
		this.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Copied";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		this.Text = "Copied";
		base.TopMost = true;
		base.TransparencyKey = global::System.Drawing.Color.FromArgb(64, 153, 242);
		base.Load += new global::System.EventHandler(this.Copied_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040001E5 RID: 485
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x040001E6 RID: 486
	private global::System.Windows.Forms.Label name;

	// Token: 0x040001E7 RID: 487
	private global::System.Windows.Forms.Timer timer_0;
}
