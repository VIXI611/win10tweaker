﻿using System;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000050 RID: 80
internal class Class24
{
	// Token: 0x1700001F RID: 31
	// (get) Token: 0x060003DB RID: 987 RVA: 0x000182C0 File Offset: 0x000164C0
	public static Class24 Class24_0
	{
		get
		{
			if (Class24.class24_0 == null)
			{
				object obj = Class24.object_0;
				lock (obj)
				{
					if (Class24.class24_0 == null)
					{
						Class24.class24_0 = new Class24();
					}
				}
			}
			return Class24.class24_0;
		}
	}

	// Token: 0x060003DC RID: 988 RVA: 0x00018320 File Offset: 0x00016520
	public void method_0()
	{
		Registry.ClassesRoot.CreateSubKey("*" + Class24.string_0).SetValue("", GClass2.GClass2_0.method_1("CreateSymbolicLink"));
		Registry.ClassesRoot.CreateSubKey("Directory" + Class24.string_0).SetValue("", GClass2.GClass2_0.method_1("CreateSymbolicLink"));
		Registry.ClassesRoot.CreateSubKey("*" + Class24.string_0 + "\\command").SetValue("", "cmd /c echo @echo off>>%%windir%%\\Symlinker.cmd & echo set IS_MINIMIZED=1>>%%windir%%\\Symlinker.cmd & echo set \"myCommand=\"(new-object -COM 'Shell.Application')^^.BrowseForFolder(0,'',0).self.path\"\">> %%windir%%\\Symlinker.cmd & echo for /f \"usebackq delims=\" %%%%I in (`powershell %%myCommand%%`) do set \"dir=%%%%I\">>%%windir%%\\Symlinker.cmd & echo setlocal enabledelayedexpansion>>%%windir%%\\Symlinker.cmd & echo mklink \"!dir!\\%%~nx1\" %%1 ^& del /f /q %%windir%%\\Symlinker.cmd>>%%windir%%\\Symlinker.cmd & start /min Symlinker.cmd \"%1\" ^& exit");
		Registry.ClassesRoot.CreateSubKey("Directory" + Class24.string_0 + "\\command").SetValue("", "cmd /c echo @echo off>>%%windir%%\\Symlinker.cmd & echo set IS_MINIMIZED=1>>%%windir%%\\Symlinker.cmd & echo set \"myCommand=\"(new-object -COM 'Shell.Application')^^.BrowseForFolder(0,'',0).self.path\"\">> %%windir%%\\Symlinker.cmd & echo for /f \"usebackq delims=\" %%%%I in (`powershell %%myCommand%%`) do set \"dir=%%%%I\">>%%windir%%\\Symlinker.cmd & echo setlocal enabledelayedexpansion>>%%windir%%\\Symlinker.cmd & echo mklink /d \"!dir!\\%%~nx1\" %%1 ^& del /f /q %%windir%%\\Symlinker.cmd>>%%windir%%\\Symlinker.cmd & start /min Symlinker.cmd \"%1\" ^& exit");
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			Registry.ClassesRoot.CreateSubKey("*" + Class24.string_0).SetValue("Icon", "imageres.dll,225");
			Registry.ClassesRoot.CreateSubKey("Directory" + Class24.string_0).SetValue("Icon", "imageres.dll,225");
		}
		using (RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey("*" + Class24.string_0, true))
		{
			if (registryKey != null && registryKey.GetValue("Extended") != null)
			{
				registryKey.DeleteValue("Extended");
			}
		}
		using (RegistryKey registryKey2 = Registry.ClassesRoot.OpenSubKey("Directory" + Class24.string_0, true))
		{
			if (registryKey2 != null && registryKey2.GetValue("Extended") != null)
			{
				registryKey2.DeleteValue("Extended");
			}
		}
	}

	// Token: 0x060003DD RID: 989 RVA: 0x000184F4 File Offset: 0x000166F4
	public void method_1()
	{
		Registry.ClassesRoot.CreateSubKey("*" + Class24.string_0).SetValue("Extended", "");
		Registry.ClassesRoot.CreateSubKey("Directory" + Class24.string_0).SetValue("Extended", "");
	}

	// Token: 0x060003DE RID: 990 RVA: 0x000039E2 File Offset: 0x00001BE2
	public void method_2()
	{
		Registry.ClassesRoot.DeleteSubKeyTree("*" + Class24.string_0, false);
		Registry.ClassesRoot.DeleteSubKeyTree("Directory" + Class24.string_0, false);
	}

	// Token: 0x060003E1 RID: 993 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060003E2 RID: 994 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060003E3 RID: 995 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_2(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x060003E4 RID: 996 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_3(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x060003E5 RID: 997 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_4(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x060003E6 RID: 998 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_5(string string_1, string string_2, string string_3)
	{
		return string_1 + string_2 + string_3;
	}

	// Token: 0x060003E7 RID: 999 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_6(string string_1, string string_2)
	{
		return string_1.Contains(string_2);
	}

	// Token: 0x060003E8 RID: 1000 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_7(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_1, bool_0);
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_8(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.GetValue(string_1);
	}

	// Token: 0x060003EA RID: 1002 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_9(RegistryKey registryKey_0, string string_1)
	{
		registryKey_0.DeleteValue(string_1);
	}

	// Token: 0x060003EB RID: 1003 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_10(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060003EC RID: 1004 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_11(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_1, bool_0);
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_12()
	{
		return new object();
	}

	// Token: 0x040001F4 RID: 500
	private static volatile Class24 class24_0;

	// Token: 0x040001F5 RID: 501
	private static readonly object object_0 = new object();

	// Token: 0x040001F6 RID: 502
	private static readonly string string_0 = "\\shell\\CreateSymbolicLink";
}
