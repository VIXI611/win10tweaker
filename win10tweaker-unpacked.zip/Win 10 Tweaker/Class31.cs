﻿using System;
using System.Collections.Generic;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000069 RID: 105
internal class Class31
{
	// Token: 0x17000024 RID: 36
	// (get) Token: 0x06000513 RID: 1299 RVA: 0x00019C80 File Offset: 0x00017E80
	public static Class31 Class31_0
	{
		get
		{
			if (Class31.class31_0 == null)
			{
				object obj = Class31.object_0;
				lock (obj)
				{
					if (Class31.class31_0 == null)
					{
						Class31.class31_0 = new Class31();
					}
				}
			}
			return Class31.class31_0;
		}
	}

	// Token: 0x06000514 RID: 1300 RVA: 0x00019CE0 File Offset: 0x00017EE0
	public void method_0()
	{
		GClass6.GClass6_0.method_17(Registry.ClassesRoot.OpenSubKey("DesktopBackground"), true);
		Registry.ClassesRoot.DeleteSubKeyTree(this.string_0, false);
		using (RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey("DesktopBackground\\Shell\\Personalize"))
		{
			if (registryKey != null && registryKey.GetValue("") != null)
			{
				registryKey.DeleteValue("");
			}
			registryKey.SetValue("muiverb", this.string_5);
			registryKey.SetValue("subcommands", (!(GClass2.GClass2_0.String_3.Contains("7") | GClass2.GClass2_0.String_3.Contains("8"))) ? "Windows settings;Display;Personalize;GodMode;Logout;Reboot;Shutdown" : "Personalize;Display;GodMode;Logout;Reboot;Shutdown");
		}
		string str = GClass2.GClass2_0.String_0 + "\\Explorer\\CommandStore\\shell";
		if (!(GClass2.GClass2_0.String_3.Contains("7") | GClass2.GClass2_0.String_3.Contains("8")))
		{
			RegistryKey registryKey2 = Registry.LocalMachine.CreateSubKey(str + "\\Windows settings");
			registryKey2.SetValue("", GClass2.GClass2_0.method_1("WindowsSettings"));
			registryKey2.SetValue("Icon", "%systemroot%\\ImmersiveControlPanel\\SystemSettings.exe");
			Registry.LocalMachine.CreateSubKey(str + "\\Windows settings\\command").SetValue("", "explorer shell:AppsFolder\\Windows.ImmersiveControlPanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel");
			RegistryKey registryKey3 = Registry.LocalMachine.CreateSubKey(str + "\\Display");
			registryKey3.SetValue("", this.string_4);
			registryKey3.SetValue("Icon", this.string_2);
			registryKey3.SetValue("SettingsUri", "ms-settings:display");
			Registry.LocalMachine.CreateSubKey(str + "\\Display\\command").SetValue(this.string_6, this.string_8);
			RegistryKey registryKey4 = Registry.LocalMachine.CreateSubKey(str + "\\Personalize");
			registryKey4.SetValue("", this.string_5);
			registryKey4.SetValue("Icon", this.string_3);
			registryKey4.SetValue("SettingsUri", "ms-settings:personalization-background");
			Registry.LocalMachine.CreateSubKey(str + "\\Personalize\\command").SetValue(this.string_6, this.string_8);
		}
		else
		{
			RegistryKey registryKey5 = Registry.LocalMachine.CreateSubKey(str + "\\Personalize");
			registryKey5.SetValue("ControlPanelName", "Microsoft.Personalization");
			registryKey5.SetValue("Icon", this.string_3);
			registryKey5.SetValue("muiverb", this.string_5);
			Registry.LocalMachine.CreateSubKey(str + "\\Personalize\\command").SetValue(this.string_6, this.string_7);
			RegistryKey registryKey6 = Registry.LocalMachine.CreateSubKey(str + "\\Display");
			registryKey6.SetValue("ControlPanelName", "Microsoft.Display");
			registryKey6.SetValue("ControlPanelPage", "Settings");
			registryKey6.SetValue("Icon", this.string_2);
			registryKey6.SetValue("muiverb", this.string_4);
			Registry.LocalMachine.CreateSubKey(str + "\\Display\\command").SetValue(this.string_6, this.string_7);
		}
		RegistryKey registryKey7 = Registry.LocalMachine.CreateSubKey(str + "\\GodMode");
		registryKey7.SetValue("", GClass2.GClass2_0.method_1("GodMode"));
		registryKey7.SetValue("Icon", "control.exe");
		registryKey7 = Registry.LocalMachine.CreateSubKey(str + "\\GodMode\\command");
		registryKey7.SetValue("", "explorer shell:::{ED7BA470-8E54-465E-825C-99712043E01C}");
		registryKey7 = Registry.LocalMachine.CreateSubKey(str + "\\Logout");
		registryKey7.SetValue("", GClass2.GClass2_0.method_1("LogoutItem"));
		if (!GClass2.GClass2_0.String_3.Contains("10"))
		{
			if (!GClass2.GClass2_0.String_3.Contains("7"))
			{
				if (GClass2.GClass2_0.String_3.Contains("8"))
				{
					registryKey7.SetValue("Icon", "imageres.dll,242");
				}
			}
			else
			{
				registryKey7.SetValue("Icon", "shell32.dll,44");
			}
		}
		else
		{
			registryKey7.SetValue("Icon", "imageres.dll,255");
		}
		registryKey7 = Registry.LocalMachine.CreateSubKey(str + "\\Logout\\command");
		registryKey7.SetValue("", "logoff");
		registryKey7 = Registry.LocalMachine.CreateSubKey(str + "\\Reboot");
		registryKey7.SetValue("", GClass2.GClass2_0.method_1("NormalReboot"));
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			registryKey7.SetValue("Icon", "imageres.dll,228");
		}
		if (GClass2.GClass2_0.String_3.Contains("7"))
		{
			registryKey7.SetValue("Icon", "shell32.dll,176");
		}
		if (GClass2.GClass2_0.String_3.Contains("8"))
		{
			registryKey7.SetValue("Icon", "shell32.dll,238");
		}
		registryKey7 = Registry.LocalMachine.CreateSubKey(str + "\\Reboot\\command");
		registryKey7.SetValue("", "shutdown.exe -r -t 0");
		registryKey7 = Registry.LocalMachine.CreateSubKey(str + "\\Shutdown");
		registryKey7.SetValue("", GClass2.GClass2_0.method_1("ShutdownItem"));
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			registryKey7.SetValue("Icon", "imageres.dll,235");
		}
		if (GClass2.GClass2_0.String_3.Contains("7"))
		{
			registryKey7.SetValue("Icon", "shell32.dll,27");
		}
		if (GClass2.GClass2_0.String_3.Contains("8"))
		{
			registryKey7.SetValue("Icon", "imageres.dll,222");
		}
		registryKey7 = Registry.LocalMachine.CreateSubKey(str + "\\Shutdown\\command");
		registryKey7.SetValue("", "shutdown.exe -s -t 0");
	}

	// Token: 0x06000515 RID: 1301 RVA: 0x0001A2E0 File Offset: 0x000184E0
	public void method_1()
	{
		RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey(this.string_0);
		registryKey.CreateSubKey("command");
		registryKey.SetValue("", this.string_4, RegistryValueKind.ExpandString);
		registryKey.SetValue("Icon", this.string_2, RegistryValueKind.ExpandString);
		registryKey.SetValue("Position", "Bottom");
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			registryKey.SetValue("SettingsUri", "ms-settings:display");
			registryKey.CreateSubKey("command").SetValue(this.string_6, this.string_8);
		}
		else
		{
			registryKey.SetValue("ControlPanelName", "Microsoft.Display");
			registryKey.SetValue("ControlPanelPage", "Settings");
			registryKey.CreateSubKey("command").SetValue(this.string_6, this.string_7);
		}
		List<string> list = new List<string>();
		list.Add(this.string_1 + "\\Personalize");
		list.Add(this.string_1 + "\\Windows settings");
		list.Add(this.string_1 + "\\Display");
		list.Add(this.string_1 + "\\Logout");
		list.Add(this.string_1 + "\\Reboot");
		list.Add(this.string_1 + "\\Shutdown");
		list.ForEach(new Action<string>(Class31.<>c.<>9.method_0));
		registryKey = Registry.ClassesRoot.CreateSubKey("DesktopBackground\\Shell\\Personalize");
		registryKey.SetValue("", this.string_5, RegistryValueKind.ExpandString);
		if (registryKey.GetValue("subcommands") != null)
		{
			registryKey.DeleteValue("subcommands");
		}
	}

	// Token: 0x06000518 RID: 1304 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000519 RID: 1305 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x0600051A RID: 1306 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_9)
	{
		return registryKey_0.OpenSubKey(string_9);
	}

	// Token: 0x0600051B RID: 1307 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_3(RegistryKey registryKey_0, string string_9, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_9, bool_0);
	}

	// Token: 0x0600051C RID: 1308 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_4(RegistryKey registryKey_0, string string_9)
	{
		return registryKey_0.CreateSubKey(string_9);
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_5(RegistryKey registryKey_0, string string_9)
	{
		return registryKey_0.GetValue(string_9);
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_6(RegistryKey registryKey_0, string string_9)
	{
		registryKey_0.DeleteValue(string_9);
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_7(RegistryKey registryKey_0, string string_9, object object_1)
	{
		registryKey_0.SetValue(string_9, object_1);
	}

	// Token: 0x06000520 RID: 1312 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_8(string string_9, string string_10)
	{
		return string_9.Contains(string_10);
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_9(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000522 RID: 1314 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_10(string string_9, string string_10)
	{
		return string_9 + string_10;
	}

	// Token: 0x06000523 RID: 1315 RVA: 0x00002EED File Offset: 0x000010ED
	static void smethod_11(RegistryKey registryKey_0, string string_9, object object_1, RegistryValueKind registryValueKind_0)
	{
		registryKey_0.SetValue(string_9, object_1, registryValueKind_0);
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_12(RegistryKey registryKey_0, string string_9)
	{
		return registryKey_0.GetValue(string_9);
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_13()
	{
		return new object();
	}

	// Token: 0x04000231 RID: 561
	private static volatile Class31 class31_0;

	// Token: 0x04000232 RID: 562
	private static readonly object object_0 = new object();

	// Token: 0x04000233 RID: 563
	private readonly string string_0 = "DesktopBackground\\Shell\\Display";

	// Token: 0x04000234 RID: 564
	private readonly string string_1 = GClass2.GClass2_0.String_0 + "\\Explorer\\CommandStore\\shell";

	// Token: 0x04000235 RID: 565
	private readonly string string_2 = "%SystemRoot%\\System32\\display.dll,-1";

	// Token: 0x04000236 RID: 566
	private readonly string string_3 = "%systemroot%\\system32\\themecpl.dll,-1";

	// Token: 0x04000237 RID: 567
	private readonly string string_4 = "@%SystemRoot%\\System32\\display.dll,-4";

	// Token: 0x04000238 RID: 568
	private readonly string string_5 = "@%systemroot%\\system32\\themecpl.dll,-10";

	// Token: 0x04000239 RID: 569
	private readonly string string_6 = "DelegateExecute";

	// Token: 0x0400023A RID: 570
	private readonly string string_7 = "{06622D85-6856-4460-8DE1-A81921B41C4B}";

	// Token: 0x0400023B RID: 571
	private readonly string string_8 = "{556FF0D6-A1EE-49E5-9FA4-90AE116AD744}";
}
