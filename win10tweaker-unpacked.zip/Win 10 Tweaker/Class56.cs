﻿using System;
using System.Collections.Generic;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000094 RID: 148
internal class Class56
{
	// Token: 0x1700003C RID: 60
	// (get) Token: 0x06000744 RID: 1860 RVA: 0x0001F8C4 File Offset: 0x0001DAC4
	public static Class56 Class56_0
	{
		get
		{
			if (Class56.class56_0 == null)
			{
				object obj = Class56.object_0;
				lock (obj)
				{
					if (Class56.class56_0 == null)
					{
						Class56.class56_0 = new Class56();
					}
				}
			}
			return Class56.class56_0;
		}
	}

	// Token: 0x1700003D RID: 61
	// (get) Token: 0x06000745 RID: 1861 RVA: 0x0001F924 File Offset: 0x0001DB24
	private string String_0
	{
		get
		{
			string result;
			if ((result = this.string_0) == null)
			{
				result = (this.string_0 = GClass2.GClass2_0.String_0 + "\\Explorer\\MyComputer\\NameSpace\\");
			}
			return result;
		}
	}

	// Token: 0x1700003E RID: 62
	// (get) Token: 0x06000746 RID: 1862 RVA: 0x0001F958 File Offset: 0x0001DB58
	private string String_1
	{
		get
		{
			string result;
			if ((result = this.string_1) == null)
			{
				result = (this.string_1 = "SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Explorer\\MyComputer\\NameSpace\\");
			}
			return result;
		}
	}

	// Token: 0x06000747 RID: 1863 RVA: 0x0001F980 File Offset: 0x0001DB80
	public void method_0(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree(this.String_0 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[0] : this.List_3[0]), false);
			if (GClass2.GClass2_0.Boolean_0)
			{
				Registry.LocalMachine.DeleteSubKeyTree(this.String_1 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[0] : this.List_3[0]), false);
			}
		}
	}

	// Token: 0x06000748 RID: 1864 RVA: 0x0001FA2C File Offset: 0x0001DC2C
	public void method_1(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree(this.String_0 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[1] : this.List_3[1]), false);
			if (GClass2.GClass2_0.Boolean_0)
			{
				Registry.LocalMachine.DeleteSubKeyTree(this.String_1 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[1] : this.List_3[1]), false);
			}
		}
	}

	// Token: 0x06000749 RID: 1865 RVA: 0x0001FAD8 File Offset: 0x0001DCD8
	public void method_2(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree(this.String_0 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[2] : this.List_3[2]), false);
			if (GClass2.GClass2_0.Boolean_0)
			{
				Registry.LocalMachine.DeleteSubKeyTree(this.String_1 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[2] : this.List_3[2]), false);
			}
		}
	}

	// Token: 0x0600074A RID: 1866 RVA: 0x0001FB84 File Offset: 0x0001DD84
	public void method_3(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree(this.String_0 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[3] : this.List_3[3]), false);
			if (GClass2.GClass2_0.Boolean_0)
			{
				Registry.LocalMachine.DeleteSubKeyTree(this.String_1 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[3] : this.List_3[3]), false);
			}
		}
	}

	// Token: 0x0600074B RID: 1867 RVA: 0x0001FC30 File Offset: 0x0001DE30
	public void method_4(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree(this.String_0 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[4] : this.List_3[4]), false);
			if (!GClass2.GClass2_0.Boolean_0)
			{
			}
		}
	}

	// Token: 0x0600074C RID: 1868 RVA: 0x0001FC94 File Offset: 0x0001DE94
	public void method_5(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree(this.String_0 + (GClass2.GClass2_0.String_3.Contains("10") ? Class56.List_0[5] : this.List_3[5]), false);
			if (!GClass2.GClass2_0.Boolean_0)
			{
			}
		}
	}

	// Token: 0x1700003F RID: 63
	// (get) Token: 0x0600074D RID: 1869 RVA: 0x0001FCF8 File Offset: 0x0001DEF8
	private static List<string> List_0
	{
		get
		{
			return new List<string>
			{
				"{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}",
				"{d3162b92-9365-467a-956b-92703aca08af}",
				"{088e3905-0323-4b02-9826-5d99428e115f}",
				"{24ad3ad4-a569-4530-98e1-ab02f9417aa8}",
				"{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}",
				"{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}"
			};
		}
	}

	// Token: 0x17000040 RID: 64
	// (get) Token: 0x0600074E RID: 1870 RVA: 0x0001FD4C File Offset: 0x0001DF4C
	public List<string> List_1
	{
		get
		{
			return new List<string>
			{
				this.String_0 + Class56.List_0[0],
				this.String_0 + Class56.List_0[1],
				this.String_0 + Class56.List_0[2],
				this.String_0 + Class56.List_0[3],
				this.String_0 + Class56.List_0[4],
				this.String_0 + Class56.List_0[5],
				this.String_1 + Class56.List_0[0],
				this.String_1 + Class56.List_0[1],
				this.String_1 + Class56.List_0[2],
				this.String_1 + Class56.List_0[3],
				this.String_1 + Class56.List_0[4],
				this.String_1 + Class56.List_0[5]
			};
		}
	}

	// Token: 0x17000041 RID: 65
	// (get) Token: 0x0600074F RID: 1871 RVA: 0x0001FEB0 File Offset: 0x0001E0B0
	private List<string> List_2
	{
		get
		{
			return new List<string>
			{
				this.String_0 + Class56.List_0[0],
				this.String_0 + Class56.List_0[1],
				this.String_0 + Class56.List_0[2],
				this.String_0 + Class56.List_0[3],
				this.String_0 + Class56.List_0[4],
				this.String_0 + Class56.List_0[5]
			};
		}
	}

	// Token: 0x17000042 RID: 66
	// (get) Token: 0x06000750 RID: 1872 RVA: 0x0001FF6C File Offset: 0x0001E16C
	private List<string> List_3
	{
		get
		{
			return new List<string>
			{
				"{A0953C92-50DC-43bf-BE83-3742FED03C9C}",
				"{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}",
				"{374DE290-123F-4565-9164-39C4925E467B}",
				"{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}",
				"{1CF1260C-4DD0-4ebb-811F-33C572699FDE}",
				"{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}"
			};
		}
	}

	// Token: 0x17000043 RID: 67
	// (get) Token: 0x06000751 RID: 1873 RVA: 0x0001FFC0 File Offset: 0x0001E1C0
	public List<string> List_4
	{
		get
		{
			return new List<string>
			{
				this.String_0 + this.List_3[0],
				this.String_0 + this.List_3[1],
				this.String_0 + this.List_3[2],
				this.String_0 + this.List_3[3],
				this.String_0 + this.List_3[4],
				this.String_0 + this.List_3[5],
				this.String_1 + this.List_3[0],
				this.String_1 + this.List_3[1],
				this.String_1 + this.List_3[2],
				this.String_1 + this.List_3[3],
				this.String_1 + this.List_3[4],
				this.String_1 + this.List_3[5]
			};
		}
	}

	// Token: 0x17000044 RID: 68
	// (get) Token: 0x06000752 RID: 1874 RVA: 0x00020130 File Offset: 0x0001E330
	private List<string> List_5
	{
		get
		{
			return new List<string>
			{
				this.String_0 + this.List_3[0],
				this.String_0 + this.List_3[1],
				this.String_0 + this.List_3[2],
				this.String_0 + this.List_3[3],
				this.String_0 + this.List_3[4],
				this.String_0 + this.List_3[5]
			};
		}
	}

	// Token: 0x06000753 RID: 1875 RVA: 0x000201F0 File Offset: 0x0001E3F0
	public void method_6()
	{
		foreach (string subkey in (GClass2.GClass2_0.String_3.Contains("10") ? (GClass2.GClass2_0.Boolean_0 ? this.List_1 : this.List_2) : (GClass2.GClass2_0.Boolean_0 ? this.List_4 : this.List_5)))
		{
			Registry.LocalMachine.CreateSubKey(subkey);
		}
	}

	// Token: 0x06000756 RID: 1878 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000757 RID: 1879 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000758 RID: 1880 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_2(string string_2, string string_3)
	{
		return string_2 + string_3;
	}

	// Token: 0x06000759 RID: 1881 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_3(string string_2, string string_3)
	{
		return string_2.Contains(string_3);
	}

	// Token: 0x0600075A RID: 1882 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_4(RegistryKey registryKey_0, string string_2, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_2, bool_0);
	}

	// Token: 0x0600075B RID: 1883 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_5(RegistryKey registryKey_0, string string_2)
	{
		return registryKey_0.CreateSubKey(string_2);
	}

	// Token: 0x0600075C RID: 1884 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_6()
	{
		return new object();
	}

	// Token: 0x040002C3 RID: 707
	private static volatile Class56 class56_0;

	// Token: 0x040002C4 RID: 708
	private static readonly object object_0 = new object();

	// Token: 0x040002C5 RID: 709
	private string string_0;

	// Token: 0x040002C6 RID: 710
	private string string_1;
}
