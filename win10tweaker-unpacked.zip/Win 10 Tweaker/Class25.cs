﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x02000051 RID: 81
[Guid("EA502722-A23D-11d1-A7D3-0000F87571E3")]
[ComImport]
internal class Class25
{
	// Token: 0x060003EE RID: 1006
	[MethodImpl(MethodImplOptions.InternalCall)]
	public extern Class25();
}
