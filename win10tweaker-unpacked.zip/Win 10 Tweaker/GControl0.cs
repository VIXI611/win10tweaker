﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

// Token: 0x02000037 RID: 55
public class GControl0 : UserControl
{
	// Token: 0x06000206 RID: 518 RVA: 0x000031DD File Offset: 0x000013DD
	public GControl0()
	{
		this.method_1();
	}

	// Token: 0x06000207 RID: 519 RVA: 0x00012018 File Offset: 0x00010218
	private void GControl0_Paint(object sender, PaintEventArgs e)
	{
		try
		{
			Graphics graphics = e.Graphics;
			Rectangle rectangle = new Rectangle(1, 1, 79, 79);
			GraphicsPath graphicsPath = new GraphicsPath();
			graphicsPath.AddEllipse(rectangle);
			graphics.TranslateTransform(81f, 81f);
			graphics.RotateTransform(180f);
			graphicsPath.Flatten();
			int num = (graphicsPath.PointCount - 1) / 3;
			Color[] array = new Color[graphicsPath.PointCount];
			float num2 = 255f;
			float num3 = 0f;
			float num4 = 0f;
			for (int i = 0; i < num; i++)
			{
				array[i] = Color.FromArgb(255, (int)num2, (int)num3, (int)num4);
			}
			num2 = 0f;
			num3 = 0f;
			num4 = 255f;
			float num5 = (float)(255 / num);
			for (int j = num; j < 2 * num; j++)
			{
				array[j] = Color.FromArgb(255, (int)num2, (int)num3, (int)num4);
				num3 += num5;
			}
			num2 = 0f;
			num3 = 255f;
			num4 = 0f;
			float num6 = (float)(255 / (graphicsPath.PointCount - 2 * num));
			num5 = (float)(-255 / (graphicsPath.PointCount - 2 * num));
			for (int k = 2 * num; k < graphicsPath.PointCount; k++)
			{
				array[k] = Color.FromArgb(255, (int)num2, (int)num3, (int)num4);
				num2 += num6;
				num3 += num5;
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
			}
			PathGradientBrush brush = new PathGradientBrush(graphicsPath)
			{
				SurroundColors = array
			};
			graphics.FillPath(brush, graphicsPath);
			Pen pen = new Pen(ColorTranslator.FromHtml("#1f2434"), 2f);
			graphics.DrawPath(pen, graphicsPath);
			rectangle = new Rectangle(0, 0, base.Width, base.Height);
			graphics.TranslateTransform(81f, 81f);
			graphics.RotateTransform(180f);
			graphics.FillPie(new SolidBrush(GClass2.GClass2_0.Color_0), rectangle, -90f, (float)((int)((double)this.int_0 * 3.6) - 360));
			rectangle = new Rectangle(10, 1, base.Width - 18, base.Height - 12);
			graphics.FillPie(new SolidBrush(GClass2.GClass2_0.Color_0), rectangle, 0f, 360f);
			StringFormat format = new StringFormat
			{
				LineAlignment = StringAlignment.Center,
				Alignment = StringAlignment.Center
			};
			graphics.DrawString(this.int_0.ToString() + "%", new Font("Arial", 15f), new SolidBrush(Color.FromArgb(103, 137, 178)), rectangle, format);
		}
		catch
		{
		}
	}

	// Token: 0x06000208 RID: 520 RVA: 0x000031EB File Offset: 0x000013EB
	public void method_0(int int_1)
	{
		this.int_0 = int_1;
		base.Invalidate();
	}

	// Token: 0x06000209 RID: 521 RVA: 0x000031FA File Offset: 0x000013FA
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600020A RID: 522 RVA: 0x000122F0 File Offset: 0x000104F0
	private void method_1()
	{
		base.SuspendLayout();
		base.AutoScaleMode = AutoScaleMode.None;
		this.DoubleBuffered = true;
		base.Name = "Circle";
		base.Size = new Size(80, 80);
		base.Paint += this.GControl0_Paint;
		base.ResumeLayout(false);
	}

	// Token: 0x0600020B RID: 523 RVA: 0x00002B88 File Offset: 0x00000D88
	static Graphics smethod_0(PaintEventArgs paintEventArgs_0)
	{
		return paintEventArgs_0.Graphics;
	}

	// Token: 0x0600020C RID: 524 RVA: 0x00003219 File Offset: 0x00001419
	static GraphicsPath smethod_1()
	{
		return new GraphicsPath();
	}

	// Token: 0x0600020D RID: 525 RVA: 0x00003220 File Offset: 0x00001420
	static void smethod_2(GraphicsPath graphicsPath_0, Rectangle rectangle_0)
	{
		graphicsPath_0.AddEllipse(rectangle_0);
	}

	// Token: 0x0600020E RID: 526 RVA: 0x00003229 File Offset: 0x00001429
	static void smethod_3(Graphics graphics_0, float float_0, float float_1)
	{
		graphics_0.TranslateTransform(float_0, float_1);
	}

	// Token: 0x0600020F RID: 527 RVA: 0x00003233 File Offset: 0x00001433
	static void smethod_4(Graphics graphics_0, float float_0)
	{
		graphics_0.RotateTransform(float_0);
	}

	// Token: 0x06000210 RID: 528 RVA: 0x0000323C File Offset: 0x0000143C
	static void smethod_5(GraphicsPath graphicsPath_0)
	{
		graphicsPath_0.Flatten();
	}

	// Token: 0x06000211 RID: 529 RVA: 0x00003244 File Offset: 0x00001444
	static int smethod_6(GraphicsPath graphicsPath_0)
	{
		return graphicsPath_0.PointCount;
	}

	// Token: 0x06000212 RID: 530 RVA: 0x0000324C File Offset: 0x0000144C
	static void smethod_7(Graphics graphics_0, SmoothingMode smoothingMode_0)
	{
		graphics_0.SmoothingMode = smoothingMode_0;
	}

	// Token: 0x06000213 RID: 531 RVA: 0x00003255 File Offset: 0x00001455
	static PathGradientBrush smethod_8(GraphicsPath graphicsPath_0)
	{
		return new PathGradientBrush(graphicsPath_0);
	}

	// Token: 0x06000214 RID: 532 RVA: 0x0000325D File Offset: 0x0000145D
	static void smethod_9(PathGradientBrush pathGradientBrush_0, Color[] color_0)
	{
		pathGradientBrush_0.SurroundColors = color_0;
	}

	// Token: 0x06000215 RID: 533 RVA: 0x00003266 File Offset: 0x00001466
	static void smethod_10(Graphics graphics_0, Brush brush_0, GraphicsPath graphicsPath_0)
	{
		graphics_0.FillPath(brush_0, graphicsPath_0);
	}

	// Token: 0x06000216 RID: 534 RVA: 0x00003270 File Offset: 0x00001470
	static Color smethod_11(string string_0)
	{
		return ColorTranslator.FromHtml(string_0);
	}

	// Token: 0x06000217 RID: 535 RVA: 0x00003278 File Offset: 0x00001478
	static Pen smethod_12(Color color_0, float float_0)
	{
		return new Pen(color_0, float_0);
	}

	// Token: 0x06000218 RID: 536 RVA: 0x00003281 File Offset: 0x00001481
	static void smethod_13(Graphics graphics_0, Pen pen_0, GraphicsPath graphicsPath_0)
	{
		graphics_0.DrawPath(pen_0, graphicsPath_0);
	}

	// Token: 0x06000219 RID: 537 RVA: 0x0000328B File Offset: 0x0000148B
	static int smethod_14(Control control_0)
	{
		return control_0.Width;
	}

	// Token: 0x0600021A RID: 538 RVA: 0x00003293 File Offset: 0x00001493
	static int smethod_15(Control control_0)
	{
		return control_0.Height;
	}

	// Token: 0x0600021B RID: 539 RVA: 0x0000329B File Offset: 0x0000149B
	static SolidBrush smethod_16(Color color_0)
	{
		return new SolidBrush(color_0);
	}

	// Token: 0x0600021C RID: 540 RVA: 0x000032A3 File Offset: 0x000014A3
	static void smethod_17(Graphics graphics_0, Brush brush_0, Rectangle rectangle_0, float float_0, float float_1)
	{
		graphics_0.FillPie(brush_0, rectangle_0, float_0, float_1);
	}

	// Token: 0x0600021D RID: 541 RVA: 0x000032B0 File Offset: 0x000014B0
	static StringFormat smethod_18()
	{
		return new StringFormat();
	}

	// Token: 0x0600021E RID: 542 RVA: 0x000032B7 File Offset: 0x000014B7
	static void smethod_19(StringFormat stringFormat_0, StringAlignment stringAlignment_0)
	{
		stringFormat_0.LineAlignment = stringAlignment_0;
	}

	// Token: 0x0600021F RID: 543 RVA: 0x000032C0 File Offset: 0x000014C0
	static void smethod_20(StringFormat stringFormat_0, StringAlignment stringAlignment_0)
	{
		stringFormat_0.Alignment = stringAlignment_0;
	}

	// Token: 0x06000220 RID: 544 RVA: 0x000032C9 File Offset: 0x000014C9
	static void smethod_21(Control control_0)
	{
		control_0.Invalidate();
	}

	// Token: 0x06000221 RID: 545 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_22(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000222 RID: 546 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_23(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x06000223 RID: 547 RVA: 0x000032D1 File Offset: 0x000014D1
	static void smethod_24(ContainerControl containerControl_0, AutoScaleMode autoScaleMode_0)
	{
		containerControl_0.AutoScaleMode = autoScaleMode_0;
	}

	// Token: 0x06000224 RID: 548 RVA: 0x000032DA File Offset: 0x000014DA
	static void smethod_25(Control control_0, string string_0)
	{
		control_0.Name = string_0;
	}

	// Token: 0x040000F7 RID: 247
	private int int_0;

	// Token: 0x040000F8 RID: 248
	private IContainer icontainer_0;
}
