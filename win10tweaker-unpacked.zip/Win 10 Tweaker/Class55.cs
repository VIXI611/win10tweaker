﻿using System;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000093 RID: 147
internal class Class55
{
	// Token: 0x1700003B RID: 59
	// (get) Token: 0x06000735 RID: 1845 RVA: 0x0001F7C8 File Offset: 0x0001D9C8
	public static Class55 Class55_0
	{
		get
		{
			if (Class55.class55_0 == null)
			{
				object obj = Class55.object_0;
				lock (obj)
				{
					if (Class55.class55_0 == null)
					{
						Class55.class55_0 = new Class55();
					}
				}
			}
			return Class55.class55_0;
		}
	}

	// Token: 0x06000736 RID: 1846 RVA: 0x0001F828 File Offset: 0x0001DA28
	public void method_0()
	{
		RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey("Directory\\shell\\EmptyThisFolder\\command");
		registryKey.SetValue("", "cmd /c \"cd /d %1 && del /s /f /q *.* && rd /s /q .\"");
		registryKey = Registry.ClassesRoot.CreateSubKey(Class55.string_0);
		registryKey.SetValue("Icon", GClass2.GClass2_0.String_3.Contains("10") ? "imageres.dll,257" : "SHELL32.dll,19");
		registryKey.SetValue("", GClass2.GClass2_0.method_1("EmptyThisFolder"));
		if (registryKey.GetValue("Extended") != null)
		{
			registryKey.DeleteValue("Extended");
		}
	}

	// Token: 0x06000737 RID: 1847 RVA: 0x00004A00 File Offset: 0x00002C00
	public void method_1()
	{
		Registry.ClassesRoot.CreateSubKey(Class55.string_0).SetValue("Extended", "");
	}

	// Token: 0x06000738 RID: 1848 RVA: 0x00004A20 File Offset: 0x00002C20
	public void method_2()
	{
		Registry.ClassesRoot.DeleteSubKeyTree(Class55.string_0, false);
	}

	// Token: 0x0600073B RID: 1851 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x0600073C RID: 1852 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x0600073D RID: 1853 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x0600073E RID: 1854 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_3(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x0600073F RID: 1855 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_4(string string_1, string string_2)
	{
		return string_1.Contains(string_2);
	}

	// Token: 0x06000740 RID: 1856 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_5(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.GetValue(string_1);
	}

	// Token: 0x06000741 RID: 1857 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_6(RegistryKey registryKey_0, string string_1)
	{
		registryKey_0.DeleteValue(string_1);
	}

	// Token: 0x06000742 RID: 1858 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_7(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_1, bool_0);
	}

	// Token: 0x06000743 RID: 1859 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_8()
	{
		return new object();
	}

	// Token: 0x040002C0 RID: 704
	private static volatile Class55 class55_0;

	// Token: 0x040002C1 RID: 705
	private static readonly object object_0 = new object();

	// Token: 0x040002C2 RID: 706
	private static readonly string string_0 = "Directory\\shell\\EmptyThisFolder";
}
