﻿// Token: 0x02000188 RID: 392
public partial class WMessageBox : global::GForm0
{
	// Token: 0x06001349 RID: 4937 RVA: 0x0006B7D0 File Offset: 0x000699D0
	private void InitializeComponent()
	{
		this.HeaderPanel = new global::System.Windows.Forms.Panel();
		this.Header = new global::System.Windows.Forms.Label();
		this.CloseIcon = new global::System.Windows.Forms.Button();
		this.Yes = new global::System.Windows.Forms.Button();
		this.No = new global::System.Windows.Forms.Button();
		this.Cancel = new global::System.Windows.Forms.Button();
		this.OK = new global::System.Windows.Forms.Button();
		this.MessageLabel = new global::System.Windows.Forms.Label();
		this.ButtonsPanel = new global::System.Windows.Forms.Panel();
		this.DontShowAgain = new global::System.Windows.Forms.CheckBox();
		this.HeaderPanel.SuspendLayout();
		this.ButtonsPanel.SuspendLayout();
		base.SuspendLayout();
		this.HeaderPanel.Controls.Add(this.Header);
		this.HeaderPanel.Controls.Add(this.CloseIcon);
		this.HeaderPanel.Location = new global::System.Drawing.Point(0, 0);
		this.HeaderPanel.Margin = new global::System.Windows.Forms.Padding(0);
		this.HeaderPanel.Name = "HeaderPanel";
		this.HeaderPanel.Size = new global::System.Drawing.Size(380, 38);
		this.HeaderPanel.TabIndex = 179;
		this.Header.AutoSize = true;
		this.Header.BackColor = global::System.Drawing.Color.Transparent;
		this.Header.Font = new global::System.Drawing.Font("Calibri", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.Header.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.Header.Location = new global::System.Drawing.Point(12, 9);
		this.Header.Name = "Header";
		this.Header.Size = new global::System.Drawing.Size(0, 15);
		this.Header.TabIndex = 31;
		this.CloseIcon.BackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.BackgroundImage = global::Class89.Bitmap_17;
		this.CloseIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.CloseIcon.DialogResult = global::System.Windows.Forms.DialogResult.OK;
		this.CloseIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
		this.CloseIcon.FlatAppearance.BorderSize = 0;
		this.CloseIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.CloseIcon.Location = new global::System.Drawing.Point(347, 5);
		this.CloseIcon.Name = "CloseIcon";
		this.CloseIcon.Size = new global::System.Drawing.Size(22, 22);
		this.CloseIcon.TabIndex = 18;
		this.CloseIcon.TabStop = false;
		this.CloseIcon.UseVisualStyleBackColor = false;
		this.Yes.BackColor = global::System.Drawing.SystemColors.Control;
		this.Yes.DialogResult = global::System.Windows.Forms.DialogResult.Yes;
		this.Yes.FlatAppearance.BorderSize = 0;
		this.Yes.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.Yes.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.Yes.Location = new global::System.Drawing.Point(105, 11);
		this.Yes.Name = "Yes";
		this.Yes.Size = new global::System.Drawing.Size(82, 22);
		this.Yes.TabIndex = 2;
		this.Yes.UseVisualStyleBackColor = false;
		this.No.BackColor = global::System.Drawing.SystemColors.Control;
		this.No.DialogResult = global::System.Windows.Forms.DialogResult.No;
		this.No.FlatAppearance.BorderSize = 0;
		this.No.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.No.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.No.Location = new global::System.Drawing.Point(193, 11);
		this.No.Name = "No";
		this.No.Size = new global::System.Drawing.Size(82, 22);
		this.No.TabIndex = 3;
		this.No.UseVisualStyleBackColor = false;
		this.Cancel.BackColor = global::System.Drawing.SystemColors.Control;
		this.Cancel.DialogResult = global::System.Windows.Forms.DialogResult.Cancel;
		this.Cancel.FlatAppearance.BorderSize = 0;
		this.Cancel.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.Cancel.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.Cancel.Location = new global::System.Drawing.Point(281, 11);
		this.Cancel.Name = "Cancel";
		this.Cancel.Size = new global::System.Drawing.Size(82, 22);
		this.Cancel.TabIndex = 4;
		this.Cancel.UseVisualStyleBackColor = false;
		this.OK.BackColor = global::System.Drawing.SystemColors.Control;
		this.OK.DialogResult = global::System.Windows.Forms.DialogResult.OK;
		this.OK.FlatAppearance.BorderSize = 0;
		this.OK.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.OK.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.OK.Location = new global::System.Drawing.Point(17, 11);
		this.OK.Name = "OK";
		this.OK.Size = new global::System.Drawing.Size(82, 22);
		this.OK.TabIndex = 1;
		this.OK.UseVisualStyleBackColor = false;
		this.MessageLabel.AutoSize = true;
		this.MessageLabel.BackColor = global::System.Drawing.Color.Transparent;
		this.MessageLabel.ForeColor = global::System.Drawing.Color.FromArgb(175, 201, 211);
		this.MessageLabel.Location = new global::System.Drawing.Point(14, 50);
		this.MessageLabel.Name = "MessageLabel";
		this.MessageLabel.Size = new global::System.Drawing.Size(0, 13);
		this.MessageLabel.TabIndex = 199;
		this.ButtonsPanel.BackColor = global::System.Drawing.Color.Transparent;
		this.ButtonsPanel.Controls.Add(this.OK);
		this.ButtonsPanel.Controls.Add(this.Yes);
		this.ButtonsPanel.Controls.Add(this.No);
		this.ButtonsPanel.Controls.Add(this.Cancel);
		this.ButtonsPanel.Location = new global::System.Drawing.Point(0, 70);
		this.ButtonsPanel.Margin = new global::System.Windows.Forms.Padding(0);
		this.ButtonsPanel.Name = "ButtonsPanel";
		this.ButtonsPanel.Size = new global::System.Drawing.Size(380, 50);
		this.ButtonsPanel.TabIndex = 200;
		this.DontShowAgain.AutoSize = true;
		this.DontShowAgain.BackColor = global::System.Drawing.Color.Transparent;
		this.DontShowAgain.ForeColor = global::System.Drawing.Color.FromArgb(175, 201, 211);
		this.DontShowAgain.Location = new global::System.Drawing.Point(17, 50);
		this.DontShowAgain.Name = "DontShowAgain";
		this.DontShowAgain.Size = new global::System.Drawing.Size(15, 14);
		this.DontShowAgain.TabIndex = 201;
		this.DontShowAgain.UseVisualStyleBackColor = false;
		this.DontShowAgain.Visible = false;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
		this.AutoSize = true;
		base.ClientSize = new global::System.Drawing.Size(380, 120);
		base.Controls.Add(this.DontShowAgain);
		base.Controls.Add(this.ButtonsPanel);
		base.Controls.Add(this.MessageLabel);
		base.Controls.Add(this.HeaderPanel);
		this.DoubleBuffered = true;
		this.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "WMessageBox";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		this.Text = "WMessageBox";
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.WMessageBox_Load);
		this.HeaderPanel.ResumeLayout(false);
		this.HeaderPanel.PerformLayout();
		this.ButtonsPanel.ResumeLayout(false);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000931 RID: 2353
	private global::System.Windows.Forms.Panel HeaderPanel;

	// Token: 0x04000932 RID: 2354
	private global::System.Windows.Forms.Button CloseIcon;

	// Token: 0x04000933 RID: 2355
	private global::System.Windows.Forms.Label Header;

	// Token: 0x04000934 RID: 2356
	private global::System.Windows.Forms.Button OK;

	// Token: 0x04000935 RID: 2357
	private global::System.Windows.Forms.Button Yes;

	// Token: 0x04000936 RID: 2358
	private global::System.Windows.Forms.Button No;

	// Token: 0x04000937 RID: 2359
	private global::System.Windows.Forms.Button Cancel;

	// Token: 0x04000938 RID: 2360
	private global::System.Windows.Forms.Label MessageLabel;

	// Token: 0x04000939 RID: 2361
	private global::System.Windows.Forms.Panel ButtonsPanel;

	// Token: 0x0400093A RID: 2362
	private global::System.Windows.Forms.CheckBox DontShowAgain;
}
