﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;

// Token: 0x02000024 RID: 36
public class GClass0
{
	// Token: 0x0600014A RID: 330 RVA: 0x00002DC4 File Offset: 0x00000FC4
	public GClass0(string string_0)
	{
		this.byte_0 = File.ReadAllBytes(string_0);
	}

	// Token: 0x0600014B RID: 331 RVA: 0x0000FF1C File Offset: 0x0000E11C
	public void method_0(int[] int_0, byte[] byte_1)
	{
		int num = 0;
		for (;;)
		{
			IEnumerable<byte> source = this.byte_0;
			Func<byte, int> selector;
			if ((selector = GClass0.<>c.<>9__2_0) == null)
			{
				selector = (GClass0.<>c.<>9__2_0 = new Func<byte, int>(GClass0.<>c.<>9.method_0));
			}
			if ((num = this.method_2(source.Select(selector).ToArray<int>(), int_0, num)) < 0)
			{
				break;
			}
			byte[] dst = new byte[this.byte_0.Length - int_0.Length + byte_1.Length];
			Buffer.BlockCopy(this.byte_0, 0, dst, 0, num);
			Buffer.BlockCopy(byte_1, 0, dst, num, byte_1.Length);
			Buffer.BlockCopy(this.byte_0, num + int_0.Length, dst, num + byte_1.Length, this.byte_0.Length - (num + int_0.Length));
			this.byte_0 = dst;
			num += byte_1.Length;
		}
	}

	// Token: 0x0600014C RID: 332 RVA: 0x00002DD8 File Offset: 0x00000FD8
	public void method_1(string string_0)
	{
		File.WriteAllBytes(string_0, this.byte_0);
	}

	// Token: 0x0600014D RID: 333 RVA: 0x0000FFDC File Offset: 0x0000E1DC
	private int method_2(IReadOnlyList<int> ireadOnlyList_0, IReadOnlyList<int> ireadOnlyList_1, int int_0 = 0)
	{
		GClass0.Class11 @class = new GClass0.Class11();
		@class.ireadOnlyList_0 = ireadOnlyList_0;
		@class.int_0 = int_0;
		while (@class.int_0 < @class.ireadOnlyList_0.Count)
		{
			if (@class.ireadOnlyList_0[@class.int_0] == ireadOnlyList_1[0])
			{
				Func<int, int, bool> predicate;
				if ((predicate = @class.func_0) == null)
				{
					predicate = (@class.func_0 = new Func<int, int, bool>(@class.method_0));
				}
				if (!ireadOnlyList_1.Where(predicate).Any<int>())
				{
					return @class.int_0;
				}
			}
			int int_ = @class.int_0;
			@class.int_0 = int_ + 1;
		}
		return -1;
	}

	// Token: 0x0600014E RID: 334 RVA: 0x00002DE6 File Offset: 0x00000FE6
	static byte[] smethod_0(string string_0)
	{
		return File.ReadAllBytes(string_0);
	}

	// Token: 0x0600014F RID: 335 RVA: 0x00002DEE File Offset: 0x00000FEE
	static void smethod_1(Array array_0, int int_0, Array array_1, int int_1, int int_2)
	{
		Buffer.BlockCopy(array_0, int_0, array_1, int_1, int_2);
	}

	// Token: 0x06000150 RID: 336 RVA: 0x00002DFB File Offset: 0x00000FFB
	static void smethod_2(string string_0, byte[] byte_1)
	{
		File.WriteAllBytes(string_0, byte_1);
	}

	// Token: 0x040000AF RID: 175
	private byte[] byte_0;

	// Token: 0x02000026 RID: 38
	[CompilerGenerated]
	private sealed class Class11
	{
		// Token: 0x06000155 RID: 341 RVA: 0x00002E13 File Offset: 0x00001013
		internal bool method_0(int int_1, int int_2)
		{
			return this.ireadOnlyList_0[this.int_0 + int_2] != int_1 && int_1 != -1;
		}

		// Token: 0x040000B2 RID: 178
		public IReadOnlyList<int> ireadOnlyList_0;

		// Token: 0x040000B3 RID: 179
		public int int_0;

		// Token: 0x040000B4 RID: 180
		public Func<int, int, bool> func_0;
	}
}
