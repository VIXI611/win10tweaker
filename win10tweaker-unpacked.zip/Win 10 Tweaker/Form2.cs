﻿using System;
using System.Threading;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x0200004A RID: 74
internal partial class Form2 : Form1
{
	// Token: 0x17000006 RID: 6
	// (get) Token: 0x06000377 RID: 887 RVA: 0x000172FC File Offset: 0x000154FC
	public static Form2 Form2_0
	{
		get
		{
			if (Form2.form2_0 == null)
			{
				object obj = Form2.object_0;
				lock (obj)
				{
					if (Form2.form2_0 == null)
					{
						Form2.form2_0 = new Form2();
					}
				}
			}
			return Form2.form2_0;
		}
	}

	// Token: 0x06000378 RID: 888 RVA: 0x0001735C File Offset: 0x0001555C
	public void method_19()
	{
		RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Console\\%SystemRoot%_system32_cmd.exe");
		registryKey.SetValue("FaceName", "Lucida Console");
		registryKey.SetValue("FontFamily", 54);
		registryKey.SetValue("FontSize", 917512);
		registryKey.SetValue("FontWeight", 400);
		registryKey.SetValue("PopupColors", 240);
		registryKey.SetValue("ScreenBufferSize", 589889620);
		registryKey.SetValue("ScreenColors", 240);
		registryKey.SetValue("WindowAlpha", 236);
		registryKey.SetValue("WindowSize", 1572948);
		RegistryKey registryKey2 = Registry.CurrentUser.CreateSubKey("Console\\%SystemRoot%_System32_WindowsPowerShell_v1.0_powershell.exe");
		registryKey2.SetValue("PopupColors", 95);
		registryKey2.SetValue("ScreenBufferSize", 196608083);
		registryKey2.SetValue("ScreenColors", 95);
		registryKey2.SetValue("WindowSize", 1638483);
		registryKey2.SetValue("FontSize", 851976);
		registryKey2.SetValue("WindowAlpha", 235);
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\FlightedFeatures").SetValue("ImmersiveContextMenu", 0);
		}
	}

	// Token: 0x06000379 RID: 889 RVA: 0x000174F8 File Offset: 0x000156F8
	public void method_20()
	{
		try
		{
			Registry.CurrentUser.DeleteSubKeyTree("Console\\%SystemRoot%_system32_cmd.exe");
		}
		catch
		{
		}
		try
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Console\\%SystemRoot%_System32_WindowsPowerShell_v1.0_powershell.exe");
			registryKey.SetValue("PopupColors", 243);
			registryKey.SetValue("ScreenBufferSize", 196608120);
			registryKey.SetValue("ScreenColors", 86);
			registryKey.SetValue("WindowSize", 3276920);
		}
		catch
		{
		}
		try
		{
			RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("Console\\%SystemRoot%_System32_WindowsPowerShell_v1.0_powershell.exe", true);
			registryKey2.DeleteValue("FontSize");
			registryKey2.Close();
		}
		catch
		{
		}
		try
		{
			RegistryKey registryKey3 = Registry.CurrentUser.OpenSubKey("Console\\%SystemRoot%_System32_WindowsPowerShell_v1.0_powershell.exe", true);
			registryKey3.DeleteValue("WindowAlpha");
			registryKey3.Close();
		}
		catch
		{
		}
		try
		{
			RegistryKey registryKey4 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\FlightedFeatures", true);
			registryKey4.DeleteValue("ImmersiveContextMenu");
			registryKey4.Close();
		}
		catch
		{
		}
	}

	// Token: 0x0600037C RID: 892 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_303(object object_1, ref bool bool_1)
	{
		Monitor.Enter(object_1, ref bool_1);
	}

	// Token: 0x0600037D RID: 893 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_304(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x0600037E RID: 894 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_305(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x0600037F RID: 895 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_306(RegistryKey registryKey_0, string string_0, object object_1)
	{
		registryKey_0.SetValue(string_0, object_1);
	}

	// Token: 0x06000380 RID: 896 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_307(string string_0, string string_1)
	{
		return string_0.Contains(string_1);
	}

	// Token: 0x06000381 RID: 897 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_308(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x06000382 RID: 898 RVA: 0x00003021 File Offset: 0x00001221
	static void smethod_309(RegistryKey registryKey_0, string string_0)
	{
		registryKey_0.DeleteSubKeyTree(string_0);
	}

	// Token: 0x06000383 RID: 899 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_310(RegistryKey registryKey_0, string string_0, bool bool_1)
	{
		return registryKey_0.OpenSubKey(string_0, bool_1);
	}

	// Token: 0x06000384 RID: 900 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_311(RegistryKey registryKey_0, string string_0)
	{
		registryKey_0.DeleteValue(string_0);
	}

	// Token: 0x06000385 RID: 901 RVA: 0x00003884 File Offset: 0x00001A84
	static void smethod_312(RegistryKey registryKey_0)
	{
		registryKey_0.Close();
	}

	// Token: 0x06000386 RID: 902 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_313()
	{
		return new object();
	}

	// Token: 0x040001C1 RID: 449
	private static volatile Form2 form2_0;

	// Token: 0x040001C2 RID: 450
	private static readonly object object_0 = new object();
}
