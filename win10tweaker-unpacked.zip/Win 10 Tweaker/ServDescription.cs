﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.ServiceProcess;
using System.Windows.Forms;

// Token: 0x02000098 RID: 152
public partial class ServDescription : GForm0
{
	// Token: 0x0600078E RID: 1934 RVA: 0x000208E4 File Offset: 0x0001EAE4
	public ServDescription()
	{
		this.InitializeComponent();
		this.ServTooltip.Text = GClass2.GClass2_0.method_1(this.ServTooltip.Name);
		this.ServListLabel.MouseEnter += this.method_1;
		this.ServListLabel.MouseLeave += this.method_2;
		base.Deactivate += this.method_3;
	}

	// Token: 0x0600078F RID: 1935 RVA: 0x00020968 File Offset: 0x0001EB68
	private void ServDescription_Load(object sender, EventArgs e)
	{
		ServDescription.Struct41 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.servDescription_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<ServDescription.Struct41>(ref @struct);
	}

	// Token: 0x17000047 RID: 71
	// (get) Token: 0x06000790 RID: 1936 RVA: 0x000209A0 File Offset: 0x0001EBA0
	public Dictionary<string, Dictionary<string, string>> Dictionary_0
	{
		get
		{
			Dictionary<string, Dictionary<string, string>> dictionary = new Dictionary<string, Dictionary<string, string>>();
			dictionary["Serv1"] = this.Dictionary_1;
			dictionary["Serv2"] = this.Dictionary_2;
			dictionary["Serv3"] = this.Dictionary_3;
			dictionary["Serv4"] = this.Dictionary_4;
			dictionary["Serv5"] = this.Dictionary_5;
			dictionary["Serv6"] = this.Dictionary_6;
			dictionary["Serv7"] = this.Dictionary_7;
			dictionary["Serv8"] = this.Dictionary_8;
			dictionary["Serv9"] = this.Dictionary_9;
			dictionary["Serv10"] = this.Dictionary_10;
			dictionary["Serv11"] = this.Dictionary_11;
			dictionary["Serv12"] = this.Dictionary_12;
			dictionary["Serv13"] = this.Dictionary_13;
			dictionary["Serv14"] = this.Dictionary_14;
			dictionary["Serv15"] = this.Dictionary_15;
			dictionary["Serv16"] = this.Dictionary_16;
			dictionary["Serv17"] = this.Dictionary_17;
			dictionary["Serv18"] = this.Dictionary_18;
			dictionary["Serv19"] = this.Dictionary_19;
			dictionary["Serv20"] = this.Dictionary_20;
			dictionary["Serv21"] = this.Dictionary_21;
			dictionary["Serv22"] = this.Dictionary_22;
			dictionary["Serv23"] = this.Dictionary_23;
			dictionary["Serv24"] = this.Dictionary_24;
			dictionary["Serv25"] = this.Dictionary_25;
			dictionary["Serv26"] = this.Dictionary_26;
			dictionary["Serv27"] = this.Dictionary_27;
			dictionary["Serv28"] = this.Dictionary_28;
			dictionary["Serv29"] = this.Dictionary_29;
			dictionary["Serv30"] = this.Dictionary_30;
			dictionary["Serv31"] = this.Dictionary_31;
			dictionary["Serv32"] = this.Dictionary_32;
			return dictionary;
		}
	}

	// Token: 0x17000048 RID: 72
	// (get) Token: 0x06000791 RID: 1937 RVA: 0x00020BD4 File Offset: 0x0001EDD4
	public Dictionary<string, string> Dictionary_1
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["vmicvmsession"] = this.string_1 + "служба-hyper-v-powershell-direct";
			dictionary["vmictimesync"] = this.string_1 + "служба-синхронизации-времени-hyper-v";
			dictionary["vmicshutdown"] = this.string_1 + "служба-завершения-работы-hyper-v";
			dictionary["vmicrdv"] = this.string_1 + "служба-удаленных-рабочих-столов-hyper-v";
			dictionary["vmickvpexchange"] = this.string_1 + "служба-обмена-данными-hyper-v";
			dictionary["vmicheartbeat"] = this.string_1 + "служба-пульса-hyper-v";
			dictionary["vmicguestinterface"] = this.string_1 + "интерфейс-гостевой-службы-hyper-v";
			dictionary["HvHost"] = this.string_1 + "служба-узла-hv";
			dictionary["vmicvss"] = this.string_1 + "служба-запросов-hyper-v";
			return dictionary;
		}
	}

	// Token: 0x17000049 RID: 73
	// (get) Token: 0x06000792 RID: 1938 RVA: 0x00020CDC File Offset: 0x0001EEDC
	public Dictionary<string, string> Dictionary_2
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string key = "BcastDVRUserService_" + Class61.String_1;
			dictionary[key] = this.string_1 + "пользовательская-служба-dvr-bcastdvruserservice";
			return dictionary;
		}
	}

	// Token: 0x1700004A RID: 74
	// (get) Token: 0x06000793 RID: 1939 RVA: 0x00020D18 File Offset: 0x0001EF18
	public Dictionary<string, string> Dictionary_3
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["NcaSvc"] = this.string_1 + "помощник-по-подключению-к-сети";
			dictionary["SSDPSRV"] = this.string_1 + "обнаружение-ssdp";
			dictionary["wcncsvc"] = this.string_1 + "немедленные-подключения-windows-wcncsvc";
			return dictionary;
		}
	}

	// Token: 0x1700004B RID: 75
	// (get) Token: 0x06000794 RID: 1940 RVA: 0x00020D7C File Offset: 0x0001EF7C
	public Dictionary<string, string> Dictionary_4
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string key = "PimIndexMaintenanceSvc_" + Class61.String_1;
			dictionary[key] = this.string_1 + "служба-контактных-данных";
			string key2 = "UserDataSvc_" + Class61.String_1;
			dictionary[key2] = this.string_1 + "служба-доступа-к-данным-пользователя";
			string key3 = "UnistoreSvc_" + Class61.String_1;
			dictionary[key3] = this.string_1 + "служба-хранения-данных-пользователя";
			string key4 = "OneSyncSvc_" + Class61.String_1;
			dictionary[key4] = this.string_1 + "синхронизация-узла-onesyncsvc";
			dictionary["WalletService"] = this.string_1 + "служба-кошелька-walletservice";
			dictionary["VacSvc"] = this.string_1 + "служба-компоновщика-объемного-звука";
			dictionary["spectrum"] = this.string_1 + "служба-восприятия-windows";
			dictionary["SharedRealitySvc"] = this.string_1 + "служба-пространственных-данных";
			dictionary["perceptionsimulation"] = this.string_1 + "служба-имитации-восприятия-windows";
			dictionary["MixedRealityOpenXRSvc"] = this.string_1 + "windows-mixed-reality-openxr-service";
			dictionary["MapsBroker"] = this.string_1 + "диспетчер-скачанных-карт";
			dictionary["EntAppSvc"] = this.string_1 + "служба-управления-корпоративными-entappsvc";
			dictionary["embeddedmode"] = this.string_1 + "встроенный-режим";
			dictionary["wlidsvc"] = this.string_1 + "помощник-по-входу-в-учетную-запись";
			dictionary["WEPHOSTSVC"] = this.string_1 + "служба-узла-поставщика-шифрования-windows";
			dictionary["StorSvc"] = this.string_1 + "служба-хранилища";
			dictionary["LicenseManager"] = this.string_1 + "служба-windows-license-manager";
			dictionary["ClipSVC"] = this.string_1 + "служба-лицензий-клиента-clipsvc";
			dictionary["TokenBroker"] = this.string_1 + "диспетчер-учетных-веб-записей";
			dictionary["InstallService"] = this.string_1 + "служба-установки-microsoft-store";
			return dictionary;
		}
	}

	// Token: 0x1700004C RID: 76
	// (get) Token: 0x06000795 RID: 1941 RVA: 0x00020FDC File Offset: 0x0001F1DC
	public Dictionary<string, string> Dictionary_5
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string key = "CredentialEnrollmentManagerUserSvc_" + Class61.String_1;
			dictionary[key] = this.string_1 + "credentialenrollmentmanagerusersvc";
			return dictionary;
		}
	}

	// Token: 0x1700004D RID: 77
	// (get) Token: 0x06000796 RID: 1942 RVA: 0x00004BCF File Offset: 0x00002DCF
	public Dictionary<string, string> Dictionary_6
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["WbioSrvc"] = this.string_1 + "биометрическая-служба-windows";
			return dictionary;
		}
	}

	// Token: 0x1700004E RID: 78
	// (get) Token: 0x06000797 RID: 1943 RVA: 0x00021018 File Offset: 0x0001F218
	public Dictionary<string, string> Dictionary_7
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string key = "ConsentUxUserSvc_" + Class61.String_1;
			dictionary[key] = this.string_1 + "consentux";
			string key2 = "BluetoothUserService_" + Class61.String_1;
			dictionary[key2] = this.string_1 + "служба-поддержки-пользователей-bluetooth";
			dictionary["bthserv"] = this.string_1 + "служба-поддержки-bluetooth";
			dictionary["BthAvctpSvc"] = this.string_1 + "служба-avctp";
			dictionary["BTAGService"] = this.string_1 + "служба-звукового-шлюза-bluetooth";
			return dictionary;
		}
	}

	// Token: 0x1700004F RID: 79
	// (get) Token: 0x06000798 RID: 1944 RVA: 0x000210CC File Offset: 0x0001F2CC
	public Dictionary<string, string> Dictionary_8
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string key = "DeviceAssociationBrokerSvc_" + Class61.String_1;
			dictionary[key] = this.string_1 + "deviceassociationbroker";
			dictionary["XboxNetApiSvc"] = this.string_1 + "сетевая-служба-xbox-live";
			dictionary["XboxGipSvc"] = this.string_1 + "xbox-accessory-management-service";
			dictionary["XblGameSave"] = this.string_1 + "сохранение-игр-на-xbox-live";
			dictionary["XblAuthManager"] = this.string_1 + "диспетчер-проверки-подлинности-xbox-live";
			return dictionary;
		}
	}

	// Token: 0x17000050 RID: 80
	// (get) Token: 0x06000799 RID: 1945 RVA: 0x00021174 File Offset: 0x0001F374
	public Dictionary<string, string> Dictionary_9
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string key = "PrintWorkflowUserSvc_" + Class61.String_1;
			dictionary[key] = this.string_1 + "printworkflow";
			dictionary["Spooler"] = this.string_1 + "служба-диспетчер-печати-spooler";
			dictionary["PrintNotify"] = this.string_1 + "расширения-и-уведомления-printnotify";
			return dictionary;
		}
	}

	// Token: 0x17000051 RID: 81
	// (get) Token: 0x0600079A RID: 1946 RVA: 0x00004BF1 File Offset: 0x00002DF1
	public Dictionary<string, string> Dictionary_10
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["WiaRpc"] = this.string_1 + "события-неподвижных-изображений-wiarpc";
			dictionary["stisvc"] = this.string_1 + "служба-загрузки-изображений-windows-wia";
			return dictionary;
		}
	}

	// Token: 0x17000052 RID: 82
	// (get) Token: 0x0600079B RID: 1947 RVA: 0x000211E4 File Offset: 0x0001F3E4
	public Dictionary<string, string> Dictionary_11
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["TapiSrv"] = this.string_1 + "телефония";
			dictionary["PhoneSvc"] = this.string_1 + "телефонная-связь";
			dictionary["Fax"] = this.string_1 + "факс";
			return dictionary;
		}
	}

	// Token: 0x17000053 RID: 83
	// (get) Token: 0x0600079C RID: 1948 RVA: 0x00021248 File Offset: 0x0001F448
	public Dictionary<string, string> Dictionary_12
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["wisvc"] = this.string_1 + "служба-предварительной-оценки-windows";
			dictionary["DmEnrollmentSvc"] = this.string_1 + "служба-регистрации-управления-dmenrollmentsvc";
			dictionary["wuauserv"] = this.string_1 + "центр-обновления-windows";
			dictionary["WaaSMedicSvc"] = this.string_1 + "windows-update-medic-service";
			dictionary["DoSvc"] = this.string_1 + "оптимизация-доставки";
			dictionary["UsoSvc"] = this.string_1 + "обновить-службу-оркестратора-usosvc";
			return dictionary;
		}
	}

	// Token: 0x17000054 RID: 84
	// (get) Token: 0x0600079D RID: 1949 RVA: 0x000212FC File Offset: 0x0001F4FC
	public Dictionary<string, string> Dictionary_13
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["SensrSvc"] = this.string_1 + "служба-наблюдения-за-датчиками";
			dictionary["SensorService"] = this.string_1 + "служба-датчиков";
			dictionary["SensorDataService"] = this.string_1 + "служба-данных-датчиков";
			dictionary["SEMgrSvc"] = this.string_1 + "диспетчер-платежей-и-nfc";
			dictionary["lfsvc"] = this.string_1 + "служба-географического-положения";
			return dictionary;
		}
	}

	// Token: 0x17000055 RID: 85
	// (get) Token: 0x0600079E RID: 1950 RVA: 0x00004C2E File Offset: 0x00002E2E
	public Dictionary<string, string> Dictionary_14
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["DispBrokerDesktopSvc"] = this.string_1 + "служба-политики-отображения";
			return dictionary;
		}
	}

	// Token: 0x17000056 RID: 86
	// (get) Token: 0x0600079F RID: 1951 RVA: 0x00021398 File Offset: 0x0001F598
	public Dictionary<string, string> Dictionary_15
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["CDPSvc"] = this.string_1 + "служба-cdpsvc-cdpusersvc";
			string key = "CDPUserSvc_" + Class61.String_1;
			dictionary[key] = this.string_1 + "служба-пользователя-платформы-cdpsvc-cdpusersvc";
			string key2 = "MessagingService_" + Class61.String_1;
			dictionary[key2] = this.string_1 + "messagingservice";
			dictionary["PushToInstall"] = this.string_1 + "служба-pushtoinstall-windows";
			dictionary["WpnService"] = this.string_1 + "служба-системы-push-уведомлений-windows";
			return dictionary;
		}
	}

	// Token: 0x17000057 RID: 87
	// (get) Token: 0x060007A0 RID: 1952 RVA: 0x00004C50 File Offset: 0x00002E50
	public Dictionary<string, string> Dictionary_16
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["Themes"] = this.string_1 + "темы";
			return dictionary;
		}
	}

	// Token: 0x17000058 RID: 88
	// (get) Token: 0x060007A1 RID: 1953 RVA: 0x0002144C File Offset: 0x0001F64C
	public Dictionary<string, string> Dictionary_17
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["WwanSvc"] = this.string_1 + "автонастройка-wwan";
			dictionary["wlpasvc"] = this.string_1 + "служба-помощника-wlpasvc";
			dictionary["icssvc"] = this.string_1 + "служба-windows-mobile-hotspot";
			dictionary["DusmSvc"] = this.string_1 + "использование-данных";
			dictionary["autotimesvc"] = this.string_1 + "время-в-сети-мобильной-связи";
			return dictionary;
		}
	}

	// Token: 0x17000059 RID: 89
	// (get) Token: 0x060007A2 RID: 1954 RVA: 0x000214E8 File Offset: 0x0001F6E8
	public Dictionary<string, string> Dictionary_18
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["Netlogon"] = this.string_1 + "сетевой-вход-в-систему";
			dictionary["CscService"] = this.string_1 + "автономные-файлы";
			dictionary["lmhosts"] = this.string_1 + "модуль-поддержки-netbios-через-tcp-ip";
			dictionary["FDResPub"] = this.string_1 + "публикация-ресурсов-обнаружения-fdrespub";
			dictionary["fdPHost"] = this.string_1 + "хост-поставщика-функции-обнаружения";
			dictionary["LanmanServer"] = this.string_1 + "сервер";
			dictionary["LanmanWorkstation"] = this.string_1 + "рабочая-станция";
			return dictionary;
		}
	}

	// Token: 0x1700005A RID: 90
	// (get) Token: 0x060007A3 RID: 1955 RVA: 0x000215B8 File Offset: 0x0001F7B8
	public Dictionary<string, string> Dictionary_19
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["PolicyAgent"] = this.string_1 + "агент-политики-ipsec";
			dictionary["IKEEXT"] = this.string_1 + "модули-ключей-ipsec";
			dictionary["p2pimsvc"] = this.string_1 + "диспетчер-удостоверения-участников";
			dictionary["Eaphost"] = this.string_1 + "расширяемый-протокол-проверки-eap";
			return dictionary;
		}
	}

	// Token: 0x1700005B RID: 91
	// (get) Token: 0x060007A4 RID: 1956 RVA: 0x00004C72 File Offset: 0x00002E72
	public Dictionary<string, string> Dictionary_20
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["WPDBusEnum"] = this.string_1 + "служба-перечислителя-wpdbusenum";
			dictionary["WMPNetworkSvc"] = this.string_1 + "служба-сетевых-ресурсов-windows-media";
			return dictionary;
		}
	}

	// Token: 0x1700005C RID: 92
	// (get) Token: 0x060007A5 RID: 1957 RVA: 0x00021638 File Offset: 0x0001F838
	public Dictionary<string, string> Dictionary_21
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["UmRdpService"] = this.string_1 + "перенаправитель-портов-umrdpservice";
			dictionary["TermService"] = this.string_1 + "службы-удаленных-рабочих-столов";
			dictionary["DsSvc"] = this.string_1 + "служба-совместного-доступа-к-данным";
			dictionary["RemoteRegistry"] = this.string_1 + "удаленный-реестр";
			return dictionary;
		}
	}

	// Token: 0x1700005D RID: 93
	// (get) Token: 0x060007A6 RID: 1958 RVA: 0x000216B8 File Offset: 0x0001F8B8
	public Dictionary<string, string> Dictionary_22
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["WerSvc"] = this.string_1 + "служба-регистрации-ошибок-windows";
			dictionary["wercplsupport"] = this.string_1 + "поддержка-элемента-панели-wercplsupport";
			dictionary["Wecsvc"] = this.string_1 + "сборщик-событий-windows";
			return dictionary;
		}
	}

	// Token: 0x1700005E RID: 94
	// (get) Token: 0x060007A7 RID: 1959 RVA: 0x00004CAF File Offset: 0x00002EAF
	public Dictionary<string, string> Dictionary_23
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["WebClient"] = this.string_1 + "веб-клиент";
			return dictionary;
		}
	}

	// Token: 0x1700005F RID: 95
	// (get) Token: 0x060007A8 RID: 1960 RVA: 0x0002171C File Offset: 0x0001F91C
	public Dictionary<string, string> Dictionary_24
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["SCPolicySvc"] = this.string_1 + "политика-удаления-смарт-карт";
			dictionary["ScDeviceEnum"] = this.string_1 + "служба-перечисления-смарт-карт";
			dictionary["SCardSvr"] = this.string_1 + "смарт-карта";
			dictionary["CertPropSvc"] = this.string_1 + "распространение-сертификата";
			return dictionary;
		}
	}

	// Token: 0x17000060 RID: 96
	// (get) Token: 0x060007A9 RID: 1961 RVA: 0x00004CD1 File Offset: 0x00002ED1
	public Dictionary<string, string> Dictionary_25
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["AssignedAccessManagerSvc"] = this.string_1 + "служба-assignedaccessmanager";
			dictionary["AppReadiness"] = this.string_1 + "готовность-приложений";
			return dictionary;
		}
	}

	// Token: 0x17000061 RID: 97
	// (get) Token: 0x060007AA RID: 1962 RVA: 0x0002179C File Offset: 0x0001F99C
	public Dictionary<string, string> Dictionary_26
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["WSearch"] = this.string_1 + "windows-search";
			dictionary["fhsvc"] = this.string_1 + "служба-истории-файлов";
			dictionary["WMPNetworkSvc"] = this.string_1 + "служба-сетевых-ресурсов-windows-media";
			dictionary["workfolderssvc"] = this.string_1 + "рабочие-папки";
			return dictionary;
		}
	}

	// Token: 0x17000062 RID: 98
	// (get) Token: 0x060007AB RID: 1963 RVA: 0x00004D0E File Offset: 0x00002F0E
	public Dictionary<string, string> Dictionary_27
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["EFS"] = this.string_1 + "EFS";
			dictionary["BDESVC"] = this.string_1 + "служба-шифрования-дисков-bitlocker";
			return dictionary;
		}
	}

	// Token: 0x17000063 RID: 99
	// (get) Token: 0x060007AC RID: 1964 RVA: 0x00004D4B File Offset: 0x00002F4B
	public Dictionary<string, string> Dictionary_28
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["LxpSvc"] = this.string_1 + "служба-language-experience-service";
			return dictionary;
		}
	}

	// Token: 0x17000064 RID: 100
	// (get) Token: 0x060007AD RID: 1965 RVA: 0x00004D6D File Offset: 0x00002F6D
	public Dictionary<string, string> Dictionary_29
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["WarpJITSvc"] = this.string_1 + "warpjitsvc";
			dictionary["wscsvc"] = this.string_1 + "центр-обеспечения-безопасности";
			return dictionary;
		}
	}

	// Token: 0x17000065 RID: 101
	// (get) Token: 0x060007AE RID: 1966 RVA: 0x0002181C File Offset: 0x0001FA1C
	public Dictionary<string, string> Dictionary_30
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["wmiApSrv"] = this.string_1 + "адаптер-производительности-wmi";
			dictionary["pla"] = this.string_1 + "журналы-производительности";
			dictionary["PerfHost"] = this.string_1 + "хост-библиотеки-счетчика-perfhost";
			return dictionary;
		}
	}

	// Token: 0x17000066 RID: 102
	// (get) Token: 0x060007AF RID: 1967 RVA: 0x00021880 File Offset: 0x0001FA80
	public Dictionary<string, string> Dictionary_31
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["WdiSystemHost"] = this.string_1 + "узел-системы-диагностики";
			dictionary["WdiServiceHost"] = this.string_1 + "узел-службы-диагностики";
			dictionary["TroubleshootingSvc"] = this.string_1 + "служба-устранения-неполадок-troubleshootingsvc";
			dictionary["DPS"] = this.string_1 + "служба-политики-диагностики";
			dictionary["diagnosticshub.standardcollector.service"] = this.string_1 + "служба-сборщика-diagnosticshub-standardcollector-service";
			return dictionary;
		}
	}

	// Token: 0x17000067 RID: 103
	// (get) Token: 0x060007B0 RID: 1968 RVA: 0x0002191C File Offset: 0x0001FB1C
	public Dictionary<string, string> Dictionary_32
	{
		get
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["workfolderssvc"] = this.string_1 + "рабочие-папки";
			dictionary["SNMPTRAP"] = this.string_1 + "ловушка-snmp";
			dictionary["SessionEnv"] = this.string_1 + "настройка-сервера-удаленных-рабочих";
			dictionary["RemoteRegistry"] = this.string_1 + "удаленный-реестр";
			dictionary["Netlogon"] = this.string_1 + "сетевой-вход-в-систему";
			dictionary["EntAppSvc"] = this.string_1 + "служба-управления-корпоративными-entappsvc";
			dictionary["dot3svc"] = this.string_1 + "проводная-автонастройка";
			dictionary["DevQueryBroker"] = this.string_1 + "брокер-фонового-обнаружения-devquery";
			dictionary["AppMgmt"] = this.string_1 + "управление-приложениями";
			return dictionary;
		}
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x00004DAA File Offset: 0x00002FAA
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x00004DC9 File Offset: 0x00002FC9
	[CompilerGenerated]
	private void method_1(object sender, EventArgs e)
	{
		this.ServListLabel.LinkBehavior = LinkBehavior.HoverUnderline;
	}

	// Token: 0x060007B4 RID: 1972 RVA: 0x00004DD7 File Offset: 0x00002FD7
	[CompilerGenerated]
	private void method_2(object sender, EventArgs e)
	{
		this.ServListLabel.LinkBehavior = LinkBehavior.NeverUnderline;
	}

	// Token: 0x060007B5 RID: 1973 RVA: 0x00004DE5 File Offset: 0x00002FE5
	[CompilerGenerated]
	private void method_3(object sender, EventArgs e)
	{
		base.TopMost = false;
	}

	// Token: 0x060007B6 RID: 1974 RVA: 0x00002C23 File Offset: 0x00000E23
	static string smethod_3(Control control_0)
	{
		return control_0.Name;
	}

	// Token: 0x060007B7 RID: 1975 RVA: 0x00002920 File Offset: 0x00000B20
	static void smethod_4(Control control_0, string string_2)
	{
		control_0.Text = string_2;
	}

	// Token: 0x060007B8 RID: 1976 RVA: 0x00002962 File Offset: 0x00000B62
	static void smethod_5(Control control_0, EventHandler eventHandler_0)
	{
		control_0.MouseEnter += eventHandler_0;
	}

	// Token: 0x060007B9 RID: 1977 RVA: 0x0000296B File Offset: 0x00000B6B
	static void smethod_6(Control control_0, EventHandler eventHandler_0)
	{
		control_0.MouseLeave += eventHandler_0;
	}

	// Token: 0x060007BA RID: 1978 RVA: 0x00004DEE File Offset: 0x00002FEE
	static void smethod_7(Form form_0, EventHandler eventHandler_0)
	{
		form_0.Deactivate += eventHandler_0;
	}

	// Token: 0x060007BB RID: 1979 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_8(string string_2, string string_3)
	{
		return string_2 + string_3;
	}

	// Token: 0x060007BC RID: 1980 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_9(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x060007BD RID: 1981 RVA: 0x00002A70 File Offset: 0x00000C70
	static LinkLabel smethod_10()
	{
		return new LinkLabel();
	}

	// Token: 0x060007BE RID: 1982 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_11()
	{
		return new Label();
	}

	// Token: 0x060007BF RID: 1983 RVA: 0x00002A8D File Offset: 0x00000C8D
	static void smethod_12(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060007C0 RID: 1984 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_13(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060007C1 RID: 1985 RVA: 0x00004DF7 File Offset: 0x00002FF7
	static void smethod_14(LinkLabel linkLabel_0, Color color_0)
	{
		linkLabel_0.ActiveLinkColor = color_0;
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x00004E00 File Offset: 0x00003000
	static void smethod_15(Label label_0, bool bool_1)
	{
		label_0.AutoEllipsis = bool_1;
	}

	// Token: 0x060007C3 RID: 1987 RVA: 0x00002A9D File Offset: 0x00000C9D
	static void smethod_16(Control control_0, bool bool_1)
	{
		control_0.AutoSize = bool_1;
	}

	// Token: 0x060007C4 RID: 1988 RVA: 0x00002B7F File Offset: 0x00000D7F
	static void smethod_17(Control control_0, Color color_0)
	{
		control_0.ForeColor = color_0;
	}

	// Token: 0x060007C5 RID: 1989 RVA: 0x00002B9E File Offset: 0x00000D9E
	static void smethod_18(LinkLabel linkLabel_0, LinkBehavior linkBehavior_0)
	{
		linkLabel_0.LinkBehavior = linkBehavior_0;
	}

	// Token: 0x060007C6 RID: 1990 RVA: 0x00004E09 File Offset: 0x00003009
	static void smethod_19(LinkLabel linkLabel_0, Color color_0)
	{
		linkLabel_0.LinkColor = color_0;
	}

	// Token: 0x060007C7 RID: 1991 RVA: 0x00004E12 File Offset: 0x00003012
	static void smethod_20(Form form_0, bool bool_1)
	{
		form_0.TopMost = bool_1;
	}

	// Token: 0x040002D3 RID: 723
	public string string_0;

	// Token: 0x040002D4 RID: 724
	public int int_0;

	// Token: 0x040002D5 RID: 725
	public int int_1;

	// Token: 0x040002D6 RID: 726
	private readonly string string_1 = "https://win10tweaker.pro/twikinarium/services/";

	// Token: 0x040002D7 RID: 727
	private IContainer icontainer_0;

	// Token: 0x02000099 RID: 153
	[CompilerGenerated]
	private sealed class Class59
	{
		// Token: 0x060007C9 RID: 1993 RVA: 0x00004E1B File Offset: 0x0000301B
		internal bool method_0(KeyValuePair<string, Dictionary<string, string>> keyValuePair_0)
		{
			return keyValuePair_0.Key == this.servDescription_0.string_0;
		}

		// Token: 0x060007CA RID: 1994 RVA: 0x00004E34 File Offset: 0x00003034
		internal void method_1(KeyValuePair<string, Dictionary<string, string>> keyValuePair_0)
		{
			this.dictionary_0 = keyValuePair_0.Value;
		}

		// Token: 0x060007CB RID: 1995 RVA: 0x00021D70 File Offset: 0x0001FF70
		internal void method_2(KeyValuePair<string, string> keyValuePair_0)
		{
			ServDescription.Class60 @class = new ServDescription.Class60();
			@class.class59_0 = this;
			@class.keyValuePair_0 = keyValuePair_0;
			ServiceController.GetServices().Where(new Func<ServiceController, bool>(@class.method_0)).ToList<ServiceController>().ForEach(new Action<ServiceController>(@class.method_1));
		}

		// Token: 0x060007CC RID: 1996 RVA: 0x00002B59 File Offset: 0x00000D59
		static bool smethod_0(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060007CD RID: 1997 RVA: 0x00004E43 File Offset: 0x00003043
		static ServiceController[] smethod_1()
		{
			return ServiceController.GetServices();
		}

		// Token: 0x040002DB RID: 731
		public ServDescription servDescription_0;

		// Token: 0x040002DC RID: 732
		public Dictionary<string, string> dictionary_0;
	}

	// Token: 0x0200009A RID: 154
	[CompilerGenerated]
	private sealed class Class60
	{
		// Token: 0x060007CF RID: 1999 RVA: 0x00004E4A File Offset: 0x0000304A
		internal bool method_0(ServiceController serviceController_0)
		{
			return this.keyValuePair_0.Key == serviceController_0.ServiceName;
		}

		// Token: 0x060007D0 RID: 2000 RVA: 0x00021DC0 File Offset: 0x0001FFC0
		internal void method_1(ServiceController serviceController_0)
		{
			string text = serviceController_0.DisplayName.Replace("_" + Class61.String_1, "");
			LinkLabel servListLabel = this.class59_0.servDescription_0.ServListLabel;
			servListLabel.Text = servListLabel.Text + text + Environment.NewLine;
			this.class59_0.servDescription_0.ServListLabel.Links.Add(this.class59_0.servDescription_0.ServListLabel.Text.IndexOf(text + Environment.NewLine), text.Length, this.keyValuePair_0.Value);
		}

		// Token: 0x060007D1 RID: 2001 RVA: 0x00004E62 File Offset: 0x00003062
		static string smethod_0(ServiceController serviceController_0)
		{
			return serviceController_0.ServiceName;
		}

		// Token: 0x060007D2 RID: 2002 RVA: 0x00002B59 File Offset: 0x00000D59
		static bool smethod_1(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060007D3 RID: 2003 RVA: 0x00004E6A File Offset: 0x0000306A
		static string smethod_2(ServiceController serviceController_0)
		{
			return serviceController_0.DisplayName;
		}

		// Token: 0x060007D4 RID: 2004 RVA: 0x000025E0 File Offset: 0x000007E0
		static string smethod_3(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x000033D1 File Offset: 0x000015D1
		static string smethod_4(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x060007D6 RID: 2006 RVA: 0x00002A18 File Offset: 0x00000C18
		static string smethod_5(Control control_0)
		{
			return control_0.Text;
		}

		// Token: 0x060007D7 RID: 2007 RVA: 0x00003E79 File Offset: 0x00002079
		static string smethod_6()
		{
			return Environment.NewLine;
		}

		// Token: 0x060007D8 RID: 2008 RVA: 0x00003033 File Offset: 0x00001233
		static string smethod_7(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x060007D9 RID: 2009 RVA: 0x00002920 File Offset: 0x00000B20
		static void smethod_8(Control control_0, string string_0)
		{
			control_0.Text = string_0;
		}

		// Token: 0x060007DA RID: 2010 RVA: 0x00004E72 File Offset: 0x00003072
		static LinkLabel.LinkCollection smethod_9(LinkLabel linkLabel_0)
		{
			return linkLabel_0.Links;
		}

		// Token: 0x060007DB RID: 2011 RVA: 0x00002A32 File Offset: 0x00000C32
		static int smethod_10(string string_0, string string_1)
		{
			return string_0.IndexOf(string_1);
		}

		// Token: 0x060007DC RID: 2012 RVA: 0x00002A44 File Offset: 0x00000C44
		static int smethod_11(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060007DD RID: 2013 RVA: 0x00004E7A File Offset: 0x0000307A
		static LinkLabel.Link smethod_12(LinkLabel.LinkCollection linkCollection_0, int int_0, int int_1, object object_0)
		{
			return linkCollection_0.Add(int_0, int_1, object_0);
		}

		// Token: 0x040002DD RID: 733
		public KeyValuePair<string, string> keyValuePair_0;

		// Token: 0x040002DE RID: 734
		public ServDescription.Class59 class59_0;
	}
}
