﻿using System;
using System.Threading;

// Token: 0x0200007B RID: 123
internal class Class39
{
	// Token: 0x1700002E RID: 46
	// (get) Token: 0x060005F7 RID: 1527 RVA: 0x0001C6F0 File Offset: 0x0001A8F0
	public static Class39 Class39_0
	{
		get
		{
			if (Class39.class39_0 == null)
			{
				object obj = Class39.object_0;
				lock (obj)
				{
					if (Class39.class39_0 == null)
					{
						Class39.class39_0 = new Class39();
					}
				}
			}
			return Class39.class39_0;
		}
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x00004405 File Offset: 0x00002605
	public void method_0()
	{
		GClass6.GClass6_0.method_14("netsh interface teredo set state disabled &netsh interface isatap set state disabled &netsh int ipv6 isatap set state disabled &netsh int ipv6 6to4 set state disabled &netsh interface IPV6 set global randomizeidentifier=disabled &netsh interface IPV6 set privacy state=disabled");
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x00004416 File Offset: 0x00002616
	public void method_1()
	{
		GClass6.GClass6_0.method_14("netsh interface teredo set state default &netsh interface isatap set state default &netsh int ipv6 isatap set state default &netsh int ipv6 6to4 set state default &netsh interface IPV6 set global randomizeidentifier=enabled &netsh interface IPV6 set privacy state=enabled");
	}

	// Token: 0x060005FC RID: 1532 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_2()
	{
		return new object();
	}

	// Token: 0x0400027C RID: 636
	private static volatile Class39 class39_0;

	// Token: 0x0400027D RID: 637
	private static readonly object object_0 = new object();
}
