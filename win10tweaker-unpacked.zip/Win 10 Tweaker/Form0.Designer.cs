﻿// Token: 0x0200003B RID: 59
internal partial class Form0 : global::Win_10_Tweaker.Form1
{
}
