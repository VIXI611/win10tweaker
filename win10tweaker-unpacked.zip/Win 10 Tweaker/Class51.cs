﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.Win32;

// Token: 0x0200008C RID: 140
internal class Class51
{
	// Token: 0x17000039 RID: 57
	// (get) Token: 0x06000701 RID: 1793 RVA: 0x0001F3BC File Offset: 0x0001D5BC
	public static Class51 Class51_0
	{
		get
		{
			if (Class51.class51_0 == null)
			{
				object obj = Class51.object_0;
				lock (obj)
				{
					if (Class51.class51_0 == null)
					{
						Class51.class51_0 = new Class51();
					}
				}
			}
			return Class51.class51_0;
		}
	}

	// Token: 0x06000702 RID: 1794 RVA: 0x0001F41C File Offset: 0x0001D61C
	public void method_0()
	{
		Class51.Class52 @class = new Class51.Class52();
		@class.registryKey_0 = Registry.ClassesRoot.CreateSubKey("Applications\\photoviewer.dll\\shell\\open");
		@class.registryKey_0.SetValue("MuiVerb", "@photoviewer.dll,-3043");
		@class.registryKey_0.CreateSubKey("command").SetValue("", "%SystemRoot%\\System32\\rundll32.exe \"%ProgramFiles%\\Windows Photo Viewer\\PhotoViewer.dll\", ImageView_Fullscreen %1", RegistryValueKind.ExpandString);
		@class.registryKey_0 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows Photo Viewer\\Capabilities\\FileAssociations");
		new List<string>
		{
			".bmp",
			".gif",
			".jpeg",
			".jpg",
			".png"
		}.ForEach(new Action<string>(@class.method_0));
	}

	// Token: 0x06000705 RID: 1797 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000706 RID: 1798 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000707 RID: 1799 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x06000708 RID: 1800 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_3(RegistryKey registryKey_0, string string_0, object object_1)
	{
		registryKey_0.SetValue(string_0, object_1);
	}

	// Token: 0x06000709 RID: 1801 RVA: 0x00002EED File Offset: 0x000010ED
	static void smethod_4(RegistryKey registryKey_0, string string_0, object object_1, RegistryValueKind registryValueKind_0)
	{
		registryKey_0.SetValue(string_0, object_1, registryValueKind_0);
	}

	// Token: 0x0600070A RID: 1802 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_5()
	{
		return new object();
	}

	// Token: 0x040002AD RID: 685
	private static volatile Class51 class51_0;

	// Token: 0x040002AE RID: 686
	private static readonly object object_0 = new object();

	// Token: 0x0200008D RID: 141
	[CompilerGenerated]
	private sealed class Class52
	{
		// Token: 0x0600070C RID: 1804 RVA: 0x00004939 File Offset: 0x00002B39
		internal void method_0(string string_0)
		{
			this.registryKey_0.SetValue(string_0, "PhotoViewer.FileAssoc.Tiff");
		}

		// Token: 0x0600070D RID: 1805 RVA: 0x00002C41 File Offset: 0x00000E41
		static void smethod_0(RegistryKey registryKey_1, string string_0, object object_0)
		{
			registryKey_1.SetValue(string_0, object_0);
		}

		// Token: 0x040002AF RID: 687
		public RegistryKey registryKey_0;
	}
}
