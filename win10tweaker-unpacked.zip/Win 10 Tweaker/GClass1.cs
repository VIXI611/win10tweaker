﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x02000038 RID: 56
[DesignerCategory("Code")]
public class GClass1 : Panel
{
	// Token: 0x06000225 RID: 549 RVA: 0x00012344 File Offset: 0x00010544
	protected virtual void OnPaint(PaintEventArgs e)
	{
		using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
		{
			e.Graphics.FillRectangle(solidBrush, base.ClientRectangle);
		}
		e.Graphics.DrawRectangle(new Pen(this.color_0), 0, 0, base.ClientSize.Width - 1, base.ClientSize.Height - 1);
		base.Controls.Add(this.label_0);
		base.Controls.Add(this.button_0);
		base.Controls.Add(this.button_1);
		this.button_0.Location = new Point(base.Width - this.button_0.Width, this.button_0.Location.Y);
		this.button_1.Location = new Point(base.Width - this.button_1.Width, this.button_0.Height);
		this.label_0.MaximumSize = new Size(base.Width - this.button_0.Width - SystemInformation.VerticalScrollBarWidth - 5, 0);
	}

	// Token: 0x06000226 RID: 550 RVA: 0x00012484 File Offset: 0x00010684
	public GClass1(string string_0, Action action_2, Action action_3, Color color_3, bool bool_0, bool bool_1, int int_0, int int_1)
	{
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, true);
		this.BackColor = (bool_0 ? Color.FromArgb(18, 44, 67) : Color.FromArgb(9, 40, 59));
		this.label_0.Text = string_0;
		this.action_0 = action_2;
		this.action_1 = action_3;
		this.color_0 = color_3;
		this.button_0.Enabled = bool_0;
		this.button_1.Enabled = bool_1;
		this.label_0.AutoSize = true;
		this.label_0.ForeColor = color_3;
		this.label_0.Location = new Point(8, 8);
		this.button_0.FlatAppearance.BorderSize = 0;
		this.button_0.FlatStyle = FlatStyle.Flat;
		this.button_0.Size = new Size(int_0, int_1);
		this.button_0.BackColor = (bool_0 ? this.color_1 : Color.FromArgb(72, 147, 147));
		this.button_0.Text = (bool_0 ? GClass2.GClass2_0.method_1("Apply") : GClass2.GClass2_0.method_1("PersonalApplied"));
		this.button_1.FlatAppearance.BorderSize = 0;
		this.button_1.FlatStyle = FlatStyle.Flat;
		this.button_1.Size = new Size(int_0, int_1);
		this.button_1.BackColor = (bool_1 ? this.color_2 : Color.FromArgb(88, 129, 162));
		this.button_1.Text = GClass2.GClass2_0.method_1("PersonalRestore");
		this.button_0.Click += this.button_0_Click;
		this.button_1.Click += this.button_1_Click;
	}

	// Token: 0x06000227 RID: 551 RVA: 0x000126A8 File Offset: 0x000108A8
	private void button_0_Click(object sender, EventArgs e)
	{
		GClass1.Struct26 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.gclass1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<GClass1.Struct26>(ref @struct);
	}

	// Token: 0x06000228 RID: 552 RVA: 0x000126E0 File Offset: 0x000108E0
	private void button_1_Click(object sender, EventArgs e)
	{
		this.action_1();
		this.color_0 = this.color_1;
		this.label_0.ForeColor = this.color_1;
		this.button_0.BackColor = this.color_1;
		this.BackColor = Color.FromArgb(18, 44, 67);
		this.button_1.BackColor = Color.FromArgb(88, 129, 162);
		this.button_0.Text = GClass2.GClass2_0.method_1("Apply");
		base.Invalidate();
		this.button_0.Enabled = true;
		this.button_1.Enabled = false;
	}

	// Token: 0x06000229 RID: 553 RVA: 0x000032E3 File Offset: 0x000014E3
	static Color smethod_0(Control control_0)
	{
		return control_0.BackColor;
	}

	// Token: 0x0600022A RID: 554 RVA: 0x0000329B File Offset: 0x0000149B
	static SolidBrush smethod_1(Color color_3)
	{
		return new SolidBrush(color_3);
	}

	// Token: 0x0600022B RID: 555 RVA: 0x00002B88 File Offset: 0x00000D88
	static Graphics smethod_2(PaintEventArgs paintEventArgs_0)
	{
		return paintEventArgs_0.Graphics;
	}

	// Token: 0x0600022C RID: 556 RVA: 0x000032EB File Offset: 0x000014EB
	static Rectangle smethod_3(Control control_0)
	{
		return control_0.ClientRectangle;
	}

	// Token: 0x0600022D RID: 557 RVA: 0x00002C0B File Offset: 0x00000E0B
	static void smethod_4(Graphics graphics_0, Brush brush_0, Rectangle rectangle_0)
	{
		graphics_0.FillRectangle(brush_0, rectangle_0);
	}

	// Token: 0x0600022E RID: 558 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_5(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x0600022F RID: 559 RVA: 0x000032F3 File Offset: 0x000014F3
	static Pen smethod_6(Color color_3)
	{
		return new Pen(color_3);
	}

	// Token: 0x06000230 RID: 560 RVA: 0x000032FB File Offset: 0x000014FB
	static Size smethod_7(Control control_0)
	{
		return control_0.ClientSize;
	}

	// Token: 0x06000231 RID: 561 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_8()
	{
		return new Label();
	}

	// Token: 0x06000232 RID: 562 RVA: 0x00002A69 File Offset: 0x00000C69
	static Button smethod_9()
	{
		return new Button();
	}

	// Token: 0x06000233 RID: 563 RVA: 0x00002BA7 File Offset: 0x00000DA7
	static void smethod_10(Control control_0, Color color_3)
	{
		control_0.BackColor = color_3;
	}

	// Token: 0x06000234 RID: 564 RVA: 0x00002920 File Offset: 0x00000B20
	static void smethod_11(Control control_0, string string_0)
	{
		control_0.Text = string_0;
	}

	// Token: 0x06000235 RID: 565 RVA: 0x00002C67 File Offset: 0x00000E67
	static void smethod_12(Control control_0, bool bool_0)
	{
		control_0.Enabled = bool_0;
	}

	// Token: 0x06000236 RID: 566 RVA: 0x00002A9D File Offset: 0x00000C9D
	static void smethod_13(Control control_0, bool bool_0)
	{
		control_0.AutoSize = bool_0;
	}

	// Token: 0x06000237 RID: 567 RVA: 0x00002B7F File Offset: 0x00000D7F
	static void smethod_14(Control control_0, Color color_3)
	{
		control_0.ForeColor = color_3;
	}

	// Token: 0x06000238 RID: 568 RVA: 0x000032C9 File Offset: 0x000014C9
	static void smethod_15(Control control_0)
	{
		control_0.Invalidate();
	}

	// Token: 0x040000F9 RID: 249
	private readonly Label label_0 = new Label();

	// Token: 0x040000FA RID: 250
	private readonly Action action_0;

	// Token: 0x040000FB RID: 251
	private readonly Action action_1;

	// Token: 0x040000FC RID: 252
	private Color color_0;

	// Token: 0x040000FD RID: 253
	private readonly Color color_1 = Color.FromArgb(129, 193, 247);

	// Token: 0x040000FE RID: 254
	private readonly Color color_2 = Color.FromArgb(104, 193, 203);

	// Token: 0x040000FF RID: 255
	private readonly Button button_0 = new Button();

	// Token: 0x04000100 RID: 256
	private readonly Button button_1 = new Button();
}
