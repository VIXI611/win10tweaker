﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Deps;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Management;
using System.Management.Automation;
using System.Net;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ArpanTECH;
using Microsoft.CSharp.RuntimeBinder;
using Microsoft.VisualBasic.Devices;
using Microsoft.Win32;

namespace Win_10_Tweaker
{
	// Token: 0x020000F1 RID: 241
	public partial class Form1 : GForm0
	{
		// Token: 0x06000C29 RID: 3113 RVA: 0x0003AF74 File Offset: 0x00039174
		public Form1()
		{
			this.InitializeComponent();
			this.servLabels = this.MainPanelServ1.Controls.OfType<Label>().ToList<Label>().Union(this.MainPanelServ2.Controls.OfType<Label>()).ToList<Label>();
			this.CloseCleaner.Click += delegate(object sender, EventArgs e)
			{
				this.CleanerMainPanel.Visible = false;
			};
			this.CloseRecommendations.Click += delegate(object sender, EventArgs e)
			{
				this.PersonalPanel.Visible = false;
				new Settings_1(this).method_7();
			};
			this.Table.Sorted += delegate(object sender, EventArgs e)
			{
				this.TableOrderByNum();
			};
			new List<Control>
			{
				this.ApplyButton,
				this.HeaderPanel,
				this.PersonalPanelHeaderLabel,
				this.PersonalPanelHeaderPanel
			}.ForEach(delegate(Control panel)
			{
				panel.MouseDown += delegate(object sender, MouseEventArgs e)
				{
					this.ServClose();
					panel.Capture = false;
					this.Capture = false;
					Message message = Message.Create(this.method_0(), 161, new IntPtr(2), IntPtr.Zero);
					this.<>n__0(ref message);
				};
			});
			Panel[] array = new Panel[]
			{
				this.MainPanel1,
				this.MainPanel2,
				this.MainPanel3,
				this.MainPanel4
			};
			for (int i = 0; i < array.Length; i++)
			{
				using (IEnumerator<Button> enumerator = array[i].Controls.OfType<Button>().GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Button restore = enumerator.Current;
						if (restore.Name.Contains("Restore"))
						{
							restore.BackgroundImageLayout = ImageLayout.Stretch;
							restore.BackgroundImage = Class89.Bitmap_49;
							restore.FlatAppearance.BorderSize = 0;
							restore.FlatStyle = FlatStyle.Flat;
							restore.FlatAppearance.MouseDownBackColor = Color.Transparent;
							restore.FlatAppearance.MouseOverBackColor = Color.Transparent;
							restore.FlatAppearance.MouseOverBackColor = restore.BackColor;
							restore.BackColorChanged += delegate(object sender, EventArgs e)
							{
								restore.FlatAppearance.MouseOverBackColor = restore.BackColor;
							};
						}
					}
				}
			}
			Enumerable.Range(0, 8).ToList<int>().ForEach(delegate(int x)
			{
				this.copics[x] = new PictureBox
				{
					Image = Class89.Bitmap_19,
					Size = new Size(12, 12),
					SizeMode = PictureBoxSizeMode.StretchImage
				};
				this.copics[x].Image = Class89.Bitmap_19;
			});
			this.copics[0].Click += delegate(object sender, EventArgs e)
			{
				Clipboard.SetDataObject(this._os1.Text);
				this.ShowCopied();
			};
			this.copics[1].Click += delegate(object sender, EventArgs e)
			{
				Clipboard.SetDataObject((this.tooltip.GetToolTip(this._mother1).Length <= 0) ? this._mother1.Text : this.tooltip.GetToolTip(this._mother1));
				this.ShowCopied();
			};
			this.copics[2].Click += delegate(object sender, EventArgs e)
			{
				Clipboard.SetDataObject(this._cpu1.Text);
				this.ShowCopied();
			};
			this.copics[3].Click += delegate(object sender, EventArgs e)
			{
				Clipboard.SetDataObject(this._gpu1.Text);
				this.ShowCopied();
			};
			this.copics[4].Click += delegate(object sender, EventArgs e)
			{
				Clipboard.SetDataObject(this._monitor1.Text.TrimEnd(null));
				this.ShowCopied();
			};
			this.copics[5].Click += delegate(object sender, EventArgs e)
			{
				Clipboard.SetDataObject(this._drive1.Text);
				this.ShowCopied();
			};
			this.copics[6].Click += delegate(object sender, EventArgs e)
			{
				Clipboard.SetDataObject(this._ip1.Text);
				this.ShowCopied();
			};
			this.copics[7].Click += delegate(object sender, EventArgs e)
			{
				Clipboard.SetDataObject(this._speed1.Text);
				this.ShowCopied();
			};
			array = new Panel[]
			{
				this.MainPanel1,
				this.MainPanel2,
				this.MainPanel3,
				this.MainPanel4,
				this.MainPanel6
			};
			for (int i = 0; i < array.Length; i++)
			{
				Panel panel = array[i];
				using (IEnumerator<CheckBox> enumerator2 = panel.Controls.OfType<CheckBox>().GetEnumerator())
				{
					EventHandler <>9__38;
					while (enumerator2.MoveNext())
					{
						CheckBox checktip = enumerator2.Current;
						if (!checktip.Name.Contains("Shift"))
						{
							checktip.MouseEnter += delegate(object sender, EventArgs e)
							{
								this.TipDefault.Text = GClass2.GClass2_0.method_1(checktip.Name.ToLower());
							};
							Control checktip2 = checktip;
							EventHandler value;
							if ((value = <>9__38) == null)
							{
								value = (<>9__38 = delegate(object sender, EventArgs e)
								{
									this.TipDefault.Text = ((panel != this.MainPanel6) ? GClass2.GClass2_0.method_1(this.TipDefault.Name) : GClass2.GClass2_0.method_1("TipCleaner"));
								});
							}
							checktip2.MouseLeave += value;
						}
					}
				}
			}
			this.linkmenu1.Click += delegate(object sender, EventArgs e)
			{
				this.method_1(this.linkmenu1, this.panelmenu1);
			};
			this.linkmenu2.Click += delegate(object sender, EventArgs e)
			{
				this.method_1(this.linkmenu2, this.panelmenu2);
			};
			this.linkmenu3.Click += delegate(object sender, EventArgs e)
			{
				this.method_1(this.linkmenu3, this.panelmenu3);
			};
			this.linkmenu4.Click += delegate(object sender, EventArgs e)
			{
				this.method_1(this.linkmenu4, this.panelmenu4);
			};
			this.linkmenu5.Click += delegate(object sender, EventArgs e)
			{
				this.method_1(this.linkmenu5, this.panelmenu5);
			};
			this.linkmenu6.Click += delegate(object sender, EventArgs e)
			{
				this.method_1(this.linkmenu6, this.panelmenu6);
			};
			this.OffDefender.Click += delegate(object sender, EventArgs e)
			{
				if (GClass2.GClass2_0.RegistryKey_0.GetValue(Systems.l) == null)
				{
					this.MakeOffer(false);
				}
			};
			this.OffDefender.MouseEnter += delegate(object sender, EventArgs e)
			{
				Form1.<<-ctor>b__8_21>d <<-ctor>b__8_21>d;
				<<-ctor>b__8_21>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<-ctor>b__8_21>d.<>4__this = this;
				<<-ctor>b__8_21>d.<>1__state = -1;
				<<-ctor>b__8_21>d.<>t__builder.Start<Form1.<<-ctor>b__8_21>d>(ref <<-ctor>b__8_21>d);
			};
			this.OffDefender.MouseLeave += delegate(object sender, EventArgs e)
			{
				Form1.<<-ctor>b__8_22>d <<-ctor>b__8_22>d;
				<<-ctor>b__8_22>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<-ctor>b__8_22>d.<>4__this = this;
				<<-ctor>b__8_22>d.<>1__state = -1;
				<<-ctor>b__8_22>d.<>t__builder.Start<Form1.<<-ctor>b__8_22>d>(ref <<-ctor>b__8_22>d);
			};
			this.OffDefender.Paint += delegate(object sender, PaintEventArgs e)
			{
				Graphics graphics = e.Graphics;
				Point[] points = new Point[]
				{
					new Point(this.OffDefender.Width, 0),
					new Point(0, 0),
					new Point(0, this.OffDefender.Height),
					new Point(this.OffDefender.Width / 2, this.OffDefender.Height - this.OffDefender.Height / 6),
					new Point(this.OffDefender.Width, this.OffDefender.Height)
				};
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.FillPolygon(new SolidBrush(Color.FromArgb(70, 104, 135)), points);
				Font font = new Font(new FontFamily((!GClass2.GClass2_0.String_3.Contains("7")) ? "Segoe UI Semilight" : "Segoe UI"), 18f, FontStyle.Regular, GraphicsUnit.Point);
				SolidBrush brush = new SolidBrush(Color.White);
				e.Graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
				e.Graphics.DrawString("Pro?", font, brush, new Point(3, 8));
			};
			this.OffDefender.Invalidate();
			this.servLabels.ToList<Label>().ForEach(delegate(Label x)
			{
				x.MouseEnter += delegate(object sender, EventArgs e)
				{
					if (!this.servLabels.Any((Label z) => z.ForeColor == this.AliceBlue))
					{
						x.BackColor = this.Backcolor;
					}
					this.TipDefault.Text = GClass2.GClass2_0.method_1(x.Name.ToLower());
				};
				x.MouseLeave += delegate(object sender, EventArgs e)
				{
					x.BackColor = Color.Transparent;
					this.TipDefault.Text = GClass2.GClass2_0.method_1("TipServices");
				};
			});
			this.MainPanelServ1.Controls.OfType<Label>().ToList<Label>().ForEach(delegate(Label x)
			{
				x.MouseEnter += delegate(object sender, EventArgs e)
				{
					Form1.<<-ctor>b__8_42>d <<-ctor>b__8_42>d;
					<<-ctor>b__8_42>d.<>t__builder = AsyncVoidMethodBuilder.Create();
					<<-ctor>b__8_42>d.<>4__this = this;
					<<-ctor>b__8_42>d.<>1__state = -1;
					<<-ctor>b__8_42>d.<>t__builder.Start<Form1.<<-ctor>b__8_42>d>(ref <<-ctor>b__8_42>d);
				};
			});
			this.servLabels.ForEach(delegate(Label x)
			{
				Action<Label> <>9__46;
				x.Click += delegate(object sender, EventArgs e)
				{
					if (!this.ServPanelChoice.Visible)
					{
						if (!this.expectation && !this.servLabels.Any((Label y) => y.ForeColor == this.AliceBlue))
						{
							List<Label> list = (from y in this.servLabels
							where y.ForeColor != this.Blue || this.servLabels.All((Label z) => z.ForeColor == this.Blue)
							select y).ToList<Label>();
							Action<Label> action;
							if ((action = <>9__46) == null)
							{
								action = (<>9__46 = delegate(Label y)
								{
									this.ServPanelChoice.Visible = true;
									this.ServPanelChoice.Location = (this.IsFirstPanel ? new Point(this.MainPanelServ1.Location.X + x.Location.X + (x.Width - this.ServPanelChoice.Width) / 2, this.MainPanelServ1.Location.Y + x.Location.Y + x.Height) : new Point(this.MainPanelServ2.Location.X + x.Location.X + (x.Width - this.ServPanelChoice.Width) / 2, this.MainPanelServ1.Location.Y + x.Location.Y + x.Height));
									y.ForeColor = ((y.ForeColor == this.Blue) ? this.Blue : this.DarkGray);
									x.ForeColor = this.AliceBlue;
								});
							}
							list.ForEach(action);
						}
						this.servlist = x.Name;
						if (this.servShow)
						{
							this.method_2();
						}
					}
				};
			});
			this.MainPanelServ2.MouseEnter += delegate(object sender, EventArgs e)
			{
				Form1.<<-ctor>b__8_27>d <<-ctor>b__8_27>d;
				<<-ctor>b__8_27>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<-ctor>b__8_27>d.<>4__this = this;
				<<-ctor>b__8_27>d.<>1__state = -1;
				<<-ctor>b__8_27>d.<>t__builder.Start<Form1.<<-ctor>b__8_27>d>(ref <<-ctor>b__8_27>d);
			};
			this.ServList.Click += delegate(object sender, EventArgs e)
			{
				this.method_2();
				this.servShow = !this.servShow;
			};
			this.CleanerLog.Click += delegate(object sender, EventArgs e)
			{
				this.CleanerMainPanel.Visible = (this.CleanerLog.Text != "");
			};
			this.CleanerLog.MouseEnter += delegate(object sender, EventArgs e)
			{
				this.CleanerLog.LinkBehavior = LinkBehavior.AlwaysUnderline;
			};
			this.CleanerLog.MouseLeave += delegate(object sender, EventArgs e)
			{
				this.CleanerLog.LinkBehavior = LinkBehavior.NeverUnderline;
			};
			base.Controls.OfType<Panel>().ToList<Panel>().ForEach(delegate(Panel x)
			{
				Form1.smethod_3(x);
			});
			Form1.smethod_3(this.autorunpanel);
			Form1.smethod_3(this.FlowPanel);
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x06000C2A RID: 3114 RVA: 0x0003B624 File Offset: 0x00039824
		private Color Backcolor
		{
			get
			{
				if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "DarkSkin")
				{
					this._Backcolor = GClass2.GClass2_0.color_8;
					return this._Backcolor;
				}
				if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SkySkin")
				{
					this._Backcolor = GClass2.GClass2_0.color_9;
					return this._Backcolor;
				}
				if (!(GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SeaSkin"))
				{
					return this._Backcolor;
				}
				this._Backcolor = GClass2.GClass2_0.color_10;
				return this._Backcolor;
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x06000C2B RID: 3115 RVA: 0x00006BD1 File Offset: 0x00004DD1
		private Color Neutral
		{
			get
			{
				return GClass6.GClass6_0.method_10("9DA7AF");
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x06000C2C RID: 3116 RVA: 0x00006BE2 File Offset: 0x00004DE2
		private Color DarkGray
		{
			get
			{
				return GClass6.GClass6_0.method_10("6F747E");
			}
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x06000C2D RID: 3117 RVA: 0x00006BF3 File Offset: 0x00004DF3
		private Color AliceBlue
		{
			get
			{
				return Color.AliceBlue;
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x06000C2E RID: 3118 RVA: 0x00006BFA File Offset: 0x00004DFA
		private Color Blue
		{
			get
			{
				return GClass6.GClass6_0.method_10("83B8E4");
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x06000C2F RID: 3119 RVA: 0x00006C0B File Offset: 0x00004E0B
		private Color Yellow
		{
			get
			{
				return GClass6.GClass6_0.method_10("EFD29E");
			}
		}

		// Token: 0x06000C30 RID: 3120 RVA: 0x0003B6EC File Offset: 0x000398EC
		private void LinkLabel6_LinkClicked(object sender, EventArgs e)
		{
			Form1.<LinkLabel6_LinkClicked>d__31 <LinkLabel6_LinkClicked>d__;
			<LinkLabel6_LinkClicked>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<LinkLabel6_LinkClicked>d__.<>4__this = this;
			<LinkLabel6_LinkClicked>d__.sender = sender;
			<LinkLabel6_LinkClicked>d__.<>1__state = -1;
			<LinkLabel6_LinkClicked>d__.<>t__builder.Start<Form1.<LinkLabel6_LinkClicked>d__31>(ref <LinkLabel6_LinkClicked>d__);
		}

		// Token: 0x06000C31 RID: 3121 RVA: 0x0003B72C File Offset: 0x0003992C
		public void LeftMenu1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.ClickLeftMenu(this.LeftMenu1, this.MainPanel1);
			this.PanelOffer.Location = new Point(base.Width, this.PanelOffer.Location.Y);
			this.TipDefault.Text = GClass2.GClass2_0.method_1(this.TipDefault.Name);
			this.Apply.Visible = true;
			this.ButtonBack.Visible = true;
			this.Apply.Text = GClass2.GClass2_0.method_1(this.Apply.Name);
			this.RemAllButton.Visible = false;
			this.ResAllButton.Visible = false;
			this.dot1.Visible = false;
			this.dot2.Visible = false;
			this.dot3.Visible = false;
			this.ServDownPanel.Visible = false;
		}

		// Token: 0x06000C32 RID: 3122 RVA: 0x0003B814 File Offset: 0x00039A14
		private void LeftMenu2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.ClickLeftMenu(this.LeftMenu2, this.MainPanel2);
			this.PanelOffer.Location = new Point(base.Width, this.PanelOffer.Location.Y);
			this.TipDefault.Text = GClass2.GClass2_0.method_1(this.TipDefault.Name);
			this.Apply.Visible = true;
			this.ButtonBack.Visible = true;
			this.Apply.Text = GClass2.GClass2_0.method_1(this.Apply.Name);
			this.RemAllButton.Visible = false;
			this.ResAllButton.Visible = false;
			this.dot1.Visible = false;
			this.dot2.Visible = false;
			this.dot3.Visible = false;
			this.ServDownPanel.Visible = false;
		}

		// Token: 0x06000C33 RID: 3123 RVA: 0x0003B8FC File Offset: 0x00039AFC
		private void LeftMenu3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.ClickLeftMenu(this.LeftMenu3, this.MainPanel3);
			this.PanelOffer.Location = new Point(base.Width, this.PanelOffer.Location.Y);
			this.TipDefault.Text = GClass2.GClass2_0.method_1(this.TipDefault.Name);
			this.Apply.Visible = true;
			this.ButtonBack.Visible = true;
			this.Apply.Text = GClass2.GClass2_0.method_1(this.Apply.Name);
			this.RemAllButton.Visible = false;
			this.ResAllButton.Visible = false;
			this.dot1.Visible = false;
			this.dot2.Visible = false;
			this.dot3.Visible = false;
			this.ServDownPanel.Visible = false;
		}

		// Token: 0x06000C34 RID: 3124 RVA: 0x0003B9E4 File Offset: 0x00039BE4
		private void LeftMenu4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.ClickLeftMenu(this.LeftMenu4, this.MainPanel4);
			this.PanelOffer.Location = new Point(base.Width, this.PanelOffer.Location.Y);
			this.TipDefault.Text = GClass2.GClass2_0.method_1(this.TipDefault.Name);
			this.Apply.Visible = true;
			this.ButtonBack.Visible = true;
			this.Apply.Text = GClass2.GClass2_0.method_1(this.Apply.Name);
			this.RemAllButton.Visible = false;
			this.ResAllButton.Visible = false;
			this.dot1.Visible = false;
			this.dot2.Visible = false;
			this.dot3.Visible = false;
			Infobase.Own();
			if ((GClass2.GClass2_0.String_3.Contains("10 Home") || GClass2.GClass2_0.String_3.Contains("7 Home") || GClass2.GClass2_0.String_3.Contains("8.1 Connected")) && !File.Exists(GClass13.string_6 + "\\System32\\gpedit.msc"))
			{
				this.Popup(GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("Win10HomeSuggestion"), 8000);
			}
			if (base.Opacity != 0.0 && Systems.DefenderDisabled())
			{
				this.OffDefender.Visible = true;
			}
			this.ServDownPanel.Visible = false;
		}

		// Token: 0x06000C35 RID: 3125 RVA: 0x0003BB7C File Offset: 0x00039D7C
		private void LeftMenu5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Form1.<LeftMenu5_LinkClicked>d__36 <LeftMenu5_LinkClicked>d__;
			<LeftMenu5_LinkClicked>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<LeftMenu5_LinkClicked>d__.<>4__this = this;
			<LeftMenu5_LinkClicked>d__.sender = sender;
			<LeftMenu5_LinkClicked>d__.<>1__state = -1;
			<LeftMenu5_LinkClicked>d__.<>t__builder.Start<Form1.<LeftMenu5_LinkClicked>d__36>(ref <LeftMenu5_LinkClicked>d__);
		}

		// Token: 0x06000C36 RID: 3126 RVA: 0x0003BBBC File Offset: 0x00039DBC
		private void LeftMenu6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.ClickLeftMenu(this.LeftMenu6, this.MainPanel6);
			this.PanelOffer.Location = new Point(base.Width, this.PanelOffer.Location.Y);
			this.TipDefault.Text = GClass2.GClass2_0.method_1("TipCleaner");
			this.Apply.Visible = true;
			this.ButtonBack.Visible = true;
			this.Apply.Text = GClass2.GClass2_0.method_1(this.Apply.Name);
			this.RemAllButton.Visible = false;
			this.ResAllButton.Visible = false;
			this.ServDownPanel.Visible = false;
		}

		// Token: 0x06000C37 RID: 3127 RVA: 0x0003BC7C File Offset: 0x00039E7C
		private void LeftMenu7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.ClickLeftMenu(this.LeftMenu7, this.MainPanel7);
			this.PanelOffer.Location = new Point(base.Width, this.PanelOffer.Location.Y);
			this.TipDefault.Text = GClass2.GClass2_0.method_1("TipApps");
			this.Apply.Visible = false;
			this.ButtonBack.Visible = false;
			this.RemAllButton.Visible = true;
			this.ResAllButton.Visible = true;
			this.dot1.Visible = false;
			this.dot2.Visible = false;
			this.dot3.Visible = false;
			this.ServDownPanel.Visible = false;
			if (GClass2.GClass2_0.String_3.Contains("7"))
			{
				this.RemAllButton.Enabled = false;
				this.ResAllButton.Enabled = false;
			}
			GClass2.GClass2_0.RegistryKey_0.SetValue("First Run AppsVisited", "true");
		}

		// Token: 0x06000C38 RID: 3128 RVA: 0x0003BD88 File Offset: 0x00039F88
		private void LeftMenu8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.Autoruns();
			this.ClickLeftMenu(this.LeftMenu8, this.MainPanel8);
			this.PanelOffer.Location = new Point(base.Width, this.PanelOffer.Location.Y);
			if (!GClass2.GClass2_0.String_3.Contains("7"))
			{
				this.TipDefault.Text = GClass2.GClass2_0.method_1("TipAutorunsWin10");
			}
			else
			{
				this.TipDefault.Text = GClass2.GClass2_0.method_1("TipAutorunsWin7");
			}
			this.Apply.Text = GClass2.GClass2_0.method_1("StartupAddItem");
			this.Apply.Visible = true;
			this.ButtonBack.Visible = true;
			this.RemAllButton.Visible = false;
			this.ResAllButton.Visible = false;
			this.dot1.Visible = false;
			this.dot2.Visible = false;
			this.dot3.Visible = false;
			this.ServDownPanel.Visible = false;
		}

		// Token: 0x06000C39 RID: 3129 RVA: 0x0003BE9C File Offset: 0x0003A09C
		private void LeftMenu9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Form1.<LeftMenu9_LinkClicked>d__40 <LeftMenu9_LinkClicked>d__;
			<LeftMenu9_LinkClicked>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<LeftMenu9_LinkClicked>d__.<>4__this = this;
			<LeftMenu9_LinkClicked>d__.<>1__state = -1;
			<LeftMenu9_LinkClicked>d__.<>t__builder.Start<Form1.<LeftMenu9_LinkClicked>d__40>(ref <LeftMenu9_LinkClicked>d__);
		}

		// Token: 0x06000C3A RID: 3130 RVA: 0x0003BED4 File Offset: 0x0003A0D4
		private void LeftMenu10_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.ClickLeftMenu(this.LeftMenu10, this.MainPanel10);
			this.PanelOffer.Location = new Point(base.Width, this.PanelOffer.Location.Y);
			this.TipDefault.Text = GClass2.GClass2_0.method_1("TipVirusTotal");
			this.Apply.Visible = false;
			this.ButtonBack.Visible = false;
			this.RemAllButton.Visible = false;
			this.ResAllButton.Visible = false;
			this.dot1.Visible = false;
			this.dot2.Visible = false;
			this.dot3.Visible = false;
			this.ServDownPanel.Visible = false;
			if (this.APIKey() == "")
			{
				Form1.<>c__DisplayClass41_0 CS$<>8__locals1 = new Form1.<>c__DisplayClass41_0();
				CS$<>8__locals1.<>4__this = this;
				this.DropFileHereVT.Text = GClass2.GClass2_0.method_1("YouNeedAPI");
				this.DropFileHereVT.Font = new Font(this.DropFileHereVT.Font.Name, this.DropFileHereVT.Font.SizeInPoints, FontStyle.Underline);
				this.DropFileHereVT.Cursor = Cursors.Hand;
				CS$<>8__locals1.field = new TextBox();
				new LinkLabel();
				CS$<>8__locals1.field.Size = new Size(this.panelVT.Width, 22);
				CS$<>8__locals1.field.BackColor = SystemColors.InactiveBorder;
				CS$<>8__locals1.field.ForeColor = Color.SlateGray;
				CS$<>8__locals1.field.Location = new Point(CS$<>8__locals1.field.Location.X, CS$<>8__locals1.field.Location.Y + 2);
				CS$<>8__locals1.field.Text = "API Key";
				this.DropFileHereVT.Click += delegate(object sender, EventArgs e)
				{
					this.APIVideo();
				};
				CS$<>8__locals1.field.Click += delegate(object sender, EventArgs e)
				{
					if (CS$<>8__locals1.field.Text.Contains("API Key"))
					{
						CS$<>8__locals1.field.Text = "";
					}
				};
				CS$<>8__locals1.field.TextChanged += delegate(object sender, EventArgs e)
				{
					Form1.<>c__DisplayClass41_0.<<LeftMenu10_LinkClicked>b__2>d <<LeftMenu10_LinkClicked>b__2>d;
					<<LeftMenu10_LinkClicked>b__2>d.<>t__builder = AsyncVoidMethodBuilder.Create();
					<<LeftMenu10_LinkClicked>b__2>d.<>4__this = CS$<>8__locals1;
					<<LeftMenu10_LinkClicked>b__2>d.<>1__state = -1;
					<<LeftMenu10_LinkClicked>b__2>d.<>t__builder.Start<Form1.<>c__DisplayClass41_0.<<LeftMenu10_LinkClicked>b__2>d>(ref <<LeftMenu10_LinkClicked>b__2>d);
				};
				this.panelVT.Controls.Add(CS$<>8__locals1.field);
			}
		}

		// Token: 0x06000C3B RID: 3131 RVA: 0x0003C104 File Offset: 0x0003A304
		private void LeftMenu11_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Form1.<LeftMenu11_LinkClicked>d__42 <LeftMenu11_LinkClicked>d__;
			<LeftMenu11_LinkClicked>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<LeftMenu11_LinkClicked>d__.<>4__this = this;
			<LeftMenu11_LinkClicked>d__.<>1__state = -1;
			<LeftMenu11_LinkClicked>d__.<>t__builder.Start<Form1.<LeftMenu11_LinkClicked>d__42>(ref <LeftMenu11_LinkClicked>d__);
		}

		// Token: 0x06000C3C RID: 3132 RVA: 0x0003C13C File Offset: 0x0003A33C
		private void ClickLeftMenu(LinkLabel LinkLabel, Panel panel)
		{
			foreach (LinkLabel linkLabel in this.LeftPanel.Controls.OfType<LinkLabel>())
			{
				if (linkLabel.Name.Contains("LeftMenu"))
				{
					linkLabel.LinkColor = GClass2.GClass2_0.color_0;
				}
			}
			using (IEnumerator<Panel> enumerator2 = base.Controls.OfType<Panel>().GetEnumerator())
			{
				while (enumerator2.MoveNext())
				{
					Panel pnl = enumerator2.Current;
					if (pnl.Name.Contains("MainPanel"))
					{
						base.Invoke(new Action(delegate()
						{
							pnl.Visible = false;
						}));
					}
				}
			}
			LinkLabel.LinkColor = this.Blue;
			panel.Visible = true;
			if (this.ServPanelChoice.Visible)
			{
				this.ServCancel.PerformClick();
				this.ServPanelChoice.Visible = false;
			}
			if (this.MainPanelServ1.Visible)
			{
				this.AddToApply.Visible = true;
				this.AddToApply.Image = Class89.Bitmap_52;
				this.AddToApply.BackColor = this.LeftPanel.BackColor;
				this.tooltip.SetToolTip(this.AddToApply, GClass2.GClass2_0.method_1("ServRestoreTooltip"));
				return;
			}
			if (this.MainPanel6.Visible)
			{
				this.AddToApply.Visible = true;
				this.AddToApply.Image = Class89.Bitmap_54;
				this.tooltip.SetToolTip(this.AddToApply, GClass2.GClass2_0.method_1("SaveCleanerCheks"));
				return;
			}
			this.AddToApply.Visible = false;
		}

		// Token: 0x06000C3D RID: 3133 RVA: 0x00006C1C File Offset: 0x00004E1C
		private void LinkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.CheckUncheck(this.checkAll1, this.MainPanel1);
		}

		// Token: 0x06000C3E RID: 3134 RVA: 0x00006C30 File Offset: 0x00004E30
		private void LinkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.CheckUncheck(this.checkAll2, this.MainPanel2);
		}

		// Token: 0x06000C3F RID: 3135 RVA: 0x00006C44 File Offset: 0x00004E44
		private void LinkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.CheckUncheck(this.checkAll3, this.MainPanel3);
		}

		// Token: 0x06000C40 RID: 3136 RVA: 0x00006C58 File Offset: 0x00004E58
		private void LinkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.CheckUncheck(this.checkAll4, this.MainPanel4);
		}

		// Token: 0x06000C41 RID: 3137 RVA: 0x00006C6C File Offset: 0x00004E6C
		private void LinkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.CheckUncheck(this.checkAll5, this.MainPanel6);
		}

		// Token: 0x06000C42 RID: 3138 RVA: 0x0003C30C File Offset: 0x0003A50C
		private void CheckUncheck(LinkLabel checker, Panel panel)
		{
			if (checker.Text == GClass2.GClass2_0.method_1("uncheckAll"))
			{
				checker.Text = GClass2.GClass2_0.method_1("checkAll");
				using (IEnumerator<CheckBox> enumerator = panel.Controls.OfType<CheckBox>().GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						CheckBox checkBox = enumerator.Current;
						checkBox.Checked = false;
					}
					return;
				}
			}
			checker.Text = GClass2.GClass2_0.method_1("uncheckAll");
			foreach (CheckBox checkBox2 in panel.Controls.OfType<CheckBox>())
			{
				if (checkBox2.Enabled)
				{
					checkBox2.Checked = true;
				}
			}
		}

		// Token: 0x06000C43 RID: 3139 RVA: 0x0003C3F0 File Offset: 0x0003A5F0
		private void MinimizeIcon_Click(object sender, EventArgs e)
		{
			Form1.<MinimizeIcon_Click>d__50 <MinimizeIcon_Click>d__;
			<MinimizeIcon_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<MinimizeIcon_Click>d__.<>4__this = this;
			<MinimizeIcon_Click>d__.<>1__state = -1;
			<MinimizeIcon_Click>d__.<>t__builder.Start<Form1.<MinimizeIcon_Click>d__50>(ref <MinimizeIcon_Click>d__);
		}

		// Token: 0x06000C44 RID: 3140 RVA: 0x00006C80 File Offset: 0x00004E80
		private void PlayIcon_Click(object sender, EventArgs e)
		{
			if (!this.OptWorking() && !Application.OpenForms.OfType<About>().Any<About>() && !Application.OpenForms.OfType<Settings_1>().Any<Settings_1>())
			{
				new YouTube(this).ShowDialog();
			}
		}

		// Token: 0x06000C45 RID: 3141 RVA: 0x00006CB8 File Offset: 0x00004EB8
		private void SettingsIcon_Click(object sender, EventArgs e)
		{
			if (!this.OptWorking() && !Application.OpenForms.OfType<Settings_1>().Any<Settings_1>())
			{
				new Settings_1(this).Show();
			}
		}

		// Token: 0x06000C46 RID: 3142 RVA: 0x00006CDE File Offset: 0x00004EDE
		private void AboutIcon_Click(object sender, EventArgs e)
		{
			if (!this.OptWorking() && Application.OpenForms["About"] == null)
			{
				new About(this).Show();
			}
		}

		// Token: 0x06000C47 RID: 3143 RVA: 0x0003C428 File Offset: 0x0003A628
		private void CloseIcon_Click(object sender, EventArgs e)
		{
			this.ServClose();
			if (!this.OptWorking())
			{
				this.method_3();
				return;
			}
			if (WMessageBox.smethod_3(GClass2.GClass2_0.method_1("OptCloseConfirm"), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
			{
				Form1.CloseDim();
				this.method_3();
				return;
			}
		}

		// Token: 0x06000C48 RID: 3144 RVA: 0x00006D04 File Offset: 0x00004F04
		public void ForceClose()
		{
			GClass6.GClass6_0.method_18();
			GClass6.GClass6_0.method_14(string.Format("taskkill /f /pid \"{0}\"", Process.GetCurrentProcess().Id));
		}

		// Token: 0x06000C49 RID: 3145 RVA: 0x0003C47C File Offset: 0x0003A67C
		private void Apply_Click(object sender, EventArgs e)
		{
			Form1.<Apply_Click>d__56 <Apply_Click>d__;
			<Apply_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Apply_Click>d__.<>4__this = this;
			<Apply_Click>d__.<>1__state = -1;
			<Apply_Click>d__.<>t__builder.Start<Form1.<Apply_Click>d__56>(ref <Apply_Click>d__);
		}

		// Token: 0x06000C4A RID: 3146 RVA: 0x0003C4B4 File Offset: 0x0003A6B4
		private void AddToApply_Click(object sender, EventArgs e)
		{
			if (this.MainPanel6.Visible)
			{
				this.SaveCleaner();
				this.Popup(GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("CleanerSavedMarks"), 8000);
				return;
			}
			if (!this.MainPanelServ1.Visible || WMessageBox.smethod_3(GClass2.GClass2_0.method_1("ServRestoreButton2") ?? "", GClass2.GClass2_0.method_1("ServRestoreButton1") ?? "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
			{
				this.method_6();
			}
		}

		// Token: 0x06000C4B RID: 3147 RVA: 0x0003C558 File Offset: 0x0003A758
		private void CleanerTask()
		{
			Form1.<CleanerTask>d__59 <CleanerTask>d__;
			<CleanerTask>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<CleanerTask>d__.<>4__this = this;
			<CleanerTask>d__.<>1__state = -1;
			<CleanerTask>d__.<>t__builder.Start<Form1.<CleanerTask>d__59>(ref <CleanerTask>d__);
		}

		// Token: 0x06000C4C RID: 3148 RVA: 0x00006D33 File Offset: 0x00004F33
		public void AddRows(List<string> rows)
		{
			rows.ForEach(delegate(string x)
			{
				base.Invoke(new Action(delegate()
				{
					double num = Convert.ToDouble(x.Substring(x.IndexOf(">") + 1));
					this.sum += num;
					this.Table.Rows.Add(new object[]
					{
						1,
						x.Remove(x.IndexOf(">")),
						num / 1048576.0
					});
				}));
			});
		}

		// Token: 0x06000C4D RID: 3149 RVA: 0x0003C590 File Offset: 0x0003A790
		private void TableOrderByNum()
		{
			int num = 1;
			foreach (object obj in ((IEnumerable)this.Table.Rows))
			{
				foreach (object obj2 in ((DataGridViewRow)obj).Cells)
				{
					DataGridViewCell dataGridViewCell = (DataGridViewCell)obj2;
					if (dataGridViewCell.ColumnIndex == 0)
					{
						dataGridViewCell.Value = string.Format("{0}", num++);
					}
				}
			}
		}

		// Token: 0x06000C4E RID: 3150 RVA: 0x0003C654 File Offset: 0x0003A854
		private void CleanerView()
		{
			this.CleanerMainPanel.MouseDown += delegate(object sender, MouseEventArgs e)
			{
				this.CleanerMainPanel.Capture = false;
				base.Capture = false;
				Message message = Message.Create(this.method_17(), 161, new IntPtr(2), IntPtr.Zero);
				base.System.Windows.Forms.Form.WndProc(ref message);
			};
			this.HeaderCleanerLog.MouseDown += delegate(object sender, MouseEventArgs e)
			{
				this.HeaderCleanerLog.Capture = false;
				base.Capture = false;
				Message message = Message.Create(this.method_17(), 161, new IntPtr(2), IntPtr.Zero);
				base.System.Windows.Forms.Form.WndProc(ref message);
			};
			DataGridViewCellStyle defaultCellStyle = new DataGridViewCellStyle
			{
				Format = string.Format("{0}.#0 MB", 0),
				NullValue = null
			};
			this.Column3.DefaultCellStyle = defaultCellStyle;
			this.Column1.Width = this.Table.Width / 100 * 7;
			this.Column3.Width = this.Table.Width / 100 * 12;
			this.Column2.Width = this.Table.Width - (this.Column1.Width + this.Column3.Width + SystemInformation.VerticalScrollBarWidth + 5);
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "DarkSkin")
			{
				this.CleanerMainPanel.BackColor = GClass2.GClass2_0.color_5;
				this.Table.BackgroundColor = GClass2.GClass2_0.color_5;
				this.Table.RowTemplate.DefaultCellStyle.BackColor = GClass2.GClass2_0.color_5;
				this.Table.ColumnHeadersDefaultCellStyle.BackColor = GClass6.GClass6_0.method_10("293440");
				return;
			}
			if (!(GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SkySkin"))
			{
				if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SeaSkin")
				{
					this.CleanerMainPanel.BackColor = GClass2.GClass2_0.color_7;
					this.Table.BackgroundColor = GClass2.GClass2_0.color_7;
					this.Table.RowTemplate.DefaultCellStyle.BackColor = GClass2.GClass2_0.color_7;
					this.Table.ColumnHeadersDefaultCellStyle.BackColor = GClass6.GClass6_0.method_10("0D3B52");
				}
				return;
			}
			this.CleanerMainPanel.BackColor = GClass2.GClass2_0.color_6;
			this.Table.BackgroundColor = GClass2.GClass2_0.color_6;
			this.Table.RowTemplate.DefaultCellStyle.BackColor = GClass2.GClass2_0.color_6;
			this.Table.ColumnHeadersDefaultCellStyle.BackColor = GClass6.GClass6_0.method_10("0D3455");
		}

		// Token: 0x06000C4F RID: 3151 RVA: 0x0003C8D8 File Offset: 0x0003AAD8
		private void SaveCleaner()
		{
			string text = "";
			string path = "Win 10 Tweaker.ini";
			while (!File.Exists(path))
			{
				File.Create("Win 10 Tweaker.ini").Close();
			}
			string[] first = File.ReadAllLines(path);
			if (File.ReadAllText(path).Contains("checkBoxCleaner"))
			{
				File.WriteAllText(path, "");
				foreach (CheckBox checkBox in this.MainPanel6.Controls.OfType<CheckBox>())
				{
					text = string.Concat(new string[]
					{
						text,
						checkBox.Text,
						"\n",
						checkBox.Name,
						"\n"
					});
				}
				string[] second = text.Split(new char[]
				{
					'\r',
					'\n'
				}, StringSplitOptions.RemoveEmptyEntries);
				IEnumerable<string> enumerable = first.Except(second);
				FileStream fileStream = new FileStream(path, FileMode.OpenOrCreate);
				StreamWriter streamWriter = new StreamWriter(fileStream);
				fileStream.Seek(0L, SeekOrigin.End);
				foreach (string value in enumerable)
				{
					streamWriter.WriteLine(value);
				}
				streamWriter.Close();
			}
			FileStream fileStream2 = new FileStream(path, FileMode.OpenOrCreate);
			StreamWriter streamWriter2 = new StreamWriter(fileStream2);
			fileStream2.Seek(0L, SeekOrigin.End);
			foreach (CheckBox checkBox2 in this.MainPanel6.Controls.OfType<CheckBox>())
			{
				if (checkBox2.Checked)
				{
					streamWriter2.WriteLine(checkBox2.Text);
					streamWriter2.WriteLine(checkBox2.Name);
					streamWriter2.WriteLine("");
				}
			}
			streamWriter2.Close();
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x0003CAC8 File Offset: 0x0003ACC8
		private void ServYes_Click(object sender, EventArgs e)
		{
			Label label = this.servLabels.FirstOrDefault((Label x) => x.ForeColor == this.AliceBlue);
			this.ServPanelChoice.Visible = false;
			(from x in this.servLabels
			where x.ForeColor == this.DarkGray && x.Font.Style != FontStyle.Strikeout
			select x).ToList<Label>().ForEach(delegate(Label x)
			{
				x.ForeColor = this.Neutral;
			});
			this.ServChangeYes(label);
			if (label.Name == "Serv4")
			{
				this.ServChangeYes(this.Serv8);
				this.ServChangeYes(this.Serv25);
			}
			else if (!(label.Name == "Serv5"))
			{
				if (label.Name == "Serv12")
				{
					this.ServChangeYes(this.Serv4);
					this.ServChangeYes(this.Serv8);
					this.ServChangeYes(this.Serv24);
					this.ServChangeYes(this.Serv25);
				}
			}
			else
			{
				this.ServChangeYes(this.Serv6);
				this.ServChangeYes(this.Serv24);
			}
			this.ServCommon();
			this.ServClose();
		}

		// Token: 0x06000C51 RID: 3153 RVA: 0x0003CBD4 File Offset: 0x0003ADD4
		private void ServNo_Click(object sender, EventArgs e)
		{
			Label label = this.servLabels.FirstOrDefault((Label x) => x.ForeColor == this.AliceBlue);
			this.ServPanelChoice.Visible = false;
			(from x in this.servLabels
			where x.ForeColor == this.DarkGray && x.Font.Style != FontStyle.Strikeout
			select x).ToList<Label>().ForEach(delegate(Label x)
			{
				x.ForeColor = this.Neutral;
			});
			this.ServChangeNo(label);
			if (label.Name == "Serv4")
			{
				this.ServChangeNo(this.Serv12);
			}
			if (!(label.Name == "Serv5"))
			{
				if (label.Name == "Serv6")
				{
					this.ServChangeNo(this.Serv5);
				}
				else if (label.Name == "Serv8" || label.Name == "Serv19" || label.Name == "Serv24" || label.Name == "Serv25")
				{
					this.ServChangeNo(this.Serv4);
					this.ServChangeNo(this.Serv12);
				}
			}
			else if ((from s in WindowsIdentity.GetCurrent().Groups
			select new SecurityIdentifier(s.Value).Translate(typeof(NTAccount)).Value).Any((string g) => g.StartsWith("MicrosoftAccount\\")))
			{
				this.ServChangeNo(this.Serv6);
			}
			this.ServCommon();
			this.ServClose();
		}

		// Token: 0x06000C52 RID: 3154 RVA: 0x0003CD60 File Offset: 0x0003AF60
		private void ServCancel_Click(object sender, EventArgs e)
		{
			Label label = this.servLabels.FirstOrDefault((Label x) => x.ForeColor == this.AliceBlue) ?? this.servLabels[0];
			this.ServPanelChoice.Visible = false;
			(from x in this.servLabels
			where x.ForeColor == this.DarkGray && x.Font.Style != FontStyle.Strikeout
			select x).ToList<Label>().ForEach(delegate(Label x)
			{
				x.ForeColor = this.Neutral;
			});
			label.ForeColor = this.Neutral;
			label.Font = new Font(label.Font, FontStyle.Regular);
			if (label.Name == "Serv4")
			{
				if (this.Serv12.ForeColor == this.Blue)
				{
					this.ServChangeNeutral(this.Serv12);
				}
				if (this.Serv8.Font.Style == FontStyle.Strikeout)
				{
					this.ServChangeNeutral(this.Serv8);
				}
				if (this.Serv19.Font.Style == FontStyle.Strikeout)
				{
					this.ServChangeNeutral(this.Serv19);
				}
				if (this.Serv24.Font.Style == FontStyle.Strikeout)
				{
					this.ServChangeNeutral(this.Serv24);
				}
				if (this.Serv25.Font.Style == FontStyle.Strikeout)
				{
					this.ServChangeNeutral(this.Serv25);
				}
			}
			else if (label.Name == "Serv5" && this.Serv6.Font.Style == FontStyle.Strikeout)
			{
				this.ServChangeNeutral(this.Serv6);
			}
			else if (label.Name == "Serv12")
			{
				if (this.Serv4.Font.Style == FontStyle.Strikeout)
				{
					this.ServChangeNeutral(this.Serv4);
				}
				if (this.Serv8.Font.Style == FontStyle.Strikeout)
				{
					this.ServChangeNeutral(this.Serv8);
				}
				if (this.Serv19.Font.Style == FontStyle.Strikeout)
				{
					this.ServChangeNeutral(this.Serv19);
				}
				if (this.Serv24.Font.Style == FontStyle.Strikeout)
				{
					this.ServChangeNeutral(this.Serv24);
				}
				if (this.Serv25.Font.Style == FontStyle.Strikeout)
				{
					this.ServChangeNeutral(this.Serv25);
				}
			}
			this.ServCommon();
			this.ServClose();
		}

		// Token: 0x06000C53 RID: 3155 RVA: 0x00006D47 File Offset: 0x00004F47
		private void ServChangeYes(Label Serv)
		{
			Serv.ForeColor = this.Blue;
			Serv.Font = new Font(Serv.Font, FontStyle.Regular);
		}

		// Token: 0x06000C54 RID: 3156 RVA: 0x00006D67 File Offset: 0x00004F67
		private void ServChangeNo(Label Serv)
		{
			Serv.ForeColor = this.DarkGray;
			Serv.Font = new Font(Serv.Font, FontStyle.Strikeout);
		}

		// Token: 0x06000C55 RID: 3157 RVA: 0x00006D87 File Offset: 0x00004F87
		private void ServChangeNeutral(Label Serv)
		{
			Serv.ForeColor = this.Neutral;
			Serv.Font = new Font(Serv.Font, FontStyle.Regular);
		}

		// Token: 0x06000C56 RID: 3158 RVA: 0x0003CFA8 File Offset: 0x0003B1A8
		private void ServCommon()
		{
			int temp = 0;
			(from x in this.servLabels
			where x.ForeColor == this.Blue
			select x).ToList<Label>().ForEach(delegate(Label x)
			{
				Class61.Class61_0.Dictionary_0.ToList<KeyValuePair<string, List<string>>>().ForEach(delegate(KeyValuePair<string, List<string>> y)
				{
					if (x.Name == y.Key)
					{
						temp += y.Value.Count<string>();
					}
				});
			});
			this.ServProgressBar.Value = temp;
			this.ServStepsLabel.Text = string.Format("{0} {1} / {2}", GClass2.GClass2_0.method_1("ServStepsLabel2"), this.ServProgressBar.Value, this.ServProgressBar.Maximum);
		}

		// Token: 0x06000C57 RID: 3159 RVA: 0x0003D04C File Offset: 0x0003B24C
		private void ServChecker()
		{
			int blue = 0;
			this.servLabels.ForEach(delegate(Label x)
			{
				Class61.Class61_0.Dictionary_0.ToList<KeyValuePair<string, List<string>>>().ForEach(delegate(KeyValuePair<string, List<string>> y)
				{
					if (x.Name == y.Key)
					{
						blue = y.Value.Count<string>();
						int i = 0;
						y.Value.ForEach(delegate(string z)
						{
							using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\" + z))
							{
								string a;
								if (registryKey != null)
								{
									object value = registryKey.GetValue("Start");
									a = ((value != null) ? value.ToString() : null);
								}
								else
								{
									a = null;
								}
								if (a == "4")
								{
									int i = i;
									i++;
								}
							}
						});
						if (blue == i)
						{
							x.ForeColor = this.Blue;
						}
					}
				});
			});
		}

		// Token: 0x06000C58 RID: 3160 RVA: 0x00006DA7 File Offset: 0x00004FA7
		private void ServClose()
		{
			if (Application.OpenForms.OfType<ServDescription>().Any<ServDescription>())
			{
				Application.OpenForms["ServDescription"].Close();
			}
		}

		// Token: 0x06000C59 RID: 3161 RVA: 0x0003D084 File Offset: 0x0003B284
		private string TooltipInstalled(string appname)
		{
			return string.Concat(new string[]
			{
				GClass2.GClass2_0.method_1("AppInstalled1"),
				" ",
				appname.Replace("_", ""),
				" ",
				GClass2.GClass2_0.method_1("AppInstalled2")
			});
		}

		// Token: 0x06000C5A RID: 3162 RVA: 0x0003D0E4 File Offset: 0x0003B2E4
		private string TooltipDeleted(string appname)
		{
			return string.Concat(new string[]
			{
				GClass2.GClass2_0.method_1("AppInstalled1"),
				" ",
				appname.Replace("_", ""),
				" ",
				GClass2.GClass2_0.method_1("AppInstalled3")
			});
		}

		// Token: 0x06000C5B RID: 3163 RVA: 0x0003D144 File Offset: 0x0003B344
		private string OutputApps()
		{
			string result;
			using (PowerShell powerShell = PowerShell.Create())
			{
				powerShell.AddScript("Get-AppxPackage");
				result = string.Join<object>(Environment.NewLine, from x in powerShell.Invoke().ToList<PSObject>()
				select x.Properties["Name"].Value);
			}
			return result;
		}

		// Token: 0x06000C5C RID: 3164 RVA: 0x0003D1BC File Offset: 0x0003B3BC
		private void AppsGridRules()
		{
			Form1.<AppsGridRules>d__77 <AppsGridRules>d__;
			<AppsGridRules>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<AppsGridRules>d__.<>4__this = this;
			<AppsGridRules>d__.<>1__state = -1;
			<AppsGridRules>d__.<>t__builder.Start<Form1.<AppsGridRules>d__77>(ref <AppsGridRules>d__);
		}

		// Token: 0x06000C5D RID: 3165 RVA: 0x0003D1F4 File Offset: 0x0003B3F4
		private void RemoveMetroApp(string appname, bool permanently)
		{
			GClass6.GClass6_0.method_16(permanently ? string.Concat(new string[]
			{
				"Get-AppxPackage *",
				appname,
				"* | Remove-AppxPackage; Get-AppxProvisionedPackage –online | where-object {$_.packagename -like “*",
				appname,
				"*”} | Remove-AppxProvisionedPackage -online"
			}) : ("Get-AppxPackage *" + appname + "* | Remove-AppxPackage"));
		}

		// Token: 0x06000C5E RID: 3166 RVA: 0x00006DCE File Offset: 0x00004FCE
		private void RestoreMetroApp(string appname)
		{
			GClass6.GClass6_0.method_16("Add-AppxPackage -register 'C:\\Program Files\\WindowsApps\\*" + appname + "*\\AppxManifest.xml' -DisableDevelopmentMode");
		}

		// Token: 0x06000C5F RID: 3167 RVA: 0x0003D24C File Offset: 0x0003B44C
		private void RemAllButton_Click(object sender, EventArgs e)
		{
			Form1.<RemAllButton_Click>d__80 <RemAllButton_Click>d__;
			<RemAllButton_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<RemAllButton_Click>d__.<>4__this = this;
			<RemAllButton_Click>d__.<>1__state = -1;
			<RemAllButton_Click>d__.<>t__builder.Start<Form1.<RemAllButton_Click>d__80>(ref <RemAllButton_Click>d__);
		}

		// Token: 0x06000C60 RID: 3168 RVA: 0x0003D284 File Offset: 0x0003B484
		private void ResAllButton_Click(object sender, EventArgs e)
		{
			Form1.<ResAllButton_Click>d__81 <ResAllButton_Click>d__;
			<ResAllButton_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ResAllButton_Click>d__.<>4__this = this;
			<ResAllButton_Click>d__.<>1__state = -1;
			<ResAllButton_Click>d__.<>t__builder.Start<Form1.<ResAllButton_Click>d__81>(ref <ResAllButton_Click>d__);
		}

		// Token: 0x06000C61 RID: 3169 RVA: 0x0003D2BC File Offset: 0x0003B4BC
		public Bitmap GrayScale(Image image, bool rip = false)
		{
			Bitmap bitmap = new Bitmap(image);
			for (int i = 0; i < bitmap.Width; i++)
			{
				for (int j = 0; j < bitmap.Height; j++)
				{
					int num = (int)((bitmap.GetPixel(i, j).R + bitmap.GetPixel(i, j).G + bitmap.GetPixel(i, j).B) / (rip ? 6 : 3));
					bitmap.SetPixel(i, j, Color.FromArgb(num, num, num));
				}
			}
			return bitmap;
		}

		// Token: 0x06000C62 RID: 3170 RVA: 0x0003D344 File Offset: 0x0003B544
		private void Autoruns()
		{
			try
			{
				this.autorunpanel.Controls.Clear();
				int num = Convert.ToInt32(Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Run").ValueCount.ToString());
				int num2 = Convert.ToInt32(Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Run").ValueCount.ToString());
				int num3 = Convert.ToInt32(Registry.LocalMachine.CreateSubKey("SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run").ValueCount.ToString());
				int num4 = Convert.ToInt32(new DirectoryInfo(GClass2.GClass2_0.String_13).GetFiles("*.lnk").Length.ToString());
				int num5 = Convert.ToInt32(new DirectoryInfo(GClass2.GClass2_0.String_14).GetFiles("*.lnk").Length.ToString());
				int num6 = Convert.ToInt32(new DirectoryInfo(GClass13.string_6 + "\\System32\\Tasks").GetFiles("*").Length.ToString());
				RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Run");
				try
				{
					if (registryKey != null)
					{
						registryKey.DeleteValue("");
					}
				}
				catch
				{
				}
				string[] valueNames = registryKey.GetValueNames();
				RegistryKey registryKey2 = Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Run");
				try
				{
					if (registryKey2 != null)
					{
						registryKey2.DeleteValue("");
					}
				}
				catch
				{
				}
				string[] valueNames2 = registryKey2.GetValueNames();
				RegistryKey registryKey3 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run");
				try
				{
					if (registryKey3 != null)
					{
						registryKey3.DeleteValue("");
					}
				}
				catch
				{
				}
				string[] valueNames3 = registryKey3.GetValueNames();
				string[] array = Directory.EnumerateFiles(GClass2.GClass2_0.String_13, "*.lnk", SearchOption.AllDirectories).Select(new Func<string, string>(Path.GetFileName)).ToArray<string>();
				string[] array2 = Directory.EnumerateFiles(GClass2.GClass2_0.String_14, "*.lnk", SearchOption.AllDirectories).Select(new Func<string, string>(Path.GetFileName)).ToArray<string>();
				string[] array3 = Directory.EnumerateFiles(GClass13.string_6 + "\\System32\\Tasks", "*").Select(new Func<string, string>(Path.GetFileName)).ToArray<string>();
				RegistryKey registryKey4 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\Run");
				registryKey4.GetValueNames();
				RegistryKey registryKey5 = Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\Run");
				registryKey5.GetValueNames();
				RegistryKey registryKey6 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\Run32");
				registryKey6.GetValueNames();
				RegistryKey registryKey7 = Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\StartupFolder");
				RegistryKey registryKey8 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\StartupFolder");
				Label[] array4 = new Label[num];
				Label[] array5 = new Label[num2];
				Label[] array6 = new Label[num3];
				Label[] array7 = new Label[num4];
				Label[] array8 = new Label[num5];
				Label[] array9 = new Label[num6];
				Button[] array10 = new Button[num];
				Button[] array11 = new Button[num2];
				Button[] array12 = new Button[num3];
				Button[] array13 = new Button[num4];
				Button[] array14 = new Button[num5];
				Button[] array15 = new Button[num6];
				int height = this.CloseIcon.Height;
				int num7 = this.autorunpanel.Width * 30 / 100;
				int num8 = num7 + num7 * 5 / 100;
				int width = this.autorunpanel.Width - num8 - num7 * 15 / 100;
				if (num != 0)
				{
					for (int i = 0; i < num; i++)
					{
						array4[i] = new Label();
						array4[i].Click += this.Label_Click_HKLM;
						try
						{
							array4[i].Name = BitConverter.ToString((byte[])registryKey4.GetValue(valueNames[i] ?? "")).Replace("-", "");
							if (array4[i].Name.Contains("0200"))
							{
								array4[i].ForeColor = GClass2.GClass2_0.color_1;
							}
							else
							{
								array4[i].ForeColor = GClass2.GClass2_0.color_2;
							}
						}
						catch
						{
							array4[i].ForeColor = GClass2.GClass2_0.color_1;
						}
						array4[i].Text = (valueNames[i] ?? "");
						array4[i].AutoEllipsis = true;
						array4[i].Size = new Size(num7, height);
						array4[i].Location = new Point(0, i * height);
						array4[i].Padding = new Padding(4, 4, 4, 4);
						if (!GClass2.GClass2_0.String_3.Contains("7"))
						{
							array10[i] = new Button
							{
								FlatStyle = FlatStyle.Flat
							};
							this.StartupControlsView(array10[i], array4[i], registryKey, registryKey4, false, false);
							this.autorunpanel.Controls.Add(array10[i]);
						}
						this.autorunpanel.Controls.Add(array4[i]);
					}
				}
				if (num2 != 0)
				{
					for (int j = 0; j < num2; j++)
					{
						array5[j] = new Label();
						array5[j].Click += this.Label_Click_HKCU;
						try
						{
							array5[j].Name = BitConverter.ToString((byte[])registryKey5.GetValue(valueNames2[j] ?? "")).Replace("-", "");
							if (!array5[j].Name.Contains("0200"))
							{
								array5[j].ForeColor = GClass2.GClass2_0.color_2;
							}
							else
							{
								array5[j].ForeColor = GClass2.GClass2_0.color_1;
							}
						}
						catch
						{
							array5[j].ForeColor = GClass2.GClass2_0.color_1;
						}
						array5[j].Text = (valueNames2[j] ?? "");
						array5[j].AutoEllipsis = true;
						array5[j].Size = new Size(num7, height);
						array5[j].Location = new Point(0, (j + num) * height);
						array5[j].Padding = new Padding(4, 4, 4, 4);
						if (!GClass2.GClass2_0.String_3.Contains("7"))
						{
							array11[j] = new Button
							{
								FlatStyle = FlatStyle.Flat
							};
							this.StartupControlsView(array11[j], array5[j], registryKey2, registryKey5, false, false);
							this.autorunpanel.Controls.Add(array11[j]);
						}
						this.autorunpanel.Controls.Add(array5[j]);
					}
				}
				if (num3 != 0)
				{
					for (int k = 0; k < num3; k++)
					{
						array6[k] = new Label();
						array6[k].Click += this.Label_Click_WOW6432Node;
						try
						{
							array6[k].Name = BitConverter.ToString((byte[])registryKey6.GetValue(valueNames3[k] ?? "")).Replace("-", "");
							if (array6[k].Name.Contains("0200"))
							{
								array6[k].ForeColor = GClass2.GClass2_0.color_1;
							}
							else
							{
								array6[k].ForeColor = GClass2.GClass2_0.color_2;
							}
						}
						catch
						{
							array6[k].ForeColor = GClass2.GClass2_0.color_1;
						}
						array6[k].Text = (valueNames3[k] ?? "");
						array6[k].AutoEllipsis = true;
						array6[k].Size = new Size(num7, height);
						array6[k].Location = new Point(0, (k + num + num2) * height);
						array6[k].Padding = new Padding(4, 4, 4, 4);
						if (!GClass2.GClass2_0.String_3.Contains("7"))
						{
							array12[k] = new Button
							{
								FlatStyle = FlatStyle.Flat
							};
							this.StartupControlsView(array12[k], array6[k], registryKey3, registryKey6, false, false);
							this.autorunpanel.Controls.Add(array12[k]);
						}
						this.autorunpanel.Controls.Add(array6[k]);
					}
				}
				if (num4 != 0)
				{
					for (int l = 0; l < num4; l++)
					{
						array7[l] = new Label();
						array7[l].Click += this.Lbl_click_Startup;
						try
						{
							array7[l].Name = BitConverter.ToString((byte[])registryKey7.GetValue(array[l] ?? "")).Replace("-", "");
							if (array7[l].Name.Contains("0200"))
							{
								array7[l].ForeColor = GClass2.GClass2_0.color_1;
							}
							else
							{
								array7[l].ForeColor = GClass2.GClass2_0.color_2;
							}
						}
						catch
						{
							array7[l].ForeColor = GClass2.GClass2_0.color_1;
						}
						array7[l].Text = (array[l].Replace(".lnk", "") ?? "");
						array7[l].Tag = "hkcu";
						array7[l].AutoEllipsis = true;
						array7[l].Size = new Size(num7, height);
						array7[l].Location = new Point(0, (l + num + num2 + num3) * height);
						array7[l].Padding = new Padding(4, 4, 4, 4);
						if (!GClass2.GClass2_0.String_3.Contains("7"))
						{
							array13[l] = new Button
							{
								FlatStyle = FlatStyle.Flat
							};
							this.StartupControlsView(array13[l], array7[l], null, null, true, false);
							this.autorunpanel.Controls.Add(array13[l]);
						}
						this.autorunpanel.Controls.Add(array7[l]);
					}
				}
				if (num5 != 0)
				{
					for (int m = 0; m < num5; m++)
					{
						array8[m] = new Label();
						array8[m].Click += this.Lbl_click_Startup;
						try
						{
							array8[m].Name = BitConverter.ToString((byte[])registryKey8.GetValue(array2[m] ?? "")).Replace("-", "");
							if (array8[m].Name.Contains("0200"))
							{
								array8[m].ForeColor = GClass2.GClass2_0.color_1;
							}
							else
							{
								array8[m].ForeColor = GClass2.GClass2_0.color_2;
							}
						}
						catch
						{
							array8[m].ForeColor = GClass2.GClass2_0.color_1;
						}
						array8[m].Text = (array2[m].Replace(".lnk", "") ?? "");
						array8[m].AutoEllipsis = true;
						array8[m].Size = new Size(num7, height);
						array8[m].Location = new Point(0, (m + num + num2 + num3 + num4) * height);
						array8[m].Padding = new Padding(4, 4, 4, 4);
						if (!GClass2.GClass2_0.String_3.Contains("7"))
						{
							array14[m] = new Button
							{
								FlatStyle = FlatStyle.Flat
							};
							this.StartupControlsView(array14[m], array8[m], null, null, true, false);
							this.autorunpanel.Controls.Add(array14[m]);
						}
						this.autorunpanel.Controls.Add(array8[m]);
					}
				}
				if (num6 != 0)
				{
					for (int n = 0; n < num6; n++)
					{
						array9[n] = new Label();
						array9[n].Click += this.Lbl_click_Tasks;
						try
						{
							if (!File.ReadAllText(GClass13.string_6 + "\\System32\\Tasks\\" + array3[n]).ToString().Contains("<Enabled>false</Enabled>"))
							{
								array9[n].ForeColor = GClass2.GClass2_0.color_1;
							}
							else
							{
								array9[n].ForeColor = GClass2.GClass2_0.color_2;
							}
						}
						catch
						{
							array9[n].ForeColor = GClass2.GClass2_0.color_1;
						}
						array9[n].Text = (array3[n] ?? "");
						array9[n].AutoEllipsis = true;
						array9[n].Size = new Size(num7, height);
						array9[n].Location = new Point(0, (n + num + num2 + num3 + num4 + num5) * height);
						array9[n].Padding = new Padding(4, 4, 4, 4);
						if (!GClass2.GClass2_0.String_3.Contains("7"))
						{
							array15[n] = new Button
							{
								FlatStyle = FlatStyle.Flat
							};
							this.StartupControlsView(array15[n], array9[n], null, null, false, true);
							this.autorunpanel.Controls.Add(array15[n]);
						}
						this.autorunpanel.Controls.Add(array9[n]);
					}
				}
				if (num != 0)
				{
					for (int num9 = 0; num9 < num; num9++)
					{
						array4[num9] = new Label
						{
							ForeColor = this.Blue,
							Text = string.Format("{0}", registryKey.GetValue(valueNames[num9]))
						};
						this.tooltip.SetToolTip(array4[num9], string.Format("{0}\n{1}", registryKey.GetValue(valueNames[num9]), GClass2.GClass2_0.method_1("StartupForAll")));
						array4[num9].Size = new Size(width, height);
						array4[num9].AutoEllipsis = true;
						array4[num9].Location = new Point(num8, num9 * height);
						array4[num9].Padding = new Padding(4, 4, 4, 4);
						array4[num9].Click += delegate(object sender, EventArgs e)
						{
							this.OpenRegedit("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run");
						};
						this.autorunpanel.Controls.Add(array4[num9]);
					}
				}
				if (num2 != 0)
				{
					for (int num10 = 0; num10 < num2; num10++)
					{
						array5[num10] = new Label
						{
							ForeColor = this.Blue,
							Text = string.Format("{0}", registryKey2.GetValue(valueNames2[num10]))
						};
						this.tooltip.SetToolTip(array5[num10], string.Format("{0}\n{1}", registryKey2.GetValue(valueNames2[num10]), GClass2.GClass2_0.method_1("StartupForCurrent")));
						array5[num10].Size = new Size(width, height);
						array5[num10].AutoEllipsis = true;
						array5[num10].Location = new Point(num8, (num10 + num) * height);
						array5[num10].Padding = new Padding(4, 4, 4, 4);
						array5[num10].Click += delegate(object sender, EventArgs e)
						{
							this.OpenRegedit("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run");
						};
						this.autorunpanel.Controls.Add(array5[num10]);
					}
				}
				if (num3 != 0)
				{
					for (int num11 = 0; num11 < num3; num11++)
					{
						array6[num11] = new Label
						{
							ForeColor = this.Blue,
							Text = string.Format("{0}", registryKey3.GetValue(valueNames3[num11]))
						};
						this.tooltip.SetToolTip(array6[num11], string.Format("{0}\n{1}", registryKey3.GetValue(valueNames3[num11]), GClass2.GClass2_0.method_1("StartupForAll32")));
						array6[num11].Size = new Size(width, height);
						array6[num11].AutoEllipsis = true;
						array6[num11].Location = new Point(num8, (num11 + num + num2) * height);
						array6[num11].Padding = new Padding(4, 4, 4, 4);
						array6[num11].Click += delegate(object sender, EventArgs e)
						{
							this.OpenRegedit("HKEY_LOCAL_MACHINE\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run");
						};
						this.autorunpanel.Controls.Add(array6[num11]);
					}
				}
				if (num4 != 0)
				{
					for (int num12 = 0; num12 < num4; num12++)
					{
						array7[num12] = new Label
						{
							ForeColor = this.Blue,
							Text = this.Lnk(GClass2.GClass2_0.String_13 + "\\" + array[num12])
						};
						this.tooltip.SetToolTip(array7[num12], string.Concat(new string[]
						{
							GClass2.GClass2_0.method_1("StartupShortcut1"),
							"\n",
							GClass2.GClass2_0.String_15,
							GClass2.GClass2_0.method_1("StartupShortcut2"),
							GClass2.GClass2_0.String_9,
							GClass2.GClass2_0.method_1("StartupShortcut3"),
							"\n",
							GClass2.GClass2_0.method_1("StartupShortcut4"),
							"\n",
							this.Lnk(GClass2.GClass2_0.String_13 + "\\" + array[num12])
						}));
						array7[num12].Size = new Size(width, height);
						array7[num12].AutoEllipsis = true;
						array7[num12].Location = new Point(num8, (num12 + num + num2 + num3) * height);
						array7[num12].Padding = new Padding(4, 4, 4, 4);
						array7[num12].Click += delegate(object sender, EventArgs e)
						{
							Process.Start(new ProcessStartInfo
							{
								FileName = "explorer",
								Arguments = "/n, /select, " + GClass2.GClass2_0.String_13
							});
						};
						this.autorunpanel.Controls.Add(array7[num12]);
					}
				}
				if (num5 != 0)
				{
					for (int num13 = 0; num13 < num5; num13++)
					{
						array8[num13] = new Label
						{
							ForeColor = this.Blue,
							Text = this.Lnk(GClass2.GClass2_0.String_14 + "\\" + array2[num13])
						};
						this.tooltip.SetToolTip(array8[num13], string.Concat(new string[]
						{
							GClass2.GClass2_0.method_1("StartupShortcut1"),
							"\n",
							GClass13.string_11,
							"\\Microsoft\\Windows",
							GClass2.GClass2_0.method_1("StartupShortcut3"),
							"\n",
							GClass2.GClass2_0.method_1("StartupShortcut4"),
							"\n",
							this.Lnk(GClass2.GClass2_0.String_14 + "\\" + array2[num13])
						}));
						array8[num13].Size = new Size(width, height);
						array8[num13].AutoEllipsis = true;
						array8[num13].Location = new Point(num8, (num13 + num + num2 + num3 + num4) * height);
						array8[num13].Padding = new Padding(4, 4, 4, 4);
						array8[num13].Click += delegate(object sender, EventArgs e)
						{
							Process.Start(new ProcessStartInfo
							{
								FileName = "explorer",
								Arguments = "/n, /select, " + GClass2.GClass2_0.String_14
							});
						};
						this.autorunpanel.Controls.Add(array8[num13]);
					}
				}
				if (num6 != 0)
				{
					for (int num14 = 0; num14 < num6; num14++)
					{
						array9[num14] = new Label
						{
							ForeColor = this.Blue
						};
						array9[num14].Text = (from line in File.ReadAllLines(GClass13.string_6 + "\\System32\\Tasks\\" + array3[num14])
						where line.Contains("<Command>")
						select line.Replace("<Command>", "").Replace("</Command>", "")).FirstOrDefault<string>().Trim();
						this.tooltip.SetToolTip(array9[num14], array9[num14].Text + "\n" + GClass2.GClass2_0.method_1("StartupScheduler"));
						array9[num14].Size = new Size(width, height);
						array9[num14].AutoEllipsis = true;
						array9[num14].Location = new Point(num8, (num14 + num + num2 + num3 + num4 + num5) * height);
						array9[num14].Padding = new Padding(4, 4, 4, 4);
						array9[num14].Click += delegate(object sender, EventArgs e)
						{
							Process.Start("taskschd.msc");
						};
						this.autorunpanel.Controls.Add(array9[num14]);
					}
				}
			}
			catch
			{
				Label value = new Label
				{
					Font = new Font("Verdana", 12.75f),
					AutoSize = true,
					ForeColor = Color.FromArgb(147, 179, 220),
					Text = GClass2.GClass2_0.method_1("StartupError"),
					TextAlign = ContentAlignment.MiddleCenter,
					Location = new Point(7, 0)
				};
				this.autorunpanel.Controls.Add(value);
			}
		}

		// Token: 0x06000C63 RID: 3171 RVA: 0x0003E97C File Offset: 0x0003CB7C
		private void StartupControlsView(Control button, Label label, RegistryKey key1, RegistryKey key2, bool lnk = false, bool tasks = false)
		{
			Form1.<>c__DisplayClass84_0 CS$<>8__locals1 = new Form1.<>c__DisplayClass84_0();
			CS$<>8__locals1.key1 = key1;
			CS$<>8__locals1.key2 = key2;
			CS$<>8__locals1.<>4__this = this;
			CS$<>8__locals1.label = label;
			CS$<>8__locals1.button = button;
			CS$<>8__locals1.closeHeight = this.CloseIcon.Height;
			CS$<>8__locals1.button.Name = CS$<>8__locals1.label.Text;
			CS$<>8__locals1.button.BackColor = ((!(GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "DarkSkin")) ? this.Backcolor : Color.FromArgb(67, 77, 107));
			CS$<>8__locals1.button.BackgroundImage = Class89.Bitmap_17;
			CS$<>8__locals1.button.BackgroundImageLayout = ImageLayout.Stretch;
			CS$<>8__locals1.button.Size = new Size(CS$<>8__locals1.closeHeight, CS$<>8__locals1.closeHeight);
			CS$<>8__locals1.button.Visible = false;
			if (!lnk && !tasks)
			{
				CS$<>8__locals1.button.Click += delegate(object sender, EventArgs e)
				{
					string name = ((Button)sender).Name;
					using (CS$<>8__locals1.key1)
					{
						if (CS$<>8__locals1.key1.GetValue(name) != null)
						{
							CS$<>8__locals1.key1.DeleteValue(name);
						}
					}
					using (CS$<>8__locals1.key2)
					{
						if (CS$<>8__locals1.key2.GetValue(name) != null)
						{
							CS$<>8__locals1.key2.DeleteValue(name);
						}
					}
					CS$<>8__locals1.<>4__this.Autoruns();
				};
			}
			else if (lnk)
			{
				CS$<>8__locals1.button.Click += delegate(object sender, EventArgs e)
				{
					string text = CS$<>8__locals1.label.Text + ".lnk";
					string path = GClass2.GClass2_0.String_13 + "\\" + text;
					if (File.Exists(path))
					{
						File.Delete(path);
						using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\StartupFolder", true))
						{
							if (registryKey != null && registryKey.GetValue(text) != null)
							{
								registryKey.DeleteValue(text);
							}
							goto IL_E1;
						}
					}
					File.Delete(GClass2.GClass2_0.String_14 + "\\" + CS$<>8__locals1.label.Text + ".lnk");
					using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\StartupFolder", true))
					{
						if (registryKey2 != null && registryKey2.GetValue(text) != null)
						{
							registryKey2.DeleteValue(text);
						}
					}
					IL_E1:
					CS$<>8__locals1.<>4__this.Autoruns();
				};
			}
			else if (tasks)
			{
				CS$<>8__locals1.button.Click += delegate(object sender, EventArgs e)
				{
					GClass6.GClass6_0.method_15("schtasks /delete /tn \"" + CS$<>8__locals1.label.Text + "\" /f");
					CS$<>8__locals1.<>4__this.Autoruns();
				};
			}
			CS$<>8__locals1.color = this.Backcolor;
			CS$<>8__locals1.label.MouseEnter += delegate(object sender, EventArgs e)
			{
				Form1.<>c__DisplayClass84_0.<<StartupControlsView>b__3>d <<StartupControlsView>b__3>d;
				<<StartupControlsView>b__3>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<StartupControlsView>b__3>d.<>4__this = CS$<>8__locals1;
				<<StartupControlsView>b__3>d.<>1__state = -1;
				<<StartupControlsView>b__3>d.<>t__builder.Start<Form1.<>c__DisplayClass84_0.<<StartupControlsView>b__3>d>(ref <<StartupControlsView>b__3>d);
			};
			CS$<>8__locals1.label.MouseLeave += delegate(object sender, EventArgs e)
			{
				CS$<>8__locals1.label.BackColor = Color.Transparent;
			};
		}

		// Token: 0x06000C64 RID: 3172 RVA: 0x0003EAF4 File Offset: 0x0003CCF4
		private void Label_Click_HKLM(object sender, EventArgs e)
		{
			byte[] array = new byte[12];
			array[0] = 2;
			byte[] value = array;
			byte[] array2 = new byte[12];
			array2[0] = 3;
			byte[] value2 = array2;
			if (!GClass2.GClass2_0.String_3.Contains("7"))
			{
				try
				{
					RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\Run", true);
					if (!BitConverter.ToString((byte[])registryKey.GetValue(((Label)sender).Text)).Replace("-", "").Contains("0200"))
					{
						registryKey.SetValue(((Label)sender).Text, value, RegistryValueKind.Binary);
						registryKey.Close();
						((Label)sender).ForeColor = GClass2.GClass2_0.color_1;
					}
					else
					{
						if (registryKey != null)
						{
							registryKey.SetValue(((Label)sender).Text, value2, RegistryValueKind.Binary);
						}
						registryKey.Close();
						((Label)sender).ForeColor = GClass2.GClass2_0.color_2;
					}
					return;
				}
				catch
				{
					Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\Run").SetValue(((Label)sender).Text, value2);
					((Label)sender).ForeColor = GClass2.GClass2_0.color_2;
					return;
				}
			}
			if (WMessageBox.smethod_3(string.Concat(new string[]
			{
				GClass2.GClass2_0.method_1("StartupConfirm1"),
				" ",
				((Label)sender).Text,
				" ",
				GClass2.GClass2_0.method_1("StartupConfirm2")
			}), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
			{
				Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Run", true).DeleteValue(((Label)sender).Text);
				this.Autoruns();
				this.Autoruns();
			}
		}

		// Token: 0x06000C65 RID: 3173 RVA: 0x0003ECE8 File Offset: 0x0003CEE8
		private void Label_Click_HKCU(object sender, EventArgs e)
		{
			byte[] array = new byte[12];
			array[0] = 2;
			byte[] value = array;
			byte[] array2 = new byte[12];
			array2[0] = 3;
			byte[] value2 = array2;
			if (!GClass2.GClass2_0.String_3.Contains("7"))
			{
				try
				{
					RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\Run", true);
					if (BitConverter.ToString((byte[])registryKey.GetValue(((Label)sender).Text)).Replace("-", "").Contains("0200"))
					{
						registryKey.SetValue(((Label)sender).Text, value2, RegistryValueKind.Binary);
						registryKey.Close();
						((Label)sender).ForeColor = GClass2.GClass2_0.color_2;
					}
					else
					{
						registryKey.SetValue(((Label)sender).Text, value, RegistryValueKind.Binary);
						registryKey.Close();
						((Label)sender).ForeColor = GClass2.GClass2_0.color_1;
					}
					return;
				}
				catch
				{
					Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\Run").SetValue(((Label)sender).Text, value2);
					((Label)sender).ForeColor = GClass2.GClass2_0.color_2;
					return;
				}
			}
			if (WMessageBox.smethod_3(string.Concat(new string[]
			{
				GClass2.GClass2_0.method_1("StartupConfirm1"),
				" ",
				((Label)sender).Text,
				" ",
				GClass2.GClass2_0.method_1("StartupConfirm2")
			}), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
			{
				Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Run", true).DeleteValue(((Label)sender).Text);
				this.Autoruns();
				this.Autoruns();
			}
		}

		// Token: 0x06000C66 RID: 3174 RVA: 0x0003EED8 File Offset: 0x0003D0D8
		private void Label_Click_WOW6432Node(object sender, EventArgs e)
		{
			byte[] array = new byte[12];
			array[0] = 2;
			byte[] value = array;
			byte[] array2 = new byte[12];
			array2[0] = 3;
			byte[] value2 = array2;
			if (!GClass2.GClass2_0.String_3.Contains("7"))
			{
				try
				{
					RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\Run32", true);
					if (BitConverter.ToString((byte[])registryKey.GetValue(((Label)sender).Text)).Replace("-", "").Contains("0200"))
					{
						registryKey.SetValue(((Label)sender).Text, value2, RegistryValueKind.Binary);
						registryKey.Close();
						((Label)sender).ForeColor = GClass2.GClass2_0.color_2;
					}
					else
					{
						registryKey.SetValue(((Label)sender).Text, value, RegistryValueKind.Binary);
						registryKey.Close();
						((Label)sender).ForeColor = GClass2.GClass2_0.color_1;
					}
					return;
				}
				catch
				{
					Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\Run32").SetValue(((Label)sender).Text, value2);
					((Label)sender).ForeColor = GClass2.GClass2_0.color_2;
					return;
				}
			}
			if (WMessageBox.smethod_3(string.Concat(new string[]
			{
				GClass2.GClass2_0.method_1("StartupConfirm1"),
				" ",
				((Label)sender).Text,
				" ",
				GClass2.GClass2_0.method_1("StartupConfirm2")
			}), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
			{
				Registry.LocalMachine.OpenSubKey("SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run", true).DeleteValue(((Label)sender).Text);
				this.Autoruns();
				this.Autoruns();
			}
		}

		// Token: 0x06000C67 RID: 3175 RVA: 0x0003F0B8 File Offset: 0x0003D2B8
		private string Lnk(string lnkname)
		{
			string directoryName = Path.GetDirectoryName(lnkname);
			string fileName = Path.GetFileName(lnkname);
			if (Form1.<>o__88.<>p__0 == null)
			{
				Form1.<>o__88.<>p__0 = CallSite<Func<CallSite, object, GInterface12>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(GInterface12), typeof(Form1)));
			}
			return Form1.<>o__88.<>p__0.Target(Form1.<>o__88.<>p__0, ((GInterface11)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("13709620-C279-11CE-A49E-444553540000")))).imethod_0(directoryName).imethod_0(fileName).Object_0).String_0;
		}

		// Token: 0x06000C68 RID: 3176 RVA: 0x0003F144 File Offset: 0x0003D344
		private void Lbl_click_Startup(object sender, EventArgs e)
		{
			byte[] array = new byte[12];
			array[0] = 2;
			byte[] value = array;
			byte[] array2 = new byte[12];
			array2[0] = 3;
			byte[] value2 = array2;
			if (!GClass2.GClass2_0.String_3.Contains("7"))
			{
				try
				{
					RegistryKey registryKey = (!(((Label)sender).Tag as string == "hkcu")) ? Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\StartupFolder", true) : Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\StartupFolder", true);
					if (BitConverter.ToString((byte[])registryKey.GetValue(((Label)sender).Text + ".lnk")).Replace("-", "").Contains("0200"))
					{
						registryKey.SetValue(((Label)sender).Text + ".lnk", value2, RegistryValueKind.Binary);
						registryKey.Close();
						((Label)sender).ForeColor = GClass2.GClass2_0.color_2;
					}
					else
					{
						registryKey.SetValue(((Label)sender).Text + ".lnk", value, RegistryValueKind.Binary);
						registryKey.Close();
						((Label)sender).ForeColor = GClass2.GClass2_0.color_1;
					}
					return;
				}
				catch
				{
					((((Label)sender).Tag as string == "hkcu") ? Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\StartupFolder") : Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\StartupApproved\\StartupFolder")).SetValue(((Label)sender).Text + ".lnk", value2);
					((Label)sender).ForeColor = GClass2.GClass2_0.color_2;
					return;
				}
			}
			if (WMessageBox.smethod_3(string.Concat(new string[]
			{
				GClass2.GClass2_0.method_1("StartupConfirm1"),
				" ",
				((Label)sender).Text,
				" ",
				GClass2.GClass2_0.method_1("StartupConfirm2")
			}), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
			{
				File.Delete(GClass2.GClass2_0.String_13 + "\\" + ((Label)sender).Text + ".lnk");
				this.Autoruns();
				this.Autoruns();
			}
		}

		// Token: 0x06000C69 RID: 3177 RVA: 0x0003F3DC File Offset: 0x0003D5DC
		private void Lbl_click_Tasks(object sender, EventArgs e)
		{
			try
			{
				if (!File.ReadAllText(GClass13.string_6 + "\\System32\\Tasks\\" + ((Label)sender).Text).ToString().Contains("<Enabled>false</Enabled>"))
				{
					GClass6.GClass6_0.method_14("schtasks /change /TN \"" + ((Label)sender).Text + "\" /disable");
					((Label)sender).ForeColor = GClass2.GClass2_0.color_2;
				}
				else
				{
					GClass6.GClass6_0.method_14("schtasks /change /TN \"" + ((Label)sender).Text + "\" /enable");
					((Label)sender).ForeColor = GClass2.GClass2_0.color_1;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000C6A RID: 3178 RVA: 0x0003F4A4 File Offset: 0x0003D6A4
		private void OpenRegedit(string line)
		{
			try
			{
				Process[] processesByName = Process.GetProcessesByName("regedit");
				for (int i = 0; i < processesByName.Length; i++)
				{
					processesByName[i].Kill();
				}
				Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Applets\\Regedit").SetValue("LastKey", line);
				Process.Start("regedit.exe");
			}
			catch
			{
			}
		}

		// Token: 0x06000C6B RID: 3179 RVA: 0x00006DEA File Offset: 0x00004FEA
		private void Autorunpanel_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				e.Effect = DragDropEffects.Copy;
			}
		}

		// Token: 0x06000C6C RID: 3180 RVA: 0x0003F51C File Offset: 0x0003D71C
		private void Autorunpanel_DragDrop(object sender, DragEventArgs e)
		{
			Form1.<Autorunpanel_DragDrop>d__93 <Autorunpanel_DragDrop>d__;
			<Autorunpanel_DragDrop>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Autorunpanel_DragDrop>d__.<>4__this = this;
			<Autorunpanel_DragDrop>d__.e = e;
			<Autorunpanel_DragDrop>d__.<>1__state = -1;
			<Autorunpanel_DragDrop>d__.<>t__builder.Start<Form1.<Autorunpanel_DragDrop>d__93>(ref <Autorunpanel_DragDrop>d__);
		}

		// Token: 0x06000C6D RID: 3181 RVA: 0x00006E05 File Offset: 0x00005005
		public int CountFiles(string path)
		{
			return Directory.GetFiles(path, "*", SearchOption.AllDirectories).Length;
		}

		// Token: 0x06000C6E RID: 3182 RVA: 0x0003F55C File Offset: 0x0003D75C
		private bool OptWorking()
		{
			return this.tip1.Text.Contains(":") || this.tip2.Text.Contains(":") || this.tip3.Text.Contains(":") || this.tip4.Text.Contains(":");
		}

		// Token: 0x06000C6F RID: 3183 RVA: 0x0003F5C8 File Offset: 0x0003D7C8
		private void Compress1_Click(object sender, EventArgs e)
		{
			if (this.OptRadioButton1.Checked | this.OptRadioButton2.Checked | this.OptRadioButton3.Checked | this.OptRadioButton4.Checked)
			{
				Form1.OpenDim(false);
				this.Compactos1();
				this.progressBar1.Visible = true;
				this.PanelOffer.Location = new Point(0, this.PanelOffer.Location.Y);
				base.TopMost = true;
				return;
			}
			WMessageBox.smethod_3(GClass2.GClass2_0.method_1("ChooseCompressionMethod"), "", WMessageBox.GEnum2.OK, false, "", null);
		}

		// Token: 0x06000C70 RID: 3184 RVA: 0x0003F66C File Offset: 0x0003D86C
		private void Restore1_Click(object sender, EventArgs e)
		{
			if (WMessageBox.smethod_3(GClass2.GClass2_0.method_1("OptSure"), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
			{
				Form1.OpenDim(false);
				this.Restorecompactos1();
				this.progressBar1.Visible = true;
				this.PanelOffer.Location = new Point(0, this.PanelOffer.Location.Y);
				base.TopMost = true;
			}
		}

		// Token: 0x06000C71 RID: 3185 RVA: 0x0003F6E0 File Offset: 0x0003D8E0
		private void Compactos1()
		{
			Form1.<Compactos1>d__98 <Compactos1>d__;
			<Compactos1>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Compactos1>d__.<>4__this = this;
			<Compactos1>d__.<>1__state = -1;
			<Compactos1>d__.<>t__builder.Start<Form1.<Compactos1>d__98>(ref <Compactos1>d__);
		}

		// Token: 0x06000C72 RID: 3186 RVA: 0x0003F718 File Offset: 0x0003D918
		private void Change11()
		{
			this.compress1.Visible = false;
			this.restore1.Visible = false;
			this.checker1.Text = "";
			this.tip1.Text = GClass2.GClass2_0.method_1("OptWaitCompress");
			this.tip1.Font = new Font("Verdana", 12.75f);
		}

		// Token: 0x06000C73 RID: 3187 RVA: 0x0003F784 File Offset: 0x0003D984
		private void Change12()
		{
			Form1.<Change12>d__100 <Change12>d__;
			<Change12>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Change12>d__.<>4__this = this;
			<Change12>d__.<>1__state = -1;
			<Change12>d__.<>t__builder.Start<Form1.<Change12>d__100>(ref <Change12>d__);
		}

		// Token: 0x06000C74 RID: 3188 RVA: 0x0003F7BC File Offset: 0x0003D9BC
		private void Restorecompactos1()
		{
			Form1.<Restorecompactos1>d__101 <Restorecompactos1>d__;
			<Restorecompactos1>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Restorecompactos1>d__.<>4__this = this;
			<Restorecompactos1>d__.<>1__state = -1;
			<Restorecompactos1>d__.<>t__builder.Start<Form1.<Restorecompactos1>d__101>(ref <Restorecompactos1>d__);
		}

		// Token: 0x06000C75 RID: 3189 RVA: 0x0003F7F4 File Offset: 0x0003D9F4
		private void Compress2_Click(object sender, EventArgs e)
		{
			Form1.OpenDim(false);
			this.Pb2();
			this.Compactos2();
			this.progressBar2.Visible = true;
			this.PanelOffer.Location = new Point(0, this.PanelOffer.Location.Y);
			base.TopMost = true;
		}

		// Token: 0x06000C76 RID: 3190 RVA: 0x0003F84C File Offset: 0x0003DA4C
		private void Restore2_Click(object sender, EventArgs e)
		{
			if (WMessageBox.smethod_3(GClass2.GClass2_0.method_1("OptSure"), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
			{
				Form1.OpenDim(false);
				this.Pb2();
				this.Restorecompactos2();
				this.progressBar2.Visible = true;
				this.PanelOffer.Location = new Point(0, this.PanelOffer.Location.Y);
				base.TopMost = true;
			}
		}

		// Token: 0x06000C77 RID: 3191 RVA: 0x0003F8C8 File Offset: 0x0003DAC8
		private void Compactos2()
		{
			Form1.<Compactos2>d__104 <Compactos2>d__;
			<Compactos2>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Compactos2>d__.<>4__this = this;
			<Compactos2>d__.<>1__state = -1;
			<Compactos2>d__.<>t__builder.Start<Form1.<Compactos2>d__104>(ref <Compactos2>d__);
		}

		// Token: 0x06000C78 RID: 3192 RVA: 0x0003F900 File Offset: 0x0003DB00
		private void Restorecompactos2()
		{
			Form1.<Restorecompactos2>d__105 <Restorecompactos2>d__;
			<Restorecompactos2>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Restorecompactos2>d__.<>4__this = this;
			<Restorecompactos2>d__.<>1__state = -1;
			<Restorecompactos2>d__.<>t__builder.Start<Form1.<Restorecompactos2>d__105>(ref <Restorecompactos2>d__);
		}

		// Token: 0x06000C79 RID: 3193 RVA: 0x0003F938 File Offset: 0x0003DB38
		private void Pb2()
		{
			Form1.<Pb2>d__106 <Pb2>d__;
			<Pb2>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Pb2>d__.<>4__this = this;
			<Pb2>d__.<>1__state = -1;
			<Pb2>d__.<>t__builder.Start<Form1.<Pb2>d__106>(ref <Pb2>d__);
		}

		// Token: 0x06000C7A RID: 3194 RVA: 0x0003F970 File Offset: 0x0003DB70
		private void Compress3_Click(object sender, EventArgs e)
		{
			Form1.OpenDim(false);
			this.Compactos3();
			this.progressBar3.Visible = true;
			this.PanelOffer.Location = new Point(0, this.PanelOffer.Location.Y);
			base.TopMost = true;
		}

		// Token: 0x06000C7B RID: 3195 RVA: 0x0003F9C0 File Offset: 0x0003DBC0
		private void Restore3_Click(object sender, EventArgs e)
		{
			if (WMessageBox.smethod_3(GClass2.GClass2_0.method_1("OptSure"), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
			{
				Form1.OpenDim(false);
				this.Restorecompactos3();
				this.progressBar3.Visible = true;
				this.PanelOffer.Location = new Point(0, this.PanelOffer.Location.Y);
				base.TopMost = true;
			}
		}

		// Token: 0x06000C7C RID: 3196 RVA: 0x0003FA34 File Offset: 0x0003DC34
		private void Compactos3()
		{
			Form1.<Compactos3>d__109 <Compactos3>d__;
			<Compactos3>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Compactos3>d__.<>4__this = this;
			<Compactos3>d__.<>1__state = -1;
			<Compactos3>d__.<>t__builder.Start<Form1.<Compactos3>d__109>(ref <Compactos3>d__);
		}

		// Token: 0x06000C7D RID: 3197 RVA: 0x0003FA6C File Offset: 0x0003DC6C
		private void Change31()
		{
			this.compress3.Visible = false;
			this.restore3.Visible = false;
			this.checker3.Text = "";
			this.tip3.Text = GClass2.GClass2_0.method_1("OptWaitCompress");
			this.tip3.Font = new Font("Verdana", 12.75f);
		}

		// Token: 0x06000C7E RID: 3198 RVA: 0x0003FAD8 File Offset: 0x0003DCD8
		private void Change32()
		{
			Form1.<Change32>d__111 <Change32>d__;
			<Change32>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Change32>d__.<>4__this = this;
			<Change32>d__.<>1__state = -1;
			<Change32>d__.<>t__builder.Start<Form1.<Change32>d__111>(ref <Change32>d__);
		}

		// Token: 0x06000C7F RID: 3199 RVA: 0x0003FB10 File Offset: 0x0003DD10
		private void Restorecompactos3()
		{
			Form1.<Restorecompactos3>d__112 <Restorecompactos3>d__;
			<Restorecompactos3>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Restorecompactos3>d__.<>4__this = this;
			<Restorecompactos3>d__.<>1__state = -1;
			<Restorecompactos3>d__.<>t__builder.Start<Form1.<Restorecompactos3>d__112>(ref <Restorecompactos3>d__);
		}

		// Token: 0x06000C80 RID: 3200 RVA: 0x0003FB48 File Offset: 0x0003DD48
		private void Compress4_Click(object sender, EventArgs e)
		{
			Form1.OpenDim(false);
			this.Pb4();
			new Thread(delegate()
			{
				this.Compactos4();
			})
			{
				IsBackground = true
			}.Start();
			this.progressBar4.Visible = true;
			this.PanelOffer.Location = new Point(0, this.PanelOffer.Location.Y);
			base.TopMost = true;
		}

		// Token: 0x06000C81 RID: 3201 RVA: 0x0003FBB8 File Offset: 0x0003DDB8
		private void Compactos4()
		{
			DriveInfo driveInfo = new DriveInfo(Path.GetPathRoot(Environment.SystemDirectory));
			double num = (double)driveInfo.AvailableFreeSpace;
			this.Change41();
			GClass6.GClass6_0.method_15("dism /online /cleanup-image /startcomponentcleanup");
			this.PanelOffer.Location = new Point(base.Width, this.PanelOffer.Location.Y);
			double double_ = (double)driveInfo.AvailableFreeSpace - num;
			this.tip4.Text = (GClass2.GClass2_0.method_1("OptCleanedUp") + " " + GClass6.GClass6_0.method_6(double_)).Replace("-", "");
			this.Change42();
		}

		// Token: 0x06000C82 RID: 3202 RVA: 0x0003FC68 File Offset: 0x0003DE68
		private void Change41()
		{
			this.compress4.Visible = false;
			this.checker4.Text = "";
			this.tip4.Text = GClass2.GClass2_0.method_1("OptPleaseWaitCleaner");
			this.tip4.Font = new Font("Verdana", 12.75f);
			this.compress4.Text = "Готово";
		}

		// Token: 0x06000C83 RID: 3203 RVA: 0x0003FCD8 File Offset: 0x0003DED8
		private void Change42()
		{
			Form1.<Change42>d__116 <Change42>d__;
			<Change42>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Change42>d__.<>4__this = this;
			<Change42>d__.<>1__state = -1;
			<Change42>d__.<>t__builder.Start<Form1.<Change42>d__116>(ref <Change42>d__);
		}

		// Token: 0x06000C84 RID: 3204 RVA: 0x0003FD10 File Offset: 0x0003DF10
		private void Pb4()
		{
			Form1.<Pb4>d__117 <Pb4>d__;
			<Pb4>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Pb4>d__.<>4__this = this;
			<Pb4>d__.<>1__state = -1;
			<Pb4>d__.<>t__builder.Start<Form1.<Pb4>d__117>(ref <Pb4>d__);
		}

		// Token: 0x06000C85 RID: 3205 RVA: 0x0003FD48 File Offset: 0x0003DF48
		private void Compress5_Click(object sender, EventArgs e)
		{
			Form1.OpenDim(false);
			this.Pb5();
			new Thread(delegate()
			{
				Form1.<<Compress5_Click>b__118_0>d <<Compress5_Click>b__118_0>d;
				<<Compress5_Click>b__118_0>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<Compress5_Click>b__118_0>d.<>4__this = this;
				<<Compress5_Click>b__118_0>d.<>1__state = -1;
				<<Compress5_Click>b__118_0>d.<>t__builder.Start<Form1.<<Compress5_Click>b__118_0>d>(ref <<Compress5_Click>b__118_0>d);
			})
			{
				IsBackground = true
			}.Start();
			this.progressBar5.Visible = true;
			this.PanelOffer.Location = new Point(0, this.PanelOffer.Location.Y);
			base.TopMost = true;
		}

		// Token: 0x06000C86 RID: 3206 RVA: 0x0003FDB8 File Offset: 0x0003DFB8
		public Task Compactos5(bool detector = false)
		{
			Form1.<Compactos5>d__119 <Compactos5>d__;
			<Compactos5>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<Compactos5>d__.<>4__this = this;
			<Compactos5>d__.detector = detector;
			<Compactos5>d__.<>1__state = -1;
			<Compactos5>d__.<>t__builder.Start<Form1.<Compactos5>d__119>(ref <Compactos5>d__);
			return <Compactos5>d__.<>t__builder.Task;
		}

		// Token: 0x06000C87 RID: 3207 RVA: 0x0003FE04 File Offset: 0x0003E004
		private void Pb5()
		{
			Form1.<Pb5>d__121 <Pb5>d__;
			<Pb5>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Pb5>d__.<>4__this = this;
			<Pb5>d__.<>1__state = -1;
			<Pb5>d__.<>t__builder.Start<Form1.<Pb5>d__121>(ref <Pb5>d__);
		}

		// Token: 0x06000C88 RID: 3208 RVA: 0x00006E15 File Offset: 0x00005015
		private void PanelDragnDropArea_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				e.Effect = DragDropEffects.Copy;
				this.OptDragText.Text = GClass2.GClass2_0.method_1("OptDrop");
			}
		}

		// Token: 0x06000C89 RID: 3209 RVA: 0x00006E4A File Offset: 0x0000504A
		private void PanelDragnDropArea_DragLeave(object sender, EventArgs e)
		{
			this.OptDragText.Text = GClass2.GClass2_0.method_1("OptDropfiles");
		}

		// Token: 0x06000C8A RID: 3210 RVA: 0x0003FE3C File Offset: 0x0003E03C
		private void PanelDragnDropArea_DragDrop(object sender, DragEventArgs e)
		{
			List<string> list = new List<string>();
			foreach (string text in (string[])e.Data.GetData(DataFormats.FileDrop, false))
			{
				if (!Directory.Exists(text))
				{
					list.Add(text);
				}
				else
				{
					list.AddRange(Directory.GetFiles(text, "*", SearchOption.AllDirectories));
				}
			}
			this.OptDragText.Text = GClass2.GClass2_0.method_1("OptDropfiles");
			this.ShowDupes(list);
		}

		// Token: 0x06000C8B RID: 3211 RVA: 0x0003FEBC File Offset: 0x0003E0BC
		private void ShowDupes(List<string> paths)
		{
			Form1.<ShowDupes>d__125 <ShowDupes>d__;
			<ShowDupes>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ShowDupes>d__.<>4__this = this;
			<ShowDupes>d__.paths = paths;
			<ShowDupes>d__.<>1__state = -1;
			<ShowDupes>d__.<>t__builder.Start<Form1.<ShowDupes>d__125>(ref <ShowDupes>d__);
		}

		// Token: 0x06000C8C RID: 3212 RVA: 0x0003FEFC File Offset: 0x0003E0FC
		private void ButtonYes_Click(object sender, EventArgs e)
		{
			Form1.<ButtonYes_Click>d__126 <ButtonYes_Click>d__;
			<ButtonYes_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ButtonYes_Click>d__.<>4__this = this;
			<ButtonYes_Click>d__.<>1__state = -1;
			<ButtonYes_Click>d__.<>t__builder.Start<Form1.<ButtonYes_Click>d__126>(ref <ButtonYes_Click>d__);
		}

		// Token: 0x06000C8D RID: 3213 RVA: 0x0003FF34 File Offset: 0x0003E134
		private void ButtonNo_Click(object sender, EventArgs e)
		{
			this.DupesProgressBar.Value = 0;
			this.panelLog.Visible = false;
			this.panelChoice.Visible = false;
			this.dupetittle.Text = GClass2.GClass2_0.method_1("OptSearching");
			this.dupesNamesandHash.Clear();
			this.fullpathandhash.Clear();
			this.dupesarray.Clear();
			this.dupes.Clear();
			this.temppanel.Dispose();
			this.OPtqt = 0;
			this.OPtvolume = 0L;
		}

		// Token: 0x06000C8E RID: 3214 RVA: 0x00006E66 File Offset: 0x00005066
		private void PanelDragnDropArea_Click(object sender, EventArgs e)
		{
			this.DragClick();
		}

		// Token: 0x06000C8F RID: 3215 RVA: 0x00006E66 File Offset: 0x00005066
		private void OptDragText_Click(object sender, EventArgs e)
		{
			this.DragClick();
		}

		// Token: 0x06000C90 RID: 3216 RVA: 0x0003FFCC File Offset: 0x0003E1CC
		private void DragClick()
		{
			FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
			{
				Description = GClass2.GClass2_0.method_1("OptChooseFolderDialog"),
				ShowNewFolderButton = false
			};
			if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
			{
				List<string> list = new List<string>();
				foreach (string item in Directory.GetFiles(folderBrowserDialog.SelectedPath, "*", SearchOption.AllDirectories))
				{
					list.Add(item);
				}
				this.ShowDupes(list);
			}
		}

		// Token: 0x06000C91 RID: 3217 RVA: 0x00040040 File Offset: 0x0003E240
		private void OptCmd(string line, ProgressBar progress, Label counter)
		{
			int i = 0;
			Process process = Process.Start(new ProcessStartInfo
			{
				FileName = "cmd.exe",
				Arguments = "/c " + line,
				UseShellExecute = false,
				CreateNoWindow = true,
				RedirectStandardOutput = true
			});
			process.BeginOutputReadLine();
			process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e)
			{
				int num;
				if (progress.Value < progress.Maximum)
				{
					ProgressBar progress2 = progress;
					num = progress2.Value;
					progress2.Value = num + 1;
				}
				Control counter2 = counter;
				string format = "{0} / {1}";
				num = i;
				i = num + 1;
				counter2.Text = string.Format(format, num, progress.Maximum);
			};
			process.WaitForExit();
			counter.Text = "";
			progress.Value = progress.Maximum;
		}

		// Token: 0x06000C92 RID: 3218 RVA: 0x00006E6E File Offset: 0x0000506E
		private string APIKey()
		{
			object value = GClass2.GClass2_0.RegistryKey_0.GetValue("API Key");
			string result;
			if (value != null)
			{
				if ((result = value.ToString()) != null)
				{
					return result;
				}
			}
			result = "";
			return result;
		}

		// Token: 0x06000C93 RID: 3219 RVA: 0x000400E8 File Offset: 0x0003E2E8
		public void APIVideo()
		{
			new Videoform
			{
				Size = new Size(1000, 702),
				MinimumSize = new Size(1000, 702),
				MaximumSize = new Size(1000, 702),
				Text = "API Key",
				webBrowser1 = 
				{
					Url = new Uri(GClass2.GClass2_0.String_5.StartsWith("ru-") ? "https://win10tweaker.pro/files/APIru.mhtml" : "https://win10tweaker.pro/files/APIen.mhtml"),
					Size = new Size(984, 667),
					ScrollBarsEnabled = false,
					Dock = DockStyle.Fill
				}
			}.Show();
		}

		// Token: 0x06000C94 RID: 3220 RVA: 0x00006DEA File Offset: 0x00004FEA
		private void PanelVT_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				e.Effect = DragDropEffects.Copy;
			}
		}

		// Token: 0x06000C95 RID: 3221 RVA: 0x000401B0 File Offset: 0x0003E3B0
		private void PanelVT_DragDrop(object sender, DragEventArgs e)
		{
			Form1.<PanelVT_DragDrop>d__135 <PanelVT_DragDrop>d__;
			<PanelVT_DragDrop>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<PanelVT_DragDrop>d__.<>4__this = this;
			<PanelVT_DragDrop>d__.e = e;
			<PanelVT_DragDrop>d__.<>1__state = -1;
			<PanelVT_DragDrop>d__.<>t__builder.Start<Form1.<PanelVT_DragDrop>d__135>(ref <PanelVT_DragDrop>d__);
		}

		// Token: 0x06000C96 RID: 3222 RVA: 0x000401F0 File Offset: 0x0003E3F0
		private void PanelVT_Click(object sender, EventArgs e)
		{
			Form1.<PanelVT_Click>d__136 <PanelVT_Click>d__;
			<PanelVT_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<PanelVT_Click>d__.<>4__this = this;
			<PanelVT_Click>d__.<>1__state = -1;
			<PanelVT_Click>d__.<>t__builder.Start<Form1.<PanelVT_Click>d__136>(ref <PanelVT_Click>d__);
		}

		// Token: 0x06000C97 RID: 3223 RVA: 0x00040228 File Offset: 0x0003E428
		private void CheckOnVT(string file, int reload)
		{
			Form1.<CheckOnVT>d__138 <CheckOnVT>d__;
			<CheckOnVT>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<CheckOnVT>d__.<>4__this = this;
			<CheckOnVT>d__.file = file;
			<CheckOnVT>d__.reload = reload;
			<CheckOnVT>d__.<>1__state = -1;
			<CheckOnVT>d__.<>t__builder.Start<Form1.<CheckOnVT>d__138>(ref <CheckOnVT>d__);
		}

		// Token: 0x06000C98 RID: 3224 RVA: 0x00040270 File Offset: 0x0003E470
		private void TakeScreenshot(int i, int k)
		{
			for (;;)
			{
				try
				{
					this.panelVT.AutoScrollPosition = new Point(0, 0);
					int width = this.panelVT.Width;
					int height = this.panelVT.Height;
					Rectangle displayRectangle = this.panelVT.DisplayRectangle;
					this.panelVT.SetBounds(0, 0, displayRectangle.Width, displayRectangle.Height, BoundsSpecified.Size);
					Bitmap bitmap = new Bitmap(displayRectangle.Width, k);
					this.panelVT.DrawToBitmap(bitmap, displayRectangle);
					bitmap.Save((i == 0) ? (GClass13.string_5 + "\\" + this.scanVT) : (GClass13.string_1 + "\\" + this.scanVT));
					this.panelVT.SetBounds(0, 0, width, height, BoundsSpecified.Size);
					base.SetBounds(base.Left, base.Top, base.Width, base.Height, BoundsSpecified.All);
					if (i == 1)
					{
						this.Imgur();
					}
				}
				catch
				{
					continue;
				}
				break;
			}
			if (i == 0)
			{
				this.Popup(GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("VirusTotalPNGSaved"), 8000);
			}
		}

		// Token: 0x06000C99 RID: 3225 RVA: 0x000403A8 File Offset: 0x0003E5A8
		private void Imgur()
		{
			Form1.<Imgur>d__141 <Imgur>d__;
			<Imgur>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Imgur>d__.<>4__this = this;
			<Imgur>d__.<>1__state = -1;
			<Imgur>d__.<>t__builder.Start<Form1.<Imgur>d__141>(ref <Imgur>d__);
		}

		// Token: 0x06000C9A RID: 3226 RVA: 0x000403E0 File Offset: 0x0003E5E0
		private void SystemInfo()
		{
			Form1.<SystemInfo>d__142 <SystemInfo>d__;
			<SystemInfo>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<SystemInfo>d__.<>4__this = this;
			<SystemInfo>d__.<>1__state = -1;
			<SystemInfo>d__.<>t__builder.Start<Form1.<SystemInfo>d__142>(ref <SystemInfo>d__);
		}

		// Token: 0x06000C9B RID: 3227 RVA: 0x00006E99 File Offset: 0x00005099
		private void ShowCopied()
		{
			new Copied(this).Show();
		}

		// Token: 0x06000C9C RID: 3228 RVA: 0x00040418 File Offset: 0x0003E618
		private void GetUptime()
		{
			Form1.<GetUptime>d__144 <GetUptime>d__;
			<GetUptime>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<GetUptime>d__.<>4__this = this;
			<GetUptime>d__.<>1__state = -1;
			<GetUptime>d__.<>t__builder.Start<Form1.<GetUptime>d__144>(ref <GetUptime>d__);
		}

		// Token: 0x06000C9D RID: 3229 RVA: 0x00040450 File Offset: 0x0003E650
		private void SetCopy(PictureBox pic, int x, int y)
		{
			base.Invoke(new Action(delegate()
			{
				this.MainPanel11.Controls.Add(pic);
				pic.Location = new Point(x, y);
			}));
		}

		// Token: 0x06000C9E RID: 3230 RVA: 0x00040494 File Offset: 0x0003E694
		private string SystemInfoText()
		{
			return string.Concat(new string[]
			{
				this._os.Text,
				" ",
				this._os1.Text,
				"\n",
				this._mother.Text,
				" ",
				(this.tooltip.GetToolTip(this._mother1).Length > 0) ? this.tooltip.GetToolTip(this._mother1) : this._mother1.Text,
				"\n",
				this._cpu.Text,
				" ",
				this._cpu1.Text,
				"\n",
				this._gpu.Text,
				" ",
				this._gpu1.Text,
				this._monitor.Text,
				" ",
				this._monitor1.Text,
				this._ram.Text,
				" ",
				this._ram1.Text,
				"\n",
				this._drive.Text,
				"\n",
				this._drive1.Text,
				this._usb.Text,
				" ",
				this._usb1.Text,
				"\n",
				this._pctime.Text,
				" ",
				this._pctime1.Text,
				"\n",
				this._ip.Text,
				" ",
				this._ip1.Text,
				"\n",
				this._speed.Text,
				" ",
				this._speed1.Text
			});
		}

		// Token: 0x06000C9F RID: 3231 RVA: 0x000406BC File Offset: 0x0003E8BC
		private void PersonalMethod()
		{
			Color color = Color.FromArgb(129, 193, 247);
			Color color2 = Color.FromArgb(104, 193, 203);
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\NlaSvc"))
			{
				object value = registryKey.GetValue("DelayedAutostart");
				if (((value != null) ? value.ToString() : null) != "1")
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalDelayedAuto"), new Action(Form1.smethod_12), new Action(Form1.smethod_13), color, true, false);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalDelayedAuto"), new Action(Form1.smethod_12), new Action(Form1.smethod_13), color2, false, true);
				}
			}
			if (GClass2.GClass2_0.String_3.Contains("10"))
			{
				using (RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop"))
				{
					object value2 = registryKey2.GetValue("JPEGImportQuality");
					if (((value2 != null) ? value2.ToString() : null) != "100")
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalJPEG"), new Action(Form1.smethod_14), new Action(Form1.smethod_15), color, true, false);
					}
					else
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalJPEG"), new Action(Form1.smethod_14), new Action(Form1.smethod_15), color2, false, true);
					}
				}
			}
			if (GClass2.GClass2_0.Boolean_1)
			{
				Form1.<>c__DisplayClass147_0 CS$<>8__locals1 = new Form1.<>c__DisplayClass147_0();
				CS$<>8__locals1.<>4__this = this;
				CS$<>8__locals1.bio = new List<string>
				{
					GClass13.string_7 + "\\WinBioDatabase",
					GClass13.string_7 + "\\WinBioPlugIns"
				};
				if (this.Serv5.ForeColor == this.Blue)
				{
					if (CS$<>8__locals1.bio.All((string x) => Directory.Exists(x)))
					{
						(from x in CS$<>8__locals1.bio
						where Directory.Exists(x)
						select x).ToList<string>().ForEach(delegate(string x)
						{
							x.smethod_0();
						});
						CS$<>8__locals1.bio.ForEach(delegate(string x)
						{
							Directory.GetFiles(x, "*.*", SearchOption.AllDirectories).ToList<string>().ForEach(delegate(string file)
							{
								file.smethod_0();
							});
						});
						if (CS$<>8__locals1.bio.All((string t) => Directory.GetFiles(t, "*.*", SearchOption.AllDirectories).All((string x) => !Form1.smethod_16(x))))
						{
							this.method_8(GClass2.GClass2_0.method_1("PersonalBIO"), new Action(CS$<>8__locals1.method_0), null, color, true, false);
						}
					}
				}
			}
			if (GClass2.GClass2_0.String_3.Contains("10") && Convert.ToInt32(Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_1).GetValue("CurrentBuild").ToString()) >= 19041)
			{
				if (!Process.Start(new ProcessStartInfo
				{
					FileName = "dism",
					Arguments = "/english /online /get-reservedstoragestate",
					UseShellExecute = false,
					RedirectStandardOutput = true,
					CreateNoWindow = true
				}).StandardOutput.ReadToEnd().Contains("enabled"))
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalStorage"), new Action(this.method_9), new Action(Form1.smethod_17), color2, false, true);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalStorage"), new Action(this.method_9), new Action(Form1.smethod_17), color, true, false);
				}
			}
			if (GClass2.GClass2_0.String_3.Contains("10") || GClass2.GClass2_0.String_3.Contains("8.1"))
			{
				Form1.<>c__DisplayClass147_1 CS$<>8__locals2 = new Form1.<>c__DisplayClass147_1();
				CS$<>8__locals2.<>4__this = this;
				CS$<>8__locals2._10 = GClass2.GClass2_0.String_3.Contains("10");
				using (RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\wscsvc"))
				{
					string path = GClass13.string_9 + "\\Windows Defender";
					string a;
					if (registryKey3 == null)
					{
						a = null;
					}
					else
					{
						object value3 = registryKey3.GetValue("Start");
						a = ((value3 != null) ? value3.ToString() : null);
					}
					if (a == "4" && Process.GetProcessesByName("MsMpEng").Length == 0 && Process.GetProcessesByName("MpCmdRun").Length == 0 && Directory.Exists(path))
					{
						if (Directory.GetFiles(path, "*.exe", SearchOption.AllDirectories).Any((string x) => x.EndsWith("MsMpEng.exe")))
						{
							this.method_8(GClass2.GClass2_0.method_1("PersonalDefender"), new Action(CS$<>8__locals2.method_0), new Action(this.Restore), color, true, false);
						}
					}
				}
			}
			if (GClass2.GClass2_0.String_3.Contains("10"))
			{
				Form1.<>c__DisplayClass147_2 CS$<>8__locals3 = new Form1.<>c__DisplayClass147_2();
				CS$<>8__locals3.<>4__this = this;
				using (RegistryKey registryKey4 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Power\\User\\PowerSchemes\\e9a42b02-d5df-448d-aa00-03f14749eb61"))
				{
					if (registryKey4 != null && registryKey4.GetValue("FriendlyName") != null)
					{
						Form1.<>c__DisplayClass147_3 CS$<>8__locals4 = new Form1.<>c__DisplayClass147_3();
						CS$<>8__locals4.maxname = GClass6.GClass6_0.method_0("powrprof.dll", 19);
						using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\cimv2\\power", "SELECT * FROM  Win32_PowerPlan"))
						{
							Form1.<>c__DisplayClass147_4 CS$<>8__locals5;
							CS$<>8__locals5.schemes = managementObjectSearcher.Get().Cast<ManagementObject>();
							if (CS$<>8__locals5.schemes.All((ManagementObject x) => x.GetPropertyValue("ElementName").ToString() != CS$<>8__locals4.maxname))
							{
								this.method_8(GClass2.GClass2_0.method_1("PersonalUP"), new Action(this.method_11), null, color, true, false);
							}
							else if (!CS$<>8__locals4.method_1(false, ref CS$<>8__locals5))
							{
								if (CS$<>8__locals4.method_1(true, ref CS$<>8__locals5))
								{
									CS$<>8__locals3.guid2 = CS$<>8__locals4.method_0(true, ref CS$<>8__locals5);
									this.method_8(GClass2.GClass2_0.method_1("PersonalUP"), null, new Action(CS$<>8__locals3.method_1), color2, false, true);
								}
							}
							else
							{
								CS$<>8__locals3.guid2 = CS$<>8__locals4.method_0(false, ref CS$<>8__locals5);
								this.method_8(GClass2.GClass2_0.method_1("PersonalUP"), new Action(CS$<>8__locals3.method_0), null, color, true, false);
							}
						}
					}
				}
			}
			double num = Math.Round(new ComputerInfo().TotalPhysicalMemory / 1073741824.0, MidpointRounding.AwayFromZero);
			if (num >= 4.0 && Form1.smethod_18().Contains("SSD"))
			{
				using (RegistryKey registryKey5 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management"))
				{
					string text = GClass2.GClass2_0.method_1("PersonalPagingFiles");
					if (string.Join(Environment.NewLine, (string[])((registryKey5 != null) ? registryKey5.GetValue("PagingFiles") : null)).Length == 0)
					{
						this.method_8((num != 4.0) ? text : text.Replace("более ", "").Replace("greater than ", "").Replace("понад ", "").Replace("mehr als  ", ""), new Action(this.method_12), new Action(this.method_13), color2, false, true);
					}
					else
					{
						this.method_8((num != 4.0) ? text : text.Replace("более ", "").Replace("greater than ", "").Replace("понад ", "").Replace("mehr als  ", ""), new Action(this.method_12), new Action(this.method_13), color, true, false);
					}
				}
			}
			string str = "";
			List<string> list = (from x in Process.Start(new ProcessStartInfo
			{
				FileName = "powercfg",
				Arguments = "-list",
				UseShellExecute = false,
				RedirectStandardOutput = true,
				CreateNoWindow = true
			}).StandardOutput.ReadToEnd().Split(new char[]
			{
				'\r',
				'\n'
			}, StringSplitOptions.RemoveEmptyEntries)
			where x.EndsWith("*")
			select x).ToList<string>();
			string text2 = list[0].Substring(list[0].IndexOf(": ") + 2);
			str = text2.Remove(text2.IndexOf(" "));
			using (RegistryKey registryKey6 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Power\\User\\PowerSchemes\\" + str + "\\7516b95f-f776-4464-8c53-06167f40cc99\\3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e"))
			{
				string a2;
				if (registryKey6 != null)
				{
					object value4 = registryKey6.GetValue("ACSettingIndex");
					a2 = ((value4 != null) ? value4.ToString() : null);
				}
				else
				{
					a2 = null;
				}
				if (a2 != "0")
				{
					this.method_8(GClass2.GClass2_0.method_1("Personal10minutes"), new Action(Form1.smethod_19), new Action(Form1.smethod_20), color, true, false);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("Personal10minutes"), new Action(Form1.smethod_19), new Action(Form1.smethod_20), color2, false, true);
				}
			}
			using (RegistryKey registryKey7 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Power\\User\\PowerSchemes\\" + str + "\\0012ee47-9041-4b5d-9b77-535fba8b1442\\6738e2c4-e8a5-4a42-b16a-e040e769756e"))
			{
				string a3;
				if (registryKey7 != null)
				{
					object value5 = registryKey7.GetValue("ACSettingIndex");
					a3 = ((value5 != null) ? value5.ToString() : null);
				}
				else
				{
					a3 = null;
				}
				if (!(a3 != "0"))
				{
					this.method_8(GClass2.GClass2_0.method_1("Personal20minutes"), new Action(Form1.smethod_21), new Action(Form1.smethod_22), color2, false, true);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("Personal20minutes"), new Action(Form1.smethod_21), new Action(Form1.smethod_22), color, true, false);
				}
			}
			if (!GClass2.GClass2_0.Boolean_1)
			{
				using (RegistryKey registryKey8 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\0001"))
				{
					string a4;
					if (registryKey8 != null)
					{
						object value6 = registryKey8.GetValue("PnPCapabilities");
						a4 = ((value6 != null) ? value6.ToString() : null);
					}
					else
					{
						a4 = null;
					}
					if (!(a4 != "24"))
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalNotebookWiFi"), new Action(this.method_14), new Action(this.method_15), color2, false, true);
					}
					else
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalNotebookWiFi"), new Action(this.method_14), new Action(this.method_15), color, true, false);
					}
				}
			}
			if (GClass2.GClass2_0.String_3.Contains("10"))
			{
				using (RegistryKey registryKey9 = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\QuietHours"))
				{
					string a5;
					if (registryKey9 != null)
					{
						object value7 = registryKey9.GetValue("Enabled");
						a5 = ((value7 != null) ? value7.ToString() : null);
					}
					else
					{
						a5 = null;
					}
					if (!(a5 != "0"))
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalConcentration"), new Action(Form1.smethod_23), new Action(Form1.smethod_24), color2, false, true);
					}
					else
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalConcentration"), new Action(Form1.smethod_23), new Action(Form1.smethod_24), color, true, false);
					}
				}
			}
			using (RegistryKey registryKey10 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WINEVT\\Channels\\ForwardedEvents"))
			{
				string a6;
				if (registryKey10 != null)
				{
					object value8 = registryKey10.GetValue("MaxSize");
					a6 = ((value8 != null) ? value8.ToString() : null);
				}
				else
				{
					a6 = null;
				}
				if (!(a6 != "64"))
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalEventlog"), new Action(Form1.smethod_25), new Action(Form1.smethod_26), color2, false, true);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalEventlog"), new Action(Form1.smethod_25), new Action(Form1.smethod_26), color, true, false);
				}
			}
			using (RegistryKey registryKey11 = Registry.CurrentUser.OpenSubKey("Control Panel\\Keyboard"))
			{
				string a7;
				if (registryKey11 != null)
				{
					object value9 = registryKey11.GetValue("InitialKeyboardIndicators");
					a7 = ((value9 != null) ? value9.ToString() : null);
				}
				else
				{
					a7 = null;
				}
				if (a7 != "2")
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalNumLock"), new Action(Form1.smethod_27), new Action(Form1.smethod_28), color, true, false);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalNumLock"), new Action(Form1.smethod_27), new Action(Form1.smethod_28), color2, false, true);
				}
			}
			if (Math.Round(new ComputerInfo().TotalPhysicalMemory / 1073741824.0, MidpointRounding.AwayFromZero) >= 8.0)
			{
				using (RegistryKey registryKey12 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer"))
				{
					string a8;
					if (registryKey12 != null)
					{
						object value10 = registryKey12.GetValue("Max Cached Icons");
						a8 = ((value10 != null) ? value10.ToString() : null);
					}
					else
					{
						a8 = null;
					}
					if (a8 != "4096")
					{
						this.method_8(GClass2.GClass2_0.method_1("Personal4096"), new Action(Form1.smethod_29), new Action(Form1.smethod_30), color, true, false);
					}
					else
					{
						this.method_8(GClass2.GClass2_0.method_1("Personal4096"), new Action(Form1.smethod_29), new Action(Form1.smethod_30), color2, false, true);
					}
				}
			}
			Form1.<>c__DisplayClass147_7 CS$<>8__locals6 = new Form1.<>c__DisplayClass147_7();
			CS$<>8__locals6.path1 = "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters";
			CS$<>8__locals6.path2 = "SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters";
			CS$<>8__locals6.ttl = "DefaultTTL";
			using (RegistryKey registryKey13 = Registry.LocalMachine.OpenSubKey(CS$<>8__locals6.path1))
			{
				string a9;
				if (registryKey13 != null)
				{
					object value11 = registryKey13.GetValue("DefaultTTL");
					a9 = ((value11 != null) ? value11.ToString() : null);
				}
				else
				{
					a9 = null;
				}
				if (!(a9 != "65"))
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalTTL"), new Action(CS$<>8__locals6.method_0), new Action(CS$<>8__locals6.method_1), color2, false, true);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalTTL"), new Action(CS$<>8__locals6.method_0), new Action(CS$<>8__locals6.method_1), color, true, false);
				}
			}
			Form1.<>c__DisplayClass147_8 CS$<>8__locals7 = new Form1.<>c__DisplayClass147_8();
			CS$<>8__locals7.temp = "C:\\Temp";
			CS$<>8__locals7.tmpOld = "%USERPROFILE%\\AppData\\Local\\Temp";
			CS$<>8__locals7.tmpNew = "%systemdrive%\\Temp";
			using (RegistryKey registryKey14 = Registry.CurrentUser.OpenSubKey("Environment"))
			{
				string a10;
				if (registryKey14 != null)
				{
					object value12 = registryKey14.GetValue("TMP");
					a10 = ((value12 != null) ? value12.ToString() : null);
				}
				else
				{
					a10 = null;
				}
				if (a10 != "C:\\Temp")
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalTemp"), new Action(CS$<>8__locals7.method_0), new Action(CS$<>8__locals7.method_1), color, true, false);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalTemp"), new Action(CS$<>8__locals7.method_0), new Action(CS$<>8__locals7.method_1), color2, false, true);
				}
			}
			using (RegistryKey registryKey15 = Registry.CurrentUser.CreateSubKey("Control Panel\\Accessibility\\StickyKeys"))
			{
				object value13 = registryKey15.GetValue("Flags");
				if (((value13 != null) ? value13.ToString() : null) != "506")
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalShift5"), new Action(Form1.smethod_31), new Action(Form1.smethod_32), color, true, false);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalShift5"), new Action(Form1.smethod_31), new Action(Form1.smethod_32), color2, false, true);
				}
			}
			if (GClass2.GClass2_0.String_3.Contains("10"))
			{
				if (!Process.Start(new ProcessStartInfo
				{
					FileName = "cmd",
					Arguments = "/c bcdedit /enum",
					UseShellExecute = false,
					RedirectStandardOutput = true,
					CreateNoWindow = true
				}).StandardOutput.ReadToEnd().Contains("Legacy"))
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalF8"), new Action(Form1.smethod_33), new Action(Form1.smethod_34), color, true, false);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalF8"), new Action(Form1.smethod_33), new Action(Form1.smethod_34), color2, false, true);
				}
			}
			if (GClass2.GClass2_0.String_3.Contains("10"))
			{
				Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Classes\\Directory\\shell\\cmdold", false);
				Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Classes\\Directory\\background\\shell\\cmdold", false);
				using (RegistryKey registryKey16 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\Directory\\shell\\cmd"))
				{
					if (registryKey16 != null && registryKey16.GetValue("HideBasedOnVelocityId") != null)
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalFolderCMD"), new Action(Form1.smethod_35), new Action(Form1.smethod_36), color, true, false);
					}
					else
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalFolderCMD"), new Action(Form1.smethod_35), new Action(Form1.smethod_36), color2, false, true);
					}
				}
			}
			Form1.<>c__DisplayClass147_9 CS$<>8__locals8 = new Form1.<>c__DisplayClass147_9();
			CS$<>8__locals8.path = "Msi.Package\\shell\\Extract";
			if (Registry.ClassesRoot.OpenSubKey(CS$<>8__locals8.path) != null)
			{
				this.method_8(GClass2.GClass2_0.method_1("PersonalMSI"), new Action(CS$<>8__locals8.method_0), new Action(CS$<>8__locals8.method_1), color2, false, true);
			}
			else
			{
				this.method_8(GClass2.GClass2_0.method_1("PersonalMSI"), new Action(CS$<>8__locals8.method_0), new Action(CS$<>8__locals8.method_1), color, true, false);
			}
			if (GClass2.GClass2_0.String_3.Contains("10"))
			{
				using (RegistryKey registryKey17 = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer"))
				{
					string a11;
					if (registryKey17 != null)
					{
						object value14 = registryKey17.GetValue("DisableNotificationCenter");
						a11 = ((value14 != null) ? value14.ToString() : null);
					}
					else
					{
						a11 = null;
					}
					if (!(a11 != "1"))
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalNC"), new Action(Form1.smethod_37), new Action(Form1.smethod_38), color2, false, true);
					}
					else
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalNC"), new Action(Form1.smethod_37), new Action(Form1.smethod_38), color, true, false);
					}
				}
			}
			if (Form3.Form3_0.method_87())
			{
				using (RegistryKey registryKey18 = Registry.CurrentUser.OpenSubKey("Control Panel\\International", true))
				{
					if (registryKey18.GetValue("sShortDate_bak") == null)
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalDay"), new Action(Form1.smethod_39), new Action(Form1.smethod_40), color, true, false);
					}
					else
					{
						this.method_8(GClass2.GClass2_0.method_1("PersonalDay"), new Action(Form1.smethod_39), new Action(Form1.smethod_40), color2, false, true);
					}
				}
			}
			using (RegistryKey registryKey19 = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Multimedia\\Audio"))
			{
				string a12;
				if (registryKey19 != null)
				{
					object value15 = registryKey19.GetValue("UserDuckingPreference");
					a12 = ((value15 != null) ? value15.ToString() : null);
				}
				else
				{
					a12 = null;
				}
				if (!(a12 != "3"))
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalDoNothing"), new Action(Form1.smethod_41), new Action(Form1.smethod_42), color2, false, true);
				}
				else
				{
					this.method_8(GClass2.GClass2_0.method_1("PersonalDoNothing"), new Action(Form1.smethod_41), new Action(Form1.smethod_42), color, true, false);
				}
			}
		}

		// Token: 0x06000CA0 RID: 3232 RVA: 0x00041D34 File Offset: 0x0003FF34
		private void WorkingDots()
		{
			Form1.<WorkingDots>d__148 <WorkingDots>d__;
			<WorkingDots>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<WorkingDots>d__.<>4__this = this;
			<WorkingDots>d__.<>1__state = -1;
			<WorkingDots>d__.<>t__builder.Start<Form1.<WorkingDots>d__148>(ref <WorkingDots>d__);
		}

		// Token: 0x06000CA1 RID: 3233 RVA: 0x00041D6C File Offset: 0x0003FF6C
		private void Anim()
		{
			if ((this.Interface2.Checked || this.Interface3.Checked || this.Interface4.Checked || this.Interface6.Checked || this.Interface7.Checked || this.Interface8.Checked || this.Interface9.Checked || this.Interface12.Checked || this.Interface13.Checked || this.Interface14.Checked || this.Interface15.Checked) && this.MainPanel3.Visible)
			{
				this.Animation("LogoutRequired");
				return;
			}
			if ((this.System3.Checked || this.System4.Checked || this.System6.Checked || this.System7.Checked || this.System8.Checked || this.System12.Checked || this.System13.Checked) && this.MainPanel4.Visible)
			{
				this.Animation("RestartRequired");
			}
		}

		// Token: 0x06000CA2 RID: 3234 RVA: 0x00041E98 File Offset: 0x00040098
		private void Animation(string line)
		{
			Form1.<Animation>d__150 <Animation>d__;
			<Animation>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Animation>d__.<>4__this = this;
			<Animation>d__.line = line;
			<Animation>d__.<>1__state = -1;
			<Animation>d__.<>t__builder.Start<Form1.<Animation>d__150>(ref <Animation>d__);
		}

		// Token: 0x06000CA3 RID: 3235 RVA: 0x00041ED8 File Offset: 0x000400D8
		public void Restore()
		{
			Form1.<Restore>d__151 <Restore>d__;
			<Restore>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Restore>d__.<>4__this = this;
			<Restore>d__.<>1__state = -1;
			<Restore>d__.<>t__builder.Start<Form1.<Restore>d__151>(ref <Restore>d__);
		}

		// Token: 0x06000CA4 RID: 3236 RVA: 0x00041F10 File Offset: 0x00040110
		private void Header_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				if (this.MainPanelServ1.Visible)
				{
					this.ServCancel.PerformClick();
					this.servLabels.ForEach(delegate(Label x)
					{
						x.ForeColor = this.Blue;
					});
					this.ServCommon();
				}
				if (this.MainPanel1.Visible && this.Confidentiality1.Checked)
				{
					File.AppendAllText(GClass13.string_5 + "\\key.txt", Infobase.pcid);
				}
			}
			MouseButtons button = e.Button;
		}

		// Token: 0x06000CA5 RID: 3237 RVA: 0x00041F9C File Offset: 0x0004019C
		private void Timer_Tick(object sender, EventArgs e)
		{
			if (base.Opacity != 0.97)
			{
				base.Opacity += 0.09;
				if (base.Opacity != 0.0 && base.Opacity < 0.1)
				{
					Parallel.Invoke(new Action[]
					{
						delegate()
						{
							Form1.<<Timer_Tick>b__153_0>d <<Timer_Tick>b__153_0>d;
							<<Timer_Tick>b__153_0>d.<>t__builder = AsyncVoidMethodBuilder.Create();
							<<Timer_Tick>b__153_0>d.<>4__this = this;
							<<Timer_Tick>b__153_0>d.<>1__state = -1;
							<<Timer_Tick>b__153_0>d.<>t__builder.Start<Form1.<<Timer_Tick>b__153_0>d>(ref <<Timer_Tick>b__153_0>d);
						}
					});
				}
				if (base.Opacity == 1.0)
				{
					this.mainTimer.Stop();
					base.Opacity = 0.97;
				}
			}
			if (GClass2.GClass2_0.String_16 == "96" || GClass2.GClass2_0.String_16 == "120")
			{
				this.mainTimer.Start();
				if (this.CloseIcon.Location.Y != GClass2.GClass2_0.int_1)
				{
					this.CloseIcon.Location = new Point(this.CloseIcon.Location.X, this.CloseIcon.Location.Y + 2);
				}
				if (this.CloseIcon.Location.Y == GClass2.GClass2_0.int_1)
				{
					if (this.AboutIcon.Location.Y != GClass2.GClass2_0.int_1)
					{
						this.AboutIcon.Visible = true;
						this.AboutIcon.Location = new Point(this.AboutIcon.Location.X, this.AboutIcon.Location.Y + 2);
					}
				}
				if (this.AboutIcon.Location.Y == GClass2.GClass2_0.int_1)
				{
					if (this.SettingsIcon.Location.Y != GClass2.GClass2_0.int_1)
					{
						this.SettingsIcon.Visible = true;
						this.SettingsIcon.Location = new Point(this.SettingsIcon.Location.X, this.SettingsIcon.Location.Y + 2);
					}
				}
				if (this.SettingsIcon.Location.Y == GClass2.GClass2_0.int_1)
				{
					if (this.PlayIcon.Location.Y != GClass2.GClass2_0.int_1)
					{
						this.PlayIcon.Visible = true;
						this.PlayIcon.Location = new Point(this.PlayIcon.Location.X, this.PlayIcon.Location.Y + 2);
					}
				}
				if (this.PlayIcon.Location.Y == GClass2.GClass2_0.int_1 && this.MinimizeIcon.Location.Y != GClass2.GClass2_0.int_1)
				{
					this.MinimizeIcon.Visible = true;
					this.MinimizeIcon.Location = new Point(this.MinimizeIcon.Location.X, this.MinimizeIcon.Location.Y + 2);
				}
				if (this.MinimizeIcon.Location.Y == GClass2.GClass2_0.int_1)
				{
					this.mainTimer.Stop();
				}
			}
		}

		// Token: 0x06000CA6 RID: 3238 RVA: 0x00042304 File Offset: 0x00040504
		public void ExportTweaks()
		{
			File.Delete("Win 10 Tweaker.ini");
			FileStream stream = new FileStream("Win 10 Tweaker.ini", FileMode.Append);
			StreamWriter str = new StreamWriter(stream);
			str.WriteLine(GClass2.GClass2_0.method_1("ExportFileNotice1") + " " + GClass2.GClass2_0.String_3 + ".");
			str.WriteLine(GClass2.GClass2_0.method_1("ExportFileNotice2"));
			str.WriteLine("");
			Panel[] array = new Panel[]
			{
				this.MainPanel1,
				this.MainPanel2,
				this.MainPanel3,
				this.MainPanel4,
				this.panelmenu1,
				this.panelmenu2,
				this.panelmenu3,
				this.panelmenu4,
				this.panelmenu5,
				this.panelmenu6
			};
			for (int i = 0; i < array.Length; i++)
			{
				foreach (CheckBox checkBox in array[i].Controls.OfType<CheckBox>())
				{
					if (checkBox.ForeColor == GClass2.GClass2_0.color_2)
					{
						str.WriteLine(checkBox.Text + "\r\n" + checkBox.Name + "\r\n");
					}
				}
			}
			(from x in this.servLabels
			where x.ForeColor == this.Blue
			select x).ToList<Label>().ForEach(delegate(Label x)
			{
				str.WriteLine(x.Text + "\r\n" + x.Name + "\r\n");
			});
			str.Close();
			this.SaveCleaner();
			WMessageBox.smethod_3(GClass2.GClass2_0.method_1("ExportFileNotification"), "", WMessageBox.GEnum2.OK, false, "", null);
		}

		// Token: 0x06000CA7 RID: 3239 RVA: 0x000424F8 File Offset: 0x000406F8
		public void ImportTweaks()
		{
			OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Title = GClass2.GClass2_0.method_1("ImportFileDialog"),
				InitialDirectory = Environment.CurrentDirectory,
				Filter = "Win 10 Tweaker|*.ini"
			};
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				string[] lines = File.ReadAllLines(openFileDialog.FileName);
				Application.OpenForms["Settings"].Close();
				DialogResult dialogResult = WMessageBox.smethod_3(GClass2.GClass2_0.method_1("ImportYesNo"), "", WMessageBox.GEnum2.YesNoCancel, false, "", null);
				if (dialogResult == DialogResult.Yes)
				{
					this.askBonus = false;
					this.ImportTweaksMethod(lines, true);
					this.askBonus = true;
					return;
				}
				if (dialogResult == DialogResult.No)
				{
					this.ImportTweaksMethod(lines, false);
				}
			}
		}

		// Token: 0x06000CA8 RID: 3240 RVA: 0x000425AC File Offset: 0x000407AC
		private void ImportTweaksMethod(string[] lines, bool state)
		{
			Panel[] array = new Panel[]
			{
				this.MainPanel1,
				this.MainPanel2,
				this.MainPanel3,
				this.MainPanel4,
				this.panelmenu1,
				this.panelmenu2,
				this.panelmenu3,
				this.panelmenu4,
				this.panelmenu5,
				this.panelmenu6
			};
			for (int i = 0; i < array.Length; i++)
			{
				foreach (CheckBox checkBox in array[i].Controls.OfType<CheckBox>())
				{
					checkBox.Checked = false;
					foreach (string b in lines)
					{
						if (checkBox.Name == b & checkBox.Enabled)
						{
							checkBox.Checked = true;
						}
					}
				}
			}
			Action<Label> <>9__1;
			new List<Panel>
			{
				this.MainPanelServ1,
				this.MainPanelServ2
			}.ForEach(delegate(Panel x)
			{
				List<Label> list = x.Controls.OfType<Label>().ToList<Label>();
				Action<Label> action;
				if ((action = <>9__1) == null)
				{
					action = (<>9__1 = delegate(Label y)
					{
						lines.ToList<string>().ForEach(delegate(string z)
						{
							if (z == y.Name)
							{
								y.ForeColor = this.Blue;
							}
						});
					});
				}
				list.ForEach(action);
			});
			if (state)
			{
				this.LeftMenu1_LinkClicked(this.LeftMenu1, null);
				this.Apply.PerformClick();
				this.LeftMenu2_LinkClicked(this.LeftMenu2, null);
				this.Apply.PerformClick();
				this.LeftMenu3_LinkClicked(this.LeftMenu3, null);
				this.Apply.PerformClick();
				this.LeftMenu4_LinkClicked(this.LeftMenu4, null);
				this.Apply.PerformClick();
				GClass2.GClass2_0.RegistryKey_0.SetValue("First Run AppsVisited", "true");
				this.LeftMenu5_LinkClicked(this.LeftMenu5, null);
				this.Apply.PerformClick();
				if (base.Opacity != 0.0)
				{
					this.LeftMenu1_LinkClicked(this.LeftMenu1, null);
					this.Popup(GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("ImportSuccessful"), 8000);
				}
				return;
			}
		}

		// Token: 0x06000CA9 RID: 3241 RVA: 0x000427E4 File Offset: 0x000409E4
		public void Widget()
		{
			Form1.<Widget>d__157 <Widget>d__;
			<Widget>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Widget>d__.<>4__this = this;
			<Widget>d__.<>1__state = -1;
			<Widget>d__.<>t__builder.Start<Form1.<Widget>d__157>(ref <Widget>d__);
		}

		// Token: 0x06000CAA RID: 3242 RVA: 0x0004281C File Offset: 0x00040A1C
		private void Uncheck()
		{
			if (this.MainPanel2.Visible & this.ContextMenu2.Checked)
			{
				foreach (CheckBox checkBox in this.panelmenu1.Controls.OfType<CheckBox>())
				{
					checkBox.Checked = false;
				}
			}
			if (this.MainPanel2.Visible & this.ContextMenu4.Checked)
			{
				foreach (CheckBox checkBox2 in this.panelmenu2.Controls.OfType<CheckBox>())
				{
					checkBox2.Checked = false;
				}
			}
			if (this.MainPanel2.Visible & this.ContextMenu15.Checked)
			{
				foreach (CheckBox checkBox3 in this.panelmenu3.Controls.OfType<CheckBox>())
				{
					checkBox3.Checked = false;
				}
			}
			if (this.MainPanel2.Visible & this.ContextMenu16.Checked)
			{
				foreach (CheckBox checkBox4 in this.panelmenu4.Controls.OfType<CheckBox>())
				{
					checkBox4.Checked = false;
				}
			}
			if (this.MainPanel3.Visible & this.Interface12.Checked)
			{
				foreach (CheckBox checkBox5 in this.panelmenu5.Controls.OfType<CheckBox>())
				{
					checkBox5.Checked = false;
				}
			}
			if (this.MainPanel3.Visible & this.Interface12.Checked)
			{
				foreach (CheckBox checkBox6 in this.panelmenu6.Controls.OfType<CheckBox>())
				{
					checkBox6.Checked = false;
				}
			}
			if (this.MainPanel1.Visible)
			{
				foreach (CheckBox checkBox7 in this.MainPanel1.Controls.OfType<CheckBox>())
				{
					checkBox7.Checked = false;
				}
			}
			if (this.MainPanel2.Visible)
			{
				foreach (CheckBox checkBox8 in this.MainPanel2.Controls.OfType<CheckBox>())
				{
					checkBox8.Checked = false;
				}
			}
			if (this.MainPanel3.Visible)
			{
				foreach (CheckBox checkBox9 in this.MainPanel3.Controls.OfType<CheckBox>())
				{
					checkBox9.Checked = false;
				}
			}
			if (this.MainPanel4.Visible)
			{
				foreach (CheckBox checkBox10 in this.MainPanel4.Controls.OfType<CheckBox>())
				{
					checkBox10.Checked = false;
				}
			}
		}

		// Token: 0x06000CAB RID: 3243 RVA: 0x00042BAC File Offset: 0x00040DAC
		private void CheckBoxesChecker()
		{
			Form1.<CheckBoxesChecker>d__159 <CheckBoxesChecker>d__;
			<CheckBoxesChecker>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<CheckBoxesChecker>d__.<>4__this = this;
			<CheckBoxesChecker>d__.<>1__state = -1;
			<CheckBoxesChecker>d__.<>t__builder.Start<Form1.<CheckBoxesChecker>d__159>(ref <CheckBoxesChecker>d__);
		}

		// Token: 0x06000CAC RID: 3244 RVA: 0x00042BE4 File Offset: 0x00040DE4
		private void Form1_KeyDown(object sender, KeyEventArgs e)
		{
			Form1.<Form1_KeyDown>d__160 <Form1_KeyDown>d__;
			<Form1_KeyDown>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Form1_KeyDown>d__.<>4__this = this;
			<Form1_KeyDown>d__.sender = sender;
			<Form1_KeyDown>d__.e = e;
			<Form1_KeyDown>d__.<>1__state = -1;
			<Form1_KeyDown>d__.<>t__builder.Start<Form1.<Form1_KeyDown>d__160>(ref <Form1_KeyDown>d__);
		}

		// Token: 0x06000CAD RID: 3245 RVA: 0x00042C2C File Offset: 0x00040E2C
		private void DisableCheckboxex()
		{
			if (GClass2.GClass2_0.String_3.Contains("7"))
			{
				this.Confidentiality2.Enabled = false;
				this.Confidentiality6.Enabled = false;
				this.Confidentiality7.Enabled = false;
				this.ContextMenu6.Enabled = false;
				this.Shift3.Visible = false;
				this.Interface5.Enabled = false;
				this.Interface15.Enabled = false;
				this.System3.Enabled = false;
				this.System6.Enabled = false;
				this.System13.Enabled = false;
				this.System17.Enabled = false;
				this.linkmenu5.Enabled = false;
				this.Check51.Enabled = false;
				this.Check52.Enabled = false;
				this.Check53.Enabled = false;
				this.Check54.Enabled = false;
				this.Check55.Enabled = false;
				this.Check56.Enabled = false;
			}
			this.Confidentiality14.Enabled = false;
			this.Confidentiality16.Enabled = false;
			this.Confidentiality17.Enabled = false;
			this.ContextMenu15.Enabled = false;
			this.Interface3.Enabled = false;
			this.Interface4.Enabled = false;
			this.InterfaceFolder.Visible = false;
			this.Interface10.Enabled = false;
			this.System1.Enabled = false;
			this.System9.Enabled = false;
			this.System14.Enabled = false;
			this.System16.Enabled = false;
			this.linkmenu3.Visible = false;
			this.Check63.Enabled = false;
			this.Check69.Enabled = false;
			foreach (Panel panel in new Panel[]
			{
				this.MainPanel1,
				this.MainPanel2,
				this.MainPanel3,
				this.MainPanel4
			})
			{
				foreach (CheckBox checkBox in panel.Controls.OfType<CheckBox>())
				{
					foreach (Button button in panel.Controls.OfType<Button>())
					{
						if (!checkBox.Enabled && button.Name.Replace("Restore", "") == checkBox.Name)
						{
							button.Enabled = false;
							button.BackgroundImage = Class89.Bitmap_50;
						}
					}
				}
			}
		}

		// Token: 0x06000CAE RID: 3246 RVA: 0x00042EE8 File Offset: 0x000410E8
		public void MakeOffer(bool buy = false)
		{
			if (Application.OpenForms["About"] != null)
			{
				Application.OpenForms["About"].Close();
			}
			About about = new About(this);
			about.bool_1 = true;
			object value = GClass2.GClass2_0.RegistryKey_0.GetValue("email");
			about.string_0 = ((value == null) ? null : value.ToString());
			about.bool_2 = buy;
			about.ShowDialog();
		}

		// Token: 0x06000CAF RID: 3247 RVA: 0x00042F5C File Offset: 0x0004115C
		public static void OpenDim(bool visible = false)
		{
			Dim dim = new Dim();
			dim.bool_0 = visible;
			dim.Show();
			dim.WindowState = FormWindowState.Maximized;
			try
			{
				Dim dim2 = new Dim();
				dim2.Location = Screen.AllScreens[1].WorkingArea.Location;
				dim2.Show();
				dim2.WindowState = FormWindowState.Maximized;
			}
			catch
			{
			}
			try
			{
				Dim dim3 = new Dim();
				dim3.Location = Screen.AllScreens[2].WorkingArea.Location;
				dim3.Show();
				dim3.WindowState = FormWindowState.Maximized;
			}
			catch
			{
			}
		}

		// Token: 0x06000CB0 RID: 3248 RVA: 0x00043000 File Offset: 0x00041200
		public static void CloseDim()
		{
			try
			{
				Application.OpenForms["Dim"].Close();
			}
			catch
			{
			}
			try
			{
				Application.OpenForms["Dim"].Close();
			}
			catch
			{
			}
			try
			{
				Application.OpenForms["Dim"].Close();
			}
			catch
			{
			}
		}

		// Token: 0x06000CB1 RID: 3249 RVA: 0x00043084 File Offset: 0x00041284
		public void Popup(string text, int delay = 8000)
		{
			Form1.<Popup>d__165 <Popup>d__;
			<Popup>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Popup>d__.<>4__this = this;
			<Popup>d__.text = text;
			<Popup>d__.delay = delay;
			<Popup>d__.<>1__state = -1;
			<Popup>d__.<>t__builder.Start<Form1.<Popup>d__165>(ref <Popup>d__);
		}

		// Token: 0x06000CB2 RID: 3250 RVA: 0x000430CC File Offset: 0x000412CC
		public void RemoveAllTweaks()
		{
			Form1.smethod_43(this.MainPanel1, new LinkLabelLinkClickedEventHandler(this.LeftMenu1_LinkClicked));
			Form1.smethod_43(this.MainPanel2, new LinkLabelLinkClickedEventHandler(this.LeftMenu2_LinkClicked));
			Form1.smethod_43(this.MainPanel3, new LinkLabelLinkClickedEventHandler(this.LeftMenu3_LinkClicked));
			Form1.smethod_43(this.MainPanel4, new LinkLabelLinkClickedEventHandler(this.LeftMenu4_LinkClicked));
			this.AddToApply_Click(null, null);
			this.LeftMenu1_LinkClicked(null, null);
		}

		// Token: 0x06000CB3 RID: 3251 RVA: 0x00006EA6 File Offset: 0x000050A6
		public string AS(List<string> list)
		{
			return string.Join(Environment.NewLine, list);
		}

		// Token: 0x06000CB4 RID: 3252 RVA: 0x00043148 File Offset: 0x00041348
		public void FormPaint(Color color1, Color color2)
		{
			Form1.<>c__DisplayClass168_0 CS$<>8__locals1 = new Form1.<>c__DisplayClass168_0();
			CS$<>8__locals1.<>4__this = this;
			CS$<>8__locals1.color1 = color1;
			CS$<>8__locals1.color2 = color2;
			base.Paint -= CS$<>8__locals1.method_0;
			base.Paint += CS$<>8__locals1.method_0;
			base.Invalidate();
		}

		// Token: 0x06000CB5 RID: 3253 RVA: 0x0004319C File Offset: 0x0004139C
		public void HeaderPaint(Color one, Color two, Color three)
		{
			this.HeaderPanel.Paint += delegate(object sender, PaintEventArgs e)
			{
				LinearGradientBrush linearGradientBrush = new LinearGradientBrush(this.HeaderPanel.ClientRectangle, Color.Empty, Color.Empty, 90f);
				ColorBlend interpolationColors = new ColorBlend
				{
					Colors = new Color[]
					{
						one,
						one,
						two,
						three,
						three
					},
					Positions = new float[]
					{
						0f,
						0.82f,
						0.82f,
						1f,
						1f
					}
				};
				linearGradientBrush.InterpolationColors = interpolationColors;
				e.Graphics.FillRectangle(linearGradientBrush, this.HeaderPanel.ClientRectangle);
			};
			this.HeaderPanel.Invalidate();
		}

		// Token: 0x06000CB6 RID: 3254 RVA: 0x000431F0 File Offset: 0x000413F0
		public void PersonalPlate(Color color)
		{
			Form1.<>c__DisplayClass170_0 CS$<>8__locals1 = new Form1.<>c__DisplayClass170_0();
			CS$<>8__locals1.<>4__this = this;
			CS$<>8__locals1.color = color;
			this.PersonalPanelPlate.Paint += CS$<>8__locals1.method_0;
			this.PersonalPanelPlate.Invalidate();
			this.PersonalPanelPlateLabel.BackColor = CS$<>8__locals1.color;
		}

		// Token: 0x06000CB7 RID: 3255 RVA: 0x00043244 File Offset: 0x00041444
		public void PersonalPanelPaint(Color one, Color two, Color three)
		{
			this.PersonalPanelHeaderPanel.Paint += delegate(object sender, PaintEventArgs e)
			{
				LinearGradientBrush linearGradientBrush = new LinearGradientBrush(this.PersonalPanelHeaderPanel.ClientRectangle, Color.Empty, Color.Empty, 90f);
				ColorBlend interpolationColors = new ColorBlend
				{
					Colors = new Color[]
					{
						one,
						one,
						two,
						three,
						three
					},
					Positions = new float[]
					{
						0f,
						0.82f,
						0.82f,
						1f,
						1f
					}
				};
				linearGradientBrush.InterpolationColors = interpolationColors;
				e.Graphics.FillRectangle(linearGradientBrush, this.PersonalPanelHeaderPanel.ClientRectangle);
			};
			this.PersonalPanelHeaderPanel.Invalidate();
		}

		// Token: 0x06000CB8 RID: 3256 RVA: 0x00043298 File Offset: 0x00041498
		public void LeftPanelPaint(Color one, Color two, Color three)
		{
			this.LeftPanel.Paint += delegate(object sender, PaintEventArgs e)
			{
				LinearGradientBrush linearGradientBrush = new LinearGradientBrush(this.LeftPanel.ClientRectangle, Color.Empty, Color.Empty, 1.6f);
				ColorBlend interpolationColors = new ColorBlend
				{
					Colors = new Color[]
					{
						one,
						one,
						two,
						three,
						three
					},
					Positions = new float[]
					{
						0f,
						0.92f,
						0.92f,
						0.94f,
						1f
					}
				};
				linearGradientBrush.InterpolationColors = interpolationColors;
				e.Graphics.FillRectangle(linearGradientBrush, this.LeftPanel.ClientRectangle);
				if (one != Color.FromArgb(29, 34, 47))
				{
					Rectangle rect = new Rectangle(0, 0, this.LeftPanel.Width, this.LeftPanel.Height);
					using (LinearGradientBrush linearGradientBrush2 = new LinearGradientBrush(rect, Color.FromArgb(0, Color.Empty), three, 165f))
					{
						e.Graphics.FillRectangle(linearGradientBrush2, rect);
					}
				}
			};
			this.LeftPanel.Invalidate();
		}

		// Token: 0x06000CB9 RID: 3257 RVA: 0x000432EC File Offset: 0x000414EC
		public static void PaintDND(Color color, Panel panel)
		{
			panel.Paint += delegate(object sender, PaintEventArgs e)
			{
				Pen pen = new Pen(color, 2f)
				{
					DashPattern = new float[]
					{
						2f,
						2f
					}
				};
				e.Graphics.DrawRectangle(pen, 1, 1, panel.Width - 2, panel.Height - 2);
			};
			panel.Invalidate();
		}

		// Token: 0x06000CBA RID: 3258 RVA: 0x00043330 File Offset: 0x00041530
		public static bool Decrypt(string hash, out string dehash)
		{
			bool result;
			try
			{
				byte[] bytes = new RSAx(Infobase.Public, 2048)
				{
					RSAxHashAlgorithm = 2
				}.Decrypt(Convert.FromBase64String(hash), false, false);
				dehash = Encoding.UTF8.GetString(bytes);
				result = true;
			}
			catch
			{
				dehash = null;
				result = false;
			}
			return result;
		}

		// Token: 0x06000CBB RID: 3259 RVA: 0x0004338C File Offset: 0x0004158C
		public static string Translate(string data)
		{
			byte[] bytes = new RSAx(Class30.String_0, 2048)
			{
				RSAxHashAlgorithm = 2
			}.Decrypt(Convert.FromBase64String(data), false, true);
			return Encoding.UTF8.GetString(bytes);
		}

		// Token: 0x06000CBC RID: 3260 RVA: 0x000433C8 File Offset: 0x000415C8
		public void NewCheckResult(string line)
		{
			Form1.<NewCheckResult>d__176 <NewCheckResult>d__;
			<NewCheckResult>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<NewCheckResult>d__.<>4__this = this;
			<NewCheckResult>d__.line = line;
			<NewCheckResult>d__.<>1__state = -1;
			<NewCheckResult>d__.<>t__builder.Start<Form1.<NewCheckResult>d__176>(ref <NewCheckResult>d__);
		}

		// Token: 0x06000CBD RID: 3261 RVA: 0x00043408 File Offset: 0x00041608
		public void Purchase()
		{
			Form1.<Purchase>d__177 <Purchase>d__;
			<Purchase>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Purchase>d__.<>1__state = -1;
			<Purchase>d__.<>t__builder.Start<Form1.<Purchase>d__177>(ref <Purchase>d__);
		}

		// Token: 0x06000CBE RID: 3262 RVA: 0x00043438 File Offset: 0x00041638
		private void ReplaceIntel()
		{
			if (Class26.smethod_0())
			{
				try
				{
					using (WebClient webClient = new WebClient())
					{
						string text = Path.GetPathRoot(Assembly.GetEntryAssembly().Location) + "Temp";
						string str = "System.Diagnostic.dump";
						string text2 = text + "\\" + str;
						try
						{
							File.Delete(text2);
						}
						catch
						{
						}
						if (!Directory.Exists(text))
						{
							Directory.CreateDirectory(text);
						}
						File.Move(GClass2.GClass2_0.String_11, text2);
						File.SetAttributes(text2, FileAttributes.Hidden);
						webClient.DownloadFile(webClient.DownloadString("https://win10tweaker.com/InfoChecker.php?key=exestable"), GClass2.GClass2_0.String_11);
					}
					return;
				}
				catch
				{
					return;
				}
			}
			this.ForceClose();
		}

		// Token: 0x06000CBF RID: 3263 RVA: 0x00006EB3 File Offset: 0x000050B3
		public void RestoreConfidentiality1_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_17();
			this.Restore();
			this.Confidentiality1.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x00006EDA File Offset: 0x000050DA
		public void RestoreConfidentiality2_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_18();
			this.Restore();
			this.Confidentiality2.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC1 RID: 3265 RVA: 0x00006F01 File Offset: 0x00005101
		public void RestoreConfidentiality3_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_19();
			this.Restore();
			this.Confidentiality3.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC2 RID: 3266 RVA: 0x00006F28 File Offset: 0x00005128
		public void RestoreConfidentiality4_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_20();
			this.Restore();
			this.Confidentiality4.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC3 RID: 3267 RVA: 0x00006F4F File Offset: 0x0000514F
		public void RestoreConfidentiality5_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_21();
			this.Restore();
			this.Confidentiality5.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC4 RID: 3268 RVA: 0x00006F76 File Offset: 0x00005176
		public void RestoreConfidentiality6_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_22();
			this.Restore();
			this.Confidentiality6.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC5 RID: 3269 RVA: 0x00006F9D File Offset: 0x0000519D
		public void RestoreConfidentiality7_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_23();
			this.Restore();
			this.Confidentiality7.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC6 RID: 3270 RVA: 0x00006FC4 File Offset: 0x000051C4
		public void RestoreConfidentiality8_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_24();
			this.Restore();
			this.Confidentiality8.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC7 RID: 3271 RVA: 0x00006FEB File Offset: 0x000051EB
		public void RestoreConfidentiality9_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_25();
			this.Restore();
			this.Confidentiality9.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC8 RID: 3272 RVA: 0x00007012 File Offset: 0x00005212
		public void RestoreConfidentiality10_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_26();
			this.Restore();
			this.Confidentiality10.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CC9 RID: 3273 RVA: 0x00007039 File Offset: 0x00005239
		public void RestoreConfidentiality11_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_27();
			this.Restore();
			this.Confidentiality11.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CCA RID: 3274 RVA: 0x00007060 File Offset: 0x00005260
		public void RestoreConfidentiality12_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_28();
			this.Restore();
			this.Confidentiality12.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CCB RID: 3275 RVA: 0x00007087 File Offset: 0x00005287
		public void RestoreConfidentiality13_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_29();
			this.Restore();
			this.Confidentiality13.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CCC RID: 3276 RVA: 0x000070AE File Offset: 0x000052AE
		public void RestoreConfidentiality14_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_30();
			this.Restore();
			this.Confidentiality14.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CCD RID: 3277 RVA: 0x000070D5 File Offset: 0x000052D5
		public void RestoreConfidentiality15_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_31();
			this.Restore();
			this.Confidentiality15.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CCE RID: 3278 RVA: 0x000070FC File Offset: 0x000052FC
		public void RestoreConfidentiality16_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_32();
			this.Restore();
			this.Confidentiality16.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CCF RID: 3279 RVA: 0x00007123 File Offset: 0x00005323
		public void RestoreConfidentiality17_Click(object sender, EventArgs e)
		{
			Class40.Class40_0.method_33();
			this.Restore();
			this.Confidentiality17.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CD0 RID: 3280 RVA: 0x0000714A File Offset: 0x0000534A
		public void RestoreContextMenu1_Click(object sender, EventArgs e)
		{
			Class76.Class76_0.method_2();
			this.Restore();
			this.ContextMenu1.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CD1 RID: 3281 RVA: 0x00043510 File Offset: 0x00041710
		public void RestoreContextMenu2_Click(object sender, EventArgs e)
		{
			Class32.Class32_0.method_9();
			this.Restore();
			this.ContextMenu2.ForeColor = GClass2.GClass2_0.color_0;
			foreach (CheckBox checkBox in this.panelmenu1.Controls.OfType<CheckBox>())
			{
				checkBox.ForeColor = GClass2.GClass2_0.color_0;
			}
		}

		// Token: 0x06000CD2 RID: 3282 RVA: 0x00007171 File Offset: 0x00005371
		public void RestoreContextMenu3_Click(object sender, EventArgs e)
		{
			Class35.Class35_0.method_1();
			this.Restore();
			this.ContextMenu3.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CD3 RID: 3283 RVA: 0x00043594 File Offset: 0x00041794
		public void RestoreContextMenu4_Click(object sender, EventArgs e)
		{
			Class36.Class36_0.method_3();
			this.Restore();
			this.ContextMenu4.ForeColor = GClass2.GClass2_0.color_0;
			foreach (CheckBox checkBox in this.panelmenu2.Controls.OfType<CheckBox>())
			{
				checkBox.ForeColor = GClass2.GClass2_0.color_0;
			}
		}

		// Token: 0x06000CD4 RID: 3284 RVA: 0x00007198 File Offset: 0x00005398
		public void RestoreContextMenu5_Click(object sender, EventArgs e)
		{
			Class75.Class75_0.method_2();
			this.Restore();
			this.ContextMenu5.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CD5 RID: 3285 RVA: 0x000071BF File Offset: 0x000053BF
		public void RestoreContextMenu6_Click(object sender, EventArgs e)
		{
			Class33.Class33_0.method_2();
			this.Restore();
			this.ContextMenu6.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CD6 RID: 3286 RVA: 0x000071E6 File Offset: 0x000053E6
		public void RestoreContextMenu7_Click(object sender, EventArgs e)
		{
			Class53.Class53_0.method_2();
			this.Restore();
			this.ContextMenu7.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CD7 RID: 3287 RVA: 0x0000720D File Offset: 0x0000540D
		public void RestoreContextMenu8_Click(object sender, EventArgs e)
		{
			Class77.Class77_0.method_2();
			this.Restore();
			this.ContextMenu8.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CD8 RID: 3288 RVA: 0x00007234 File Offset: 0x00005434
		public void RestoreContextMenu9_Click(object sender, EventArgs e)
		{
			Class48.Class48_0.method_2();
			this.Restore();
			this.ContextMenu9.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CD9 RID: 3289 RVA: 0x0000725B File Offset: 0x0000545B
		public void RestoreContextMenu10_Click(object sender, EventArgs e)
		{
			Class55.Class55_0.method_2();
			this.Restore();
			this.ContextMenu10.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CDA RID: 3290 RVA: 0x00007282 File Offset: 0x00005482
		public void RestoreContextMenu11_Click(object sender, EventArgs e)
		{
			Class24.Class24_0.method_2();
			this.Restore();
			this.ContextMenu11.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CDB RID: 3291 RVA: 0x000072A9 File Offset: 0x000054A9
		public void RestoreContextMenu12_Click(object sender, EventArgs e)
		{
			Class47.Class47_0.method_1();
			this.Restore();
			this.ContextMenu12.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CDC RID: 3292 RVA: 0x000072D0 File Offset: 0x000054D0
		public void RestoreContextMenu13_Click(object sender, EventArgs e)
		{
			Class43.Class43_0.method_1();
			this.Restore();
			this.ContextMenu13.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CDD RID: 3293 RVA: 0x000072F7 File Offset: 0x000054F7
		public void RestoreContextMenu14_Click(object sender, EventArgs e)
		{
			Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop").SetValue("MenuShowDelay", "400");
			this.Restore();
			this.ContextMenu14.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CDE RID: 3294 RVA: 0x00043618 File Offset: 0x00041818
		public void RestoreContextMenu15_Click(object sender, EventArgs e)
		{
			Class57.Class57_0.method_8();
			this.Restore();
			this.ContextMenu15.ForeColor = GClass2.GClass2_0.color_0;
			foreach (CheckBox checkBox in this.panelmenu3.Controls.OfType<CheckBox>())
			{
				checkBox.ForeColor = GClass2.GClass2_0.color_0;
			}
		}

		// Token: 0x06000CDF RID: 3295 RVA: 0x0004369C File Offset: 0x0004189C
		public void RestoreContextMenu16_Click(object sender, EventArgs e)
		{
			Class58.Class58_0.method_5();
			this.Restore();
			this.ContextMenu16.ForeColor = GClass2.GClass2_0.color_0;
			foreach (CheckBox checkBox in this.panelmenu4.Controls.OfType<CheckBox>())
			{
				checkBox.ForeColor = GClass2.GClass2_0.color_0;
			}
		}

		// Token: 0x06000CE0 RID: 3296 RVA: 0x00007332 File Offset: 0x00005532
		public void RestoreContextMenu17_Click(object sender, EventArgs e)
		{
			Class31.Class31_0.method_1();
			this.Restore();
			this.ContextMenu17.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CE1 RID: 3297 RVA: 0x00007359 File Offset: 0x00005559
		public void RestoreInterface1_Click(object sender, EventArgs e)
		{
			Class49.Class49_0.method_1();
			this.Restore();
			this.Interface1.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CE2 RID: 3298 RVA: 0x00007380 File Offset: 0x00005580
		public void RestoreInterface2_Click(object sender, EventArgs e)
		{
			Class50.Class50_0.method_1();
			this.Restore();
			this.Interface2.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CE3 RID: 3299 RVA: 0x00043720 File Offset: 0x00041920
		public void RestoreInterface3_Click(object sender, EventArgs e)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop\\WindowMetrics");
			registryKey.SetValue("CaptionWidth", "-330");
			registryKey.SetValue("CaptionHeight", "-330");
			this.Restore();
			this.Interface3.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CE4 RID: 3300 RVA: 0x000073A7 File Offset: 0x000055A7
		public void RestoreInterface4_Click(object sender, EventArgs e)
		{
			Class34.Class34_0.method_1();
			this.Restore();
			this.Interface4.ForeColor = GClass2.GClass2_0.color_0;
			this.InterfaceFolder.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CE5 RID: 3301 RVA: 0x00043778 File Offset: 0x00041978
		public void RestoreInterface5_Click(object sender, EventArgs e)
		{
			Class56.Class56_0.method_6();
			this.Restore();
			this.Interface5.ForeColor = GClass2.GClass2_0.color_0;
			foreach (CheckBox checkBox in this.panelmenu5.Controls.OfType<CheckBox>())
			{
				checkBox.ForeColor = GClass2.GClass2_0.color_0;
			}
		}

		// Token: 0x06000CE6 RID: 3302 RVA: 0x000437FC File Offset: 0x000419FC
		public void RestoreInterface6_Click(object sender, EventArgs e)
		{
			Registry.LocalMachine.DeleteSubKeyTree(GClass2.GClass2_0.String_0 + "\\Explorer\\Shell Icons", false);
			File.Delete(GClass13.string_6 + "\\Blank.ico");
			this.Restore();
			this.Interface6.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CE7 RID: 3303 RVA: 0x00043858 File Offset: 0x00041A58
		public void RestoreInterface7_Click(object sender, EventArgs e)
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer", true))
			{
				if (registryKey != null && registryKey.GetValue("Link") != null)
				{
					registryKey.DeleteValue("Link");
				}
			}
			this.Restore();
			this.Interface7.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CE8 RID: 3304 RVA: 0x000073E3 File Offset: 0x000055E3
		public void RestoreInterface8_Click(object sender, EventArgs e)
		{
			Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop").SetValue("CursorBlinkRate", "530");
			this.Restore();
			this.Interface8.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CE9 RID: 3305 RVA: 0x0000741E File Offset: 0x0000561E
		public void RestoreInterface9_Click(object sender, EventArgs e)
		{
			Registry.CurrentUser.CreateSubKey("Control Panel\\Mouse").SetValue("MouseHoverTime", "400");
			this.Restore();
			this.Interface9.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CEA RID: 3306 RVA: 0x00007459 File Offset: 0x00005659
		public void RestoreInterface10_Click(object sender, EventArgs e)
		{
			Class14.Class14_0.method_3();
			this.Restore();
			this.Interface10.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CEB RID: 3307 RVA: 0x00007480 File Offset: 0x00005680
		public void RestoreInterface11_Click(object sender, EventArgs e)
		{
			Class12.Class12_0.method_1();
			this.Restore();
			this.Interface11.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CEC RID: 3308 RVA: 0x000438D8 File Offset: 0x00041AD8
		public void RestoreInterface12_Click(object sender, EventArgs e)
		{
			Class44.Class44_0.method_10();
			this.Restore();
			this.Interface12.ForeColor = GClass2.GClass2_0.color_0;
			foreach (CheckBox checkBox in this.panelmenu6.Controls.OfType<CheckBox>())
			{
				checkBox.ForeColor = GClass2.GClass2_0.color_0;
			}
		}

		// Token: 0x06000CED RID: 3309 RVA: 0x000074A7 File Offset: 0x000056A7
		public void RestoreInterface13_Click(object sender, EventArgs e)
		{
			Form2.Form2_0.method_20();
			this.Restore();
			this.Interface13.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CEE RID: 3310 RVA: 0x0004395C File Offset: 0x00041B5C
		public void RestoreInterface14_Click(object sender, EventArgs e)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop\\WindowMetrics");
			registryKey.SetValue("ScrollHeight", "-255");
			registryKey.SetValue("ScrollWidth", "-255");
			this.Restore();
			this.Interface14.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CEF RID: 3311 RVA: 0x000439B4 File Offset: 0x00041BB4
		public void RestoreInterface15_Click(object sender, EventArgs e)
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\DWM", true))
			{
				if (registryKey.GetValue("AnimationsShiftKey") != null)
				{
					registryKey.DeleteValue("AnimationsShiftKey");
				}
			}
			this.Restore();
			this.Interface15.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF0 RID: 3312 RVA: 0x00043A24 File Offset: 0x00041C24
		public void RestoreInterface16_Click(object sender, EventArgs e)
		{
			Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\HideDesktopIcons\\NewStartPanel").SetValue("{20D04FE0-3AEA-1069-A2D8-08002B30309D}", 1);
			this.Restore();
			this.Interface16.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF1 RID: 3313 RVA: 0x00043A7C File Offset: 0x00041C7C
		public void RestoreInterface17_Click(object sender, EventArgs e)
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced", true))
			{
				if (registryKey.GetValue("PersistBrowsers") != null)
				{
					registryKey.DeleteValue("PersistBrowsers");
				}
			}
			this.Restore();
			this.Interface17.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF2 RID: 3314 RVA: 0x00043AF8 File Offset: 0x00041CF8
		public void RestoreSystem1_Click(object sender, EventArgs e)
		{
			Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Notifications\\Settings\\Windows.SystemToast.SecurityAndMaintenance").SetValue("Enabled", 1);
			this.Restore();
			this.System1.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF3 RID: 3315 RVA: 0x00043B50 File Offset: 0x00041D50
		public void RestoreSystem2_Click(object sender, EventArgs e)
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Internet Settings\\Zones\\3", true))
			{
				if (registryKey != null && registryKey.GetValue("1806") != null)
				{
					registryKey.DeleteValue("1806");
				}
			}
			using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Internet Explorer\\Security", true))
			{
				if (registryKey2 != null && registryKey2.GetValue("DisableSecuritySettingsCheck") != null)
				{
					registryKey2.DeleteValue("DisableSecuritySettingsCheck");
				}
			}
			this.Restore();
			this.System2.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF4 RID: 3316 RVA: 0x000074CE File Offset: 0x000056CE
		public void RestoreSystem3_Click(object sender, EventArgs e)
		{
			Class82.Class82_0.method_1();
			this.Restore();
			this.System3.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF5 RID: 3317 RVA: 0x000074F5 File Offset: 0x000056F5
		public void RestoreSystem4_Click(object sender, EventArgs e)
		{
			Class42.Class42_0.method_1();
			this.Restore();
			this.System4.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF6 RID: 3318 RVA: 0x00043C14 File Offset: 0x00041E14
		public void RestoreSystem5_Click(object sender, EventArgs e)
		{
			RegistryKey key = Registry.CurrentUser.OpenSubKey("Keyboard Layout\\Toggle", true);
			try
			{
				new List<string>
				{
					"Hotkey",
					"Language Hotkey",
					"Layout Hotkey"
				}.Where(delegate(string x)
				{
					RegistryKey key = key;
					return ((key != null) ? key.GetValue(x) : null) != null;
				}).ToList<string>().ForEach(delegate(string x)
				{
					key.DeleteValue(x);
				});
			}
			finally
			{
				if (key != null)
				{
					((IDisposable)key).Dispose();
				}
			}
			this.Restore();
			this.System5.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF7 RID: 3319 RVA: 0x0000751C File Offset: 0x0000571C
		public void RestoreSystem6_Click(object sender, EventArgs e)
		{
			Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\7516b95f-f776-4464-8c53-06167f40cc99\\8EC4B3A5-6868-48c2-BE75-4F3044BE88A7").SetValue("Attributes", 1);
			this.Restore();
			this.System6.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF8 RID: 3320 RVA: 0x00043CCC File Offset: 0x00041ECC
		public void RestoreSystem7_Click(object sender, EventArgs e)
		{
			if (!GClass2.GClass2_0.String_3.Contains("7"))
			{
				GClass6.GClass6_0.method_14("schtasks /change /tn \"\\Microsoft\\Windows\\MemoryDiagnostic\\ProcessMemoryDiagnosticEvents\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\MemoryDiagnostic\\RunFullMemoryDiagnostic\" /enable");
			}
			else
			{
				GClass6.GClass6_0.method_14("schtasks /change /tn \"\\Microsoft\\Windows\\MemoryDiagnostic\\CorruptionDetector\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\MemoryDiagnostic\\DecompressionFailureDetector\" /enable");
			}
			this.Restore();
			this.System7.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x00007558 File Offset: 0x00005758
		public void RestoreSystem8_Click(object sender, EventArgs e)
		{
			Class39.Class39_0.method_1();
			this.Restore();
			this.System8.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CFA RID: 3322 RVA: 0x0000757F File Offset: 0x0000577F
		public void RestoreSystem9_Click(object sender, EventArgs e)
		{
			Class37.Class37_0.method_1();
			this.Restore();
			this.System9.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CFB RID: 3323 RVA: 0x000075A6 File Offset: 0x000057A6
		public void RestoreSystem10_Click(object sender, EventArgs e)
		{
			Class45.Class45_0.method_1();
			this.Restore();
			this.System10.ForeColor = GClass2.GClass2_0.color_0;
			this.AntiZapret.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CFC RID: 3324 RVA: 0x000075E2 File Offset: 0x000057E2
		public void RestoreSystem11_Click(object sender, EventArgs e)
		{
			Class74.Class74_0.method_1();
			this.Restore();
			this.System11.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CFD RID: 3325 RVA: 0x00007609 File Offset: 0x00005809
		public void RestoreSystem12_Click(object sender, EventArgs e)
		{
			Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management").SetValue("LargeSystemCache", 0);
			this.Restore();
			this.System12.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CFE RID: 3326 RVA: 0x00007645 File Offset: 0x00005845
		public void RestoreSystem13_Click(object sender, EventArgs e)
		{
			Registry.CurrentUser.DeleteSubKeyTree(GClass2.GClass2_0.String_0 + "\\Explorer\\Serialize", false);
			this.Restore();
			this.System13.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000CFF RID: 3327 RVA: 0x00043D2C File Offset: 0x00041F2C
		public void RestoreSystem14_Click(object sender, EventArgs e)
		{
			using (RegistryKey key2 = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer", true))
			{
				(from x in new List<string>
				{
					"ShowRecent",
					"ShowFrequent"
				}
				where key2.GetValue(x) != null
				select x).ToList<string>().ForEach(delegate(string x)
				{
					key2.DeleteValue(x);
				});
			}
			using (RegistryKey key = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced", true))
			{
				(from x in new List<string>
				{
					"Start_TrackDocs",
					"Start_TrackProgs"
				}
				where key.GetValue(x) != null
				select x).ToList<string>().ForEach(delegate(string x)
				{
					key.DeleteValue(x);
				});
			}
			this.Restore();
			this.System14.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000D00 RID: 3328 RVA: 0x00043E78 File Offset: 0x00042078
		public void RestoreSystem15_Click(object sender, EventArgs e)
		{
			Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\AutoplayHandlers").SetValue("DisableAutoplay", 0);
			this.Restore();
			this.System15.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000D01 RID: 3329 RVA: 0x00007681 File Offset: 0x00005881
		public void RestoreSystem16_Click(object sender, EventArgs e)
		{
			Registry.ClassesRoot.DeleteSubKeyTree("Applications\\photoviewer.dll\\shell\\open", false);
			this.Restore();
			this.System16.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000D02 RID: 3330 RVA: 0x000076AE File Offset: 0x000058AE
		public void RestoreSystem17_Click(object sender, EventArgs e)
		{
			Class46.Class46_0.method_1();
			this.Restore();
			this.System17.ForeColor = GClass2.GClass2_0.color_0;
		}

		// Token: 0x06000D03 RID: 3331 RVA: 0x00043ED0 File Offset: 0x000420D0
		public void Translate()
		{
			Form1.<Translate>d__247 <Translate>d__;
			<Translate>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Translate>d__.<>4__this = this;
			<Translate>d__.<>1__state = -1;
			<Translate>d__.<>t__builder.Start<Form1.<Translate>d__247>(ref <Translate>d__);
		}

		// Token: 0x06000D14 RID: 3348 RVA: 0x00055C50 File Offset: 0x00053E50
		[CompilerGenerated]
		private void method_1(LinkLabel link, Panel pnl)
		{
			if (link.Text != GClass2.GClass2_0.method_1("linkmenu2"))
			{
				foreach (Panel panel in this.MainPanel2.Controls.OfType<Panel>())
				{
					panel.Visible = false;
				}
				foreach (Panel panel2 in this.MainPanel3.Controls.OfType<Panel>())
				{
					panel2.Visible = false;
				}
				foreach (LinkLabel linkLabel in this.MainPanel2.Controls.OfType<LinkLabel>())
				{
					if (linkLabel.Name.Contains("menu"))
					{
						linkLabel.Text = GClass2.GClass2_0.method_1("linkmenu1");
					}
				}
				foreach (LinkLabel linkLabel2 in this.MainPanel3.Controls.OfType<LinkLabel>())
				{
					if (linkLabel2.Name.Contains("menu"))
					{
						linkLabel2.Text = GClass2.GClass2_0.method_1("linkmenu1");
					}
				}
			}
			if (!pnl.Visible)
			{
				pnl.Visible = true;
				link.Text = GClass2.GClass2_0.method_1("linkmenu2");
				return;
			}
			pnl.Visible = false;
			link.Text = GClass2.GClass2_0.method_1("linkmenu1");
		}

		// Token: 0x06000D28 RID: 3368 RVA: 0x000560BC File Offset: 0x000542BC
		[CompilerGenerated]
		private void method_2()
		{
			Form1.Struct80 @struct;
			@struct.<>t__builder = AsyncVoidMethodBuilder.Create();
			@struct.<>4__this = this;
			@struct.<>1__state = -1;
			@struct.<>t__builder.Start<Form1.Struct80>(ref @struct);
		}

		// Token: 0x06000D2D RID: 3373 RVA: 0x000560F4 File Offset: 0x000542F4
		[CompilerGenerated]
		internal static void smethod_3(Panel p)
		{
			typeof(Panel).method_16("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.SetProperty, null, p, new object[]
			{
				true
			});
		}

		// Token: 0x06000D31 RID: 3377 RVA: 0x00007958 File Offset: 0x00005B58
		[CompilerGenerated]
		internal static void smethod_4(string line)
		{
			if (!Directory.Exists(line))
			{
				Directory.CreateDirectory(line);
			}
		}

		// Token: 0x06000D35 RID: 3381 RVA: 0x0005612C File Offset: 0x0005432C
		[CompilerGenerated]
		internal static string smethod_5()
		{
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "DarkSkin")
			{
				return "DarkSkin";
			}
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SkySkin")
			{
				return "SkySkin";
			}
			if (!(GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SeaSkin"))
			{
			}
			return null;
		}

		// Token: 0x06000D38 RID: 3384 RVA: 0x000561FC File Offset: 0x000543FC
		[CompilerGenerated]
		private void method_3()
		{
			Form1.Struct81 @struct;
			@struct.<>t__builder = AsyncVoidMethodBuilder.Create();
			@struct.<>4__this = this;
			@struct.<>1__state = -1;
			@struct.<>t__builder.Start<Form1.Struct81>(ref @struct);
		}

		// Token: 0x06000D39 RID: 3385 RVA: 0x000079BC File Offset: 0x00005BBC
		[CompilerGenerated]
		private void method_4()
		{
			this.Anim();
			this.CheckBoxesChecker();
			this.Uncheck();
		}

		// Token: 0x06000D3A RID: 3386 RVA: 0x000079D0 File Offset: 0x00005BD0
		[CompilerGenerated]
		internal static void smethod_6()
		{
			WMessageBox.smethod_3(GClass2.GClass2_0.method_1("ServNoChoice2") ?? "", GClass2.GClass2_0.method_1("ServNoChoice1") ?? "", WMessageBox.GEnum2.OK, false, "", null);
		}

		// Token: 0x06000D3D RID: 3389 RVA: 0x000078BD File Offset: 0x00005ABD
		[CompilerGenerated]
		private bool method_5(Label label)
		{
			return label.ForeColor == this.Blue;
		}

		// Token: 0x06000D3E RID: 3390 RVA: 0x00056234 File Offset: 0x00054434
		[CompilerGenerated]
		internal static void smethod_7(List<string> servs)
		{
			string servlist = "$servs = @(";
			servs.ForEach(delegate(string x)
			{
				servlist = servlist + "'" + x + "',";
			});
			servlist = servlist.Remove(servlist.Length - 1);
			servlist += "); foreach ($serv in $servs) { stop-service $serv; reg add \"HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\$serv\" /v Start /t reg_dword /d \"4\" /f }";
			GClass14.smethod_0("powershell.exe -command " + servlist, false);
		}

		// Token: 0x06000D40 RID: 3392 RVA: 0x000562B0 File Offset: 0x000544B0
		[CompilerGenerated]
		internal static string smethod_8(ref Form1.<>c__DisplayClass56_8 <>c__DisplayClass56_8_0)
		{
			string directoryName = Path.GetDirectoryName(<>c__DisplayClass56_8_0.obj.FileName);
			string fileName = Path.GetFileName(<>c__DisplayClass56_8_0.obj.FileName);
			if (Form1.<>o__56.<>p__0 == null)
			{
				Form1.<>o__56.<>p__0 = CallSite<Func<CallSite, object, GInterface12>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(GInterface12), typeof(Form1)));
			}
			return Form1.<>o__56.<>p__0.Target(Form1.<>o__56.<>p__0, ((GInterface11)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("13709620-C279-11CE-A49E-444553540000")))).imethod_0(directoryName).imethod_0(fileName).Object_0).String_0;
		}

		// Token: 0x06000D41 RID: 3393 RVA: 0x00056350 File Offset: 0x00054550
		[CompilerGenerated]
		private void method_6()
		{
			Form1.Struct83 @struct;
			@struct.<>t__builder = AsyncVoidMethodBuilder.Create();
			@struct.<>4__this = this;
			@struct.<>1__state = -1;
			@struct.<>t__builder.Start<Form1.Struct83>(ref @struct);
		}

		// Token: 0x06000D42 RID: 3394 RVA: 0x00056388 File Offset: 0x00054588
		[CompilerGenerated]
		private void method_7()
		{
			Form1.Struct82 @struct;
			@struct.<>t__builder = AsyncVoidMethodBuilder.Create();
			@struct.<>4__this = this;
			@struct.<>1__state = -1;
			@struct.<>t__builder.Start<Form1.Struct82>(ref @struct);
		}

		// Token: 0x06000D52 RID: 3410 RVA: 0x00056A20 File Offset: 0x00054C20
		[CompilerGenerated]
		internal static int smethod_9()
		{
			string path = GClass13.string_9 + "\\WindowsApps";
			int size = 0;
			Directory.GetFiles(path, "*", SearchOption.AllDirectories).ToList<string>().ForEach(delegate(string x)
			{
				size += (int)new FileInfo(x).Length;
			});
			return size;
		}

		// Token: 0x06000D57 RID: 3415 RVA: 0x00056A70 File Offset: 0x00054C70
		[CompilerGenerated]
		internal static string smethod_10(ref Form1.<>c__DisplayClass93_0 <>c__DisplayClass93_0_0)
		{
			string directoryName = Path.GetDirectoryName(<>c__DisplayClass93_0_0.file);
			string fileName = Path.GetFileName(<>c__DisplayClass93_0_0.file);
			if (Form1.<>o__93.<>p__0 == null)
			{
				Form1.<>o__93.<>p__0 = CallSite<Func<CallSite, object, GInterface12>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(GInterface12), typeof(Form1)));
			}
			return Form1.<>o__93.<>p__0.Target(Form1.<>o__93.<>p__0, ((GInterface11)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("13709620-C279-11CE-A49E-444553540000")))).imethod_0(directoryName).imethod_0(fileName).Object_0).String_0;
		}

		// Token: 0x06000D72 RID: 3442 RVA: 0x00057DFC File Offset: 0x00055FFC
		[CompilerGenerated]
		internal static string smethod_11(string line)
		{
			return Process.Start(new ProcessStartInfo
			{
				FileName = "powershell",
				Arguments = "-command " + line,
				UseShellExecute = false,
				RedirectStandardOutput = true,
				CreateNoWindow = true
			}).StandardOutput.ReadToEnd();
		}

		// Token: 0x06000D78 RID: 3448 RVA: 0x00057F44 File Offset: 0x00056144
		[CompilerGenerated]
		private void method_8(string text, Action applyAction, Action restoreAction, Color color, bool apply, bool restore)
		{
			GClass1 gclass = new GClass1(text, applyAction, restoreAction, color, apply, restore, this.Apply.Width, this.Apply.Height);
			gclass.Location = new Point(gclass.Location.X, gclass.Location.Y);
			gclass.Size = new Size(this.FlowPanel.Width - this.FlowPanel.Location.X - SystemInformation.VerticalScrollBarWidth - 2, this.Apply.Height * 2);
			this.FlowPanel.Controls.Add(gclass);
		}

		// Token: 0x06000D79 RID: 3449 RVA: 0x00007C93 File Offset: 0x00005E93
		[CompilerGenerated]
		internal static void smethod_12()
		{
			GClass6.GClass6_0.method_14("sc config NlaSvc start= delayed-auto & sc config EventSystem start= delayed-auto");
		}

		// Token: 0x06000D7A RID: 3450 RVA: 0x00007CA4 File Offset: 0x00005EA4
		[CompilerGenerated]
		internal static void smethod_13()
		{
			GClass6.GClass6_0.method_14("sc config NlaSvc start= auto & sc config EventSystem start= auto");
		}

		// Token: 0x06000D7B RID: 3451 RVA: 0x00007CB5 File Offset: 0x00005EB5
		[CompilerGenerated]
		internal static void smethod_14()
		{
			Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop").SetValue("JPEGImportQuality", 100);
		}

		// Token: 0x06000D7C RID: 3452 RVA: 0x00007CD7 File Offset: 0x00005ED7
		[CompilerGenerated]
		internal static void smethod_15()
		{
			Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop").DeleteValue("JPEGImportQuality");
		}

		// Token: 0x06000D7D RID: 3453 RVA: 0x00057FF0 File Offset: 0x000561F0
		[CompilerGenerated]
		internal static bool smethod_16(string file)
		{
			bool result;
			try
			{
				File.OpenWrite(new FileInfo(file).FullName).Close();
				result = false;
			}
			catch
			{
				result = true;
			}
			return result;
		}

		// Token: 0x06000D7E RID: 3454 RVA: 0x0005802C File Offset: 0x0005622C
		[CompilerGenerated]
		private void method_9()
		{
			DriveInfo driveInfo = new DriveInfo("C");
			long availableFreeSpace = driveInfo.AvailableFreeSpace;
			GClass6.GClass6_0.method_15("dism /online /set-reservedstoragestate /state:disabled");
			long availableFreeSpace2 = driveInfo.AvailableFreeSpace;
			this.Popup(string.Concat(new string[]
			{
				"Win 10 Tweaker Pro",
				Environment.NewLine,
				GClass2.GClass2_0.method_1("Cleaned1"),
				" ",
				GClass6.GClass6_0.method_6((double)(availableFreeSpace2 - availableFreeSpace))
			}), 8000);
		}

		// Token: 0x06000D7F RID: 3455 RVA: 0x00007CF2 File Offset: 0x00005EF2
		[CompilerGenerated]
		internal static void smethod_17()
		{
			GClass6.GClass6_0.method_15("dism /online /set-reservedstoragestate /state:enabled");
		}

		// Token: 0x06000D80 RID: 3456 RVA: 0x00007D03 File Offset: 0x00005F03
		[CompilerGenerated]
		private void method_10()
		{
			this.FlowPanel.Controls.Clear();
			this.PersonalMethod();
		}

		// Token: 0x06000D81 RID: 3457 RVA: 0x000580B0 File Offset: 0x000562B0
		[CompilerGenerated]
		private void method_11()
		{
			string text = Process.Start(new ProcessStartInfo
			{
				FileName = "powercfg",
				Arguments = "-duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61",
				UseShellExecute = false,
				RedirectStandardOutput = true,
				CreateNoWindow = true
			}).StandardOutput.ReadToEnd();
			string text2 = text.Substring(text.IndexOf(": ") + 2);
			text = text2.Remove(text2.IndexOf(" "));
			GClass6.GClass6_0.method_15("powercfg /s " + text);
			this.method_10();
		}

		// Token: 0x06000D82 RID: 3458 RVA: 0x0005813C File Offset: 0x0005633C
		[CompilerGenerated]
		internal static string smethod_18()
		{
			return Process.Start(new ProcessStartInfo
			{
				FileName = "powershell",
				Arguments = "-command Get-PhysicalDisk | select FriendlyName,MediaType",
				UseShellExecute = false,
				RedirectStandardOutput = true,
				CreateNoWindow = true
			}).StandardOutput.ReadToEnd();
		}

		// Token: 0x06000D83 RID: 3459 RVA: 0x00058188 File Offset: 0x00056388
		[CompilerGenerated]
		private void method_12()
		{
			RegistryKey registryKey = Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management");
			registryKey.SetValue("PagingFiles_bak", (string[])((registryKey != null) ? registryKey.GetValue("PagingFiles") : null), RegistryValueKind.MultiString);
			registryKey.SetValue("PagingFiles", new string[0], RegistryValueKind.MultiString);
			this.Popup(GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("RestartRequired"), 8000);
		}

		// Token: 0x06000D84 RID: 3460 RVA: 0x00058208 File Offset: 0x00056408
		[CompilerGenerated]
		private void method_13()
		{
			RegistryKey registryKey = Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management");
			if (registryKey.GetValue("PagingFiles_bak") != null)
			{
				registryKey.SetValue("PagingFiles", (string[])((registryKey != null) ? registryKey.GetValue("PagingFiles_bak") : null), RegistryValueKind.MultiString);
				registryKey.DeleteValue("PagingFiles_bak");
			}
			else
			{
				registryKey.SetValue("PagingFiles1", new string[]
				{
					"?:\\pagefile.sys"
				}, RegistryValueKind.MultiString);
			}
			this.Popup(GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("RestartRequired"), 8000);
		}

		// Token: 0x06000D85 RID: 3461 RVA: 0x00007D1B File Offset: 0x00005F1B
		[CompilerGenerated]
		internal static void smethod_19()
		{
			GClass6.GClass6_0.method_14("powercfg /change monitor-timeout-ac 0");
		}

		// Token: 0x06000D86 RID: 3462 RVA: 0x00007D2C File Offset: 0x00005F2C
		[CompilerGenerated]
		internal static void smethod_20()
		{
			GClass6.GClass6_0.method_14("powercfg /change monitor-timeout-ac 10");
		}

		// Token: 0x06000D87 RID: 3463 RVA: 0x00007D3D File Offset: 0x00005F3D
		[CompilerGenerated]
		internal static void smethod_21()
		{
			GClass6.GClass6_0.method_14("powercfg /change disk-timeout-ac 0");
		}

		// Token: 0x06000D88 RID: 3464 RVA: 0x00007D4E File Offset: 0x00005F4E
		[CompilerGenerated]
		internal static void smethod_22()
		{
			GClass6.GClass6_0.method_14("powercfg /change disk-timeout-ac 20");
		}

		// Token: 0x06000D89 RID: 3465 RVA: 0x000582AC File Offset: 0x000564AC
		[CompilerGenerated]
		private void method_14()
		{
			Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\0001").SetValue("PnPCapabilities", 24);
			this.Popup(GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("RestartRequired"), 8000);
		}

		// Token: 0x06000D8A RID: 3466 RVA: 0x00058308 File Offset: 0x00056508
		[CompilerGenerated]
		private void method_15()
		{
			Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\0001").DeleteValue("PnPCapabilities");
			this.Popup(GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("RestartRequired"), 8000);
		}

		// Token: 0x06000D8B RID: 3467 RVA: 0x00007D5F File Offset: 0x00005F5F
		[CompilerGenerated]
		internal static void smethod_23()
		{
			Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\QuietHours").SetValue("Enabled", 0);
		}

		// Token: 0x06000D8C RID: 3468 RVA: 0x0005835C File Offset: 0x0005655C
		[CompilerGenerated]
		internal static void smethod_24()
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\QuietHours", true))
			{
				registryKey.DeleteValue("Enabled");
			}
		}

		// Token: 0x06000D8D RID: 3469 RVA: 0x00007D80 File Offset: 0x00005F80
		[CompilerGenerated]
		internal static void smethod_25()
		{
			EventLogSession.GlobalSession.GetLogNames().ToList<string>().ForEach(delegate(string x)
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WINEVT\\Channels\\" + x, true))
				{
					try
					{
						if (registryKey != null && registryKey.GetValue("MaxSize") != null)
						{
							registryKey.SetValue("MaxSize_old", (int)registryKey.GetValue("MaxSize"));
							registryKey.SetValue("MaxSize", 64);
						}
						if (registryKey != null && registryKey.GetValue("Enabled") != null)
						{
							registryKey.SetValue("Enabled_old", (int)registryKey.GetValue("Enabled"));
							registryKey.SetValue("Enabled", 0);
						}
					}
					catch
					{
					}
				}
			});
		}

		// Token: 0x06000D8E RID: 3470 RVA: 0x00007DB5 File Offset: 0x00005FB5
		[CompilerGenerated]
		internal static void smethod_26()
		{
			EventLogSession.GlobalSession.GetLogNames().ToList<string>().ForEach(delegate(string x)
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WINEVT\\Channels\\" + x, true))
				{
					try
					{
						if (registryKey != null && registryKey.GetValue("MaxSize") != null && registryKey != null && registryKey.GetValue("MaxSize_old") != null)
						{
							registryKey.SetValue("MaxSize", (int)registryKey.GetValue("MaxSize_old"));
							registryKey.DeleteValue("MaxSize_old");
						}
						if (registryKey != null && registryKey.GetValue("Enabled") != null && registryKey != null && registryKey.GetValue("Enabled_old") != null)
						{
							registryKey.SetValue("Enabled", (int)registryKey.GetValue("Enabled_old"));
							registryKey.DeleteValue("Enabled_old");
						}
					}
					catch
					{
					}
				}
			});
		}

		// Token: 0x06000D8F RID: 3471 RVA: 0x00007DEA File Offset: 0x00005FEA
		[CompilerGenerated]
		internal static void smethod_27()
		{
			Registry.CurrentUser.CreateSubKey("Control Panel\\Keyboard").SetValue("InitialKeyboardIndicators", "2");
		}

		// Token: 0x06000D90 RID: 3472 RVA: 0x00007E0A File Offset: 0x0000600A
		[CompilerGenerated]
		internal static void smethod_28()
		{
			Registry.CurrentUser.CreateSubKey("Control Panel\\Keyboard").SetValue("InitialKeyboardIndicators", "0");
		}

		// Token: 0x06000D91 RID: 3473 RVA: 0x00007E2A File Offset: 0x0000602A
		[CompilerGenerated]
		internal static void smethod_29()
		{
			Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer").SetValue("Max Cached Icons", "4096");
		}

		// Token: 0x06000D92 RID: 3474 RVA: 0x000583A4 File Offset: 0x000565A4
		[CompilerGenerated]
		internal static void smethod_30()
		{
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer", true))
			{
				registryKey.DeleteValue("Max Cached Icons");
			}
		}

		// Token: 0x06000D93 RID: 3475 RVA: 0x00007E4A File Offset: 0x0000604A
		[CompilerGenerated]
		internal static void smethod_31()
		{
			Registry.CurrentUser.CreateSubKey("Control Panel\\Accessibility\\StickyKeys").SetValue("Flags", "506");
		}

		// Token: 0x06000D94 RID: 3476 RVA: 0x00007E6A File Offset: 0x0000606A
		[CompilerGenerated]
		internal static void smethod_32()
		{
			Registry.CurrentUser.CreateSubKey("Control Panel\\Accessibility\\StickyKeys").SetValue("Flags", "510");
		}

		// Token: 0x06000D95 RID: 3477 RVA: 0x00007E8A File Offset: 0x0000608A
		[CompilerGenerated]
		internal static void smethod_33()
		{
			GClass6.GClass6_0.method_14("bcdedit /set {default} bootmenupolicy legacy");
		}

		// Token: 0x06000D96 RID: 3478 RVA: 0x00007E9B File Offset: 0x0000609B
		[CompilerGenerated]
		internal static void smethod_34()
		{
			GClass6.GClass6_0.method_14("bcdedit /set {default} bootmenupolicy standard");
		}

		// Token: 0x06000D97 RID: 3479 RVA: 0x000583EC File Offset: 0x000565EC
		[CompilerGenerated]
		internal static void smethod_35()
		{
			List<string> list = new List<string>();
			list.Add("SOFTWARE\\Classes\\Directory\\shell\\cmd");
			list.Add("SOFTWARE\\Classes\\Directory\\background\\shell\\cmd");
			list.ForEach(delegate(string x)
			{
				GClass6.GClass6_0.method_17(Registry.LocalMachine.OpenSubKey(x), true);
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(x, true))
				{
					registryKey.DeleteValue("HideBasedOnVelocityId");
				}
			});
		}

		// Token: 0x06000D98 RID: 3480 RVA: 0x00058438 File Offset: 0x00056638
		[CompilerGenerated]
		internal static void smethod_36()
		{
			List<string> list = new List<string>();
			list.Add("SOFTWARE\\Classes\\Directory\\shell\\cmd");
			list.Add("SOFTWARE\\Classes\\Directory\\background\\shell\\cmd");
			list.ForEach(delegate(string x)
			{
				GClass6.GClass6_0.method_17(Registry.LocalMachine.OpenSubKey(x), true);
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(x, true))
				{
					registryKey.SetValue("HideBasedOnVelocityId", 6527944);
				}
			});
		}

		// Token: 0x06000D99 RID: 3481 RVA: 0x00007EAC File Offset: 0x000060AC
		[CompilerGenerated]
		internal static void smethod_37()
		{
			Registry.CurrentUser.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer").SetValue("DisableNotificationCenter", 1);
			Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\PushNotifications").SetValue("ToastEnabled", 0);
		}

		// Token: 0x06000D9A RID: 3482 RVA: 0x00058484 File Offset: 0x00056684
		[CompilerGenerated]
		internal static void smethod_38()
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer", true))
			{
				registryKey.DeleteValue("DisableNotificationCenter");
			}
			using (RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\PushNotifications", true))
			{
				registryKey2.DeleteValue("ToastEnabled");
			}
		}

		// Token: 0x06000D9B RID: 3483 RVA: 0x00058500 File Offset: 0x00056700
		[CompilerGenerated]
		internal static void smethod_39()
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Control Panel\\International", true))
			{
				registryKey.SetValue("sShortDate_bak", registryKey.GetValue("sShortDate"));
				if (!registryKey.GetValue("sShortDate").ToString().StartsWith("ddd, "))
				{
					registryKey.SetValue("sShortDate", string.Format("ddd, {0}", registryKey.GetValue("sShortDate")));
				}
			}
		}

		// Token: 0x06000D9C RID: 3484 RVA: 0x0005858C File Offset: 0x0005678C
		[CompilerGenerated]
		internal static void smethod_40()
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Control Panel\\International", true))
			{
				registryKey.SetValue("sShortDate", registryKey.GetValue("sShortDate_bak").ToString());
				registryKey.DeleteValue("sShortDate_bak");
			}
		}

		// Token: 0x06000D9D RID: 3485 RVA: 0x00007EEC File Offset: 0x000060EC
		[CompilerGenerated]
		internal static void smethod_41()
		{
			Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Multimedia\\Audio").SetValue("UserDuckingPreference", 3);
		}

		// Token: 0x06000D9E RID: 3486 RVA: 0x000585EC File Offset: 0x000567EC
		[CompilerGenerated]
		internal static void smethod_42()
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Multimedia\\Audio", true))
			{
				registryKey.DeleteValue("UserDuckingPreference");
			}
		}

		// Token: 0x06000DA3 RID: 3491 RVA: 0x0005866C File Offset: 0x0005686C
		[CompilerGenerated]
		internal static void smethod_43(Panel panel, LinkLabelLinkClickedEventHandler link)
		{
			foreach (Button button in panel.Controls.OfType<Button>())
			{
				foreach (CheckBox checkBox in panel.Controls.OfType<CheckBox>())
				{
					MethodInfo[] array = typeof(Form1).method_18();
					for (int i = 0; i < array.Length; i++)
					{
						if (array[i].Name.Contains(button.Name + "_C") && button.Name.Replace("Restore", "") == checkBox.Name && checkBox.ForeColor == GClass2.GClass2_0.color_2)
						{
							link(null, null);
							button.PerformClick();
						}
					}
				}
			}
		}

		// Token: 0x06000DA4 RID: 3492 RVA: 0x0005878C File Offset: 0x0005698C
		[CompilerGenerated]
		internal static void smethod_44()
		{
			GClass6.GClass6_0.method_14(string.Concat(new string[]
			{
				"Taskkill /f /im \"",
				GClass2.GClass2_0.String_10,
				"\" && Timeout /t 1 && \"",
				GClass2.GClass2_0.String_10,
				"\""
			}));
		}

		// Token: 0x06000DA5 RID: 3493 RVA: 0x00002A53 File Offset: 0x00000C53
		static Label smethod_45()
		{
			return new Label();
		}

		// Token: 0x06000DA6 RID: 3494 RVA: 0x00002A77 File Offset: 0x00000C77
		static Panel smethod_46()
		{
			return new Panel();
		}

		// Token: 0x06000DA7 RID: 3495 RVA: 0x0000295A File Offset: 0x00000B5A
		static Control.ControlCollection smethod_47(Control control_0)
		{
			return control_0.Controls;
		}

		// Token: 0x06000DA8 RID: 3496 RVA: 0x00002951 File Offset: 0x00000B51
		static void smethod_48(Control control_0, EventHandler eventHandler_0)
		{
			control_0.Click += eventHandler_0;
		}

		// Token: 0x06000DA9 RID: 3497 RVA: 0x00007F39 File Offset: 0x00006139
		static void smethod_49(DataGridView dataGridView_0, EventHandler eventHandler_0)
		{
			dataGridView_0.Sorted += eventHandler_0;
		}

		// Token: 0x06000DAA RID: 3498 RVA: 0x00002C23 File Offset: 0x00000E23
		static string smethod_50(Control control_0)
		{
			return control_0.Name;
		}

		// Token: 0x06000DAB RID: 3499 RVA: 0x00002A20 File Offset: 0x00000C20
		static bool smethod_51(string string_0, string string_1)
		{
			return string_0.Contains(string_1);
		}

		// Token: 0x06000DAC RID: 3500 RVA: 0x00002E61 File Offset: 0x00001061
		static void smethod_52(Control control_0, ImageLayout imageLayout_0)
		{
			control_0.BackgroundImageLayout = imageLayout_0;
		}

		// Token: 0x06000DAD RID: 3501 RVA: 0x00002B2F File Offset: 0x00000D2F
		static void smethod_53(Control control_0, Image image_0)
		{
			control_0.BackgroundImage = image_0;
		}

		// Token: 0x06000DAE RID: 3502 RVA: 0x00005815 File Offset: 0x00003A15
		static FlatButtonAppearance smethod_54(ButtonBase buttonBase_0)
		{
			return buttonBase_0.FlatAppearance;
		}

		// Token: 0x06000DAF RID: 3503 RVA: 0x00005826 File Offset: 0x00003A26
		static void smethod_55(FlatButtonAppearance flatButtonAppearance_0, int int_0)
		{
			flatButtonAppearance_0.BorderSize = int_0;
		}

		// Token: 0x06000DB0 RID: 3504 RVA: 0x00005841 File Offset: 0x00003A41
		static void smethod_56(ButtonBase buttonBase_0, FlatStyle flatStyle_0)
		{
			buttonBase_0.FlatStyle = flatStyle_0;
		}

		// Token: 0x06000DB1 RID: 3505 RVA: 0x0000582F File Offset: 0x00003A2F
		static void smethod_57(FlatButtonAppearance flatButtonAppearance_0, Color color_0)
		{
			flatButtonAppearance_0.MouseDownBackColor = color_0;
		}

		// Token: 0x06000DB2 RID: 3506 RVA: 0x00005838 File Offset: 0x00003A38
		static void smethod_58(FlatButtonAppearance flatButtonAppearance_0, Color color_0)
		{
			flatButtonAppearance_0.MouseOverBackColor = color_0;
		}

		// Token: 0x06000DB3 RID: 3507 RVA: 0x000032E3 File Offset: 0x000014E3
		static Color smethod_59(Control control_0)
		{
			return control_0.BackColor;
		}

		// Token: 0x06000DB4 RID: 3508 RVA: 0x00007F42 File Offset: 0x00006142
		static void smethod_60(Control control_0, EventHandler eventHandler_0)
		{
			control_0.BackColorChanged += eventHandler_0;
		}

		// Token: 0x06000DB5 RID: 3509 RVA: 0x00002974 File Offset: 0x00000B74
		static bool smethod_61(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06000DB6 RID: 3510 RVA: 0x0000297C File Offset: 0x00000B7C
		static void smethod_62(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06000DB7 RID: 3511 RVA: 0x00007F4B File Offset: 0x0000614B
		static IEnumerable<int> smethod_63(int int_0, int int_1)
		{
			return Enumerable.Range(int_0, int_1);
		}

		// Token: 0x06000DB8 RID: 3512 RVA: 0x00002962 File Offset: 0x00000B62
		static void smethod_64(Control control_0, EventHandler eventHandler_0)
		{
			control_0.MouseEnter += eventHandler_0;
		}

		// Token: 0x06000DB9 RID: 3513 RVA: 0x0000296B File Offset: 0x00000B6B
		static void smethod_65(Control control_0, EventHandler eventHandler_0)
		{
			control_0.MouseLeave += eventHandler_0;
		}

		// Token: 0x06000DBA RID: 3514 RVA: 0x00002A0F File Offset: 0x00000C0F
		static void smethod_66(Control control_0, PaintEventHandler paintEventHandler_0)
		{
			control_0.Paint += paintEventHandler_0;
		}

		// Token: 0x06000DBB RID: 3515 RVA: 0x00002929 File Offset: 0x00000B29
		static void smethod_67(Control control_0)
		{
			control_0.Invalidate();
		}

		// Token: 0x06000DBC RID: 3516 RVA: 0x00002984 File Offset: 0x00000B84
		static Control.ControlCollection smethod_68(Control control_0)
		{
			return control_0.Controls;
		}

		// Token: 0x06000DBD RID: 3517 RVA: 0x000029DD File Offset: 0x00000BDD
		static object smethod_69(RegistryKey registryKey_0, string string_0)
		{
			return registryKey_0.GetValue(string_0);
		}

		// Token: 0x06000DBE RID: 3518 RVA: 0x000029E6 File Offset: 0x00000BE6
		static string smethod_70(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000DBF RID: 3519 RVA: 0x00002B59 File Offset: 0x00000D59
		static bool smethod_71(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000DC0 RID: 3520 RVA: 0x0000328B File Offset: 0x0000148B
		static int smethod_72(Control control_0)
		{
			return control_0.Width;
		}

		// Token: 0x06000DC1 RID: 3521 RVA: 0x00002A07 File Offset: 0x00000C07
		static Point smethod_73(Control control_0)
		{
			return control_0.Location;
		}

		// Token: 0x06000DC2 RID: 3522 RVA: 0x00004E09 File Offset: 0x00003009
		static void smethod_74(LinkLabel linkLabel_0, Color color_0)
		{
			linkLabel_0.LinkColor = color_0;
		}

		// Token: 0x06000DC3 RID: 3523 RVA: 0x000052FC File Offset: 0x000034FC
		static object smethod_75(Control control_0, Delegate delegate_0)
		{
			return control_0.Invoke(delegate_0);
		}

		// Token: 0x06000DC4 RID: 3524 RVA: 0x000029D4 File Offset: 0x00000BD4
		static void smethod_76(Control control_0, bool bool_1)
		{
			control_0.Visible = bool_1;
		}

		// Token: 0x06000DC5 RID: 3525 RVA: 0x00007F54 File Offset: 0x00006154
		static bool smethod_77(Control control_0)
		{
			return control_0.Visible;
		}

		// Token: 0x06000DC6 RID: 3526 RVA: 0x00007F5C File Offset: 0x0000615C
		static void smethod_78(Button button_0)
		{
			button_0.PerformClick();
		}

		// Token: 0x06000DC7 RID: 3527 RVA: 0x00002E6A File Offset: 0x0000106A
		static void smethod_79(PictureBox pictureBox_0, Image image_0)
		{
			pictureBox_0.Image = image_0;
		}

		// Token: 0x06000DC8 RID: 3528 RVA: 0x00002BA7 File Offset: 0x00000DA7
		static void smethod_80(Control control_0, Color color_0)
		{
			control_0.BackColor = color_0;
		}

		// Token: 0x06000DC9 RID: 3529 RVA: 0x00007F64 File Offset: 0x00006164
		static void smethod_81(ToolTip toolTip_0, Control control_0, string string_0)
		{
			toolTip_0.SetToolTip(control_0, string_0);
		}

		// Token: 0x06000DCA RID: 3530 RVA: 0x00002A18 File Offset: 0x00000C18
		static string smethod_82(Control control_0)
		{
			return control_0.Text;
		}

		// Token: 0x06000DCB RID: 3531 RVA: 0x00002920 File Offset: 0x00000B20
		static void smethod_83(Control control_0, string string_0)
		{
			control_0.Text = string_0;
		}

		// Token: 0x06000DCC RID: 3532 RVA: 0x00007F6E File Offset: 0x0000616E
		static void smethod_84(CheckBox checkBox_0, bool bool_1)
		{
			checkBox_0.Checked = bool_1;
		}

		// Token: 0x06000DCD RID: 3533 RVA: 0x0000584A File Offset: 0x00003A4A
		static bool smethod_85(Control control_0)
		{
			return control_0.Enabled;
		}

		// Token: 0x06000DCE RID: 3534 RVA: 0x000029CD File Offset: 0x00000BCD
		static FormCollection smethod_86()
		{
			return Application.OpenForms;
		}

		// Token: 0x06000DCF RID: 3535 RVA: 0x000057CB File Offset: 0x000039CB
		static DialogResult smethod_87(Form form_0)
		{
			return form_0.ShowDialog();
		}

		// Token: 0x06000DD0 RID: 3536 RVA: 0x00002AB7 File Offset: 0x00000CB7
		static void smethod_88(Control control_0)
		{
			control_0.Show();
		}

		// Token: 0x06000DD1 RID: 3537 RVA: 0x000057C2 File Offset: 0x000039C2
		static Form smethod_89(FormCollection formCollection_0, string string_0)
		{
			return formCollection_0[string_0];
		}

		// Token: 0x06000DD2 RID: 3538 RVA: 0x00003C75 File Offset: 0x00001E75
		static Process smethod_90()
		{
			return Process.GetCurrentProcess();
		}

		// Token: 0x06000DD3 RID: 3539 RVA: 0x00003C7C File Offset: 0x00001E7C
		static int smethod_91(Process process_0)
		{
			return process_0.Id;
		}

		// Token: 0x06000DD4 RID: 3540 RVA: 0x000033C8 File Offset: 0x000015C8
		static string smethod_92(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000DD5 RID: 3541 RVA: 0x00003033 File Offset: 0x00001233
		static string smethod_93(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x06000DD6 RID: 3542 RVA: 0x00002FD2 File Offset: 0x000011D2
		static DataGridViewRowCollection smethod_94(DataGridView dataGridView_0)
		{
			return dataGridView_0.Rows;
		}

		// Token: 0x06000DD7 RID: 3543 RVA: 0x00007F77 File Offset: 0x00006177
		static IEnumerator smethod_95(IEnumerable ienumerable_0)
		{
			return ienumerable_0.GetEnumerator();
		}

		// Token: 0x06000DD8 RID: 3544 RVA: 0x00003FEB File Offset: 0x000021EB
		static object smethod_96(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x06000DD9 RID: 3545 RVA: 0x00007F7F File Offset: 0x0000617F
		static DataGridViewCellCollection smethod_97(DataGridViewRow dataGridViewRow_0)
		{
			return dataGridViewRow_0.Cells;
		}

		// Token: 0x06000DDA RID: 3546 RVA: 0x00007F87 File Offset: 0x00006187
		static IEnumerator smethod_98(BaseCollection baseCollection_0)
		{
			return baseCollection_0.GetEnumerator();
		}

		// Token: 0x06000DDB RID: 3547 RVA: 0x00007F8F File Offset: 0x0000618F
		static int smethod_99(DataGridViewCell dataGridViewCell_0)
		{
			return dataGridViewCell_0.ColumnIndex;
		}

		// Token: 0x06000DDC RID: 3548 RVA: 0x00007F97 File Offset: 0x00006197
		static void smethod_100(DataGridViewCell dataGridViewCell_0, object object_0)
		{
			dataGridViewCell_0.Value = object_0;
		}

		// Token: 0x06000DDD RID: 3549 RVA: 0x00002AAE File Offset: 0x00000CAE
		static void smethod_101(Control control_0, MouseEventHandler mouseEventHandler_0)
		{
			control_0.MouseDown += mouseEventHandler_0;
		}

		// Token: 0x06000DDE RID: 3550 RVA: 0x0000303D File Offset: 0x0000123D
		static DataGridViewCellStyle smethod_102()
		{
			return new DataGridViewCellStyle();
		}

		// Token: 0x06000DDF RID: 3551 RVA: 0x00007FA0 File Offset: 0x000061A0
		static void smethod_103(DataGridViewCellStyle dataGridViewCellStyle_0, string string_0)
		{
			dataGridViewCellStyle_0.Format = string_0;
		}

		// Token: 0x06000DE0 RID: 3552 RVA: 0x00007FA9 File Offset: 0x000061A9
		static void smethod_104(DataGridViewCellStyle dataGridViewCellStyle_0, object object_0)
		{
			dataGridViewCellStyle_0.NullValue = object_0;
		}

		// Token: 0x06000DE1 RID: 3553 RVA: 0x00007FB2 File Offset: 0x000061B2
		static void smethod_105(DataGridViewBand dataGridViewBand_0, DataGridViewCellStyle dataGridViewCellStyle_0)
		{
			dataGridViewBand_0.DefaultCellStyle = dataGridViewCellStyle_0;
		}

		// Token: 0x06000DE2 RID: 3554 RVA: 0x000029FF File Offset: 0x00000BFF
		static int smethod_106(Control control_0)
		{
			return control_0.Width;
		}

		// Token: 0x06000DE3 RID: 3555 RVA: 0x0000309B File Offset: 0x0000129B
		static void smethod_107(DataGridViewColumn dataGridViewColumn_0, int int_0)
		{
			dataGridViewColumn_0.Width = int_0;
		}

		// Token: 0x06000DE4 RID: 3556 RVA: 0x000030A4 File Offset: 0x000012A4
		static int smethod_108(DataGridViewColumn dataGridViewColumn_0)
		{
			return dataGridViewColumn_0.Width;
		}

		// Token: 0x06000DE5 RID: 3557 RVA: 0x000030AC File Offset: 0x000012AC
		static int smethod_109()
		{
			return SystemInformation.VerticalScrollBarWidth;
		}

		// Token: 0x06000DE6 RID: 3558 RVA: 0x00002FA0 File Offset: 0x000011A0
		static void smethod_110(DataGridView dataGridView_0, Color color_0)
		{
			dataGridView_0.BackgroundColor = color_0;
		}

		// Token: 0x06000DE7 RID: 3559 RVA: 0x00002FA9 File Offset: 0x000011A9
		static DataGridViewRow smethod_111(DataGridView dataGridView_0)
		{
			return dataGridView_0.RowTemplate;
		}

		// Token: 0x06000DE8 RID: 3560 RVA: 0x00002FB1 File Offset: 0x000011B1
		static DataGridViewCellStyle smethod_112(DataGridViewBand dataGridViewBand_0)
		{
			return dataGridViewBand_0.DefaultCellStyle;
		}

		// Token: 0x06000DE9 RID: 3561 RVA: 0x00002FB9 File Offset: 0x000011B9
		static void smethod_113(DataGridViewCellStyle dataGridViewCellStyle_0, Color color_0)
		{
			dataGridViewCellStyle_0.BackColor = color_0;
		}

		// Token: 0x06000DEA RID: 3562 RVA: 0x00002FC2 File Offset: 0x000011C2
		static DataGridViewCellStyle smethod_114(DataGridView dataGridView_0)
		{
			return dataGridView_0.ColumnHeadersDefaultCellStyle;
		}

		// Token: 0x06000DEB RID: 3563 RVA: 0x00002F0D File Offset: 0x0000110D
		static bool smethod_115(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06000DEC RID: 3564 RVA: 0x000033DB File Offset: 0x000015DB
		static string[] smethod_116(string string_0)
		{
			return File.ReadAllLines(string_0);
		}

		// Token: 0x06000DED RID: 3565 RVA: 0x00003CE7 File Offset: 0x00001EE7
		static string smethod_117(string string_0)
		{
			return File.ReadAllText(string_0);
		}

		// Token: 0x06000DEE RID: 3566 RVA: 0x00003D00 File Offset: 0x00001F00
		static void smethod_118(string string_0, string string_1)
		{
			File.WriteAllText(string_0, string_1);
		}

		// Token: 0x06000DEF RID: 3567 RVA: 0x0000298C File Offset: 0x00000B8C
		static string smethod_119(string[] string_0)
		{
			return string.Concat(string_0);
		}

		// Token: 0x06000DF0 RID: 3568 RVA: 0x00002C70 File Offset: 0x00000E70
		static string[] smethod_120(string string_0, char[] char_0, StringSplitOptions stringSplitOptions_0)
		{
			return string_0.Split(char_0, stringSplitOptions_0);
		}

		// Token: 0x06000DF1 RID: 3569 RVA: 0x00003D09 File Offset: 0x00001F09
		static FileStream smethod_121(string string_0, FileMode fileMode_0)
		{
			return new FileStream(string_0, fileMode_0);
		}

		// Token: 0x06000DF2 RID: 3570 RVA: 0x00003D12 File Offset: 0x00001F12
		static StreamWriter smethod_122(Stream stream_0)
		{
			return new StreamWriter(stream_0);
		}

		// Token: 0x06000DF3 RID: 3571 RVA: 0x00005585 File Offset: 0x00003785
		static long smethod_123(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06000DF4 RID: 3572 RVA: 0x00003D1A File Offset: 0x00001F1A
		static void smethod_124(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.WriteLine(string_0);
		}

		// Token: 0x06000DF5 RID: 3573 RVA: 0x00007FBB File Offset: 0x000061BB
		static void smethod_125(TextWriter textWriter_0)
		{
			textWriter_0.Close();
		}

		// Token: 0x06000DF6 RID: 3574 RVA: 0x00007FC3 File Offset: 0x000061C3
		static bool smethod_126(CheckBox checkBox_0)
		{
			return checkBox_0.Checked;
		}

		// Token: 0x06000DF7 RID: 3575 RVA: 0x00003CD7 File Offset: 0x00001ED7
		static FileStream smethod_127(string string_0)
		{
			return File.Create(string_0);
		}

		// Token: 0x06000DF8 RID: 3576 RVA: 0x00003CDF File Offset: 0x00001EDF
		static void smethod_128(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x06000DF9 RID: 3577 RVA: 0x00003F1F File Offset: 0x0000211F
		static WindowsIdentity smethod_129()
		{
			return WindowsIdentity.GetCurrent();
		}

		// Token: 0x06000DFA RID: 3578 RVA: 0x00007FCB File Offset: 0x000061CB
		static IdentityReferenceCollection smethod_130(WindowsIdentity windowsIdentity_0)
		{
			return windowsIdentity_0.Groups;
		}

		// Token: 0x06000DFB RID: 3579 RVA: 0x00002B7F File Offset: 0x00000D7F
		static void smethod_131(Control control_0, Color color_0)
		{
			control_0.ForeColor = color_0;
		}

		// Token: 0x06000DFC RID: 3580 RVA: 0x00007FD3 File Offset: 0x000061D3
		static Font smethod_132(Control control_0)
		{
			return control_0.Font;
		}

		// Token: 0x06000DFD RID: 3581 RVA: 0x00007FDB File Offset: 0x000061DB
		static Font smethod_133(Font font_0, FontStyle fontStyle_0)
		{
			return new Font(font_0, fontStyle_0);
		}

		// Token: 0x06000DFE RID: 3582 RVA: 0x000039B6 File Offset: 0x00001BB6
		static void smethod_134(Control control_0, Font font_0)
		{
			control_0.Font = font_0;
		}

		// Token: 0x06000DFF RID: 3583 RVA: 0x00007FE4 File Offset: 0x000061E4
		static Color smethod_135(Control control_0)
		{
			return control_0.ForeColor;
		}

		// Token: 0x06000E00 RID: 3584 RVA: 0x00007FEC File Offset: 0x000061EC
		static FontStyle smethod_136(Font font_0)
		{
			return font_0.Style;
		}

		// Token: 0x06000E01 RID: 3585 RVA: 0x00007FF4 File Offset: 0x000061F4
		static void smethod_137(ProgressBar progressBar_0, int int_0)
		{
			progressBar_0.Value = int_0;
		}

		// Token: 0x06000E02 RID: 3586 RVA: 0x00007FFD File Offset: 0x000061FD
		static int smethod_138(ProgressBar progressBar_0)
		{
			return progressBar_0.Value;
		}

		// Token: 0x06000E03 RID: 3587 RVA: 0x00008005 File Offset: 0x00006205
		static int smethod_139(ProgressBar progressBar_0)
		{
			return progressBar_0.Maximum;
		}

		// Token: 0x06000E04 RID: 3588 RVA: 0x0000800D File Offset: 0x0000620D
		static string smethod_140(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x06000E05 RID: 3589 RVA: 0x000052BB File Offset: 0x000034BB
		static void smethod_141(Form form_0)
		{
			form_0.Close();
		}

		// Token: 0x06000E06 RID: 3590 RVA: 0x000033D1 File Offset: 0x000015D1
		static string smethod_142(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000E07 RID: 3591 RVA: 0x00003454 File Offset: 0x00001654
		static PowerShell smethod_143()
		{
			return PowerShell.Create();
		}

		// Token: 0x06000E08 RID: 3592 RVA: 0x0000345B File Offset: 0x0000165B
		static PowerShell smethod_144(PowerShell powerShell_0, string string_0)
		{
			return powerShell_0.AddScript(string_0);
		}

		// Token: 0x06000E09 RID: 3593 RVA: 0x00003E79 File Offset: 0x00002079
		static string smethod_145()
		{
			return Environment.NewLine;
		}

		// Token: 0x06000E0A RID: 3594 RVA: 0x00003464 File Offset: 0x00001664
		static Collection<PSObject> smethod_146(PowerShell powerShell_0)
		{
			return powerShell_0.Invoke();
		}

		// Token: 0x06000E0B RID: 3595 RVA: 0x00008018 File Offset: 0x00006218
		static Bitmap smethod_147(Image image_0)
		{
			return new Bitmap(image_0);
		}

		// Token: 0x06000E0C RID: 3596 RVA: 0x00008020 File Offset: 0x00006220
		static Color smethod_148(Bitmap bitmap_0, int int_0, int int_1)
		{
			return bitmap_0.GetPixel(int_0, int_1);
		}

		// Token: 0x06000E0D RID: 3597 RVA: 0x0000802A File Offset: 0x0000622A
		static void smethod_149(Control.ControlCollection controlCollection_0)
		{
			controlCollection_0.Clear();
		}

		// Token: 0x06000E0E RID: 3598 RVA: 0x000025E0 File Offset: 0x000007E0
		static string smethod_150(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06000E0F RID: 3599 RVA: 0x00002EBE File Offset: 0x000010BE
		static RegistryKey smethod_151(RegistryKey registryKey_0, string string_0)
		{
			return registryKey_0.CreateSubKey(string_0);
		}

		// Token: 0x06000E10 RID: 3600 RVA: 0x00008032 File Offset: 0x00006232
		static int smethod_152(RegistryKey registryKey_0)
		{
			return registryKey_0.ValueCount;
		}

		// Token: 0x06000E11 RID: 3601 RVA: 0x0000803A File Offset: 0x0000623A
		static int smethod_153(Control control_0)
		{
			return control_0.Height;
		}

		// Token: 0x06000E12 RID: 3602 RVA: 0x00006AED File Offset: 0x00004CED
		static void smethod_154(Control control_0, string string_0)
		{
			control_0.Name = string_0;
		}

		// Token: 0x06000E13 RID: 3603 RVA: 0x00003006 File Offset: 0x00001206
		static RegistryKey smethod_155(RegistryKey registryKey_0, string string_0, bool bool_1)
		{
			return registryKey_0.OpenSubKey(string_0, bool_1);
		}

		// Token: 0x06000E14 RID: 3604 RVA: 0x00008042 File Offset: 0x00006242
		static string smethod_156(byte[] byte_0)
		{
			return BitConverter.ToString(byte_0);
		}

		// Token: 0x06000E15 RID: 3605 RVA: 0x0000804A File Offset: 0x0000624A
		static void smethod_157(RegistryKey registryKey_0, string string_0, object object_0, RegistryValueKind registryValueKind_0)
		{
			registryKey_0.SetValue(string_0, object_0, registryValueKind_0);
		}

		// Token: 0x06000E16 RID: 3606 RVA: 0x00003884 File Offset: 0x00001A84
		static void smethod_158(RegistryKey registryKey_0)
		{
			registryKey_0.Close();
		}

		// Token: 0x06000E17 RID: 3607 RVA: 0x00002EED File Offset: 0x000010ED
		static void smethod_159(RegistryKey registryKey_0, string string_0, object object_0, RegistryValueKind registryValueKind_0)
		{
			registryKey_0.SetValue(string_0, object_0, registryValueKind_0);
		}

		// Token: 0x06000E18 RID: 3608 RVA: 0x00002C41 File Offset: 0x00000E41
		static void smethod_160(RegistryKey registryKey_0, string string_0, object object_0)
		{
			registryKey_0.SetValue(string_0, object_0);
		}

		// Token: 0x06000E19 RID: 3609 RVA: 0x00003010 File Offset: 0x00001210
		static void smethod_161(RegistryKey registryKey_0, string string_0)
		{
			registryKey_0.DeleteValue(string_0);
		}

		// Token: 0x06000E1A RID: 3610 RVA: 0x000031C3 File Offset: 0x000013C3
		static string smethod_162(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x06000E1B RID: 3611 RVA: 0x000031CB File Offset: 0x000013CB
		static string smethod_163(string string_0)
		{
			return Path.GetFileName(string_0);
		}

		// Token: 0x06000E1C RID: 3612 RVA: 0x000025CE File Offset: 0x000007CE
		static Type smethod_164(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06000E1D RID: 3613 RVA: 0x000031D3 File Offset: 0x000013D3
		static CallSiteBinder smethod_165(CSharpBinderFlags csharpBinderFlags_0, Type type_0, Type type_1)
		{
			return Microsoft.CSharp.RuntimeBinder.Binder.Convert(csharpBinderFlags_0, type_0, type_1);
		}

		// Token: 0x06000E1E RID: 3614 RVA: 0x000029BB File Offset: 0x00000BBB
		static object smethod_166(Control control_0)
		{
			return control_0.Tag;
		}

		// Token: 0x06000E1F RID: 3615 RVA: 0x000033BD File Offset: 0x000015BD
		static string smethod_167(string string_0, string string_1, string string_2, string string_3)
		{
			return string_0 + string_1 + string_2 + string_3;
		}

		// Token: 0x06000E20 RID: 3616 RVA: 0x00002F15 File Offset: 0x00001115
		static void smethod_168(string string_0)
		{
			File.Delete(string_0);
		}

		// Token: 0x06000E21 RID: 3617 RVA: 0x000033EC File Offset: 0x000015EC
		static Process[] smethod_169(string string_0)
		{
			return Process.GetProcessesByName(string_0);
		}

		// Token: 0x06000E22 RID: 3618 RVA: 0x000036A7 File Offset: 0x000018A7
		static void smethod_170(Process process_0)
		{
			process_0.Kill();
		}

		// Token: 0x06000E23 RID: 3619 RVA: 0x00002AA6 File Offset: 0x00000CA6
		static Process smethod_171(string string_0)
		{
			return Process.Start(string_0);
		}

		// Token: 0x06000E24 RID: 3620 RVA: 0x00008055 File Offset: 0x00006255
		static IDataObject smethod_172(DragEventArgs dragEventArgs_0)
		{
			return dragEventArgs_0.Data;
		}

		// Token: 0x06000E25 RID: 3621 RVA: 0x0000805D File Offset: 0x0000625D
		static bool smethod_173(IDataObject idataObject_0, string string_0)
		{
			return idataObject_0.GetDataPresent(string_0);
		}

		// Token: 0x06000E26 RID: 3622 RVA: 0x00008066 File Offset: 0x00006266
		static void smethod_174(DragEventArgs dragEventArgs_0, DragDropEffects dragDropEffects_0)
		{
			dragEventArgs_0.Effect = dragDropEffects_0;
		}

		// Token: 0x06000E27 RID: 3623 RVA: 0x000031B9 File Offset: 0x000013B9
		static string[] smethod_175(string string_0, string string_1, SearchOption searchOption_0)
		{
			return Directory.GetFiles(string_0, string_1, searchOption_0);
		}

		// Token: 0x06000E28 RID: 3624 RVA: 0x0000806F File Offset: 0x0000626F
		static bool smethod_176(RadioButton radioButton_0)
		{
			return radioButton_0.Checked;
		}

		// Token: 0x06000E29 RID: 3625 RVA: 0x00008077 File Offset: 0x00006277
		static Font smethod_177(string string_0, float float_0)
		{
			return new Font(string_0, float_0);
		}

		// Token: 0x06000E2A RID: 3626 RVA: 0x000052EC File Offset: 0x000034EC
		static Thread smethod_178(ThreadStart threadStart_0)
		{
			return new Thread(threadStart_0);
		}

		// Token: 0x06000E2B RID: 3627 RVA: 0x0000260C File Offset: 0x0000080C
		static void smethod_179(Thread thread_0, bool bool_1)
		{
			thread_0.IsBackground = bool_1;
		}

		// Token: 0x06000E2C RID: 3628 RVA: 0x000052F4 File Offset: 0x000034F4
		static void smethod_180(Thread thread_0)
		{
			thread_0.Start();
		}

		// Token: 0x06000E2D RID: 3629 RVA: 0x0000393D File Offset: 0x00001B3D
		static string smethod_181()
		{
			return Environment.SystemDirectory;
		}

		// Token: 0x06000E2E RID: 3630 RVA: 0x00003944 File Offset: 0x00001B44
		static string smethod_182(string string_0)
		{
			return Path.GetPathRoot(string_0);
		}

		// Token: 0x06000E2F RID: 3631 RVA: 0x00008080 File Offset: 0x00006280
		static DriveInfo smethod_183(string string_0)
		{
			return new DriveInfo(string_0);
		}

		// Token: 0x06000E30 RID: 3632 RVA: 0x00008088 File Offset: 0x00006288
		static long smethod_184(DriveInfo driveInfo_0)
		{
			return driveInfo_0.AvailableFreeSpace;
		}

		// Token: 0x06000E31 RID: 3633 RVA: 0x00008090 File Offset: 0x00006290
		static object smethod_185(IDataObject idataObject_0, string string_0, bool bool_1)
		{
			return idataObject_0.GetData(string_0, bool_1);
		}

		// Token: 0x06000E32 RID: 3634 RVA: 0x00002EE5 File Offset: 0x000010E5
		static bool smethod_186(string string_0)
		{
			return Directory.Exists(string_0);
		}

		// Token: 0x06000E33 RID: 3635 RVA: 0x0000809A File Offset: 0x0000629A
		static void smethod_187(Component component_0)
		{
			component_0.Dispose();
		}

		// Token: 0x06000E34 RID: 3636 RVA: 0x000052C3 File Offset: 0x000034C3
		static FolderBrowserDialog smethod_188()
		{
			return new FolderBrowserDialog();
		}

		// Token: 0x06000E35 RID: 3637 RVA: 0x000052CA File Offset: 0x000034CA
		static void smethod_189(FolderBrowserDialog folderBrowserDialog_0, string string_0)
		{
			folderBrowserDialog_0.Description = string_0;
		}

		// Token: 0x06000E36 RID: 3638 RVA: 0x000052D3 File Offset: 0x000034D3
		static void smethod_190(FolderBrowserDialog folderBrowserDialog_0, bool bool_1)
		{
			folderBrowserDialog_0.ShowNewFolderButton = bool_1;
		}

		// Token: 0x06000E37 RID: 3639 RVA: 0x000052DC File Offset: 0x000034DC
		static DialogResult smethod_191(CommonDialog commonDialog_0)
		{
			return commonDialog_0.ShowDialog();
		}

		// Token: 0x06000E38 RID: 3640 RVA: 0x000052E4 File Offset: 0x000034E4
		static string smethod_192(FolderBrowserDialog folderBrowserDialog_0)
		{
			return folderBrowserDialog_0.SelectedPath;
		}

		// Token: 0x06000E39 RID: 3641 RVA: 0x00003100 File Offset: 0x00001300
		static ProcessStartInfo smethod_193()
		{
			return new ProcessStartInfo();
		}

		// Token: 0x06000E3A RID: 3642 RVA: 0x00003107 File Offset: 0x00001307
		static void smethod_194(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.FileName = string_0;
		}

		// Token: 0x06000E3B RID: 3643 RVA: 0x00003110 File Offset: 0x00001310
		static void smethod_195(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.Arguments = string_0;
		}

		// Token: 0x06000E3C RID: 3644 RVA: 0x000065B6 File Offset: 0x000047B6
		static void smethod_196(ProcessStartInfo processStartInfo_0, bool bool_1)
		{
			processStartInfo_0.UseShellExecute = bool_1;
		}

		// Token: 0x06000E3D RID: 3645 RVA: 0x000065C8 File Offset: 0x000047C8
		static void smethod_197(ProcessStartInfo processStartInfo_0, bool bool_1)
		{
			processStartInfo_0.CreateNoWindow = bool_1;
		}

		// Token: 0x06000E3E RID: 3646 RVA: 0x000065BF File Offset: 0x000047BF
		static void smethod_198(ProcessStartInfo processStartInfo_0, bool bool_1)
		{
			processStartInfo_0.RedirectStandardOutput = bool_1;
		}

		// Token: 0x06000E3F RID: 3647 RVA: 0x00003122 File Offset: 0x00001322
		static Process smethod_199(ProcessStartInfo processStartInfo_0)
		{
			return Process.Start(processStartInfo_0);
		}

		// Token: 0x06000E40 RID: 3648 RVA: 0x000080A2 File Offset: 0x000062A2
		static void smethod_200(Process process_0)
		{
			process_0.BeginOutputReadLine();
		}

		// Token: 0x06000E41 RID: 3649 RVA: 0x000080AA File Offset: 0x000062AA
		static void smethod_201(Process process_0, DataReceivedEventHandler dataReceivedEventHandler_0)
		{
			process_0.OutputDataReceived += dataReceivedEventHandler_0;
		}

		// Token: 0x06000E42 RID: 3650 RVA: 0x00003D5D File Offset: 0x00001F5D
		static void smethod_202(Process process_0)
		{
			process_0.WaitForExit();
		}

		// Token: 0x06000E43 RID: 3651 RVA: 0x000080B3 File Offset: 0x000062B3
		static string smethod_203(ToolTip toolTip_0, Control control_0)
		{
			return toolTip_0.GetToolTip(control_0);
		}

		// Token: 0x06000E44 RID: 3652 RVA: 0x00002A44 File Offset: 0x00000C44
		static int smethod_204(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000E45 RID: 3653 RVA: 0x0000307B File Offset: 0x0000127B
		static RegistryKey smethod_205(RegistryKey registryKey_0, string string_0)
		{
			return registryKey_0.OpenSubKey(string_0);
		}

		// Token: 0x06000E46 RID: 3654 RVA: 0x00002917 File Offset: 0x00000B17
		static bool smethod_206(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x06000E47 RID: 3655 RVA: 0x00006B1E File Offset: 0x00004D1E
		static int smethod_207(string string_0)
		{
			return Convert.ToInt32(string_0);
		}

		// Token: 0x06000E48 RID: 3656 RVA: 0x000065D1 File Offset: 0x000047D1
		static StreamReader smethod_208(Process process_0)
		{
			return process_0.StandardOutput;
		}

		// Token: 0x06000E49 RID: 3657 RVA: 0x000065D9 File Offset: 0x000047D9
		static string smethod_209(TextReader textReader_0)
		{
			return textReader_0.ReadToEnd();
		}

		// Token: 0x06000E4A RID: 3658 RVA: 0x00002EDC File Offset: 0x000010DC
		static object smethod_210(RegistryKey registryKey_0, string string_0)
		{
			return registryKey_0.GetValue(string_0);
		}

		// Token: 0x06000E4B RID: 3659 RVA: 0x00003C43 File Offset: 0x00001E43
		static ManagementObjectSearcher smethod_211(string string_0, string string_1)
		{
			return new ManagementObjectSearcher(string_0, string_1);
		}

		// Token: 0x06000E4C RID: 3660 RVA: 0x00003C4C File Offset: 0x00001E4C
		static ManagementObjectCollection smethod_212(ManagementObjectSearcher managementObjectSearcher_0)
		{
			return managementObjectSearcher_0.Get();
		}

		// Token: 0x06000E4D RID: 3661 RVA: 0x00006AFF File Offset: 0x00004CFF
		static ComputerInfo smethod_213()
		{
			return new ComputerInfo();
		}

		// Token: 0x06000E4E RID: 3662 RVA: 0x00006B06 File Offset: 0x00004D06
		static ulong smethod_214(ComputerInfo computerInfo_0)
		{
			return computerInfo_0.TotalPhysicalMemory;
		}

		// Token: 0x06000E4F RID: 3663 RVA: 0x000080BC File Offset: 0x000062BC
		static double smethod_215(double double_0, MidpointRounding midpointRounding_0)
		{
			return Math.Round(double_0, midpointRounding_0);
		}

		// Token: 0x06000E50 RID: 3664 RVA: 0x00003D23 File Offset: 0x00001F23
		static string smethod_216(string string_0, string[] string_1)
		{
			return string.Join(string_0, string_1);
		}

		// Token: 0x06000E51 RID: 3665 RVA: 0x00002A32 File Offset: 0x00000C32
		static int smethod_217(string string_0, string string_1)
		{
			return string_0.IndexOf(string_1);
		}

		// Token: 0x06000E52 RID: 3666 RVA: 0x00002C7A File Offset: 0x00000E7A
		static string smethod_218(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x06000E53 RID: 3667 RVA: 0x00002A3B File Offset: 0x00000C3B
		static string smethod_219(string string_0, int int_0)
		{
			return string_0.Remove(int_0);
		}

		// Token: 0x06000E54 RID: 3668 RVA: 0x00003A2E File Offset: 0x00001C2E
		static void smethod_220(RegistryKey registryKey_0, string string_0, bool bool_1)
		{
			registryKey_0.DeleteSubKeyTree(string_0, bool_1);
		}

		// Token: 0x06000E55 RID: 3669 RVA: 0x00002D75 File Offset: 0x00000F75
		static MouseButtons smethod_221(MouseEventArgs mouseEventArgs_0)
		{
			return mouseEventArgs_0.Button;
		}

		// Token: 0x06000E56 RID: 3670 RVA: 0x000042A6 File Offset: 0x000024A6
		static void smethod_222(string string_0, string string_1)
		{
			File.AppendAllText(string_0, string_1);
		}

		// Token: 0x06000E57 RID: 3671 RVA: 0x000043B4 File Offset: 0x000025B4
		static double smethod_223(Form form_0)
		{
			return form_0.Opacity;
		}

		// Token: 0x06000E58 RID: 3672 RVA: 0x00002ADC File Offset: 0x00000CDC
		static void smethod_224(Form form_0, double double_0)
		{
			form_0.Opacity = double_0;
		}

		// Token: 0x06000E59 RID: 3673 RVA: 0x000080C5 File Offset: 0x000062C5
		static void smethod_225(Action[] action_0)
		{
			Parallel.Invoke(action_0);
		}

		// Token: 0x06000E5A RID: 3674 RVA: 0x000043BC File Offset: 0x000025BC
		static void smethod_226(System.Windows.Forms.Timer timer_0)
		{
			timer_0.Stop();
		}

		// Token: 0x06000E5B RID: 3675 RVA: 0x000080CD File Offset: 0x000062CD
		static void smethod_227(System.Windows.Forms.Timer timer_0)
		{
			timer_0.Start();
		}

		// Token: 0x06000E5C RID: 3676 RVA: 0x00005516 File Offset: 0x00003716
		static OpenFileDialog smethod_228()
		{
			return new OpenFileDialog();
		}

		// Token: 0x06000E5D RID: 3677 RVA: 0x000080D5 File Offset: 0x000062D5
		static void smethod_229(FileDialog fileDialog_0, string string_0)
		{
			fileDialog_0.Title = string_0;
		}

		// Token: 0x06000E5E RID: 3678 RVA: 0x00005292 File Offset: 0x00003492
		static string smethod_230()
		{
			return Environment.CurrentDirectory;
		}

		// Token: 0x06000E5F RID: 3679 RVA: 0x0000551D File Offset: 0x0000371D
		static void smethod_231(FileDialog fileDialog_0, string string_0)
		{
			fileDialog_0.InitialDirectory = string_0;
		}

		// Token: 0x06000E60 RID: 3680 RVA: 0x00005526 File Offset: 0x00003726
		static void smethod_232(FileDialog fileDialog_0, string string_0)
		{
			fileDialog_0.Filter = string_0;
		}

		// Token: 0x06000E61 RID: 3681 RVA: 0x0000552F File Offset: 0x0000372F
		static string smethod_233(FileDialog fileDialog_0)
		{
			return fileDialog_0.FileName;
		}

		// Token: 0x06000E62 RID: 3682 RVA: 0x00002C67 File Offset: 0x00000E67
		static void smethod_234(Control control_0, bool bool_1)
		{
			control_0.Enabled = bool_1;
		}

		// Token: 0x06000E63 RID: 3683 RVA: 0x000080DE File Offset: 0x000062DE
		static DialogResult smethod_235(Form form_0)
		{
			return form_0.ShowDialog();
		}

		// Token: 0x06000E64 RID: 3684 RVA: 0x00006B91 File Offset: 0x00004D91
		static void smethod_236(Control control_0)
		{
			control_0.Show();
		}

		// Token: 0x06000E65 RID: 3685 RVA: 0x00003064 File Offset: 0x00001264
		static void smethod_237(Form form_0, FormWindowState formWindowState_0)
		{
			form_0.WindowState = formWindowState_0;
		}

		// Token: 0x06000E66 RID: 3686 RVA: 0x000080E6 File Offset: 0x000062E6
		static Screen[] smethod_238()
		{
			return Screen.AllScreens;
		}

		// Token: 0x06000E67 RID: 3687 RVA: 0x000080ED File Offset: 0x000062ED
		static Rectangle smethod_239(Screen screen_0)
		{
			return screen_0.WorkingArea;
		}

		// Token: 0x06000E68 RID: 3688 RVA: 0x00003E13 File Offset: 0x00002013
		static string smethod_240(string string_0, IEnumerable<string> ienumerable_0)
		{
			return string.Join(string_0, ienumerable_0);
		}

		// Token: 0x06000E69 RID: 3689 RVA: 0x000080F5 File Offset: 0x000062F5
		static void smethod_241(Control control_0, PaintEventHandler paintEventHandler_0)
		{
			control_0.Paint -= paintEventHandler_0;
		}

		// Token: 0x06000E6A RID: 3690 RVA: 0x000080FE File Offset: 0x000062FE
		static void smethod_242(Control control_0, PaintEventHandler paintEventHandler_0)
		{
			control_0.Paint += paintEventHandler_0;
		}

		// Token: 0x06000E6B RID: 3691 RVA: 0x000032C9 File Offset: 0x000014C9
		static void smethod_243(Control control_0)
		{
			control_0.Invalidate();
		}

		// Token: 0x06000E6C RID: 3692 RVA: 0x00008107 File Offset: 0x00006307
		static RSAx smethod_244(string string_0, int int_0)
		{
			return new RSAx(string_0, int_0);
		}

		// Token: 0x06000E6D RID: 3693 RVA: 0x00008110 File Offset: 0x00006310
		static void smethod_245(RSAx rsax_0, RSAxParameters.RSAxHashAlgorithm rsaxHashAlgorithm_0)
		{
			rsax_0.RSAxHashAlgorithm = rsaxHashAlgorithm_0;
		}

		// Token: 0x06000E6E RID: 3694 RVA: 0x00008119 File Offset: 0x00006319
		static byte[] smethod_246(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x06000E6F RID: 3695 RVA: 0x00008121 File Offset: 0x00006321
		static byte[] smethod_247(RSAx rsax_0, byte[] byte_0, bool bool_1, bool bool_2)
		{
			return rsax_0.Decrypt(byte_0, bool_1, bool_2);
		}

		// Token: 0x06000E70 RID: 3696 RVA: 0x000056A4 File Offset: 0x000038A4
		static Encoding smethod_248()
		{
			return Encoding.UTF8;
		}

		// Token: 0x06000E71 RID: 3697 RVA: 0x000056B3 File Offset: 0x000038B3
		static string smethod_249(Encoding encoding_0, byte[] byte_0)
		{
			return encoding_0.GetString(byte_0);
		}

		// Token: 0x06000E72 RID: 3698 RVA: 0x00002994 File Offset: 0x00000B94
		static WebClient smethod_250()
		{
			return new WebClient();
		}

		// Token: 0x06000E73 RID: 3699 RVA: 0x00003926 File Offset: 0x00001B26
		static Assembly smethod_251()
		{
			return Assembly.GetEntryAssembly();
		}

		// Token: 0x06000E74 RID: 3700 RVA: 0x0000392D File Offset: 0x00001B2D
		static string smethod_252(Assembly assembly_0)
		{
			return assembly_0.Location;
		}

		// Token: 0x06000E75 RID: 3701 RVA: 0x0000429E File Offset: 0x0000249E
		static DirectoryInfo smethod_253(string string_0)
		{
			return Directory.CreateDirectory(string_0);
		}

		// Token: 0x06000E76 RID: 3702 RVA: 0x00003E1C File Offset: 0x0000201C
		static void smethod_254(string string_0, string string_1)
		{
			File.Move(string_0, string_1);
		}

		// Token: 0x06000E77 RID: 3703 RVA: 0x000036D9 File Offset: 0x000018D9
		static void smethod_255(string string_0, FileAttributes fileAttributes_0)
		{
			File.SetAttributes(string_0, fileAttributes_0);
		}

		// Token: 0x06000E78 RID: 3704 RVA: 0x0000299B File Offset: 0x00000B9B
		static string smethod_256(WebClient webClient_0, string string_0)
		{
			return webClient_0.DownloadString(string_0);
		}

		// Token: 0x06000E79 RID: 3705 RVA: 0x000029C3 File Offset: 0x00000BC3
		static void smethod_257(WebClient webClient_0, string string_0, string string_1)
		{
			webClient_0.DownloadFile(string_0, string_1);
		}

		// Token: 0x06000E7A RID: 3706 RVA: 0x00002A4C File Offset: 0x00000C4C
		static Container smethod_258()
		{
			return new Container();
		}

		// Token: 0x06000E7B RID: 3707 RVA: 0x00005305 File Offset: 0x00003505
		static ComponentResourceManager smethod_259(Type type_0)
		{
			return new ComponentResourceManager(type_0);
		}

		// Token: 0x06000E7C RID: 3708 RVA: 0x00002A70 File Offset: 0x00000C70
		static LinkLabel smethod_260()
		{
			return new LinkLabel();
		}

		// Token: 0x06000E7D RID: 3709 RVA: 0x0000812C File Offset: 0x0000632C
		static CheckBox smethod_261()
		{
			return new CheckBox();
		}

		// Token: 0x06000E7E RID: 3710 RVA: 0x00002A69 File Offset: 0x00000C69
		static Button smethod_262()
		{
			return new Button();
		}

		// Token: 0x06000E7F RID: 3711 RVA: 0x00002A61 File Offset: 0x00000C61
		static ToolTip smethod_263(IContainer icontainer_0)
		{
			return new ToolTip(icontainer_0);
		}

		// Token: 0x06000E80 RID: 3712 RVA: 0x00002A5A File Offset: 0x00000C5A
		static PictureBox smethod_264()
		{
			return new PictureBox();
		}

		// Token: 0x06000E81 RID: 3713 RVA: 0x000039A1 File Offset: 0x00001BA1
		static System.Windows.Forms.Timer smethod_265(IContainer icontainer_0)
		{
			return new System.Windows.Forms.Timer(icontainer_0);
		}

		// Token: 0x06000E82 RID: 3714 RVA: 0x00008133 File Offset: 0x00006333
		static ProgressBar smethod_266()
		{
			return new ProgressBar();
		}

		// Token: 0x06000E83 RID: 3715 RVA: 0x0000813A File Offset: 0x0000633A
		static RadioButton smethod_267()
		{
			return new RadioButton();
		}

		// Token: 0x06000E84 RID: 3716 RVA: 0x00003044 File Offset: 0x00001244
		static DataGridView smethod_268()
		{
			return new DataGridView();
		}

		// Token: 0x06000E85 RID: 3717 RVA: 0x0000304B File Offset: 0x0000124B
		static DataGridViewTextBoxColumn smethod_269()
		{
			return new DataGridViewTextBoxColumn();
		}

		// Token: 0x06000E86 RID: 3718 RVA: 0x00008141 File Offset: 0x00006341
		static FlowLayoutPanel smethod_270()
		{
			return new FlowLayoutPanel();
		}

		// Token: 0x06000E87 RID: 3719 RVA: 0x00002A8D File Offset: 0x00000C8D
		static void smethod_271(Control control_0)
		{
			control_0.SuspendLayout();
		}

		// Token: 0x06000E88 RID: 3720 RVA: 0x00002A85 File Offset: 0x00000C85
		static void smethod_272(ISupportInitialize isupportInitialize_0)
		{
			isupportInitialize_0.BeginInit();
		}

		// Token: 0x06000E89 RID: 3721 RVA: 0x00002A95 File Offset: 0x00000C95
		static void smethod_273(Control control_0)
		{
			control_0.SuspendLayout();
		}

		// Token: 0x06000E8A RID: 3722 RVA: 0x00004DF7 File Offset: 0x00002FF7
		static void smethod_274(LinkLabel linkLabel_0, Color color_0)
		{
			linkLabel_0.ActiveLinkColor = color_0;
		}

		// Token: 0x06000E8B RID: 3723 RVA: 0x00002A9D File Offset: 0x00000C9D
		static void smethod_275(Control control_0, bool bool_1)
		{
			control_0.AutoSize = bool_1;
		}

		// Token: 0x06000E8C RID: 3724 RVA: 0x000039A9 File Offset: 0x00001BA9
		static Font smethod_276(string string_0, float float_0, FontStyle fontStyle_0, GraphicsUnit graphicsUnit_0, byte byte_0)
		{
			return new Font(string_0, float_0, fontStyle_0, graphicsUnit_0, byte_0);
		}

		// Token: 0x06000E8D RID: 3725 RVA: 0x00002B9E File Offset: 0x00000D9E
		static void smethod_277(LinkLabel linkLabel_0, LinkBehavior linkBehavior_0)
		{
			linkLabel_0.LinkBehavior = linkBehavior_0;
		}

		// Token: 0x06000E8E RID: 3726 RVA: 0x00002B77 File Offset: 0x00000D77
		static void smethod_278(object object_0)
		{
			Clipboard.SetDataObject(object_0);
		}

		// Token: 0x06000E8F RID: 3727 RVA: 0x00008148 File Offset: 0x00006348
		static string smethod_279(string string_0, char[] char_0)
		{
			return string_0.TrimEnd(char_0);
		}

		// Token: 0x06000E90 RID: 3728 RVA: 0x00002B88 File Offset: 0x00000D88
		static Graphics smethod_280(PaintEventArgs paintEventArgs_0)
		{
			return paintEventArgs_0.Graphics;
		}

		// Token: 0x06000E91 RID: 3729 RVA: 0x00002ABF File Offset: 0x00000CBF
		object method_16(string string_0, BindingFlags bindingFlags_0, System.Reflection.Binder binder_0, object object_0, object[] object_1)
		{
			return base.InvokeMember(string_0, bindingFlags_0, binder_0, object_0, object_1);
		}

		// Token: 0x06000E92 RID: 3730 RVA: 0x0000316F File Offset: 0x0000136F
		static FileInfo smethod_281(string string_0)
		{
			return new FileInfo(string_0);
		}

		// Token: 0x06000E93 RID: 3731 RVA: 0x00003404 File Offset: 0x00001604
		static long smethod_282(FileInfo fileInfo_0)
		{
			return fileInfo_0.Length;
		}

		// Token: 0x06000E94 RID: 3732 RVA: 0x00002AF5 File Offset: 0x00000CF5
		static void smethod_283(Control control_0, bool bool_1)
		{
			control_0.Capture = bool_1;
		}

		// Token: 0x06000E95 RID: 3733 RVA: 0x00002AFE File Offset: 0x00000CFE
		static void smethod_284(Control control_0, bool bool_1)
		{
			control_0.Capture = bool_1;
		}

		// Token: 0x06000E96 RID: 3734 RVA: 0x00002B07 File Offset: 0x00000D07
		IntPtr method_17()
		{
			return base.Handle;
		}

		// Token: 0x06000E97 RID: 3735 RVA: 0x000033B5 File Offset: 0x000015B5
		static string[] smethod_285(string string_0)
		{
			return Directory.GetDirectories(string_0);
		}

		// Token: 0x06000E98 RID: 3736 RVA: 0x000036AF File Offset: 0x000018AF
		static string smethod_286(string string_0)
		{
			return string_0.ToLower();
		}

		// Token: 0x06000E99 RID: 3737 RVA: 0x00005314 File Offset: 0x00003514
		static object smethod_287(ResourceManager resourceManager_0, string string_0)
		{
			return resourceManager_0.GetObject(string_0);
		}

		// Token: 0x06000E9A RID: 3738 RVA: 0x00003219 File Offset: 0x00001419
		static GraphicsPath smethod_288()
		{
			return new GraphicsPath();
		}

		// Token: 0x06000E9B RID: 3739 RVA: 0x00008151 File Offset: 0x00006351
		static void smethod_289(GraphicsPath graphicsPath_0, int int_0, int int_1, int int_2, int int_3)
		{
			graphicsPath_0.AddEllipse(int_0, int_1, int_2, int_3);
		}

		// Token: 0x06000E9C RID: 3740 RVA: 0x0000815E File Offset: 0x0000635E
		static Image smethod_290(Control control_0)
		{
			return control_0.BackgroundImage;
		}

		// Token: 0x06000E9D RID: 3741 RVA: 0x00008166 File Offset: 0x00006366
		static void smethod_291(ProgressBar progressBar_0, int int_0)
		{
			progressBar_0.Maximum = int_0;
		}

		// Token: 0x06000E9E RID: 3742 RVA: 0x0000816F File Offset: 0x0000636F
		static string smethod_292(string string_0, object[] object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000E9F RID: 3743 RVA: 0x00008178 File Offset: 0x00006378
		static string smethod_293(string string_0, string string_1, string string_2)
		{
			return Regex.Replace(string_0, string_1, string_2);
		}

		// Token: 0x06000EA0 RID: 3744 RVA: 0x00008182 File Offset: 0x00006382
		static double smethod_294(string string_0)
		{
			return Convert.ToDouble(string_0);
		}

		// Token: 0x06000EA1 RID: 3745 RVA: 0x0000818A File Offset: 0x0000638A
		static string smethod_295(WebClient webClient_0, string string_0)
		{
			return webClient_0.DownloadString(string_0);
		}

		// Token: 0x06000EA2 RID: 3746 RVA: 0x000057BA File Offset: 0x000039BA
		static object smethod_296(Control control_0)
		{
			return control_0.Tag;
		}

		// Token: 0x06000EA3 RID: 3747 RVA: 0x00003439 File Offset: 0x00001639
		static string smethod_297(FileSystemInfo fileSystemInfo_0)
		{
			return fileSystemInfo_0.FullName;
		}

		// Token: 0x06000EA4 RID: 3748 RVA: 0x00008193 File Offset: 0x00006393
		static FileStream smethod_298(string string_0)
		{
			return File.OpenWrite(string_0);
		}

		// Token: 0x06000EA5 RID: 3749 RVA: 0x0000341A File Offset: 0x0000161A
		static EventLogSession smethod_299()
		{
			return EventLogSession.GlobalSession;
		}

		// Token: 0x06000EA6 RID: 3750 RVA: 0x00003421 File Offset: 0x00001621
		static IEnumerable<string> smethod_300(EventLogSession eventLogSession_0)
		{
			return eventLogSession_0.GetLogNames();
		}

		// Token: 0x06000EA7 RID: 3751 RVA: 0x000036C8 File Offset: 0x000018C8
		static bool smethod_301(string string_0, string string_1)
		{
			return string_0.StartsWith(string_1);
		}

		// Token: 0x06000EA8 RID: 3752 RVA: 0x0000819B File Offset: 0x0000639B
		MethodInfo[] method_18()
		{
			return base.GetMethods();
		}

		// Token: 0x06000EA9 RID: 3753 RVA: 0x000081A3 File Offset: 0x000063A3
		static string smethod_302(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x040004DF RID: 1247
		private readonly PictureBox[] copics = new PictureBox[8];

		// Token: 0x040004E0 RID: 1248
		private Point Serv2EndPosition;

		// Token: 0x040004E1 RID: 1249
		private bool IsFirstPanel = true;

		// Token: 0x040004E2 RID: 1250
		private bool expectation;

		// Token: 0x040004E3 RID: 1251
		public List<Label> servLabels;

		// Token: 0x040004E4 RID: 1252
		private string servlist;

		// Token: 0x040004E5 RID: 1253
		private bool servShow;

		// Token: 0x040004E6 RID: 1254
		public bool askBonus = true;

		// Token: 0x040004E7 RID: 1255
		private int OPtqt;

		// Token: 0x040004E8 RID: 1256
		private long OPtvolume;

		// Token: 0x040004E9 RID: 1257
		private List<string> dupesNamesandHash = new List<string>();

		// Token: 0x040004EA RID: 1258
		private readonly List<string> fullpathandhash = new List<string>();

		// Token: 0x040004EB RID: 1259
		private readonly List<string> dupesarray = new List<string>();

		// Token: 0x040004EC RID: 1260
		private readonly List<string> dupes = new List<string>();

		// Token: 0x040004ED RID: 1261
		private readonly Label dupetittle = new Label();

		// Token: 0x040004EE RID: 1262
		public int driversdupes;

		// Token: 0x040004EF RID: 1263
		private Panel temppanel = new Panel();

		// Token: 0x040004F0 RID: 1264
		private Color _Backcolor;

		// Token: 0x040004F1 RID: 1265
		private double sum;

		// Token: 0x040004F2 RID: 1266
		private bool permanent = true;

		// Token: 0x040004F3 RID: 1267
		private int VTPanelFinalHeight;

		// Token: 0x040004F4 RID: 1268
		private readonly string scanVT = GClass2.GClass2_0.method_1("VirusTotalPNG");

		// Token: 0x020000F2 RID: 242
		public class DriversList
		{
			// Token: 0x170000A2 RID: 162
			// (get) Token: 0x06000EAA RID: 3754 RVA: 0x000081AB File Offset: 0x000063AB
			// (set) Token: 0x06000EAB RID: 3755 RVA: 0x000081B3 File Offset: 0x000063B3
			public string PublishedName { get; set; }

			// Token: 0x170000A3 RID: 163
			// (get) Token: 0x06000EAC RID: 3756 RVA: 0x000081BC File Offset: 0x000063BC
			// (set) Token: 0x06000EAD RID: 3757 RVA: 0x000081C4 File Offset: 0x000063C4
			public string OriginalFileName { get; set; }

			// Token: 0x170000A4 RID: 164
			// (get) Token: 0x06000EAE RID: 3758 RVA: 0x000081CD File Offset: 0x000063CD
			// (set) Token: 0x06000EAF RID: 3759 RVA: 0x000081D5 File Offset: 0x000063D5
			public string ProviderName { get; set; }

			// Token: 0x170000A5 RID: 165
			// (get) Token: 0x06000EB0 RID: 3760 RVA: 0x000081DE File Offset: 0x000063DE
			// (set) Token: 0x06000EB1 RID: 3761 RVA: 0x000081E6 File Offset: 0x000063E6
			public Version Version { get; set; }
		}
	}
}
