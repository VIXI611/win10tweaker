﻿using System;
using System.IO;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000087 RID: 135
internal class Class47
{
	// Token: 0x17000035 RID: 53
	// (get) Token: 0x060006C0 RID: 1728 RVA: 0x0001E94C File Offset: 0x0001CB4C
	public static Class47 Class47_0
	{
		get
		{
			if (Class47.class47_0 == null)
			{
				object obj = Class47.object_0;
				lock (obj)
				{
					if (Class47.class47_0 == null)
					{
						Class47.class47_0 = new Class47();
					}
				}
			}
			return Class47.class47_0;
		}
	}

	// Token: 0x060006C1 RID: 1729 RVA: 0x0001E9AC File Offset: 0x0001CBAC
	public void method_0()
	{
		string text = GClass2.GClass2_0.String_15 + "\\Program Files (x86)\\Notepad++\\notepad++.exe";
		string text2 = GClass2.GClass2_0.String_15 + "\\Program Files\\Notepad++\\notepad++.exe";
		string text3 = "D:\\Portable Soft\\Portable Notepad++\\notepad++.exe";
		string text4 = GClass2.GClass2_0.String_15 + "\\Program Files (x86)\\AkelPad\\AkelPad.exe";
		string text5 = GClass2.GClass2_0.String_15 + "\\Program Files\\AkelPad\\AkelPad.exe";
		string text6 = GClass2.GClass2_0.String_15 + "\\Program Files\\Sublime Text 3\\sublime_text.exe";
		foreach (RegistryKey registryKey in new RegistryKey[]
		{
			Registry.CurrentUser.CreateSubKey("Software\\Classes\\MSInfoFile\\shell\\open\\command"),
			Registry.LocalMachine.CreateSubKey("SOFTWARE\\Classes\\Unknown\\shell\\edit\\command")
		})
		{
			if (!File.Exists(text))
			{
				if (File.Exists(text2))
				{
					registryKey.SetValue("", "\"" + text2 + "\" \"%1\"");
				}
				else if (!File.Exists(text3))
				{
					if (!File.Exists(text4))
					{
						if (!File.Exists(text5))
						{
							if (!File.Exists(text6))
							{
								registryKey.SetValue("", "notepad.exe \"%1\"");
							}
							else
							{
								registryKey.SetValue("", "\"" + text6 + "\" \"%1\"");
							}
						}
						else
						{
							registryKey.SetValue("", "\"" + text5 + "\" \"%1\"");
						}
					}
					else
					{
						registryKey.SetValue("", "\"" + text4 + "\" \"%1\"");
					}
				}
				else
				{
					registryKey.SetValue("", "\"" + text3 + "\" \"%1\"");
				}
			}
			else
			{
				registryKey.SetValue("", "\"" + text + "\" \"%1\"");
			}
		}
		foreach (RegistryKey registryKey2 in Class47.registryKey_0)
		{
			if (!File.Exists(text))
			{
				if (!File.Exists(text2))
				{
					if (!File.Exists(text3))
					{
						if (File.Exists(text4))
						{
							registryKey2.SetValue("", "\"" + text4 + "\" \"%1\"");
						}
						else if (File.Exists(text5))
						{
							registryKey2.SetValue("", "\"" + text5 + "\" \"%1\"");
						}
						else if (File.Exists(text6))
						{
							registryKey2.SetValue("", "\"" + text6 + "\" \"%1\"");
						}
						else
						{
							registryKey2.SetValue("", "notepad.exe \"%1\"");
						}
					}
					else
					{
						registryKey2.SetValue("", "\"" + text3 + "\" \"%1\"");
					}
				}
				else
				{
					registryKey2.SetValue("", "\"" + text2 + "\" \"%1\"");
				}
			}
			else
			{
				registryKey2.SetValue("", "\"" + text + "\" \"%1\"");
			}
		}
	}

	// Token: 0x060006C2 RID: 1730 RVA: 0x0001ECAC File Offset: 0x0001CEAC
	public void method_1()
	{
		Registry.CurrentUser.DeleteSubKeyTree("Software\\Classes\\MSInfoFile", false);
		Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Classes\\Unknown\\shell\\edit", false);
		RegistryKey[] array = Class47.registryKey_0;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetValue("", "notepad.exe \"%1\"");
		}
	}

	// Token: 0x060006C5 RID: 1733 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060006C6 RID: 1734 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060006C7 RID: 1735 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_2(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x060006C8 RID: 1736 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_3(RegistryKey registryKey_1, string string_0)
	{
		return registryKey_1.CreateSubKey(string_0);
	}

	// Token: 0x060006C9 RID: 1737 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_4(string string_0)
	{
		return File.Exists(string_0);
	}

	// Token: 0x060006CA RID: 1738 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_5(string string_0, string string_1, string string_2)
	{
		return string_0 + string_1 + string_2;
	}

	// Token: 0x060006CB RID: 1739 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_6(RegistryKey registryKey_1, string string_0, object object_1)
	{
		registryKey_1.SetValue(string_0, object_1);
	}

	// Token: 0x060006CC RID: 1740 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_7(RegistryKey registryKey_1, string string_0, bool bool_0)
	{
		registryKey_1.DeleteSubKeyTree(string_0, bool_0);
	}

	// Token: 0x060006CD RID: 1741 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_8()
	{
		return new object();
	}

	// Token: 0x0400029E RID: 670
	private static volatile Class47 class47_0;

	// Token: 0x0400029F RID: 671
	private static readonly object object_0 = new object();

	// Token: 0x040002A0 RID: 672
	private static readonly RegistryKey[] registryKey_0 = new RegistryKey[]
	{
		Registry.LocalMachine.CreateSubKey("SOFTWARE\\Classes\\batfile\\shell\\edit\\command"),
		Registry.LocalMachine.CreateSubKey("SOFTWARE\\Classes\\cmdfile\\shell\\edit\\command"),
		Registry.LocalMachine.CreateSubKey("SOFTWARE\\Classes\\VBSFile\\shell\\edit\\command")
	};
}
