﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000027 RID: 39
public partial class Bitcoin : Form
{
	// Token: 0x06000156 RID: 342 RVA: 0x00002E34 File Offset: 0x00001034
	public Bitcoin()
	{
		this.InitializeComponent();
	}

	// Token: 0x06000157 RID: 343 RVA: 0x00002E42 File Offset: 0x00001042
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06000159 RID: 345 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_0(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x0600015A RID: 346 RVA: 0x00002A5A File Offset: 0x00000C5A
	static PictureBox smethod_1()
	{
		return new PictureBox();
	}

	// Token: 0x0600015B RID: 347 RVA: 0x00002A7E File Offset: 0x00000C7E
	static TextBox smethod_2()
	{
		return new TextBox();
	}

	// Token: 0x0600015C RID: 348 RVA: 0x00002A85 File Offset: 0x00000C85
	static void smethod_3(ISupportInitialize isupportInitialize_0)
	{
		isupportInitialize_0.BeginInit();
	}

	// Token: 0x0600015D RID: 349 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_4(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x0600015E RID: 350 RVA: 0x00002E61 File Offset: 0x00001061
	static void smethod_5(Control control_0, ImageLayout imageLayout_0)
	{
		control_0.BackgroundImageLayout = imageLayout_0;
	}

	// Token: 0x0600015F RID: 351 RVA: 0x00002E6A File Offset: 0x0000106A
	static void smethod_6(PictureBox pictureBox_0, Image image_0)
	{
		pictureBox_0.Image = image_0;
	}

	// Token: 0x040000B5 RID: 181
	private IContainer icontainer_0;
}
