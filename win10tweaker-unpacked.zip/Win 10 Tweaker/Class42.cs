﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.Win32;

// Token: 0x0200007F RID: 127
internal class Class42
{
	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000648 RID: 1608 RVA: 0x0001D99C File Offset: 0x0001BB9C
	public static Class42 Class42_0
	{
		get
		{
			if (Class42.class42_0 == null)
			{
				object obj = Class42.object_0;
				lock (obj)
				{
					if (Class42.class42_0 == null)
					{
						Class42.class42_0 = new Class42();
					}
				}
			}
			return Class42.class42_0;
		}
	}

	// Token: 0x06000649 RID: 1609 RVA: 0x0001D9FC File Offset: 0x0001BBFC
	public void method_0()
	{
		Class42.Struct40 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Class42.Struct40>(ref @struct);
	}

	// Token: 0x0600064A RID: 1610 RVA: 0x0001DA2C File Offset: 0x0001BC2C
	public void method_1()
	{
		RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\System");
		registryKey.SetValue("EnableLUA", 1);
		registryKey.SetValue("EnableInstallerDetection", 1);
		registryKey.SetValue("PromptOnSecureDesktop", 1);
		registryKey.SetValue("ConsentPromptBehaviorAdmin", 5);
		registryKey.SetValue("EnableSecureUIAPaths", 1);
		registryKey.SetValue("EnableVirtualization", 1);
		registryKey.SetValue("FilterAdministratorToken", 1);
		RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\luafv", true);
		if (registryKey2 == null)
		{
			return;
		}
		registryKey2.SetValue("Start", 2);
	}

	// Token: 0x0600064D RID: 1613 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x0600064E RID: 1614 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x0600064F RID: 1615 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_2(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_3(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_4(RegistryKey registryKey_0, string string_0, object object_1)
	{
		registryKey_0.SetValue(string_0, object_1);
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_5(RegistryKey registryKey_0, string string_0, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_0, bool_0);
	}

	// Token: 0x06000653 RID: 1619 RVA: 0x000043D9 File Offset: 0x000025D9
	static void smethod_6(RegistryKey registryKey_0, string string_0, object object_1)
	{
		registryKey_0.SetValue(string_0, object_1);
	}

	// Token: 0x06000654 RID: 1620 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_7()
	{
		return new object();
	}

	// Token: 0x0400028A RID: 650
	private static volatile Class42 class42_0;

	// Token: 0x0400028B RID: 651
	private static readonly object object_0 = new object();
}
