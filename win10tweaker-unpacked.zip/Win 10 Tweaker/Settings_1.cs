﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Management;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.FileIO;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x0200009F RID: 159
public partial class Settings_1 : GForm0
{
	// Token: 0x06000829 RID: 2089 RVA: 0x000230F0 File Offset: 0x000212F0
	private void method_1()
	{
		Settings_1.Struct42 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct42>(ref @struct);
	}

	// Token: 0x0600082A RID: 2090 RVA: 0x00023128 File Offset: 0x00021328
	public Settings_1(Form1 form1_1)
	{
		this.InitializeComponent();
		this.form1_0 = form1_1;
		this.CloseIcon.Click += this.method_9;
		base.MouseWheel += this.method_2;
		typeof(Panel).method_19("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.SetProperty, null, this.LangPanel, new object[]
		{
			true
		});
		this.HeaderPanel.MouseDown += this.method_10;
		using (IEnumerator<PictureBox> enumerator = this.IconsPanel.Controls.OfType<PictureBox>().GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Settings_1.Class62 @class = new Settings_1.Class62();
				@class.pictureBox_0 = enumerator.Current;
				@class.pictureBox_0.MouseEnter += @class.method_0;
			}
		}
		using (IEnumerator<PictureBox> enumerator = this.IconsPanel.Controls.OfType<PictureBox>().GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Settings_1.Class63 class2 = new Settings_1.Class63();
				class2.pictureBox_0 = enumerator.Current;
				class2.pictureBox_0.MouseLeave += class2.method_0;
			}
		}
		this.int_0 = this.TogglesPanel.Width - (this.TogglesPanel.Width - this.CloseIcon.Location.X - this.CloseIcon.Width);
		this.int_1 = this.TogglesPanel.Width - this.LangPanel.Width + this.CloseIcon.Width + this.Russian.Height;
		this.int_2 = this.TogglesPanel.Width - this.LangPanel.Width * 44 / 100;
		this.LangPanel.MouseEnter += this.LangPanel_MouseEnter;
		this.TogglesPanel.MouseEnter += this.TogglesPanel_MouseEnter;
		this.SkinPanel.MouseEnter += this.SkinPanel_MouseEnter;
		this.TogglesPanel.MouseEnter += this.TogglesPanel_MouseEnter_1;
		this.LangPanel.Controls.OfType<PictureBox>().ToList<PictureBox>().ForEach(new Action<PictureBox>(this.method_11));
		foreach (PictureBox pictureBox in this.SkinPanel.Controls.OfType<PictureBox>())
		{
			pictureBox.Click += this.method_13;
		}
	}

	// Token: 0x0600082B RID: 2091 RVA: 0x0002343C File Offset: 0x0002163C
	private void Settings_1_Load(object sender, EventArgs e)
	{
		Settings_1.Struct43 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct43>(ref @struct);
	}

	// Token: 0x0600082C RID: 2092 RVA: 0x000051A3 File Offset: 0x000033A3
	private void method_2(object sender, MouseEventArgs e)
	{
		if (e.Delta > 0)
		{
			this.IconsPanel_MouseEnter(sender, null);
			return;
		}
		if (base.Opacity > 0.4)
		{
			this.InvisPanel_MouseEnter(sender, null);
		}
	}

	// Token: 0x0600082D RID: 2093 RVA: 0x00023474 File Offset: 0x00021674
	private void InvisPanel_MouseEnter(object sender, EventArgs e)
	{
		Settings_1.Struct44 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct44>(ref @struct);
	}

	// Token: 0x0600082E RID: 2094 RVA: 0x000234AC File Offset: 0x000216AC
	private void IconsPanel_MouseEnter(object sender, EventArgs e)
	{
		Settings_1.Struct45 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct45>(ref @struct);
	}

	// Token: 0x0600082F RID: 2095 RVA: 0x000234E4 File Offset: 0x000216E4
	private void Toggle1_Click(object sender, EventArgs e)
	{
		if (Settings_1.registryKey_0.GetValue("Auto Update").ToString() == "false")
		{
			Settings_1.registryKey_0.SetValue("Auto Update", "true");
			this.Toggle1.Image = Class89.Bitmap_64;
			return;
		}
		Settings_1.registryKey_0.SetValue("Auto Update", "false");
		this.Toggle1.Image = Class89.Bitmap_63;
	}

	// Token: 0x06000830 RID: 2096 RVA: 0x0002355C File Offset: 0x0002175C
	private void Toggle2_Click(object sender, EventArgs e)
	{
		if (Settings_1.registryKey_0.GetValue("Antispy Rules Auto Update").ToString() == "false")
		{
			Settings_1.registryKey_0.SetValue("Antispy Rules Auto Update", "true");
			Settings_1.registryKey_0.SetValue("Antispy Rules Auto Update FQ", this.Nud1.Text);
			this.Toggle2.Image = Class89.Bitmap_64;
			this.Nud1.Enabled = false;
			string text = GClass13.string_7 + "\\Tasks\\Win 10 Tweaker (AntiSpy)";
			if (File.Exists(text))
			{
				File.Delete(text);
			}
			File.WriteAllBytes(text, Class89.Byte_2);
			string text2 = File.ReadAllText(text);
			File.WriteAllText(text, text2.Replace("Username", GClass2.GClass2_0.String_9).Replace("FullWin10TweakerPath", GClass2.GClass2_0.String_11).Replace("pdvalue", "P" + this.Nud1.Text + "D").Replace("daysvalue", this.Nud1.Text), Encoding.Unicode);
			GClass6.GClass6_0.method_14("schtasks /create /xml \"" + text + "\" /tn \"Win 10 Tweaker (AntiSpy)\" /f");
		}
		else
		{
			Settings_1.registryKey_0.SetValue("Antispy Rules Auto Update", "false");
			GClass6.GClass6_0.method_14("schtasks /delete /tn \"Win 10 Tweaker (AntiSpy)\" /f");
			this.Toggle2.Image = Class89.Bitmap_63;
			this.Nud1.Enabled = true;
		}
		string path = GClass13.string_7 + "\\drivers\\etc\\hosts";
		if (File.Exists(path))
		{
			if (File.ReadAllLines(path).Any(new Func<string, bool>(Settings_1.<>c.<>9.method_0)))
			{
				this.form1_0.Close();
			}
		}
	}

	// Token: 0x06000831 RID: 2097 RVA: 0x00023720 File Offset: 0x00021920
	private void Toggle3_Click(object sender, EventArgs e)
	{
		string text = "Software\\Classes\\CLSID\\{645FF040-5081-101B-9F08-00AA002F954E}\\shell\\Win 10 Cleaner";
		if (Settings_1.registryKey_0.GetValue("Recycle Item").ToString() == "false")
		{
			Settings_1.registryKey_0.SetValue("Recycle Item", "true");
			this.Toggle3.Image = Class89.Bitmap_64;
			Registry.CurrentUser.CreateSubKey(text).SetValue("Icon", "\"" + Assembly.GetEntryAssembly().Location + "\"");
			Registry.CurrentUser.CreateSubKey(text + "\\command").SetValue("", "\"" + Assembly.GetEntryAssembly().Location + "\" clean");
			return;
		}
		Settings_1.registryKey_0.SetValue("Recycle Item", "false");
		this.Toggle3.Image = Class89.Bitmap_63;
		try
		{
			Registry.CurrentUser.DeleteSubKeyTree(text);
		}
		catch
		{
		}
	}

	// Token: 0x06000832 RID: 2098 RVA: 0x00023828 File Offset: 0x00021A28
	private void Toggle4_Click(object sender, EventArgs e)
	{
		if (Settings_1.registryKey_0.GetValue("VirusTotal Item").ToString() == "false")
		{
			Settings_1.registryKey_0.SetValue("VirusTotal Item", "true");
			this.Toggle4.Image = Class89.Bitmap_64;
			RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey("*\\shell\\VirusScanner");
			registryKey.SetValue("", GClass2.GClass2_0.method_1("VirusScanner"));
			registryKey.SetValue("Icon", "\"" + GClass2.GClass2_0.String_11 + "\"");
			Registry.ClassesRoot.CreateSubKey("*\\shell\\VirusScanner\\command").SetValue("", "\"" + GClass2.GClass2_0.String_11 + "\" \"%1\"");
			return;
		}
		Settings_1.registryKey_0.SetValue("VirusTotal Item", "false");
		this.Toggle4.Image = Class89.Bitmap_63;
		try
		{
			Registry.ClassesRoot.DeleteSubKeyTree("*\\shell\\VirusScanner");
		}
		catch
		{
		}
	}

	// Token: 0x06000833 RID: 2099 RVA: 0x00023944 File Offset: 0x00021B44
	private void Toggle5_Click(object sender, EventArgs e)
	{
		Settings_1.Struct46 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.object_0 = sender;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct46>(ref @struct);
	}

	// Token: 0x06000834 RID: 2100 RVA: 0x00023984 File Offset: 0x00021B84
	private void Toggle6_Click(object sender, EventArgs e)
	{
		Settings_1.Struct47 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.object_0 = sender;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct47>(ref @struct);
	}

	// Token: 0x06000835 RID: 2101 RVA: 0x000239C4 File Offset: 0x00021BC4
	private void Toggle7_Click(object sender, EventArgs e)
	{
		Settings_1.Struct48 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.object_0 = sender;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct48>(ref @struct);
	}

	// Token: 0x06000836 RID: 2102 RVA: 0x00023A04 File Offset: 0x00021C04
	private void Toggle8_Click(object sender, EventArgs e)
	{
		Settings_1.Struct49 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.object_0 = sender;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct49>(ref @struct);
	}

	// Token: 0x06000837 RID: 2103 RVA: 0x00023A44 File Offset: 0x00021C44
	private void Toggle9_Click(object sender, EventArgs e)
	{
		if (Settings_1.registryKey_0.GetValue("Broken Shortcuts").ToString() == "false")
		{
			Settings_1.registryKey_0.SetValue("Broken Shortcuts", "true");
			this.Toggle9.Image = Class89.Bitmap_64;
			return;
		}
		Settings_1.registryKey_0.SetValue("Broken Shortcuts", "false");
		this.Toggle9.Image = Class89.Bitmap_63;
	}

	// Token: 0x06000838 RID: 2104 RVA: 0x00023ABC File Offset: 0x00021CBC
	private void Toggle10_Click(object sender, EventArgs e)
	{
		Settings_1.registryKey_0.GetValueNames().Where(new Func<string, bool>(Settings_1.<>c.<>9.method_1)).ToList<string>().ForEach(new Action<string>(Settings_1.<>c.<>9.method_2));
		this.Toggle10.Image = Class89.Bitmap_64;
	}

	// Token: 0x06000839 RID: 2105 RVA: 0x00023B30 File Offset: 0x00021D30
	private void Toggle11_Click(object sender, EventArgs e)
	{
		if (WMessageBox.smethod_3(GClass2.GClass2_0.method_1("RemoveAllTweaksQ"), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
		{
			base.Close();
			this.form1_0.RemoveAllTweaks();
			this.form1_0.Popup(GClass2.GClass2_0.method_1("RemoveAllTweaksSuccess"), 8000);
		}
	}

	// Token: 0x0600083A RID: 2106 RVA: 0x00023B94 File Offset: 0x00021D94
	private void MenuItem1_Click(object sender, EventArgs e)
	{
		Settings_1.Struct50 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct50>(ref @struct);
	}

	// Token: 0x0600083B RID: 2107 RVA: 0x00023BCC File Offset: 0x00021DCC
	private void MenuItem2_Click(object sender, EventArgs e)
	{
		if (this.method_3())
		{
			this.method_1();
			try
			{
				Process.Start("rstrui.exe");
			}
			catch
			{
			}
		}
	}

	// Token: 0x0600083C RID: 2108 RVA: 0x00023C08 File Offset: 0x00021E08
	private bool method_3()
	{
		if (File.Exists(GClass2.GClass2_0.String_15 + "\\Windows\\System32\\rstrui.exe"))
		{
			return true;
		}
		WMessageBox.smethod_3(GClass2.GClass2_0.method_1("rstrui"), "", WMessageBox.GEnum2.OK, false, "", null);
		return false;
	}

	// Token: 0x0600083D RID: 2109 RVA: 0x00023C58 File Offset: 0x00021E58
	private void MenuItem3_Click(object sender, EventArgs e)
	{
		Settings_1.Struct51 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct51>(ref @struct);
	}

	// Token: 0x0600083E RID: 2110 RVA: 0x00023C90 File Offset: 0x00021E90
	private void MenuItem4_Click(object sender, EventArgs e)
	{
		Settings_1.Struct52 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct52>(ref @struct);
	}

	// Token: 0x0600083F RID: 2111 RVA: 0x00023CC8 File Offset: 0x00021EC8
	private void MenuItem5_Click(object sender, EventArgs e)
	{
		Settings_1.Struct53 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct53>(ref @struct);
	}

	// Token: 0x06000840 RID: 2112 RVA: 0x00023D00 File Offset: 0x00021F00
	private void MenuItem6_Click(object sender, EventArgs e)
	{
		Settings_1.Struct54 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct54>(ref @struct);
	}

	// Token: 0x06000841 RID: 2113 RVA: 0x00023D38 File Offset: 0x00021F38
	public void method_4(string string_9, bool bool_2 = false)
	{
		Settings_1.Struct55 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.string_0 = string_9;
		@struct.bool_0 = bool_2;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct55>(ref @struct);
	}

	// Token: 0x06000842 RID: 2114 RVA: 0x00023D80 File Offset: 0x00021F80
	private void method_5()
	{
		Settings_1.Class66 @class = new Settings_1.Class66();
		Settings_1.smethod_5("-show");
		Settings_1.smethod_5("-cleariconcache");
		@class.string_0 = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\Microsoft\\Internet Explorer";
		new List<string>
		{
			"ie4uinit-show.log",
			"ie4uinit-cleariconcache.log",
			"brndlog.txt",
			"ie4uinit-userconfig.log"
		}.Where(new Func<string, bool>(@class.method_0)).ToList<string>().ForEach(new Action<string>(@class.method_1));
	}

	// Token: 0x06000843 RID: 2115 RVA: 0x00023E18 File Offset: 0x00022018
	private void MenuItem7_Click(object sender, EventArgs e)
	{
		Settings_1.Struct56 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct56>(ref @struct);
	}

	// Token: 0x06000844 RID: 2116 RVA: 0x00023E50 File Offset: 0x00022050
	private void MenuItem8_Click(object sender, EventArgs e)
	{
		Settings_1.Class69 @class = new Settings_1.Class69();
		@class.settings_1_0 = this;
		@class.folderBrowserDialog_0 = new FolderBrowserDialog
		{
			Description = GClass2.GClass2_0.method_1("SpecifyDriversDirectory"),
			ShowNewFolderButton = false
		};
		if (@class.folderBrowserDialog_0.ShowDialog() == DialogResult.OK)
		{
			if (Directory.GetFiles(@class.folderBrowserDialog_0.SelectedPath, "*.inf", System.IO.SearchOption.AllDirectories).Length != 0)
			{
				Form1.OpenDim(false);
				base.TopMost = false;
				this.MenuItem8.BackgroundImage = Class89.Bitmap_36;
				Settings_1.bool_1 = true;
				Thread.Sleep(10);
				this.MenuItem8.Image = Class89.Bitmap_57;
				new Thread(new ThreadStart(@class.method_0))
				{
					IsBackground = true
				}.Start();
				this.MenuItem8.BackgroundImage = Class89.Bitmap_36;
				return;
			}
			WMessageBox.smethod_3(GClass2.GClass2_0.method_1("NoDriversFound"), "", WMessageBox.GEnum2.OK, false, "", null);
		}
	}

	// Token: 0x06000845 RID: 2117 RVA: 0x00023F48 File Offset: 0x00022148
	public static string[] smethod_3()
	{
		string text = "";
		string name = "DisplayName";
		string name2 = "UninstallString";
		string name3 = "SystemComponent";
		string[] array = new string[]
		{
			GClass2.GClass2_0.String_0 + "\\Uninstall",
			(!GClass2.GClass2_0.Boolean_0) ? " " : "SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall"
		};
		RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Uninstall");
		if (registryKey != null)
		{
			foreach (string name4 in registryKey.GetSubKeyNames())
			{
				RegistryKey registryKey2 = registryKey.OpenSubKey(name4);
				if (registryKey2.GetValue(name) != null && registryKey2.GetValue(name2) != null && (registryKey2.GetValue(name3) == null || registryKey2.GetValue(name3).ToString() == "0"))
				{
					string str = text;
					object value = registryKey2.GetValue(name);
					text = str + ((value != null) ? value.ToString() : null) + "\r\n";
				}
			}
		}
		foreach (string name5 in array)
		{
			RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey(name5);
			if (registryKey3 != null)
			{
				foreach (string name6 in registryKey3.GetSubKeyNames())
				{
					RegistryKey registryKey4 = registryKey3.OpenSubKey(name6);
					if (registryKey4.GetValue(name) != null && registryKey4.GetValue(name2) != null && (registryKey4.GetValue(name3) == null || registryKey4.GetValue(name3).ToString() == "0"))
					{
						string str2 = text;
						object value2 = registryKey4.GetValue(name);
						text = str2 + ((value2 != null) ? value2.ToString() : null) + "\r\n";
					}
				}
			}
		}
		string[] array3 = text.Split(new char[]
		{
			'\r',
			'\n'
		}, StringSplitOptions.RemoveEmptyEntries);
		Array.Sort<string>(array3);
		return array3.Distinct<string>().ToArray<string>();
	}

	// Token: 0x06000846 RID: 2118 RVA: 0x00024138 File Offset: 0x00022338
	private void MenuItem9_Click(object sender, EventArgs e)
	{
		Settings_1.Struct57 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct57>(ref @struct);
	}

	// Token: 0x06000847 RID: 2119 RVA: 0x00024170 File Offset: 0x00022370
	private void MenuItem10_Click(object sender, EventArgs e)
	{
		Settings_1.Struct58 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct58>(ref @struct);
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x000241A8 File Offset: 0x000223A8
	private void method_6()
	{
		base.Invoke(new Action(this.method_18));
		foreach (Label label in this.TogglesPanel.Controls.OfType<Label>())
		{
			label.Text = GClass2.GClass2_0.method_1(label.Name);
		}
		foreach (Label label2 in this.IconsPanel.Controls.OfType<Label>())
		{
			label2.Text = GClass2.GClass2_0.method_1(label2.Name);
			label2.MaximumSize = new Size(this.MenuItem1.Width, 0);
		}
		foreach (PictureBox pictureBox in this.IconsPanel.Controls.OfType<PictureBox>())
		{
			foreach (Label label3 in this.IconsPanel.Controls.OfType<Label>())
			{
				if (label3.Name.Replace("Label", "Item") == pictureBox.Name)
				{
					label3.Location = new Point(pictureBox.Location.X + (pictureBox.Width - label3.Width) / 2, label3.Location.Y);
				}
			}
		}
		this.Nud1.Location = new Point(this.SettingsItemlabel2.Location.X + this.SettingsItemlabel2.Width, this.SettingsItemlabel2.Location.Y - 1);
		this.DaysLabel.Size = new Size(this.DaysLabel.Width, this.Nud1.Height + 2);
		this.DaysLabel.Location = new Point(this.Nud1.Location.X + this.Nud1.Width - 16, this.SettingsItemlabel2.Location.Y - (this.Nud1.Height + 1 - this.SettingsItemlabel2.Height) / 2 - 1);
	}

	// Token: 0x06000849 RID: 2121 RVA: 0x0002444C File Offset: 0x0002264C
	public void method_7()
	{
		if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin") != null)
		{
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "DarkSkin")
			{
				this.form1_0.FormPaint(GClass2.GClass2_0.color_5, GClass2.GClass2_0.color_5);
				this.form1_0.HeaderPaint(GClass2.GClass2_0.color_5, Color.FromArgb(10, 21, 33), GClass2.GClass2_0.color_5);
				this.method_8(GClass2.GClass2_0.color_5, Color.FromArgb(10, 21, 33), GClass2.GClass2_0.color_5);
				this.form1_0.LeftPanelPaint(Color.FromArgb(29, 34, 47), Color.FromArgb(14, 20, 25), GClass2.GClass2_0.color_5);
				this.form1_0.BackColor = GClass2.GClass2_0.color_5;
				this.IconsPanel.BackColor = GClass2.GClass2_0.color_5;
				this.TogglesPanel.BackColor = GClass2.GClass2_0.color_5;
				this.HeaderPanel.BackColor = GClass2.GClass2_0.color_5;
				this.Nud1.BackColor = Color.FromArgb(41, 52, 75);
				this.form1_0.panelVT.BackColor = GClass2.GClass2_0.color_5;
				this.LangPanel.BackgroundImage = Class89.Bitmap_33;
				this.SkinPanel.BackgroundImage = Class89.Bitmap_33;
				this.form1_0.PleaseWaitVT.BackColor = GClass2.GClass2_0.Color_0;
				this.form1_0.PersonalPlate(Color.FromArgb(38, 48, 73));
				this.form1_0.PersonalPanelPaint(GClass2.GClass2_0.color_5, Color.FromArgb(10, 21, 33), GClass2.GClass2_0.color_5);
				return;
			}
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SkySkin")
			{
				this.form1_0.FormPaint(GClass2.GClass2_0.color_6, Color.FromArgb(10, 33, 58));
				this.form1_0.HeaderPaint(GClass2.GClass2_0.color_6, Color.FromArgb(15, 26, 41), GClass2.GClass2_0.color_6);
				this.method_8(GClass2.GClass2_0.color_6, Color.FromArgb(15, 26, 41), GClass2.GClass2_0.color_6);
				this.form1_0.LeftPanelPaint(Color.FromArgb(28, 57, 82), Color.FromArgb(10, 25, 50), GClass2.GClass2_0.color_6);
				this.form1_0.BackColor = GClass2.GClass2_0.color_6;
				this.IconsPanel.BackColor = GClass2.GClass2_0.color_6;
				this.TogglesPanel.BackColor = GClass2.GClass2_0.color_6;
				this.HeaderPanel.BackColor = GClass2.GClass2_0.color_6;
				this.Nud1.BackColor = Color.LightSlateGray;
				this.form1_0.panelVT.BackColor = GClass2.GClass2_0.color_6;
				this.LangPanel.BackgroundImage = Class89.Bitmap_34;
				this.SkinPanel.BackgroundImage = Class89.Bitmap_34;
				this.form1_0.PleaseWaitVT.BackColor = GClass2.GClass2_0.Color_0;
				this.form1_0.PersonalPlate(Color.FromArgb(27, 55, 79));
				this.form1_0.PersonalPanelPaint(GClass2.GClass2_0.color_6, Color.FromArgb(15, 26, 41), GClass2.GClass2_0.color_6);
				return;
			}
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SeaSkin")
			{
				this.form1_0.FormPaint(GClass2.GClass2_0.color_7, Color.FromArgb(8, 40, 60));
				this.form1_0.HeaderPaint(GClass2.GClass2_0.color_7, Color.FromArgb(15, 26, 41), GClass2.GClass2_0.color_7);
				this.method_8(GClass2.GClass2_0.color_7, Color.FromArgb(15, 26, 41), GClass2.GClass2_0.color_7);
				this.form1_0.LeftPanelPaint(Color.FromArgb(19, 62, 78), Color.FromArgb(20, 23, 36), GClass2.GClass2_0.color_7);
				this.form1_0.BackColor = GClass2.GClass2_0.color_7;
				this.IconsPanel.BackColor = GClass2.GClass2_0.color_7;
				this.TogglesPanel.BackColor = GClass2.GClass2_0.color_7;
				this.HeaderPanel.BackColor = GClass2.GClass2_0.color_7;
				this.Nud1.BackColor = Color.DarkSlateGray;
				this.form1_0.panelVT.BackColor = GClass2.GClass2_0.color_7;
				this.LangPanel.BackgroundImage = Class89.Bitmap_34;
				this.SkinPanel.BackgroundImage = Class89.Bitmap_34;
				this.form1_0.PleaseWaitVT.BackColor = GClass2.GClass2_0.Color_0;
				this.form1_0.PersonalPlate(Color.FromArgb(19, 60, 76));
				this.form1_0.PersonalPanelPaint(GClass2.GClass2_0.color_7, Color.FromArgb(15, 26, 41), GClass2.GClass2_0.color_7);
			}
		}
	}

	// Token: 0x0600084A RID: 2122 RVA: 0x000249A8 File Offset: 0x00022BA8
	public void method_8(Color color_0, Color color_1, Color color_2)
	{
		Settings_1.Class70 @class = new Settings_1.Class70();
		@class.settings_1_0 = this;
		@class.color_0 = color_0;
		@class.color_1 = color_1;
		@class.color_2 = color_2;
		this.HeaderPanel.Paint += @class.method_0;
		this.HeaderPanel.Invalidate();
	}

	// Token: 0x0600084B RID: 2123 RVA: 0x000051D0 File Offset: 0x000033D0
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600084E RID: 2126 RVA: 0x000051EF File Offset: 0x000033EF
	[CompilerGenerated]
	private void method_9(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x0600084F RID: 2127 RVA: 0x000275F0 File Offset: 0x000257F0
	[CompilerGenerated]
	private void method_10(object sender, MouseEventArgs e)
	{
		this.HeaderPanel.Capture = false;
		base.Capture = false;
		Message message = Message.Create(this.method_20(), 161, new IntPtr(2), IntPtr.Zero);
		base.System.Windows.Forms.Form.WndProc(ref message);
	}

	// Token: 0x06000850 RID: 2128 RVA: 0x00027634 File Offset: 0x00025834
	[CompilerGenerated]
	private void LangPanel_MouseEnter(object sender, EventArgs e)
	{
		Settings_1.Struct59 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct59>(ref @struct);
	}

	// Token: 0x06000851 RID: 2129 RVA: 0x0002766C File Offset: 0x0002586C
	[CompilerGenerated]
	private void TogglesPanel_MouseEnter(object sender, EventArgs e)
	{
		Settings_1.Struct60 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct60>(ref @struct);
	}

	// Token: 0x06000852 RID: 2130 RVA: 0x000276A4 File Offset: 0x000258A4
	[CompilerGenerated]
	private void SkinPanel_MouseEnter(object sender, EventArgs e)
	{
		Settings_1.Struct61 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct61>(ref @struct);
	}

	// Token: 0x06000853 RID: 2131 RVA: 0x000276DC File Offset: 0x000258DC
	[CompilerGenerated]
	private void TogglesPanel_MouseEnter_1(object sender, EventArgs e)
	{
		Settings_1.Struct62 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.settings_1_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Settings_1.Struct62>(ref @struct);
	}

	// Token: 0x06000854 RID: 2132 RVA: 0x000051F7 File Offset: 0x000033F7
	[CompilerGenerated]
	private void method_11(PictureBox pictureBox_0)
	{
		pictureBox_0.Click += this.method_12;
	}

	// Token: 0x06000855 RID: 2133 RVA: 0x00027714 File Offset: 0x00025914
	[CompilerGenerated]
	private void method_12(object sender, EventArgs e)
	{
		Settings_1.registryKey_0.SetValue("Language", ((PictureBox)sender).Name);
		GClass2.GClass2_0.string_13 = ((PictureBox)sender).Name;
		this.form1_0.Translate();
		this.form1_0.LeftMenu1_LinkClicked(sender, null);
		this.method_6();
	}

	// Token: 0x06000856 RID: 2134 RVA: 0x00027770 File Offset: 0x00025970
	[CompilerGenerated]
	private void method_13(object sender, EventArgs e)
	{
		Settings_1.registryKey_0.SetValue("Skin", ((PictureBox)sender).Name);
		this.method_7();
		this.form1_0.Popup(GClass2.GClass2_0.method_1("SkinPopupDemo"), 8000);
	}

	// Token: 0x06000857 RID: 2135 RVA: 0x000277BC File Offset: 0x000259BC
	[CompilerGenerated]
	internal static void smethod_4(PictureBox pictureBox_0, string string_9)
	{
		if (Settings_1.registryKey_0.GetValue(string_9) != null && !(Settings_1.registryKey_0.GetValue(string_9).ToString() == "false"))
		{
			if (Settings_1.registryKey_0.GetValue(string_9).ToString() == "true")
			{
				pictureBox_0.Image = Class89.Bitmap_64;
				Settings_1.registryKey_0.SetValue(string_9, "true");
			}
			return;
		}
		pictureBox_0.Image = Class89.Bitmap_63;
		Settings_1.registryKey_0.SetValue(string_9, "false");
	}

	// Token: 0x06000858 RID: 2136 RVA: 0x00027848 File Offset: 0x00025A48
	[CompilerGenerated]
	private bool method_14()
	{
		this.MenuItem1.BackgroundImage = Class89.Bitmap_36;
		bool flag = true;
		try
		{
			string pathRoot = Path.GetPathRoot(Environment.SystemDirectory);
			ManagementScope scope = new ManagementScope("\\\\localhost\\root\\default");
			ManagementPath path = new ManagementPath("SystemRestore");
			ObjectGetOptions options = new ObjectGetOptions();
			ManagementClass managementClass = new ManagementClass(scope, path, options);
			ManagementBaseObject methodParameters = managementClass.GetMethodParameters("Enable");
			methodParameters["WaitTillEnabled"] = true;
			methodParameters["Drive"] = pathRoot;
			managementClass.InvokeMethod("Enable", methodParameters, null);
			ManagementClass managementClass2 = new ManagementClass(new ManagementScope("\\\\.\\root\\default"), new ManagementPath("SystemRestore"), new ObjectGetOptions());
			ManagementBaseObject methodParameters2 = managementClass2.GetMethodParameters("CreateRestorePoint");
			methodParameters2["Description"] = string.Format(GClass2.GClass2_0.method_1("SystemStateBeforeW10T"), DateTime.Now);
			methodParameters2["RestorePointType"] = 0;
			methodParameters2["EventType"] = 100;
			managementClass2.InvokeMethod("CreateRestorePoint", methodParameters2, null);
			flag = ((methodParameters2 == null) ? (!flag) : flag);
		}
		catch
		{
		}
		this.MenuItem1.Image = Class89.Bitmap_0;
		this.MenuItem1.BackgroundImage = null;
		Form1.CloseDim();
		return flag;
	}

	// Token: 0x06000859 RID: 2137 RVA: 0x0000520B File Offset: 0x0000340B
	[CompilerGenerated]
	private void method_15()
	{
		this.method_14();
	}

	// Token: 0x0600085A RID: 2138 RVA: 0x0002799C File Offset: 0x00025B9C
	[CompilerGenerated]
	private void method_16(string string_9)
	{
		Settings_1.Class64 @class = new Settings_1.Class64();
		@class.settings_1_0 = this;
		@class.string_0 = string_9;
		Settings_1.Class64 class2 = @class;
		RegistryKey registryKey = this.registryKey_1.OpenSubKey(@class.string_0);
		string text;
		if (registryKey != null)
		{
			object value = registryKey.GetValue("");
			if (value != null)
			{
				if ((text = value.ToString()) != null)
				{
					goto IL_4C;
				}
			}
		}
		text = "";
		IL_4C:
		class2.string_1 = text;
		this.registryKey_2.OpenSubKey(this.string_7 + "\\" + @class.string_0).GetSubKeyNames().ToList<string>().ForEach(new Action<string>(@class.method_0));
	}

	// Token: 0x0600085B RID: 2139 RVA: 0x00027A38 File Offset: 0x00025C38
	[CompilerGenerated]
	private void method_17(ExtensionGroup extensionGroup_0)
	{
		RegistryKey registryKey = this.registryKey_1.OpenSubKey(extensionGroup_0.ExtensionClass);
		string text;
		if (registryKey != null)
		{
			object value = registryKey.GetValue("FriendlyTypeName");
			if (value != null)
			{
				if ((text = value.ToString()) != null)
				{
					goto IL_6A;
				}
			}
		}
		RegistryKey registryKey2 = this.registryKey_1.OpenSubKey(extensionGroup_0.ExtensionClass);
		if (registryKey2 != null)
		{
			object value2 = registryKey2.GetValue("");
			if (value2 != null)
			{
				if ((text = value2.ToString()) != null)
				{
					goto IL_6A;
				}
			}
		}
		text = extensionGroup_0.ExtensionClass;
		IL_6A:
		string value3 = text;
		if (this.registryKey_1.OpenSubKey(extensionGroup_0.ExtensionClass) != null)
		{
			GClass6.GClass6_0.method_17(this.registryKey_1.OpenSubKey(extensionGroup_0.ExtensionClass), true);
		}
		this.registryKey_1.CreateSubKey(extensionGroup_0.Extension).SetValue("", extensionGroup_0.ExtensionClass);
		this.registryKey_1.CreateSubKey(extensionGroup_0.ExtensionClass).SetValue("", value3);
		if (extensionGroup_0.ExtensionIcon != "")
		{
			this.registryKey_1.CreateSubKey(extensionGroup_0.ExtensionClass + "\\DefaultIcon").SetValue("", extensionGroup_0.ExtensionIcon);
		}
		this.registryKey_1.CreateSubKey(extensionGroup_0.ExtensionClass + "\\shell\\open\\command").SetValue("", extensionGroup_0.ExecutablePath);
	}

	// Token: 0x0600085C RID: 2140 RVA: 0x00005214 File Offset: 0x00003414
	[CompilerGenerated]
	internal static void smethod_5(string string_9)
	{
		Process.Start(new ProcessStartInfo
		{
			FileName = "ie4uinit.exe",
			Arguments = string_9,
			WindowStyle = ProcessWindowStyle.Hidden
		}).WaitForExit();
	}

	// Token: 0x0600085D RID: 2141 RVA: 0x0000523E File Offset: 0x0000343E
	[CompilerGenerated]
	internal static string smethod_6(string string_9)
	{
		return string_9.Substring(string_9.IndexOf("=") + 1).Trim().Replace("\t", "").Replace("\n", "");
	}

	// Token: 0x0600085E RID: 2142 RVA: 0x00005276 File Offset: 0x00003476
	[CompilerGenerated]
	private void method_18()
	{
		this.Header.Text = GClass2.GClass2_0.method_1("SettingsHeader");
	}

	// Token: 0x0600085F RID: 2143 RVA: 0x00005292 File Offset: 0x00003492
	static string smethod_7()
	{
		return Environment.CurrentDirectory;
	}

	// Token: 0x06000860 RID: 2144 RVA: 0x000033BD File Offset: 0x000015BD
	static string smethod_8(string string_9, string string_10, string string_11, string string_12)
	{
		return string_9 + string_10 + string_11 + string_12;
	}

	// Token: 0x06000861 RID: 2145 RVA: 0x00002951 File Offset: 0x00000B51
	static void smethod_9(Control control_0, EventHandler eventHandler_0)
	{
		control_0.Click += eventHandler_0;
	}

	// Token: 0x06000862 RID: 2146 RVA: 0x00005299 File Offset: 0x00003499
	static void smethod_10(Control control_0, MouseEventHandler mouseEventHandler_0)
	{
		control_0.MouseWheel += mouseEventHandler_0;
	}

	// Token: 0x06000863 RID: 2147 RVA: 0x000025CE File Offset: 0x000007CE
	static Type smethod_11(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x06000864 RID: 2148 RVA: 0x00002ABF File Offset: 0x00000CBF
	object method_19(string string_9, BindingFlags bindingFlags_0, Binder binder_0, object object_0, object[] object_1)
	{
		return base.InvokeMember(string_9, bindingFlags_0, binder_0, object_0, object_1);
	}

	// Token: 0x06000865 RID: 2149 RVA: 0x00002AAE File Offset: 0x00000CAE
	static void smethod_12(Control control_0, MouseEventHandler mouseEventHandler_0)
	{
		control_0.MouseDown += mouseEventHandler_0;
	}

	// Token: 0x06000866 RID: 2150 RVA: 0x0000295A File Offset: 0x00000B5A
	static Control.ControlCollection smethod_13(Control control_0)
	{
		return control_0.Controls;
	}

	// Token: 0x06000867 RID: 2151 RVA: 0x00002962 File Offset: 0x00000B62
	static void smethod_14(Control control_0, EventHandler eventHandler_0)
	{
		control_0.MouseEnter += eventHandler_0;
	}

	// Token: 0x06000868 RID: 2152 RVA: 0x00002974 File Offset: 0x00000B74
	static bool smethod_15(IEnumerator ienumerator_0)
	{
		return ienumerator_0.MoveNext();
	}

	// Token: 0x06000869 RID: 2153 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_16(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x0600086A RID: 2154 RVA: 0x0000296B File Offset: 0x00000B6B
	static void smethod_17(Control control_0, EventHandler eventHandler_0)
	{
		control_0.MouseLeave += eventHandler_0;
	}

	// Token: 0x0600086B RID: 2155 RVA: 0x000029FF File Offset: 0x00000BFF
	static int smethod_18(Control control_0)
	{
		return control_0.Width;
	}

	// Token: 0x0600086C RID: 2156 RVA: 0x00002A07 File Offset: 0x00000C07
	static Point smethod_19(Control control_0)
	{
		return control_0.Location;
	}

	// Token: 0x0600086D RID: 2157 RVA: 0x000052A2 File Offset: 0x000034A2
	static int smethod_20(MouseEventArgs mouseEventArgs_0)
	{
		return mouseEventArgs_0.Delta;
	}

	// Token: 0x0600086E RID: 2158 RVA: 0x000043B4 File Offset: 0x000025B4
	static double smethod_21(Form form_0)
	{
		return form_0.Opacity;
	}

	// Token: 0x0600086F RID: 2159 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_22(RegistryKey registryKey_3, string string_9)
	{
		return registryKey_3.GetValue(string_9);
	}

	// Token: 0x06000870 RID: 2160 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_23(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x06000871 RID: 2161 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_24(string string_9, string string_10)
	{
		return string_9 == string_10;
	}

	// Token: 0x06000872 RID: 2162 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_25(RegistryKey registryKey_3, string string_9, object object_0)
	{
		registryKey_3.SetValue(string_9, object_0);
	}

	// Token: 0x06000873 RID: 2163 RVA: 0x00002E6A File Offset: 0x0000106A
	static void smethod_26(PictureBox pictureBox_0, Image image_0)
	{
		pictureBox_0.Image = image_0;
	}

	// Token: 0x06000874 RID: 2164 RVA: 0x00002A18 File Offset: 0x00000C18
	static string smethod_27(Control control_0)
	{
		return control_0.Text;
	}

	// Token: 0x06000875 RID: 2165 RVA: 0x00002C67 File Offset: 0x00000E67
	static void smethod_28(Control control_0, bool bool_2)
	{
		control_0.Enabled = bool_2;
	}

	// Token: 0x06000876 RID: 2166 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_29(string string_9, string string_10)
	{
		return string_9 + string_10;
	}

	// Token: 0x06000877 RID: 2167 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_30(string string_9)
	{
		return File.Exists(string_9);
	}

	// Token: 0x06000878 RID: 2168 RVA: 0x00002F15 File Offset: 0x00001115
	static void smethod_31(string string_9)
	{
		File.Delete(string_9);
	}

	// Token: 0x06000879 RID: 2169 RVA: 0x00002DFB File Offset: 0x00000FFB
	static void smethod_32(string string_9, byte[] byte_0)
	{
		File.WriteAllBytes(string_9, byte_0);
	}

	// Token: 0x0600087A RID: 2170 RVA: 0x00003CE7 File Offset: 0x00001EE7
	static string smethod_33(string string_9)
	{
		return File.ReadAllText(string_9);
	}

	// Token: 0x0600087B RID: 2171 RVA: 0x000033D1 File Offset: 0x000015D1
	static string smethod_34(string string_9, string string_10, string string_11)
	{
		return string_9.Replace(string_10, string_11);
	}

	// Token: 0x0600087C RID: 2172 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_35(string string_9, string string_10, string string_11)
	{
		return string_9 + string_10 + string_11;
	}

	// Token: 0x0600087D RID: 2173 RVA: 0x000052AA File Offset: 0x000034AA
	static Encoding smethod_36()
	{
		return Encoding.Unicode;
	}

	// Token: 0x0600087E RID: 2174 RVA: 0x000052B1 File Offset: 0x000034B1
	static void smethod_37(string string_9, string string_10, Encoding encoding_0)
	{
		File.WriteAllText(string_9, string_10, encoding_0);
	}

	// Token: 0x0600087F RID: 2175 RVA: 0x000033DB File Offset: 0x000015DB
	static string[] smethod_38(string string_9)
	{
		return File.ReadAllLines(string_9);
	}

	// Token: 0x06000880 RID: 2176 RVA: 0x000052BB File Offset: 0x000034BB
	static void smethod_39(Form form_0)
	{
		form_0.Close();
	}

	// Token: 0x06000881 RID: 2177 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_40(RegistryKey registryKey_3, string string_9)
	{
		return registryKey_3.CreateSubKey(string_9);
	}

	// Token: 0x06000882 RID: 2178 RVA: 0x00003926 File Offset: 0x00001B26
	static Assembly smethod_41()
	{
		return Assembly.GetEntryAssembly();
	}

	// Token: 0x06000883 RID: 2179 RVA: 0x0000392D File Offset: 0x00001B2D
	static string smethod_42(Assembly assembly_0)
	{
		return assembly_0.Location;
	}

	// Token: 0x06000884 RID: 2180 RVA: 0x00003021 File Offset: 0x00001221
	static void smethod_43(RegistryKey registryKey_3, string string_9)
	{
		registryKey_3.DeleteSubKeyTree(string_9);
	}

	// Token: 0x06000885 RID: 2181 RVA: 0x00003019 File Offset: 0x00001219
	static string[] smethod_44(RegistryKey registryKey_3)
	{
		return registryKey_3.GetValueNames();
	}

	// Token: 0x06000886 RID: 2182 RVA: 0x00002C39 File Offset: 0x00000E39
	static void smethod_45(Form form_0)
	{
		form_0.Close();
	}

	// Token: 0x06000887 RID: 2183 RVA: 0x00002AA6 File Offset: 0x00000CA6
	static Process smethod_46(string string_9)
	{
		return Process.Start(string_9);
	}

	// Token: 0x06000888 RID: 2184 RVA: 0x00003935 File Offset: 0x00001B35
	static string smethod_47(Environment.SpecialFolder specialFolder_0)
	{
		return Environment.GetFolderPath(specialFolder_0);
	}

	// Token: 0x06000889 RID: 2185 RVA: 0x000052C3 File Offset: 0x000034C3
	static FolderBrowserDialog smethod_48()
	{
		return new FolderBrowserDialog();
	}

	// Token: 0x0600088A RID: 2186 RVA: 0x000052CA File Offset: 0x000034CA
	static void smethod_49(FolderBrowserDialog folderBrowserDialog_0, string string_9)
	{
		folderBrowserDialog_0.Description = string_9;
	}

	// Token: 0x0600088B RID: 2187 RVA: 0x000052D3 File Offset: 0x000034D3
	static void smethod_50(FolderBrowserDialog folderBrowserDialog_0, bool bool_2)
	{
		folderBrowserDialog_0.ShowNewFolderButton = bool_2;
	}

	// Token: 0x0600088C RID: 2188 RVA: 0x000052DC File Offset: 0x000034DC
	static DialogResult smethod_51(CommonDialog commonDialog_0)
	{
		return commonDialog_0.ShowDialog();
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x000052E4 File Offset: 0x000034E4
	static string smethod_52(FolderBrowserDialog folderBrowserDialog_0)
	{
		return folderBrowserDialog_0.SelectedPath;
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x000031B9 File Offset: 0x000013B9
	static string[] smethod_53(string string_9, string string_10, System.IO.SearchOption searchOption_0)
	{
		return Directory.GetFiles(string_9, string_10, searchOption_0);
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x00004E12 File Offset: 0x00003012
	static void smethod_54(Form form_0, bool bool_2)
	{
		form_0.TopMost = bool_2;
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x00002B2F File Offset: 0x00000D2F
	static void smethod_55(Control control_0, Image image_0)
	{
		control_0.BackgroundImage = image_0;
	}

	// Token: 0x06000891 RID: 2193 RVA: 0x00002625 File Offset: 0x00000825
	static void smethod_56(int int_3)
	{
		Thread.Sleep(int_3);
	}

	// Token: 0x06000892 RID: 2194 RVA: 0x000052EC File Offset: 0x000034EC
	static Thread smethod_57(ThreadStart threadStart_0)
	{
		return new Thread(threadStart_0);
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x0000260C File Offset: 0x0000080C
	static void smethod_58(Thread thread_0, bool bool_2)
	{
		thread_0.IsBackground = bool_2;
	}

	// Token: 0x06000894 RID: 2196 RVA: 0x000052F4 File Offset: 0x000034F4
	static void smethod_59(Thread thread_0)
	{
		thread_0.Start();
	}

	// Token: 0x06000895 RID: 2197 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_60(RegistryKey registryKey_3, string string_9)
	{
		return registryKey_3.OpenSubKey(string_9);
	}

	// Token: 0x06000896 RID: 2198 RVA: 0x000030B3 File Offset: 0x000012B3
	static string[] smethod_61(RegistryKey registryKey_3)
	{
		return registryKey_3.GetSubKeyNames();
	}

	// Token: 0x06000897 RID: 2199 RVA: 0x00002C70 File Offset: 0x00000E70
	static string[] smethod_62(string string_9, char[] char_0, StringSplitOptions stringSplitOptions_0)
	{
		return string_9.Split(char_0, stringSplitOptions_0);
	}

	// Token: 0x06000898 RID: 2200 RVA: 0x000052FC File Offset: 0x000034FC
	static object smethod_63(Control control_0, Delegate delegate_0)
	{
		return control_0.Invoke(delegate_0);
	}

	// Token: 0x06000899 RID: 2201 RVA: 0x00002C23 File Offset: 0x00000E23
	static string smethod_64(Control control_0)
	{
		return control_0.Name;
	}

	// Token: 0x0600089A RID: 2202 RVA: 0x00002920 File Offset: 0x00000B20
	static void smethod_65(Control control_0, string string_9)
	{
		control_0.Text = string_9;
	}

	// Token: 0x0600089B RID: 2203 RVA: 0x00002BA7 File Offset: 0x00000DA7
	static void smethod_66(Control control_0, Color color_0)
	{
		control_0.BackColor = color_0;
	}

	// Token: 0x0600089C RID: 2204 RVA: 0x00002A0F File Offset: 0x00000C0F
	static void smethod_67(Control control_0, PaintEventHandler paintEventHandler_0)
	{
		control_0.Paint += paintEventHandler_0;
	}

	// Token: 0x0600089D RID: 2205 RVA: 0x00002929 File Offset: 0x00000B29
	static void smethod_68(Control control_0)
	{
		control_0.Invalidate();
	}

	// Token: 0x0600089E RID: 2206 RVA: 0x00002A4C File Offset: 0x00000C4C
	static Container smethod_69()
	{
		return new Container();
	}

	// Token: 0x0600089F RID: 2207 RVA: 0x00005305 File Offset: 0x00003505
	static ComponentResourceManager smethod_70(Type type_0)
	{
		return new ComponentResourceManager(type_0);
	}

	// Token: 0x060008A0 RID: 2208 RVA: 0x00002A5A File Offset: 0x00000C5A
	static PictureBox smethod_71()
	{
		return new PictureBox();
	}

	// Token: 0x060008A1 RID: 2209 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_72()
	{
		return new Label();
	}

	// Token: 0x060008A2 RID: 2210 RVA: 0x00002A77 File Offset: 0x00000C77
	static Panel smethod_73()
	{
		return new Panel();
	}

	// Token: 0x060008A3 RID: 2211 RVA: 0x0000530D File Offset: 0x0000350D
	static NumericUpDown smethod_74()
	{
		return new NumericUpDown();
	}

	// Token: 0x060008A4 RID: 2212 RVA: 0x00002A69 File Offset: 0x00000C69
	static Button smethod_75()
	{
		return new Button();
	}

	// Token: 0x060008A5 RID: 2213 RVA: 0x00002A61 File Offset: 0x00000C61
	static ToolTip smethod_76(IContainer icontainer_1)
	{
		return new ToolTip(icontainer_1);
	}

	// Token: 0x060008A6 RID: 2214 RVA: 0x00002A85 File Offset: 0x00000C85
	static void smethod_77(ISupportInitialize isupportInitialize_0)
	{
		isupportInitialize_0.BeginInit();
	}

	// Token: 0x060008A7 RID: 2215 RVA: 0x00002A8D File Offset: 0x00000C8D
	static void smethod_78(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060008A8 RID: 2216 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_79(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x00005314 File Offset: 0x00003514
	static object smethod_80(ResourceManager resourceManager_0, string string_9)
	{
		return resourceManager_0.GetObject(string_9);
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x00002AF5 File Offset: 0x00000CF5
	static void smethod_81(Control control_0, bool bool_2)
	{
		control_0.Capture = bool_2;
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x00002AFE File Offset: 0x00000CFE
	static void smethod_82(Control control_0, bool bool_2)
	{
		control_0.Capture = bool_2;
	}

	// Token: 0x060008AC RID: 2220 RVA: 0x00002B07 File Offset: 0x00000D07
	IntPtr method_20()
	{
		return base.Handle;
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x0000393D File Offset: 0x00001B3D
	static string smethod_83()
	{
		return Environment.SystemDirectory;
	}

	// Token: 0x060008AE RID: 2222 RVA: 0x00003944 File Offset: 0x00001B44
	static string smethod_84(string string_9)
	{
		return Path.GetPathRoot(string_9);
	}

	// Token: 0x060008AF RID: 2223 RVA: 0x0000531D File Offset: 0x0000351D
	static ManagementScope smethod_85(string string_9)
	{
		return new ManagementScope(string_9);
	}

	// Token: 0x060008B0 RID: 2224 RVA: 0x00005325 File Offset: 0x00003525
	static ManagementPath smethod_86(string string_9)
	{
		return new ManagementPath(string_9);
	}

	// Token: 0x060008B1 RID: 2225 RVA: 0x0000532D File Offset: 0x0000352D
	static ObjectGetOptions smethod_87()
	{
		return new ObjectGetOptions();
	}

	// Token: 0x060008B2 RID: 2226 RVA: 0x00005334 File Offset: 0x00003534
	static ManagementClass smethod_88(ManagementScope managementScope_0, ManagementPath managementPath_0, ObjectGetOptions objectGetOptions_0)
	{
		return new ManagementClass(managementScope_0, managementPath_0, objectGetOptions_0);
	}

	// Token: 0x060008B3 RID: 2227 RVA: 0x0000533E File Offset: 0x0000353E
	static ManagementBaseObject smethod_89(ManagementObject managementObject_0, string string_9)
	{
		return managementObject_0.GetMethodParameters(string_9);
	}

	// Token: 0x060008B4 RID: 2228 RVA: 0x00005347 File Offset: 0x00003547
	static void smethod_90(ManagementBaseObject managementBaseObject_0, string string_9, object object_0)
	{
		managementBaseObject_0[string_9] = object_0;
	}

	// Token: 0x060008B5 RID: 2229 RVA: 0x00005351 File Offset: 0x00003551
	static ManagementBaseObject smethod_91(ManagementObject managementObject_0, string string_9, ManagementBaseObject managementBaseObject_0, InvokeMethodOptions invokeMethodOptions_0)
	{
		return managementObject_0.InvokeMethod(string_9, managementBaseObject_0, invokeMethodOptions_0);
	}

	// Token: 0x060008B6 RID: 2230 RVA: 0x000033C8 File Offset: 0x000015C8
	static string smethod_92(string string_9, object object_0)
	{
		return string.Format(string_9, object_0);
	}

	// Token: 0x060008B7 RID: 2231 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_93(RegistryKey registryKey_3, string string_9)
	{
		return registryKey_3.GetValue(string_9);
	}

	// Token: 0x060008B8 RID: 2232 RVA: 0x00002917 File Offset: 0x00000B17
	static bool smethod_94(string string_9, string string_10)
	{
		return string_9 != string_10;
	}

	// Token: 0x060008B9 RID: 2233 RVA: 0x00003100 File Offset: 0x00001300
	static ProcessStartInfo smethod_95()
	{
		return new ProcessStartInfo();
	}

	// Token: 0x060008BA RID: 2234 RVA: 0x00003107 File Offset: 0x00001307
	static void smethod_96(ProcessStartInfo processStartInfo_0, string string_9)
	{
		processStartInfo_0.FileName = string_9;
	}

	// Token: 0x060008BB RID: 2235 RVA: 0x00003110 File Offset: 0x00001310
	static void smethod_97(ProcessStartInfo processStartInfo_0, string string_9)
	{
		processStartInfo_0.Arguments = string_9;
	}

	// Token: 0x060008BC RID: 2236 RVA: 0x00003119 File Offset: 0x00001319
	static void smethod_98(ProcessStartInfo processStartInfo_0, ProcessWindowStyle processWindowStyle_0)
	{
		processStartInfo_0.WindowStyle = processWindowStyle_0;
	}

	// Token: 0x060008BD RID: 2237 RVA: 0x00003122 File Offset: 0x00001322
	static Process smethod_99(ProcessStartInfo processStartInfo_0)
	{
		return Process.Start(processStartInfo_0);
	}

	// Token: 0x060008BE RID: 2238 RVA: 0x00003D5D File Offset: 0x00001F5D
	static void smethod_100(Process process_0)
	{
		process_0.WaitForExit();
	}

	// Token: 0x060008BF RID: 2239 RVA: 0x00002A32 File Offset: 0x00000C32
	static int smethod_101(string string_9, string string_10)
	{
		return string_9.IndexOf(string_10);
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x00002C7A File Offset: 0x00000E7A
	static string smethod_102(string string_9, int int_3)
	{
		return string_9.Substring(int_3);
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x0000535C File Offset: 0x0000355C
	static string smethod_103(string string_9)
	{
		return string_9.Trim();
	}

	// Token: 0x040002F6 RID: 758
	private static readonly RegistryKey registryKey_0 = GClass2.GClass2_0.RegistryKey_0;

	// Token: 0x040002F7 RID: 759
	private static readonly string[] string_0 = new string[]
	{
		"Auto Update",
		"Antispy Rules Auto Update",
		"Recycle Item",
		"VirusTotal Item",
		"Clean",
		"Kill",
		"Widget",
		"Tray",
		"Broken Shortcuts"
	};

	// Token: 0x040002F8 RID: 760
	private static bool bool_1 = false;

	// Token: 0x040002F9 RID: 761
	private readonly Form1 form1_0;

	// Token: 0x040002FA RID: 762
	private readonly int int_0;

	// Token: 0x040002FB RID: 763
	private readonly int int_1;

	// Token: 0x040002FC RID: 764
	private readonly int int_2;

	// Token: 0x040002FD RID: 765
	public static string string_1 = "<DisallowStartIfOnBatteries>true</DisallowStartIfOnBatteries>";

	// Token: 0x040002FE RID: 766
	public static string string_2 = "<DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>";

	// Token: 0x040002FF RID: 767
	public static string string_3 = "<StopIfGoingOnBatteries>true</StopIfGoingOnBatteries>";

	// Token: 0x04000300 RID: 768
	public static string string_4 = "<StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>";

	// Token: 0x04000301 RID: 769
	public static string string_5 = "<ExecutionTimeLimit>PT72H</ExecutionTimeLimit>";

	// Token: 0x04000302 RID: 770
	public static string string_6 = "<ExecutionTimeLimit>PT0S</ExecutionTimeLimit>";

	// Token: 0x04000303 RID: 771
	private readonly RegistryKey registryKey_1 = Registry.ClassesRoot;

	// Token: 0x04000304 RID: 772
	private readonly RegistryKey registryKey_2 = Registry.CurrentUser;

	// Token: 0x04000305 RID: 773
	private readonly string string_7 = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts";

	// Token: 0x04000306 RID: 774
	private readonly string string_8 = Environment.CurrentDirectory + "\\" + GClass2.GClass2_0.method_1("MenuLabel5") + ".exts";

	// Token: 0x04000307 RID: 775
	private List<ExtensionGroup> list_0 = new List<ExtensionGroup>();

	// Token: 0x020000A1 RID: 161
	[CompilerGenerated]
	private sealed class Class62
	{
		// Token: 0x060008C8 RID: 2248 RVA: 0x00005372 File Offset: 0x00003572
		internal void method_0(object sender, EventArgs e)
		{
			if (!Application.OpenForms.OfType<Dim>().Any<Dim>())
			{
				this.pictureBox_0.BackgroundImage = Class89.Bitmap_36;
			}
			this.pictureBox_0.BackgroundImageLayout = ImageLayout.Stretch;
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x000029CD File Offset: 0x00000BCD
		static FormCollection smethod_0()
		{
			return Application.OpenForms;
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x00002B2F File Offset: 0x00000D2F
		static void smethod_1(Control control_0, Image image_0)
		{
			control_0.BackgroundImage = image_0;
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x00002E61 File Offset: 0x00001061
		static void smethod_2(Control control_0, ImageLayout imageLayout_0)
		{
			control_0.BackgroundImageLayout = imageLayout_0;
		}

		// Token: 0x04000349 RID: 841
		public PictureBox pictureBox_0;
	}

	// Token: 0x020000A2 RID: 162
	[CompilerGenerated]
	private sealed class Class63
	{
		// Token: 0x060008CD RID: 2253 RVA: 0x000053A1 File Offset: 0x000035A1
		internal void method_0(object sender, EventArgs e)
		{
			if (!Application.OpenForms.OfType<Dim>().Any<Dim>())
			{
				this.pictureBox_0.BackgroundImage = null;
			}
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x000029CD File Offset: 0x00000BCD
		static FormCollection smethod_0()
		{
			return Application.OpenForms;
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x00002B2F File Offset: 0x00000D2F
		static void smethod_1(Control control_0, Image image_0)
		{
			control_0.BackgroundImage = image_0;
		}

		// Token: 0x0400034A RID: 842
		public PictureBox pictureBox_0;
	}

	// Token: 0x020000AE RID: 174
	[CompilerGenerated]
	private sealed class Class64
	{
		// Token: 0x06000928 RID: 2344 RVA: 0x000293A8 File Offset: 0x000275A8
		internal void method_0(string string_2)
		{
			Settings_1.Class65 @class = new Settings_1.Class65();
			@class.class64_0 = this;
			@class.string_0 = string_2;
			if (@class.string_0 == "OpenWithList" && this.settings_1_0.registryKey_2.OpenSubKey(this.settings_1_0.string_7 + "\\" + this.string_0 + "\\UserChoice") == null && this.settings_1_0.registryKey_2.OpenSubKey(string.Concat(new string[]
			{
				this.settings_1_0.string_7,
				"\\",
				this.string_0,
				"\\",
				@class.string_0
			})).GetValueNames().ToList<string>().Any(new Func<string, bool>(@class.method_0)))
			{
				RegistryKey registryKey = this.settings_1_0.registryKey_1.OpenSubKey(this.string_1 + "\\shell\\open\\command");
				if (registryKey != null)
				{
					if (registryKey.GetValue("") != null)
					{
						List<ExtensionGroup> list_ = this.settings_1_0.list_0;
						ExtensionGroup extensionGroup = new ExtensionGroup();
						extensionGroup.Extension = this.string_0;
						extensionGroup.ExtensionClass = this.string_1;
						RegistryKey registryKey2 = this.settings_1_0.registryKey_1.OpenSubKey(this.string_1 + "\\DefaultIcon");
						string extensionIcon;
						if (registryKey2 != null)
						{
							object value = registryKey2.GetValue("");
							if (value != null)
							{
								if ((extensionIcon = value.ToString()) != null)
								{
									goto IL_170;
								}
							}
						}
						extensionIcon = "";
						IL_170:
						extensionGroup.ExtensionIcon = extensionIcon;
						RegistryKey registryKey3 = this.settings_1_0.registryKey_1.OpenSubKey(this.string_1 + "\\shell\\open\\command");
						string executablePath;
						if (registryKey3 == null)
						{
							executablePath = null;
						}
						else
						{
							object value2 = registryKey3.GetValue("");
							executablePath = ((value2 != null) ? value2.ToString() : null);
						}
						extensionGroup.ExecutablePath = executablePath;
						list_.Add(extensionGroup);
					}
				}
			}
			if (@class.string_0 == "UserChoice")
			{
				object value3 = this.settings_1_0.registryKey_2.OpenSubKey(string.Concat(new string[]
				{
					this.settings_1_0.string_7,
					"\\",
					this.string_0,
					"\\",
					@class.string_0
				})).GetValue("ProgId");
				string text;
				if (value3 != null)
				{
					if ((text = value3.ToString()) != null)
					{
						goto IL_23C;
					}
				}
				text = "";
				IL_23C:
				string text2 = text;
				if (text2.StartsWith("Applications\\") && text2.EndsWith(".exe"))
				{
					string text3 = text2.Replace("Applications\\", "").Replace(".exe", this.string_0);
					string extensionClass = char.ToUpper(text3[0]).ToString() + text3.Substring(1);
					List<ExtensionGroup> list_2 = this.settings_1_0.list_0;
					ExtensionGroup extensionGroup2 = new ExtensionGroup();
					extensionGroup2.Extension = this.string_0;
					extensionGroup2.ExtensionClass = extensionClass;
					RegistryKey registryKey4 = this.settings_1_0.registryKey_1.OpenSubKey(text2 + "\\DefaultIcon");
					string extensionIcon2;
					if (registryKey4 != null)
					{
						object value4 = registryKey4.GetValue("");
						if (value4 != null)
						{
							if ((extensionIcon2 = value4.ToString()) != null)
							{
								goto IL_306;
							}
						}
					}
					extensionIcon2 = "";
					IL_306:
					extensionGroup2.ExtensionIcon = extensionIcon2;
					RegistryKey registryKey5 = this.settings_1_0.registryKey_1.OpenSubKey(text2 + "\\shell\\open\\command");
					string executablePath2;
					if (registryKey5 == null)
					{
						executablePath2 = null;
					}
					else
					{
						object value5 = registryKey5.GetValue("");
						executablePath2 = ((value5 != null) ? value5.ToString() : null);
					}
					extensionGroup2.ExecutablePath = executablePath2;
					list_2.Add(extensionGroup2);
					return;
				}
				RegistryKey registryKey6 = this.settings_1_0.registryKey_1.OpenSubKey(text2 + "\\shell\\open\\command");
				if (registryKey6 != null)
				{
					if (registryKey6.GetValue("") != null)
					{
						List<ExtensionGroup> list_3 = this.settings_1_0.list_0;
						ExtensionGroup extensionGroup3 = new ExtensionGroup();
						extensionGroup3.Extension = this.string_0;
						extensionGroup3.ExtensionClass = text2;
						RegistryKey registryKey7 = this.settings_1_0.registryKey_1.OpenSubKey(text2 + "\\DefaultIcon");
						string extensionIcon3;
						if (registryKey7 != null)
						{
							object value6 = registryKey7.GetValue("");
							if (value6 != null)
							{
								if ((extensionIcon3 = value6.ToString()) != null)
								{
									goto IL_3E7;
								}
							}
						}
						extensionIcon3 = "";
						IL_3E7:
						extensionGroup3.ExtensionIcon = extensionIcon3;
						RegistryKey registryKey8 = this.settings_1_0.registryKey_1.OpenSubKey(text2 + "\\shell\\open\\command");
						string executablePath3;
						if (registryKey8 == null)
						{
							executablePath3 = null;
						}
						else
						{
							object value7 = registryKey8.GetValue("");
							executablePath3 = ((value7 != null) ? value7.ToString() : null);
						}
						extensionGroup3.ExecutablePath = executablePath3;
						list_3.Add(extensionGroup3);
						return;
					}
				}
				RegistryKey registryKey9 = this.settings_1_0.registryKey_1.OpenSubKey(this.string_1 + "\\shell\\open\\command");
				if (registryKey9 != null)
				{
					if (registryKey9.GetValue("") != null)
					{
						List<ExtensionGroup> list_4 = this.settings_1_0.list_0;
						ExtensionGroup extensionGroup4 = new ExtensionGroup();
						extensionGroup4.Extension = this.string_0;
						extensionGroup4.ExtensionClass = this.string_1;
						RegistryKey registryKey10 = this.settings_1_0.registryKey_1.OpenSubKey(this.string_1 + "\\DefaultIcon");
						string extensionIcon4;
						if (registryKey10 != null)
						{
							object value8 = registryKey10.GetValue("");
							if (value8 != null)
							{
								if ((extensionIcon4 = value8.ToString()) != null)
								{
									goto IL_4D7;
								}
							}
						}
						extensionIcon4 = "";
						IL_4D7:
						extensionGroup4.ExtensionIcon = extensionIcon4;
						RegistryKey registryKey11 = this.settings_1_0.registryKey_1.OpenSubKey(this.string_1 + "\\shell\\open\\command");
						string executablePath4;
						if (registryKey11 == null)
						{
							executablePath4 = null;
						}
						else
						{
							object value9 = registryKey11.GetValue("");
							executablePath4 = ((value9 != null) ? value9.ToString() : null);
						}
						extensionGroup4.ExecutablePath = executablePath4;
						list_4.Add(extensionGroup4);
					}
				}
			}
		}

		// Token: 0x06000929 RID: 2345 RVA: 0x00002B59 File Offset: 0x00000D59
		static bool smethod_0(string string_2, string string_3)
		{
			return string_2 == string_3;
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x000033BD File Offset: 0x000015BD
		static string smethod_1(string string_2, string string_3, string string_4, string string_5)
		{
			return string_2 + string_3 + string_4 + string_5;
		}

		// Token: 0x0600092B RID: 2347 RVA: 0x0000307B File Offset: 0x0000127B
		static RegistryKey smethod_2(RegistryKey registryKey_0, string string_2)
		{
			return registryKey_0.OpenSubKey(string_2);
		}

		// Token: 0x0600092C RID: 2348 RVA: 0x0000298C File Offset: 0x00000B8C
		static string smethod_3(string[] string_2)
		{
			return string.Concat(string_2);
		}

		// Token: 0x0600092D RID: 2349 RVA: 0x00003019 File Offset: 0x00001219
		static string[] smethod_4(RegistryKey registryKey_0)
		{
			return registryKey_0.GetValueNames();
		}

		// Token: 0x0600092E RID: 2350 RVA: 0x000025E0 File Offset: 0x000007E0
		static string smethod_5(string string_2, string string_3)
		{
			return string_2 + string_3;
		}

		// Token: 0x0600092F RID: 2351 RVA: 0x00002EDC File Offset: 0x000010DC
		static object smethod_6(RegistryKey registryKey_0, string string_2)
		{
			return registryKey_0.GetValue(string_2);
		}

		// Token: 0x06000930 RID: 2352 RVA: 0x000029E6 File Offset: 0x00000BE6
		static string smethod_7(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000931 RID: 2353 RVA: 0x000029DD File Offset: 0x00000BDD
		static object smethod_8(RegistryKey registryKey_0, string string_2)
		{
			return registryKey_0.GetValue(string_2);
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x000036C8 File Offset: 0x000018C8
		static bool smethod_9(string string_2, string string_3)
		{
			return string_2.StartsWith(string_3);
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x00002A29 File Offset: 0x00000C29
		static bool smethod_10(string string_2, string string_3)
		{
			return string_2.EndsWith(string_3);
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x000033D1 File Offset: 0x000015D1
		static string smethod_11(string string_2, string string_3, string string_4)
		{
			return string_2.Replace(string_3, string_4);
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x0000265B File Offset: 0x0000085B
		static char smethod_12(string string_2, int int_0)
		{
			return string_2[int_0];
		}

		// Token: 0x04000388 RID: 904
		public string string_0;

		// Token: 0x04000389 RID: 905
		public string string_1;

		// Token: 0x0400038A RID: 906
		public Settings_1 settings_1_0;
	}

	// Token: 0x020000AF RID: 175
	[CompilerGenerated]
	private sealed class Class65
	{
		// Token: 0x06000937 RID: 2359 RVA: 0x000298DC File Offset: 0x00027ADC
		internal bool method_0(string string_1)
		{
			return this.class64_0.settings_1_0.registryKey_2.OpenSubKey(string.Concat(new string[]
			{
				this.class64_0.settings_1_0.string_7,
				"\\",
				this.class64_0.string_0,
				"\\",
				this.string_0
			})).GetValue(string_1).ToString().Contains(".exe");
		}

		// Token: 0x06000938 RID: 2360 RVA: 0x0000298C File Offset: 0x00000B8C
		static string smethod_0(string[] string_1)
		{
			return string.Concat(string_1);
		}

		// Token: 0x06000939 RID: 2361 RVA: 0x0000307B File Offset: 0x0000127B
		static RegistryKey smethod_1(RegistryKey registryKey_0, string string_1)
		{
			return registryKey_0.OpenSubKey(string_1);
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x000029DD File Offset: 0x00000BDD
		static object smethod_2(RegistryKey registryKey_0, string string_1)
		{
			return registryKey_0.GetValue(string_1);
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x000029E6 File Offset: 0x00000BE6
		static string smethod_3(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x00002A20 File Offset: 0x00000C20
		static bool smethod_4(string string_1, string string_2)
		{
			return string_1.Contains(string_2);
		}

		// Token: 0x0400038B RID: 907
		public string string_0;

		// Token: 0x0400038C RID: 908
		public Settings_1.Class64 class64_0;
	}

	// Token: 0x020000B3 RID: 179
	[CompilerGenerated]
	private sealed class Class66
	{
		// Token: 0x06000961 RID: 2401 RVA: 0x00005555 File Offset: 0x00003755
		internal bool method_0(string string_1)
		{
			return File.Exists(this.string_0 + "\\" + string_1);
		}

		// Token: 0x06000962 RID: 2402 RVA: 0x0000556D File Offset: 0x0000376D
		internal void method_1(string string_1)
		{
			File.Delete(this.string_0 + "\\" + string_1);
		}

		// Token: 0x06000963 RID: 2403 RVA: 0x00003033 File Offset: 0x00001233
		static string smethod_0(string string_1, string string_2, string string_3)
		{
			return string_1 + string_2 + string_3;
		}

		// Token: 0x06000964 RID: 2404 RVA: 0x00002F0D File Offset: 0x0000110D
		static bool smethod_1(string string_1)
		{
			return File.Exists(string_1);
		}

		// Token: 0x06000965 RID: 2405 RVA: 0x00002F15 File Offset: 0x00001115
		static void smethod_2(string string_1)
		{
			File.Delete(string_1);
		}

		// Token: 0x040003A4 RID: 932
		public string string_0;
	}

	// Token: 0x020000B4 RID: 180
	[CompilerGenerated]
	private sealed class Class67
	{
		// Token: 0x06000967 RID: 2407 RVA: 0x0002A098 File Offset: 0x00028298
		internal void method_0()
		{
			Directory.CreateDirectory(this.folderBrowserDialog_0.SelectedPath + "\\Drivers");
			Form0.smethod_325();
			List<string> list = Directory.GetFiles(GClass13.string_6 + "\\INF", "oem*.inf").ToList<string>();
			Action<string> action;
			if ((action = this.action_2) == null)
			{
				action = (this.action_2 = new Action<string>(this.method_1));
			}
			list.ForEach(action);
			string path = this.folderBrowserDialog_0.SelectedPath + "\\Drivers\\" + GClass2.GClass2_0.method_1("InstalledPrograms") + ".htm";
			File.Delete(path);
			string str = GClass2.GClass2_0.method_1("InstalledPrograms");
			string text = GClass2.GClass2_0.method_1("GeneratedBy") + " " + GClass2.GClass2_0.String_6;
			using (FileStream fileStream = new FileStream(path, FileMode.OpenOrCreate))
			{
				using (StreamWriter streamWriter = new StreamWriter(fileStream))
				{
					fileStream.Seek(0L, SeekOrigin.End);
					streamWriter.WriteLine("<html><head><meta charset=\"utf-8\"><title>" + str + "</title><style>");
					streamWriter.WriteLine("body { font-family: Arial, sans-serif; background-color: #dbe0e212; } .header { text-align: center; color: #175d8e; font-size: 27; text-shadow: 1px 1px 0px #ffffff, -1px -1px 0px #ffffff, 2px 2px 1px #175d8e61 }");
					streamWriter.WriteLine(".box { padding: 20px; border-radius: 5px; box-shadow: 0 0 23px #d8d8d8; line-height: 1.4; background-color: white; } .programs, a { font-size: 18; text-decoration: none; color: #175d8e;  } .copyright { text-align: center; color: #175d8e; font-size: 12; } a:hover { background: #175d8e -webkit-linear-gradient(right, #175d8e 0%, #70b2e0 50%, #175d8e 100%);");
					streamWriter.WriteLine("background-repeat: no-repeat; -webkit-background-clip: text; -webkit-text-fill-color: transparent; -webkit-animation-name: shimmer; -webkit-animation-duration: 2.2s; -webkit-animation-iteration-count: infinite; -webkit-background-size: 8rem 100%; /*50px*/ }");
					streamWriter.WriteLine("@-webkit-keyframes shimmer { 0% { background-position: -5rem top; /*50px*/ } 100% { background-position: 100rem top; /*200px*/ } }");
					streamWriter.WriteLine("</style></head><body><table style=\"text-align: left; width: 800px; margin-left: auto; margin-right: auto;\" border=\"0\" cellpadding=\"2\" cellspacing=\"2\"><br><tbody><tr><td style=\"vertical-align: top;\"><div class=\"header\">" + str + "</div><br><div class=\"box\"><div class=\"programs\">");
					foreach (string text2 in Settings_1.smethod_3())
					{
						streamWriter.WriteLine(string.Concat(new string[]
						{
							"<a href=\"https://www.google.com/search?q=",
							text2,
							"\" target=\"_blank\"><span>",
							text2,
							"</span></a><br>"
						}));
					}
					streamWriter.WriteLine(string.Concat(new string[]
					{
						"</div></div></td></tr></tbody></table><br><div class=\"copyright\">",
						text,
						"<br>",
						DateTime.Today.ToShortDateString(),
						"<br></div><br><br><br></body></html>"
					}));
					this.settings_1_0.MenuItem7.Image = Class89.Bitmap_7;
					Form1.CloseDim();
					this.settings_1_0.MenuItem7.BackgroundImage = null;
					Settings_1.bool_1 = false;
					this.settings_1_0.TopMost = false;
					WMessageBox.smethod_3(GClass2.GClass2_0.method_1("DriversExported") + "\n" + this.folderBrowserDialog_0.SelectedPath + "\\Drivers", "", WMessageBox.GEnum2.OK, false, "", null);
					this.settings_1_0.TopMost = true;
				}
			}
		}

		// Token: 0x06000968 RID: 2408 RVA: 0x0002A350 File Offset: 0x00028550
		internal void method_1(string string_1)
		{
			List<string> list = File.ReadAllLines(string_1).Where(new Func<string, bool>(Settings_1.<>c.<>9.method_4)).Select(new Func<string, string>(Settings_1.<>c.<>9.method_5)).Select(new Func<string, string>(Settings_1.<>c.<>9.method_6)).Where(new Func<string, bool>(Settings_1.<>c.<>9.method_7)).ToList<string>();
			Action<string> action;
			if ((action = this.action_1) == null)
			{
				action = (this.action_1 = new Action<string>(this.method_2));
			}
			list.ForEach(action);
		}

		// Token: 0x06000969 RID: 2409 RVA: 0x0002A41C File Offset: 0x0002861C
		internal void method_2(string string_1)
		{
			Settings_1.Class68 @class = new Settings_1.Class68();
			@class.string_0 = string_1;
			List<string> list = Directory.GetDirectories(this.string_0).Where(new Func<string, bool>(@class.method_0)).ToList<string>();
			Action<string> action;
			if ((action = this.action_0) == null)
			{
				action = (this.action_0 = new Action<string>(this.method_3));
			}
			list.ForEach(action);
		}

		// Token: 0x0600096A RID: 2410 RVA: 0x0002A47C File Offset: 0x0002867C
		internal void method_3(string string_1)
		{
			string text = this.folderBrowserDialog_0.SelectedPath + "\\Drivers\\" + new DirectoryInfo(string_1).Name;
			if (!Directory.Exists(text))
			{
				FileSystem.CopyDirectory(string_1, text);
			}
		}

		// Token: 0x0600096B RID: 2411 RVA: 0x000052E4 File Offset: 0x000034E4
		static string smethod_0(FolderBrowserDialog folderBrowserDialog_1)
		{
			return folderBrowserDialog_1.SelectedPath;
		}

		// Token: 0x0600096C RID: 2412 RVA: 0x000025E0 File Offset: 0x000007E0
		static string smethod_1(string string_1, string string_2)
		{
			return string_1 + string_2;
		}

		// Token: 0x0600096D RID: 2413 RVA: 0x0000429E File Offset: 0x0000249E
		static DirectoryInfo smethod_2(string string_1)
		{
			return Directory.CreateDirectory(string_1);
		}

		// Token: 0x0600096E RID: 2414 RVA: 0x000031B0 File Offset: 0x000013B0
		static string[] smethod_3(string string_1, string string_2)
		{
			return Directory.GetFiles(string_1, string_2);
		}

		// Token: 0x0600096F RID: 2415 RVA: 0x000033BD File Offset: 0x000015BD
		static string smethod_4(string string_1, string string_2, string string_3, string string_4)
		{
			return string_1 + string_2 + string_3 + string_4;
		}

		// Token: 0x06000970 RID: 2416 RVA: 0x00002F15 File Offset: 0x00001115
		static void smethod_5(string string_1)
		{
			File.Delete(string_1);
		}

		// Token: 0x06000971 RID: 2417 RVA: 0x00003033 File Offset: 0x00001233
		static string smethod_6(string string_1, string string_2, string string_3)
		{
			return string_1 + string_2 + string_3;
		}

		// Token: 0x06000972 RID: 2418 RVA: 0x00003D09 File Offset: 0x00001F09
		static FileStream smethod_7(string string_1, FileMode fileMode_0)
		{
			return new FileStream(string_1, fileMode_0);
		}

		// Token: 0x06000973 RID: 2419 RVA: 0x00003D12 File Offset: 0x00001F12
		static StreamWriter smethod_8(Stream stream_0)
		{
			return new StreamWriter(stream_0);
		}

		// Token: 0x06000974 RID: 2420 RVA: 0x00005585 File Offset: 0x00003785
		static long smethod_9(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06000975 RID: 2421 RVA: 0x00003D1A File Offset: 0x00001F1A
		static void smethod_10(TextWriter textWriter_0, string string_1)
		{
			textWriter_0.WriteLine(string_1);
		}

		// Token: 0x06000976 RID: 2422 RVA: 0x0000298C File Offset: 0x00000B8C
		static string smethod_11(string[] string_1)
		{
			return string.Concat(string_1);
		}

		// Token: 0x06000977 RID: 2423 RVA: 0x000033DB File Offset: 0x000015DB
		static string[] smethod_12(string string_1)
		{
			return File.ReadAllLines(string_1);
		}

		// Token: 0x06000978 RID: 2424 RVA: 0x000033B5 File Offset: 0x000015B5
		static string[] smethod_13(string string_1)
		{
			return Directory.GetDirectories(string_1);
		}

		// Token: 0x06000979 RID: 2425 RVA: 0x0000558F File Offset: 0x0000378F
		static DirectoryInfo smethod_14(string string_1)
		{
			return new DirectoryInfo(string_1);
		}

		// Token: 0x0600097A RID: 2426 RVA: 0x00005597 File Offset: 0x00003797
		static string smethod_15(FileSystemInfo fileSystemInfo_0)
		{
			return fileSystemInfo_0.Name;
		}

		// Token: 0x0600097B RID: 2427 RVA: 0x00002EE5 File Offset: 0x000010E5
		static bool smethod_16(string string_1)
		{
			return Directory.Exists(string_1);
		}

		// Token: 0x0600097C RID: 2428 RVA: 0x0000559F File Offset: 0x0000379F
		static void smethod_17(string string_1, string string_2)
		{
			FileSystem.CopyDirectory(string_1, string_2);
		}

		// Token: 0x040003A5 RID: 933
		public Settings_1 settings_1_0;

		// Token: 0x040003A6 RID: 934
		public FolderBrowserDialog folderBrowserDialog_0;

		// Token: 0x040003A7 RID: 935
		public string string_0;

		// Token: 0x040003A8 RID: 936
		public Action<string> action_0;

		// Token: 0x040003A9 RID: 937
		public Action<string> action_1;

		// Token: 0x040003AA RID: 938
		public Action<string> action_2;
	}

	// Token: 0x020000B5 RID: 181
	[CompilerGenerated]
	private sealed class Class68
	{
		// Token: 0x0600097E RID: 2430 RVA: 0x0002A4BC File Offset: 0x000286BC
		internal bool method_0(string string_1)
		{
			IEnumerable<string> files = Directory.GetFiles(string_1);
			Func<string, bool> predicate;
			if ((predicate = this.func_0) == null)
			{
				predicate = (this.func_0 = new Func<string, bool>(this.method_1));
			}
			return files.Any(predicate);
		}

		// Token: 0x0600097F RID: 2431 RVA: 0x000055A8 File Offset: 0x000037A8
		internal bool method_1(string string_1)
		{
			return new FileInfo(string_1).Name.ToLower() == this.string_0;
		}

		// Token: 0x06000980 RID: 2432 RVA: 0x000055C5 File Offset: 0x000037C5
		static string[] smethod_0(string string_1)
		{
			return Directory.GetFiles(string_1);
		}

		// Token: 0x06000981 RID: 2433 RVA: 0x0000316F File Offset: 0x0000136F
		static FileInfo smethod_1(string string_1)
		{
			return new FileInfo(string_1);
		}

		// Token: 0x06000982 RID: 2434 RVA: 0x00005597 File Offset: 0x00003797
		static string smethod_2(FileSystemInfo fileSystemInfo_0)
		{
			return fileSystemInfo_0.Name;
		}

		// Token: 0x06000983 RID: 2435 RVA: 0x000036AF File Offset: 0x000018AF
		static string smethod_3(string string_1)
		{
			return string_1.ToLower();
		}

		// Token: 0x06000984 RID: 2436 RVA: 0x00002B59 File Offset: 0x00000D59
		static bool smethod_4(string string_1, string string_2)
		{
			return string_1 == string_2;
		}

		// Token: 0x040003AB RID: 939
		public string string_0;

		// Token: 0x040003AC RID: 940
		public Func<string, bool> func_0;
	}

	// Token: 0x020000B7 RID: 183
	[CompilerGenerated]
	private sealed class Class69
	{
		// Token: 0x0600098C RID: 2444 RVA: 0x0002A760 File Offset: 0x00028960
		internal void method_0()
		{
			Thread.Sleep(500);
			foreach (string str in Directory.GetFiles(this.folderBrowserDialog_0.SelectedPath, "*.inf", System.IO.SearchOption.AllDirectories))
			{
				GClass6.GClass6_0.method_15("pnputil -i -a \"" + str + "\"");
			}
			Form1.CloseDim();
			this.settings_1_0.MenuItem8.Image = Class89.Bitmap_8;
			Settings_1.bool_1 = false;
			WMessageBox.smethod_3(GClass2.GClass2_0.method_1("DriversInstalled"), "", WMessageBox.GEnum2.OK, false, "", null);
			this.settings_1_0.TopMost = true;
		}

		// Token: 0x0600098D RID: 2445 RVA: 0x00002625 File Offset: 0x00000825
		static void smethod_0(int int_0)
		{
			Thread.Sleep(int_0);
		}

		// Token: 0x0600098E RID: 2446 RVA: 0x000052E4 File Offset: 0x000034E4
		static string smethod_1(FolderBrowserDialog folderBrowserDialog_1)
		{
			return folderBrowserDialog_1.SelectedPath;
		}

		// Token: 0x0600098F RID: 2447 RVA: 0x000031B9 File Offset: 0x000013B9
		static string[] smethod_2(string string_0, string string_1, System.IO.SearchOption searchOption_0)
		{
			return Directory.GetFiles(string_0, string_1, searchOption_0);
		}

		// Token: 0x06000990 RID: 2448 RVA: 0x00003033 File Offset: 0x00001233
		static string smethod_3(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x06000991 RID: 2449 RVA: 0x00002E6A File Offset: 0x0000106A
		static void smethod_4(PictureBox pictureBox_0, Image image_0)
		{
			pictureBox_0.Image = image_0;
		}

		// Token: 0x06000992 RID: 2450 RVA: 0x00004E12 File Offset: 0x00003012
		static void smethod_5(Form form_0, bool bool_0)
		{
			form_0.TopMost = bool_0;
		}

		// Token: 0x040003B3 RID: 947
		public FolderBrowserDialog folderBrowserDialog_0;

		// Token: 0x040003B4 RID: 948
		public Settings_1 settings_1_0;
	}

	// Token: 0x020000BA RID: 186
	[CompilerGenerated]
	private sealed class Class70
	{
		// Token: 0x060009A3 RID: 2467 RVA: 0x0002AA1C File Offset: 0x00028C1C
		internal void method_0(object sender, PaintEventArgs e)
		{
			LinearGradientBrush linearGradientBrush = new LinearGradientBrush(this.settings_1_0.HeaderPanel.ClientRectangle, Color.Empty, Color.Empty, 90f);
			ColorBlend interpolationColors = new ColorBlend
			{
				Colors = new Color[]
				{
					this.color_0,
					this.color_0,
					this.color_1,
					this.color_2,
					this.color_2
				},
				Positions = new float[]
				{
					0f,
					0.82f,
					0.82f,
					1f,
					1f
				}
			};
			linearGradientBrush.InterpolationColors = interpolationColors;
			e.Graphics.FillRectangle(linearGradientBrush, this.settings_1_0.HeaderPanel.ClientRectangle);
		}

		// Token: 0x060009A4 RID: 2468 RVA: 0x00002BCC File Offset: 0x00000DCC
		static Rectangle smethod_0(Control control_0)
		{
			return control_0.ClientRectangle;
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x00002BD4 File Offset: 0x00000DD4
		static LinearGradientBrush smethod_1(Rectangle rectangle_0, Color color_3, Color color_4, float float_0)
		{
			return new LinearGradientBrush(rectangle_0, color_3, color_4, float_0);
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x000055F7 File Offset: 0x000037F7
		static ColorBlend smethod_2()
		{
			return new ColorBlend();
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x00002BE7 File Offset: 0x00000DE7
		static void smethod_3(ColorBlend colorBlend_0, Color[] color_3)
		{
			colorBlend_0.Colors = color_3;
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x00002BF0 File Offset: 0x00000DF0
		static void smethod_4(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x00002BF9 File Offset: 0x00000DF9
		static void smethod_5(ColorBlend colorBlend_0, float[] float_0)
		{
			colorBlend_0.Positions = float_0;
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x00002C02 File Offset: 0x00000E02
		static void smethod_6(LinearGradientBrush linearGradientBrush_0, ColorBlend colorBlend_0)
		{
			linearGradientBrush_0.InterpolationColors = colorBlend_0;
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x00002B88 File Offset: 0x00000D88
		static Graphics smethod_7(PaintEventArgs paintEventArgs_0)
		{
			return paintEventArgs_0.Graphics;
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x00002C0B File Offset: 0x00000E0B
		static void smethod_8(Graphics graphics_0, Brush brush_0, Rectangle rectangle_0)
		{
			graphics_0.FillRectangle(brush_0, rectangle_0);
		}

		// Token: 0x040003BD RID: 957
		public Settings_1 settings_1_0;

		// Token: 0x040003BE RID: 958
		public Color color_0;

		// Token: 0x040003BF RID: 959
		public Color color_1;

		// Token: 0x040003C0 RID: 960
		public Color color_2;
	}
}
