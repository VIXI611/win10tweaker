﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Microsoft.Win32;

// Token: 0x0200009D RID: 157
internal class Class61
{
	// Token: 0x17000068 RID: 104
	// (get) Token: 0x060007E7 RID: 2023 RVA: 0x00022128 File Offset: 0x00020328
	public static Class61 Class61_0
	{
		get
		{
			if (Class61.class61_0 == null)
			{
				object obj = Class61.object_0;
				lock (obj)
				{
					if (Class61.class61_0 == null)
					{
						Class61.class61_0 = new Class61();
					}
				}
			}
			return Class61.class61_0;
		}
	}

	// Token: 0x17000069 RID: 105
	// (get) Token: 0x060007E8 RID: 2024 RVA: 0x0000389A File Offset: 0x00001A9A
	public string String_0
	{
		get
		{
			return "SYSTEM\\CurrentControlSet\\Services";
		}
	}

	// Token: 0x1700006A RID: 106
	// (get) Token: 0x060007E9 RID: 2025 RVA: 0x00004EC7 File Offset: 0x000030C7
	public static string String_1
	{
		get
		{
			string result;
			if ((result = Class61.string_0) == null)
			{
				result = (Class61.string_0 = Class61.smethod_0());
			}
			return result;
		}
	}

	// Token: 0x060007EA RID: 2026 RVA: 0x00022188 File Offset: 0x00020388
	public static string smethod_0()
	{
		string text = Class61.list_0.FirstOrDefault(new Func<string, bool>(Class61.<>c.<>9.method_0));
		string text2;
		if (text == null)
		{
			text2 = null;
		}
		else
		{
			text2 = text.Substring(Class61.list_0.FirstOrDefault(new Func<string, bool>(Class61.<>c.<>9.method_1)).IndexOf("_") + 1);
		}
		string text3 = text2;
		if (text3 != null)
		{
			if (text3.Length == 5)
			{
				return text3;
			}
		}
		return "";
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x00004EDD File Offset: 0x000030DD
	public static bool smethod_1(string string_1)
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\" + string_1) != null;
	}

	// Token: 0x1700006B RID: 107
	// (get) Token: 0x060007EC RID: 2028 RVA: 0x00022218 File Offset: 0x00020418
	public Dictionary<string, List<string>> Dictionary_0
	{
		get
		{
			Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();
			dictionary["Serv1"] = this.List_0;
			dictionary["Serv2"] = this.List_1;
			dictionary["Serv3"] = this.List_2;
			dictionary["Serv4"] = this.List_3;
			dictionary["Serv5"] = this.List_4;
			dictionary["Serv6"] = this.List_5;
			dictionary["Serv7"] = this.List_6;
			dictionary["Serv8"] = this.List_7;
			dictionary["Serv9"] = this.List_8;
			dictionary["Serv10"] = this.List_9;
			dictionary["Serv11"] = this.List_10;
			dictionary["Serv12"] = this.List_11;
			dictionary["Serv13"] = this.List_12;
			dictionary["Serv14"] = this.List_13;
			dictionary["Serv15"] = this.List_14;
			dictionary["Serv16"] = this.List_15;
			dictionary["Serv17"] = this.List_16;
			dictionary["Serv18"] = this.List_17;
			dictionary["Serv19"] = this.List_18;
			dictionary["Serv20"] = this.List_19;
			dictionary["Serv21"] = this.List_20;
			dictionary["Serv22"] = this.List_21;
			dictionary["Serv23"] = this.List_22;
			dictionary["Serv24"] = this.List_23;
			dictionary["Serv25"] = this.List_24;
			dictionary["Serv26"] = this.List_25;
			dictionary["Serv27"] = this.List_26;
			dictionary["Serv28"] = this.List_27;
			dictionary["Serv29"] = this.List_28;
			dictionary["Serv30"] = this.List_29;
			dictionary["Serv31"] = this.List_30;
			dictionary["Serv32"] = this.List_31;
			return dictionary;
		}
	}

	// Token: 0x1700006C RID: 108
	// (get) Token: 0x060007ED RID: 2029 RVA: 0x0002244C File Offset: 0x0002064C
	public List<string> List_0
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"vmicvmsession",
				"vmictimesync",
				"vmicshutdown",
				"vmicrdv",
				"vmickvpexchange",
				"vmicheartbeat",
				"vmicguestinterface",
				"HvHost",
				"vmicvss"
			}).ToList<string>();
		}
	}

	// Token: 0x1700006D RID: 109
	// (get) Token: 0x060007EE RID: 2030 RVA: 0x000224D0 File Offset: 0x000206D0
	public List<string> List_1
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"BcastDVRUserService_" + Class61.String_1
			}).Union(new List<string>
			{
				Class61.smethod_1("BcastDVRUserService") ? "BcastDVRUserService" : ""
			}).Where(new Func<string, bool>(Class61.<>c.<>9.method_2)).ToList<string>();
		}
	}

	// Token: 0x1700006E RID: 110
	// (get) Token: 0x060007EF RID: 2031 RVA: 0x00004F01 File Offset: 0x00003101
	public List<string> List_2
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"NcaSvc",
				"SSDPSRV",
				"wcncsvc"
			}).ToList<string>();
		}
	}

	// Token: 0x1700006F RID: 111
	// (get) Token: 0x060007F0 RID: 2032 RVA: 0x00022554 File Offset: 0x00020754
	public List<string> List_3
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"PimIndexMaintenanceSvc_" + Class61.String_1,
				"UserDataSvc_" + Class61.String_1,
				"UnistoreSvc_" + Class61.String_1,
				"OneSyncSvc_" + Class61.String_1,
				"WalletService",
				"VacSvc",
				"spectrum",
				"SharedRealitySvc",
				"perceptionsimulation",
				"MixedRealityOpenXRSvc",
				"MapsBroker",
				"EntAppSvc",
				"embeddedmode",
				"wlidsvc",
				"WEPHOSTSVC",
				"StorSvc",
				"InstallService",
				"TokenBroker",
				"LicenseManager",
				"ClipSVC"
			}).Union(new List<string>
			{
				Class61.smethod_1("PimIndexMaintenanceSvc") ? "PimIndexMaintenanceSvc" : "",
				Class61.smethod_1("UserDataSvc") ? "UserDataSvc" : "",
				Class61.smethod_1("UnistoreSvc") ? "UnistoreSvc" : "",
				Class61.smethod_1("OneSyncSvc") ? "OneSyncSvc" : ""
			}).Where(new Func<string, bool>(Class61.<>c.<>9.method_3)).ToList<string>();
		}
	}

	// Token: 0x17000070 RID: 112
	// (get) Token: 0x060007F1 RID: 2033 RVA: 0x00022720 File Offset: 0x00020920
	public List<string> List_4
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"CredentialEnrollmentManagerUserSvc_" + Class61.String_1
			}).Union(new List<string>
			{
				Class61.smethod_1("CredentialEnrollmentManagerUserSvc") ? "CredentialEnrollmentManagerUserSvc" : ""
			}).Where(new Func<string, bool>(Class61.<>c.<>9.method_4)).ToList<string>();
		}
	}

	// Token: 0x17000071 RID: 113
	// (get) Token: 0x060007F2 RID: 2034 RVA: 0x00004F38 File Offset: 0x00003138
	public List<string> List_5
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"WbioSrvc"
			}).ToList<string>();
		}
	}

	// Token: 0x17000072 RID: 114
	// (get) Token: 0x060007F3 RID: 2035 RVA: 0x000227A4 File Offset: 0x000209A4
	public List<string> List_6
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"ConsentUxUserSvc_" + Class61.String_1,
				"BluetoothUserService_" + Class61.String_1,
				"bthserv",
				"BthAvctpSvc",
				"BTAGService"
			}).Union(new List<string>
			{
				Class61.smethod_1("ConsentUxUserSvc") ? "ConsentUxUserSvc" : "",
				Class61.smethod_1("BluetoothUserService") ? "BluetoothUserService" : ""
			}).Where(new Func<string, bool>(Class61.<>c.<>9.method_5)).ToList<string>();
		}
	}

	// Token: 0x17000073 RID: 115
	// (get) Token: 0x060007F4 RID: 2036 RVA: 0x0002287C File Offset: 0x00020A7C
	public List<string> List_7
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"DeviceAssociationBrokerSvc_" + Class61.String_1,
				"XboxNetApiSvc",
				"XboxGipSvc",
				"XblGameSave",
				"XblAuthManager"
			}).Union(new List<string>
			{
				Class61.smethod_1("DeviceAssociationBrokerSvc") ? "DeviceAssociationBrokerSvc" : ""
			}).Where(new Func<string, bool>(Class61.<>c.<>9.method_6)).ToList<string>();
		}
	}

	// Token: 0x17000074 RID: 116
	// (get) Token: 0x060007F5 RID: 2037 RVA: 0x0002292C File Offset: 0x00020B2C
	public List<string> List_8
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"PrintWorkflowUserSvc_" + Class61.String_1,
				"Spooler",
				"PrintNotify"
			}).Union(new List<string>
			{
				Class61.smethod_1("PrintWorkflowUserSvc") ? "PrintWorkflowUserSvc" : ""
			}).Where(new Func<string, bool>(Class61.<>c.<>9.method_7)).ToList<string>();
		}
	}

	// Token: 0x17000075 RID: 117
	// (get) Token: 0x060007F6 RID: 2038 RVA: 0x00004F59 File Offset: 0x00003159
	public List<string> List_9
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"WiaRpc",
				"stisvc"
			}).ToList<string>();
		}
	}

	// Token: 0x17000076 RID: 118
	// (get) Token: 0x060007F7 RID: 2039 RVA: 0x00004F85 File Offset: 0x00003185
	public List<string> List_10
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"TapiSrv",
				"PhoneSvc",
				"Fax"
			}).ToList<string>();
		}
	}

	// Token: 0x17000077 RID: 119
	// (get) Token: 0x060007F8 RID: 2040 RVA: 0x000229C4 File Offset: 0x00020BC4
	public List<string> List_11
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"wisvc",
				"DmEnrollmentSvc",
				"wuauserv",
				"WaaSMedicSvc",
				"DoSvc",
				"UsoSvc"
			}).Where(new Func<string, bool>(Class61.<>c.<>9.method_8)).ToList<string>();
		}
	}

	// Token: 0x17000078 RID: 120
	// (get) Token: 0x060007F9 RID: 2041 RVA: 0x00022A4C File Offset: 0x00020C4C
	public List<string> List_12
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"SensrSvc",
				"SensorService",
				"SensorDataService",
				"SEMgrSvc",
				"lfsvc"
			}).ToList<string>();
		}
	}

	// Token: 0x17000079 RID: 121
	// (get) Token: 0x060007FA RID: 2042 RVA: 0x00004FBC File Offset: 0x000031BC
	public List<string> List_13
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"DispBrokerDesktopSvc"
			}).ToList<string>();
		}
	}

	// Token: 0x1700007A RID: 122
	// (get) Token: 0x060007FB RID: 2043 RVA: 0x00022AA4 File Offset: 0x00020CA4
	public List<string> List_14
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"CDPSvc",
				"CDPUserSvc_" + Class61.String_1,
				"MessagingService_" + Class61.String_1,
				"PushToInstall",
				"WpnService"
			}).Union(new List<string>
			{
				Class61.smethod_1("CDPUserSvc") ? "CDPUserSvc" : "",
				Class61.smethod_1("MessagingService") ? "MessagingService" : ""
			}).Where(new Func<string, bool>(Class61.<>c.<>9.method_9)).ToList<string>();
		}
	}

	// Token: 0x1700007B RID: 123
	// (get) Token: 0x060007FC RID: 2044 RVA: 0x00004FDD File Offset: 0x000031DD
	public List<string> List_15
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"Themes"
			}).ToList<string>();
		}
	}

	// Token: 0x1700007C RID: 124
	// (get) Token: 0x060007FD RID: 2045 RVA: 0x00022B7C File Offset: 0x00020D7C
	public List<string> List_16
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"WwanSvc",
				"wlpasvc",
				"icssvc",
				"DusmSvc",
				"autotimesvc"
			}).ToList<string>();
		}
	}

	// Token: 0x1700007D RID: 125
	// (get) Token: 0x060007FE RID: 2046 RVA: 0x00022BD4 File Offset: 0x00020DD4
	public List<string> List_17
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"Netlogon",
				"CscService",
				"lmhosts",
				"FDResPub",
				"fdPHost",
				"LanmanServer",
				"LanmanWorkstation"
			}).ToList<string>();
		}
	}

	// Token: 0x1700007E RID: 126
	// (get) Token: 0x060007FF RID: 2047 RVA: 0x00022C44 File Offset: 0x00020E44
	public List<string> List_18
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"PolicyAgent",
				"IKEEXT",
				"p2pimsvc",
				"Eaphost"
			}).ToList<string>();
		}
	}

	// Token: 0x1700007F RID: 127
	// (get) Token: 0x06000800 RID: 2048 RVA: 0x00004FFE File Offset: 0x000031FE
	public List<string> List_19
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"WPDBusEnum",
				"WMPNetworkSvc"
			}).ToList<string>();
		}
	}

	// Token: 0x17000080 RID: 128
	// (get) Token: 0x06000801 RID: 2049 RVA: 0x00022C94 File Offset: 0x00020E94
	public List<string> List_20
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"UmRdpService",
				"TermService",
				"DsSvc",
				"RemoteRegistry"
			}).ToList<string>();
		}
	}

	// Token: 0x17000081 RID: 129
	// (get) Token: 0x06000802 RID: 2050 RVA: 0x0000502A File Offset: 0x0000322A
	public List<string> List_21
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"WerSvc",
				"wercplsupport",
				"Wecsvc"
			}).ToList<string>();
		}
	}

	// Token: 0x17000082 RID: 130
	// (get) Token: 0x06000803 RID: 2051 RVA: 0x00005061 File Offset: 0x00003261
	public List<string> List_22
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"WebClient"
			}).ToList<string>();
		}
	}

	// Token: 0x17000083 RID: 131
	// (get) Token: 0x06000804 RID: 2052 RVA: 0x00022CE4 File Offset: 0x00020EE4
	public List<string> List_23
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"SCPolicySvc",
				"ScDeviceEnum",
				"SCardSvr",
				"CertPropSvc"
			}).ToList<string>();
		}
	}

	// Token: 0x17000084 RID: 132
	// (get) Token: 0x06000805 RID: 2053 RVA: 0x00005082 File Offset: 0x00003282
	public List<string> List_24
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"AssignedAccessManagerSvc",
				"AppReadiness"
			}).ToList<string>();
		}
	}

	// Token: 0x17000085 RID: 133
	// (get) Token: 0x06000806 RID: 2054 RVA: 0x00022D34 File Offset: 0x00020F34
	public List<string> List_25
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"WSearch",
				"fhsvc",
				"WMPNetworkSvc",
				"workfolderssvc"
			}).ToList<string>();
		}
	}

	// Token: 0x17000086 RID: 134
	// (get) Token: 0x06000807 RID: 2055 RVA: 0x000050AE File Offset: 0x000032AE
	public List<string> List_26
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"EFS",
				"BDESVC"
			}).ToList<string>();
		}
	}

	// Token: 0x17000087 RID: 135
	// (get) Token: 0x06000808 RID: 2056 RVA: 0x000050DA File Offset: 0x000032DA
	public List<string> List_27
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"LxpSvc"
			}).ToList<string>();
		}
	}

	// Token: 0x17000088 RID: 136
	// (get) Token: 0x06000809 RID: 2057 RVA: 0x000050FB File Offset: 0x000032FB
	public List<string> List_28
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"WarpJITSvc",
				"wscsvc"
			}).ToList<string>();
		}
	}

	// Token: 0x17000089 RID: 137
	// (get) Token: 0x0600080A RID: 2058 RVA: 0x00005127 File Offset: 0x00003327
	public List<string> List_29
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"wmiApSrv",
				"pla",
				"PerfHost"
			}).ToList<string>();
		}
	}

	// Token: 0x1700008A RID: 138
	// (get) Token: 0x0600080B RID: 2059 RVA: 0x00022D84 File Offset: 0x00020F84
	public List<string> List_30
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"WdiSystemHost",
				"WdiServiceHost",
				"TroubleshootingSvc",
				"DPS",
				"diagnosticshub.standardcollector.service"
			}).ToList<string>();
		}
	}

	// Token: 0x1700008B RID: 139
	// (get) Token: 0x0600080C RID: 2060 RVA: 0x00022DDC File Offset: 0x00020FDC
	public List<string> List_31
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"workfolderssvc",
				"SNMPTRAP",
				"SessionEnv",
				"RemoteRegistry",
				"Netlogon",
				"EntAppSvc",
				"dot3svc",
				"DevQueryBroker",
				"AppMgmt"
			}).ToList<string>();
		}
	}

	// Token: 0x1700008C RID: 140
	// (get) Token: 0x0600080D RID: 2061 RVA: 0x00022E60 File Offset: 0x00021060
	public List<string> List_32
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"AarSvc_" + Class61.String_1,
				"AppVClient",
				"irmon",
				"WManSvc",
				"WinRM",
				"WFDSConMgrSvc",
				"UevAgentService",
				"tzautoupdate",
				"TrkWks",
				GClass2.GClass2_0.Boolean_1 ? "TabletInputService" : "",
				"SysMain",
				"SmsRouter",
				"shpamsvc",
				GClass2.GClass2_0.Boolean_1 ? "ShellHWDetection" : "",
				"SharedAccess",
				"SENS",
				"RpcLocator",
				"RetailDemo",
				"QWAVE",
				"WarpJITSvc",
				"wscsvc",
				"NaturalAuthentication"
			}).Union(new List<string>
			{
				Class61.smethod_1("AarSvc") ? "AarSvc" : ""
			}).Where(new Func<string, bool>(Class61.<>c.<>9.method_10)).ToList<string>();
		}
	}

	// Token: 0x1700008D RID: 141
	// (get) Token: 0x0600080E RID: 2062 RVA: 0x00022FF0 File Offset: 0x000211F0
	public List<string> List_33
	{
		get
		{
			return Class61.list_0.Intersect(new List<string>
			{
				"PNRPsvc",
				"PNRPAutoReg",
				"PcaSvc",
				"p2psvc",
				"NetTcpPortSharing",
				"Netlogon",
				"MSiSCSI",
				"MSDTC",
				"RemoteAccess",
				"lltdsvc",
				"IpxlatCfgSvc",
				"FontCache",
				"embeddedmode",
				"DevQueryBroker",
				"CscService",
				"AxInstSV",
				"ALG",
				"ssh-agent",
				"RasAuto",
				"AJRouter"
			}).ToList<string>();
		}
	}

	// Token: 0x06000811 RID: 2065 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_2(object object_1, ref bool bool_1)
	{
		Monitor.Enter(object_1, ref bool_1);
	}

	// Token: 0x06000812 RID: 2066 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_3(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000813 RID: 2067 RVA: 0x00002A32 File Offset: 0x00000C32
	static int smethod_4(string string_1, string string_2)
	{
		return string_1.IndexOf(string_2);
	}

	// Token: 0x06000814 RID: 2068 RVA: 0x00005174 File Offset: 0x00003374
	static string smethod_5(string string_1, int int_0)
	{
		return string_1.Substring(int_0);
	}

	// Token: 0x06000815 RID: 2069 RVA: 0x00002A44 File Offset: 0x00000C44
	static int smethod_6(string string_1)
	{
		return string_1.Length;
	}

	// Token: 0x06000816 RID: 2070 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_7(string string_1, string string_2, string string_3)
	{
		return string_1 + string_2 + string_3;
	}

	// Token: 0x06000817 RID: 2071 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_8(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.OpenSubKey(string_1);
	}

	// Token: 0x06000818 RID: 2072 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_9(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x06000819 RID: 2073 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_10()
	{
		return new object();
	}

	// Token: 0x040002E5 RID: 741
	private static volatile Class61 class61_0;

	// Token: 0x040002E6 RID: 742
	private static readonly object object_0 = new object();

	// Token: 0x040002E7 RID: 743
	public bool bool_0;

	// Token: 0x040002E8 RID: 744
	public static List<string> list_0 = new List<string>();

	// Token: 0x040002E9 RID: 745
	public static string string_0;
}
