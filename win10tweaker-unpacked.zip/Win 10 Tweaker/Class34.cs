﻿using System;
using System.IO;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000075 RID: 117
internal class Class34
{
	// Token: 0x1700002A RID: 42
	// (get) Token: 0x060005A2 RID: 1442 RVA: 0x0001BB58 File Offset: 0x00019D58
	public static Class34 Class34_0
	{
		get
		{
			if (Class34.class34_0 == null)
			{
				object obj = Class34.object_0;
				lock (obj)
				{
					if (Class34.class34_0 == null)
					{
						Class34.class34_0 = new Class34();
					}
				}
			}
			return Class34.class34_0;
		}
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x00004247 File Offset: 0x00002447
	public void method_0()
	{
		Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\" + this.string_0, false);
		Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\WOW6432Node\\" + this.string_0, false);
	}

	// Token: 0x060005A4 RID: 1444 RVA: 0x0001BBB8 File Offset: 0x00019DB8
	public void method_1()
	{
		Registry.LocalMachine.CreateSubKey("SOFTWARE\\" + this.string_0);
		Registry.LocalMachine.CreateSubKey("SOFTWARE\\WOW6432Node\\" + this.string_0);
		string text = GClass13.string_2 + "\\3D Objects";
		if (!Directory.Exists(text))
		{
			Directory.CreateDirectory(text);
			File.AppendAllText(text + "\\desktop.ini", "\r\n[.ShellClassInfo]\r\nLocalizedResourceName=@%SystemRoot%\\system32\\windows.storage.dll,-21825\r\nIconResource=%SystemRoot%\\system32\\imageres.dll,-198");
			File.SetAttributes(text + "\\desktop.ini", FileAttributes.Hidden);
		}
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_2(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x060005AA RID: 1450 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_3(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_1, bool_0);
	}

	// Token: 0x060005AB RID: 1451 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_4(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x060005AC RID: 1452 RVA: 0x00002EE5 File Offset: 0x000010E5
	static bool smethod_5(string string_1)
	{
		return Directory.Exists(string_1);
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x0000429E File Offset: 0x0000249E
	static DirectoryInfo smethod_6(string string_1)
	{
		return Directory.CreateDirectory(string_1);
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x000042A6 File Offset: 0x000024A6
	static void smethod_7(string string_1, string string_2)
	{
		File.AppendAllText(string_1, string_2);
	}

	// Token: 0x060005AF RID: 1455 RVA: 0x000036D9 File Offset: 0x000018D9
	static void smethod_8(string string_1, FileAttributes fileAttributes_0)
	{
		File.SetAttributes(string_1, fileAttributes_0);
	}

	// Token: 0x060005B0 RID: 1456 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_9()
	{
		return new object();
	}

	// Token: 0x04000265 RID: 613
	private static volatile Class34 class34_0;

	// Token: 0x04000266 RID: 614
	private static readonly object object_0 = new object();

	// Token: 0x04000267 RID: 615
	private string string_0 = "Microsoft\\Windows\\CurrentVersion\\Explorer\\MyComputer\\NameSpace\\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}";
}
