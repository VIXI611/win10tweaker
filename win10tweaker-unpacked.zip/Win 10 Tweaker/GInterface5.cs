﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A2 RID: 418
[TypeIdentifier]
[Guid("177160CA-BB5A-411C-841D-BD38FACDEAA0")]
[CompilerGenerated]
[ComImport]
public interface GInterface5 : GInterface4
{
}
