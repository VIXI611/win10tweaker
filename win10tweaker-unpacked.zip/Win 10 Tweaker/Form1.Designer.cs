﻿namespace Win_10_Tweaker
{
	// Token: 0x020000F1 RID: 241
	public partial class Form1 : global::GForm0
	{
		// Token: 0x06000D04 RID: 3332 RVA: 0x000076D5 File Offset: 0x000058D5
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000D05 RID: 3333 RVA: 0x00043F08 File Offset: 0x00042108
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new global::System.Windows.Forms.DataGridViewCellStyle();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Win_10_Tweaker.Form1));
			this.checkAll2 = new global::System.Windows.Forms.LinkLabel();
			this.ContextMenu1 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu5 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu3 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu4 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu12 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu6 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu9 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu10 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu15 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu16 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu11 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu17 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu2 = new global::System.Windows.Forms.CheckBox();
			this.Shift7 = new global::System.Windows.Forms.CheckBox();
			this.Shift6 = new global::System.Windows.Forms.CheckBox();
			this.Shift3 = new global::System.Windows.Forms.CheckBox();
			this.MainPanel2 = new global::System.Windows.Forms.Panel();
			this.RestoreContextMenu17 = new global::System.Windows.Forms.Button();
			this.panelmenu4 = new global::GClass10();
			this.Check45 = new global::System.Windows.Forms.CheckBox();
			this.Check42 = new global::System.Windows.Forms.CheckBox();
			this.Check43 = new global::System.Windows.Forms.CheckBox();
			this.Check44 = new global::System.Windows.Forms.CheckBox();
			this.Check41 = new global::System.Windows.Forms.CheckBox();
			this.RestoreContextMenu16 = new global::System.Windows.Forms.Button();
			this.panelmenu3 = new global::GClass10();
			this.Check38 = new global::System.Windows.Forms.CheckBox();
			this.Check37 = new global::System.Windows.Forms.CheckBox();
			this.Check36 = new global::System.Windows.Forms.CheckBox();
			this.Check35 = new global::System.Windows.Forms.CheckBox();
			this.Check32 = new global::System.Windows.Forms.CheckBox();
			this.Check33 = new global::System.Windows.Forms.CheckBox();
			this.Check34 = new global::System.Windows.Forms.CheckBox();
			this.Check31 = new global::System.Windows.Forms.CheckBox();
			this.RestoreContextMenu15 = new global::System.Windows.Forms.Button();
			this.panelmenu2 = new global::GClass10();
			this.Check22 = new global::System.Windows.Forms.CheckBox();
			this.Check23 = new global::System.Windows.Forms.CheckBox();
			this.Check21 = new global::System.Windows.Forms.CheckBox();
			this.RestoreContextMenu14 = new global::System.Windows.Forms.Button();
			this.panelmenu1 = new global::GClass10();
			this.Check1 = new global::System.Windows.Forms.CheckBox();
			this.Check2 = new global::System.Windows.Forms.CheckBox();
			this.Check3 = new global::System.Windows.Forms.CheckBox();
			this.Check4 = new global::System.Windows.Forms.CheckBox();
			this.Check5 = new global::System.Windows.Forms.CheckBox();
			this.Check6 = new global::System.Windows.Forms.CheckBox();
			this.Check7 = new global::System.Windows.Forms.CheckBox();
			this.Check8 = new global::System.Windows.Forms.CheckBox();
			this.Check9 = new global::System.Windows.Forms.CheckBox();
			this.RestoreContextMenu13 = new global::System.Windows.Forms.Button();
			this.linkmenu4 = new global::System.Windows.Forms.LinkLabel();
			this.RestoreContextMenu12 = new global::System.Windows.Forms.Button();
			this.linkmenu2 = new global::System.Windows.Forms.LinkLabel();
			this.RestoreContextMenu11 = new global::System.Windows.Forms.Button();
			this.linkmenu3 = new global::System.Windows.Forms.LinkLabel();
			this.RestoreContextMenu10 = new global::System.Windows.Forms.Button();
			this.linkmenu1 = new global::System.Windows.Forms.LinkLabel();
			this.RestoreContextMenu9 = new global::System.Windows.Forms.Button();
			this.RestoreContextMenu8 = new global::System.Windows.Forms.Button();
			this.Shift1 = new global::System.Windows.Forms.CheckBox();
			this.RestoreContextMenu7 = new global::System.Windows.Forms.Button();
			this.RestoreContextMenu6 = new global::System.Windows.Forms.Button();
			this.RestoreContextMenu5 = new global::System.Windows.Forms.Button();
			this.RestoreContextMenu4 = new global::System.Windows.Forms.Button();
			this.RestoreContextMenu3 = new global::System.Windows.Forms.Button();
			this.Shift2 = new global::System.Windows.Forms.CheckBox();
			this.RestoreContextMenu2 = new global::System.Windows.Forms.Button();
			this.RestoreContextMenu1 = new global::System.Windows.Forms.Button();
			this.Shift4 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu7 = new global::System.Windows.Forms.CheckBox();
			this.Shift5 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu8 = new global::System.Windows.Forms.CheckBox();
			this.Shift8 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu13 = new global::System.Windows.Forms.CheckBox();
			this.ContextMenu14 = new global::System.Windows.Forms.CheckBox();
			this.MainPanel3 = new global::System.Windows.Forms.Panel();
			this.panelmenu6 = new global::GClass10();
			this.Check70 = new global::System.Windows.Forms.CheckBox();
			this.Check69 = new global::System.Windows.Forms.CheckBox();
			this.Check68 = new global::System.Windows.Forms.CheckBox();
			this.Check67 = new global::System.Windows.Forms.CheckBox();
			this.Check66 = new global::System.Windows.Forms.CheckBox();
			this.Check65 = new global::System.Windows.Forms.CheckBox();
			this.Check64 = new global::System.Windows.Forms.CheckBox();
			this.Check63 = new global::System.Windows.Forms.CheckBox();
			this.Check62 = new global::System.Windows.Forms.CheckBox();
			this.Check61 = new global::System.Windows.Forms.CheckBox();
			this.panelmenu5 = new global::GClass10();
			this.Check56 = new global::System.Windows.Forms.CheckBox();
			this.Check55 = new global::System.Windows.Forms.CheckBox();
			this.Check54 = new global::System.Windows.Forms.CheckBox();
			this.Check53 = new global::System.Windows.Forms.CheckBox();
			this.Check52 = new global::System.Windows.Forms.CheckBox();
			this.Check51 = new global::System.Windows.Forms.CheckBox();
			this.linkmenu5 = new global::System.Windows.Forms.LinkLabel();
			this.checkAll3 = new global::System.Windows.Forms.LinkLabel();
			this.RestoreInterface17 = new global::System.Windows.Forms.Button();
			this.RestoreInterface16 = new global::System.Windows.Forms.Button();
			this.RestoreInterface15 = new global::System.Windows.Forms.Button();
			this.Interface1 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface14 = new global::System.Windows.Forms.Button();
			this.Interface2 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface13 = new global::System.Windows.Forms.Button();
			this.Interface3 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface12 = new global::System.Windows.Forms.Button();
			this.Interface4 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface11 = new global::System.Windows.Forms.Button();
			this.InterfaceFolder = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface10 = new global::System.Windows.Forms.Button();
			this.Interface5 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface9 = new global::System.Windows.Forms.Button();
			this.Interface6 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface8 = new global::System.Windows.Forms.Button();
			this.Interface7 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface7 = new global::System.Windows.Forms.Button();
			this.Interface8 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface6 = new global::System.Windows.Forms.Button();
			this.Interface9 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface5 = new global::System.Windows.Forms.Button();
			this.Interface10 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface4 = new global::System.Windows.Forms.Button();
			this.Interface11 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface3 = new global::System.Windows.Forms.Button();
			this.linkmenu6 = new global::System.Windows.Forms.LinkLabel();
			this.RestoreInterface2 = new global::System.Windows.Forms.Button();
			this.Interface12 = new global::System.Windows.Forms.CheckBox();
			this.RestoreInterface1 = new global::System.Windows.Forms.Button();
			this.Interface13 = new global::System.Windows.Forms.CheckBox();
			this.Interface14 = new global::System.Windows.Forms.CheckBox();
			this.Interface15 = new global::System.Windows.Forms.CheckBox();
			this.Interface16 = new global::System.Windows.Forms.CheckBox();
			this.Interface17 = new global::System.Windows.Forms.CheckBox();
			this.System14 = new global::System.Windows.Forms.CheckBox();
			this.System15 = new global::System.Windows.Forms.CheckBox();
			this.MainPanel4 = new global::System.Windows.Forms.Panel();
			this.RestoreSystem17 = new global::System.Windows.Forms.Button();
			this.System1 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem16 = new global::System.Windows.Forms.Button();
			this.System2 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem15 = new global::System.Windows.Forms.Button();
			this.System3 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem14 = new global::System.Windows.Forms.Button();
			this.System4 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem13 = new global::System.Windows.Forms.Button();
			this.System5 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem12 = new global::System.Windows.Forms.Button();
			this.System6 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem11 = new global::System.Windows.Forms.Button();
			this.System7 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem10 = new global::System.Windows.Forms.Button();
			this.System8 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem9 = new global::System.Windows.Forms.Button();
			this.System9 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem8 = new global::System.Windows.Forms.Button();
			this.AntiZapret = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem7 = new global::System.Windows.Forms.Button();
			this.System10 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem6 = new global::System.Windows.Forms.Button();
			this.System11 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem5 = new global::System.Windows.Forms.Button();
			this.System12 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem4 = new global::System.Windows.Forms.Button();
			this.System13 = new global::System.Windows.Forms.CheckBox();
			this.RestoreSystem3 = new global::System.Windows.Forms.Button();
			this.RestoreSystem2 = new global::System.Windows.Forms.Button();
			this.RestoreSystem1 = new global::System.Windows.Forms.Button();
			this.System16 = new global::System.Windows.Forms.CheckBox();
			this.System17 = new global::System.Windows.Forms.CheckBox();
			this.checkAll4 = new global::System.Windows.Forms.LinkLabel();
			this.ApplyButton = new global::System.Windows.Forms.Label();
			this.tooltip = new global::System.Windows.Forms.ToolTip(this.components);
			this.AddToApply = new global::System.Windows.Forms.PictureBox();
			this.MinimizeIcon = new global::System.Windows.Forms.Button();
			this.PlayIcon = new global::System.Windows.Forms.Button();
			this.MainPanel1 = new global::System.Windows.Forms.Panel();
			this.RestoreConfidentiality17 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality16 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality15 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality14 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality13 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality12 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality11 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality10 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality9 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality8 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality7 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality6 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality5 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality4 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality3 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality2 = new global::System.Windows.Forms.Button();
			this.RestoreConfidentiality1 = new global::System.Windows.Forms.Button();
			this.Confidentiality1 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality2 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality3 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality4 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality5 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality6 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality7 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality8 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality9 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality10 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality11 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality12 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality13 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality14 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality15 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality16 = new global::System.Windows.Forms.CheckBox();
			this.Confidentiality17 = new global::System.Windows.Forms.CheckBox();
			this.checkAll1 = new global::System.Windows.Forms.LinkLabel();
			this.MainPanel6 = new global::System.Windows.Forms.Panel();
			this.CleanerLog = new global::System.Windows.Forms.LinkLabel();
			this.checkBoxCleaner1 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner2 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner3 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner4 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner5 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner6 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner7 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner8 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner9 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner10 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner11 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner12 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner13 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner14 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner15 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner16 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner17 = new global::System.Windows.Forms.CheckBox();
			this.checkBoxCleaner18 = new global::System.Windows.Forms.CheckBox();
			this.checkAll5 = new global::System.Windows.Forms.LinkLabel();
			this.MainPanel7 = new global::System.Windows.Forms.Panel();
			this.Feedback_del = new global::System.Windows.Forms.Button();
			this.Feedback_ = new global::System.Windows.Forms.Button();
			this.OfficeHub_del = new global::System.Windows.Forms.Button();
			this.OfficeHub_ = new global::System.Windows.Forms.Button();
			this.Photos_del = new global::System.Windows.Forms.Button();
			this.Photos_ = new global::System.Windows.Forms.Button();
			this.Getstarted_del = new global::System.Windows.Forms.Button();
			this.Getstarted_ = new global::System.Windows.Forms.Button();
			this.Skype_del = new global::System.Windows.Forms.Button();
			this.Skype_ = new global::System.Windows.Forms.Button();
			this.Communications_del = new global::System.Windows.Forms.Button();
			this.Communications_ = new global::System.Windows.Forms.Button();
			this.GetHelp_del = new global::System.Windows.Forms.Button();
			this.GetHelp_ = new global::System.Windows.Forms.Button();
			this.BingWeather_del = new global::System.Windows.Forms.Button();
			this.BingWeather_ = new global::System.Windows.Forms.Button();
			this.Sketch_del = new global::System.Windows.Forms.Button();
			this.Sketch_ = new global::System.Windows.Forms.Button();
			this.ZuneMusic_del = new global::System.Windows.Forms.Button();
			this.ZuneMusic_ = new global::System.Windows.Forms.Button();
			this.People_del = new global::System.Windows.Forms.Button();
			this.People_ = new global::System.Windows.Forms.Button();
			this.ZuneVideo_del = new global::System.Windows.Forms.Button();
			this.ZuneVideo_ = new global::System.Windows.Forms.Button();
			this.WindowsMaps_del = new global::System.Windows.Forms.Button();
			this.WindowsMaps_ = new global::System.Windows.Forms.Button();
			this.WindowsCamera_del = new global::System.Windows.Forms.Button();
			this.WindowsCamera_ = new global::System.Windows.Forms.Button();
			this.Recorder_del = new global::System.Windows.Forms.Button();
			this.Recorder_ = new global::System.Windows.Forms.Button();
			this.WindowsAlarms_del = new global::System.Windows.Forms.Button();
			this.WindowsAlarms_ = new global::System.Windows.Forms.Button();
			this.Xbox_del = new global::System.Windows.Forms.Button();
			this.Xbox_ = new global::System.Windows.Forms.Button();
			this.StickyNotes_del = new global::System.Windows.Forms.Button();
			this.StickyNotes_ = new global::System.Windows.Forms.Button();
			this.MixedReality_del = new global::System.Windows.Forms.Button();
			this.MixedReality_ = new global::System.Windows.Forms.Button();
			this.Paint_del = new global::System.Windows.Forms.Button();
			this.Paint_ = new global::System.Windows.Forms.Button();
			this.OneNote_del = new global::System.Windows.Forms.Button();
			this.OneNote_ = new global::System.Windows.Forms.Button();
			this.Solitaire_del = new global::System.Windows.Forms.Button();
			this.Solitaire_ = new global::System.Windows.Forms.Button();
			this.Viewer_del = new global::System.Windows.Forms.Button();
			this.Viewer_ = new global::System.Windows.Forms.Button();
			this.WindowsStore_del = new global::System.Windows.Forms.Button();
			this.WindowsStore_ = new global::System.Windows.Forms.Button();
			this.Feedback_text = new global::System.Windows.Forms.Label();
			this.OfficeHub_text = new global::System.Windows.Forms.Label();
			this.Photos_text = new global::System.Windows.Forms.Label();
			this.Getstarted_text = new global::System.Windows.Forms.Label();
			this.Skype_text = new global::System.Windows.Forms.Label();
			this.Communications_text = new global::System.Windows.Forms.Label();
			this.GetHelp_text = new global::System.Windows.Forms.Label();
			this.BingWeather_text = new global::System.Windows.Forms.Label();
			this.Sketch_text = new global::System.Windows.Forms.Label();
			this.ZuneMusic_text = new global::System.Windows.Forms.Label();
			this.People_text = new global::System.Windows.Forms.Label();
			this.ZuneVideo_text = new global::System.Windows.Forms.Label();
			this.WindowsMaps_text = new global::System.Windows.Forms.Label();
			this.WindowsCamera_text = new global::System.Windows.Forms.Label();
			this.Recorder_text = new global::System.Windows.Forms.Label();
			this.WindowsAlarms_text = new global::System.Windows.Forms.Label();
			this.Xbox_text = new global::System.Windows.Forms.Label();
			this.StickyNotes_text = new global::System.Windows.Forms.Label();
			this.MixedReality_text = new global::System.Windows.Forms.Label();
			this.Paint_text = new global::System.Windows.Forms.Label();
			this.OneNote_text = new global::System.Windows.Forms.Label();
			this.Solitaire_text = new global::System.Windows.Forms.Label();
			this.Viewer_text = new global::System.Windows.Forms.Label();
			this.WindowsStore_text = new global::System.Windows.Forms.Label();
			this.MainPanelServ1 = new global::System.Windows.Forms.Panel();
			this.Serv16 = new global::System.Windows.Forms.Label();
			this.Serv15 = new global::System.Windows.Forms.Label();
			this.Serv14 = new global::System.Windows.Forms.Label();
			this.Serv13 = new global::System.Windows.Forms.Label();
			this.Serv12 = new global::System.Windows.Forms.Label();
			this.Serv11 = new global::System.Windows.Forms.Label();
			this.Serv10 = new global::System.Windows.Forms.Label();
			this.Serv9 = new global::System.Windows.Forms.Label();
			this.Serv8 = new global::System.Windows.Forms.Label();
			this.Serv7 = new global::System.Windows.Forms.Label();
			this.Serv6 = new global::System.Windows.Forms.Label();
			this.Serv5 = new global::System.Windows.Forms.Label();
			this.Serv4 = new global::System.Windows.Forms.Label();
			this.Serv3 = new global::System.Windows.Forms.Label();
			this.Serv2 = new global::System.Windows.Forms.Label();
			this.Serv1 = new global::System.Windows.Forms.Label();
			this.ServPanelChoice = new global::System.Windows.Forms.Panel();
			this.ServList = new global::System.Windows.Forms.Button();
			this.ServCancel = new global::System.Windows.Forms.Button();
			this.ServNo = new global::System.Windows.Forms.Button();
			this.ServYes = new global::System.Windows.Forms.Button();
			this.MainPanelServ2 = new global::System.Windows.Forms.Panel();
			this.Serv18 = new global::System.Windows.Forms.Label();
			this.Serv17 = new global::System.Windows.Forms.Label();
			this.Serv19 = new global::System.Windows.Forms.Label();
			this.Serv20 = new global::System.Windows.Forms.Label();
			this.Serv21 = new global::System.Windows.Forms.Label();
			this.Serv32 = new global::System.Windows.Forms.Label();
			this.Serv22 = new global::System.Windows.Forms.Label();
			this.Serv31 = new global::System.Windows.Forms.Label();
			this.Serv23 = new global::System.Windows.Forms.Label();
			this.Serv30 = new global::System.Windows.Forms.Label();
			this.Serv24 = new global::System.Windows.Forms.Label();
			this.Serv29 = new global::System.Windows.Forms.Label();
			this.Serv25 = new global::System.Windows.Forms.Label();
			this.Serv28 = new global::System.Windows.Forms.Label();
			this.Serv26 = new global::System.Windows.Forms.Label();
			this.Serv27 = new global::System.Windows.Forms.Label();
			this.mainTimer = new global::System.Windows.Forms.Timer(this.components);
			this.MainPanel8 = new global::System.Windows.Forms.Panel();
			this.MainPanel8Line2 = new global::System.Windows.Forms.PictureBox();
			this.MainPanel8Line1 = new global::System.Windows.Forms.PictureBox();
			this.autorunpanel = new global::System.Windows.Forms.Panel();
			this.StartupBlueNotWorking = new global::System.Windows.Forms.Label();
			this.StartupGrayTip = new global::System.Windows.Forms.Label();
			this.StartupBlueWorking = new global::System.Windows.Forms.Label();
			this.StartupYellowTip = new global::System.Windows.Forms.Label();
			this.StartupBottomTip = new global::System.Windows.Forms.Label();
			this.MainPanel11 = new global::System.Windows.Forms.Panel();
			this.PersonalPanelPlate = new global::System.Windows.Forms.Panel();
			this.PersonalPanelPlateLabel = new global::System.Windows.Forms.Label();
			this.showip = new global::System.Windows.Forms.LinkLabel();
			this.pctype = new global::System.Windows.Forms.Label();
			this._os = new global::System.Windows.Forms.Label();
			this._os1 = new global::System.Windows.Forms.Label();
			this._mother = new global::System.Windows.Forms.Label();
			this._mother1 = new global::System.Windows.Forms.Label();
			this._cpu = new global::System.Windows.Forms.Label();
			this._cpu1 = new global::System.Windows.Forms.Label();
			this._gpu = new global::System.Windows.Forms.Label();
			this._gpu1 = new global::System.Windows.Forms.Label();
			this._monitor = new global::System.Windows.Forms.Label();
			this._monitor1 = new global::System.Windows.Forms.Label();
			this._ram = new global::System.Windows.Forms.Label();
			this._ram1 = new global::System.Windows.Forms.Label();
			this._drive = new global::System.Windows.Forms.Label();
			this._drive1 = new global::System.Windows.Forms.Label();
			this._usb = new global::System.Windows.Forms.Label();
			this._usb1 = new global::System.Windows.Forms.Label();
			this._pctime = new global::System.Windows.Forms.Label();
			this._pctime1 = new global::System.Windows.Forms.Label();
			this._ip = new global::System.Windows.Forms.Label();
			this._ip1 = new global::System.Windows.Forms.Label();
			this._speed = new global::System.Windows.Forms.Label();
			this._speed1 = new global::System.Windows.Forms.Label();
			this.AboutIcon = new global::System.Windows.Forms.Button();
			this.CloseIcon = new global::System.Windows.Forms.Button();
			this.MainPanel10 = new global::System.Windows.Forms.Panel();
			this.scanner = new global::System.Windows.Forms.PictureBox();
			this.PleaseWaitVT = new global::System.Windows.Forms.Label();
			this.MainPanel10Line2 = new global::System.Windows.Forms.PictureBox();
			this.MainPanel10Line1 = new global::System.Windows.Forms.PictureBox();
			this.DropFileHereVT = new global::System.Windows.Forms.Label();
			this.panelVT = new global::System.Windows.Forms.Panel();
			this.MainPanel9 = new global::System.Windows.Forms.Panel();
			this.panelLog = new global::System.Windows.Forms.Panel();
			this.DupesProgressBar = new global::System.Windows.Forms.ProgressBar();
			this.panelChoice = new global::System.Windows.Forms.Panel();
			this.panelChoiceLine = new global::System.Windows.Forms.Label();
			this.buttonNo = new global::System.Windows.Forms.Button();
			this.buttonYes = new global::System.Windows.Forms.Button();
			this.PanelDragnDropArea = new global::System.Windows.Forms.Panel();
			this.OptDragText = new global::System.Windows.Forms.Label();
			this.restore1 = new global::System.Windows.Forms.Button();
			this.compress1 = new global::System.Windows.Forms.Button();
			this.OptRadioButton1 = new global::System.Windows.Forms.RadioButton();
			this.OptRadioButton2 = new global::System.Windows.Forms.RadioButton();
			this.OptRadioButton3 = new global::System.Windows.Forms.RadioButton();
			this.OptRadioButton4 = new global::System.Windows.Forms.RadioButton();
			this.restore2 = new global::System.Windows.Forms.Button();
			this.compress2 = new global::System.Windows.Forms.Button();
			this.restore3 = new global::System.Windows.Forms.Button();
			this.compress3 = new global::System.Windows.Forms.Button();
			this.compress4 = new global::System.Windows.Forms.Button();
			this.compress5 = new global::System.Windows.Forms.Button();
			this.checker4 = new global::System.Windows.Forms.Label();
			this.checker3 = new global::System.Windows.Forms.Label();
			this.checker2 = new global::System.Windows.Forms.Label();
			this.checker1 = new global::System.Windows.Forms.Label();
			this.checker5 = new global::System.Windows.Forms.Label();
			this.progressBar2 = new global::System.Windows.Forms.ProgressBar();
			this.progressBar5 = new global::System.Windows.Forms.ProgressBar();
			this.tip5 = new global::System.Windows.Forms.Label();
			this.progressBar1 = new global::System.Windows.Forms.ProgressBar();
			this.progressBar4 = new global::System.Windows.Forms.ProgressBar();
			this.tip4 = new global::System.Windows.Forms.Label();
			this.ChooseCompression = new global::System.Windows.Forms.Label();
			this.progressBar3 = new global::System.Windows.Forms.ProgressBar();
			this.tip3 = new global::System.Windows.Forms.Label();
			this.tip1 = new global::System.Windows.Forms.Label();
			this.tip2 = new global::System.Windows.Forms.Label();
			this.long4 = new global::System.Windows.Forms.Label();
			this.long3 = new global::System.Windows.Forms.Label();
			this.long2 = new global::System.Windows.Forms.Label();
			this.long1 = new global::System.Windows.Forms.Label();
			this.tip6 = new global::System.Windows.Forms.Label();
			this.long5 = new global::System.Windows.Forms.Label();
			this.Counter3 = new global::System.Windows.Forms.Label();
			this.Counter1 = new global::System.Windows.Forms.Label();
			this.SettingsIcon = new global::System.Windows.Forms.Button();
			this.CleanerMainPanel = new global::System.Windows.Forms.Panel();
			this.CloseCleaner = new global::System.Windows.Forms.Button();
			this.HeaderCleanerLog = new global::System.Windows.Forms.Label();
			this.CleanerMainPanel2 = new global::System.Windows.Forms.Panel();
			this.Table = new global::System.Windows.Forms.DataGridView();
			this.Column1 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column2 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column3 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.PanelOffer = new global::GClass11();
			this.HeaderPanel = new global::System.Windows.Forms.Panel();
			this.LeftPanel = new global::System.Windows.Forms.Panel();
			this.TipDefault = new global::System.Windows.Forms.Label();
			this.Apply = new global::System.Windows.Forms.Button();
			this.ResAllButton = new global::System.Windows.Forms.Button();
			this.RemAllButton = new global::System.Windows.Forms.Button();
			this.LogoutRestartRequired = new global::System.Windows.Forms.Label();
			this.LeftMenu11 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu10 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu9 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu8 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu7 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu6 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu5 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu4 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu3 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu2 = new global::System.Windows.Forms.LinkLabel();
			this.LeftMenu1 = new global::System.Windows.Forms.LinkLabel();
			this.dot3 = new global::System.Windows.Forms.Label();
			this.dot2 = new global::System.Windows.Forms.Label();
			this.dot1 = new global::System.Windows.Forms.Label();
			this.ButtonBack = new global::System.Windows.Forms.Label();
			this.ServDownPanel = new global::System.Windows.Forms.Panel();
			this.ServStepsLabel = new global::System.Windows.Forms.Label();
			this.ServProgressBar = new global::System.Windows.Forms.ProgressBar();
			this.OffDefender = new global::GClass11();
			this.PersonalPanel = new global::System.Windows.Forms.Panel();
			this.FlowPanel = new global::System.Windows.Forms.FlowLayoutPanel();
			this.PersonalPanelHeaderPanel = new global::System.Windows.Forms.Panel();
			this.CloseRecommendations = new global::System.Windows.Forms.Button();
			this.PersonalPanelHeaderLabel = new global::System.Windows.Forms.Label();
			this.MainPanel2.SuspendLayout();
			this.panelmenu4.SuspendLayout();
			this.panelmenu3.SuspendLayout();
			this.panelmenu2.SuspendLayout();
			this.panelmenu1.SuspendLayout();
			this.MainPanel3.SuspendLayout();
			this.panelmenu6.SuspendLayout();
			this.panelmenu5.SuspendLayout();
			this.MainPanel4.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.AddToApply).BeginInit();
			this.MainPanel1.SuspendLayout();
			this.MainPanel6.SuspendLayout();
			this.MainPanel7.SuspendLayout();
			this.MainPanelServ1.SuspendLayout();
			this.ServPanelChoice.SuspendLayout();
			this.MainPanelServ2.SuspendLayout();
			this.MainPanel8.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.MainPanel8Line2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.MainPanel8Line1).BeginInit();
			this.MainPanel11.SuspendLayout();
			this.PersonalPanelPlate.SuspendLayout();
			this.MainPanel10.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.scanner).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.MainPanel10Line2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.MainPanel10Line1).BeginInit();
			this.MainPanel9.SuspendLayout();
			this.panelLog.SuspendLayout();
			this.panelChoice.SuspendLayout();
			this.PanelDragnDropArea.SuspendLayout();
			this.CleanerMainPanel.SuspendLayout();
			this.CleanerMainPanel2.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.Table).BeginInit();
			this.HeaderPanel.SuspendLayout();
			this.LeftPanel.SuspendLayout();
			this.ServDownPanel.SuspendLayout();
			this.PersonalPanel.SuspendLayout();
			this.PersonalPanelHeaderPanel.SuspendLayout();
			base.SuspendLayout();
			this.checkAll2.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.checkAll2.AutoSize = true;
			this.checkAll2.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checkAll2.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.checkAll2.LinkColor = global::System.Drawing.Color.White;
			this.checkAll2.Location = new global::System.Drawing.Point(3, 0);
			this.checkAll2.Name = "checkAll2";
			this.checkAll2.Size = new global::System.Drawing.Size(0, 13);
			this.checkAll2.TabIndex = 1;
			this.checkAll2.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel2_LinkClicked);
			this.ContextMenu1.AutoSize = true;
			this.ContextMenu1.Location = new global::System.Drawing.Point(23, 27);
			this.ContextMenu1.Name = "ContextMenu1";
			this.ContextMenu1.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu1.TabIndex = 2;
			this.ContextMenu5.AutoSize = true;
			this.ContextMenu5.Location = new global::System.Drawing.Point(23, 119);
			this.ContextMenu5.Name = "ContextMenu5";
			this.ContextMenu5.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu5.TabIndex = 9;
			this.ContextMenu3.AutoSize = true;
			this.ContextMenu3.Location = new global::System.Drawing.Point(23, 73);
			this.ContextMenu3.Name = "ContextMenu3";
			this.ContextMenu3.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu3.TabIndex = 6;
			this.ContextMenu4.AutoSize = true;
			this.ContextMenu4.Location = new global::System.Drawing.Point(23, 96);
			this.ContextMenu4.Name = "ContextMenu4";
			this.ContextMenu4.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu4.TabIndex = 7;
			this.ContextMenu12.AutoSize = true;
			this.ContextMenu12.Location = new global::System.Drawing.Point(23, 280);
			this.ContextMenu12.Name = "ContextMenu12";
			this.ContextMenu12.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu12.TabIndex = 23;
			this.ContextMenu6.AutoSize = true;
			this.ContextMenu6.Location = new global::System.Drawing.Point(23, 142);
			this.ContextMenu6.Name = "ContextMenu6";
			this.ContextMenu6.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu6.TabIndex = 11;
			this.ContextMenu9.AutoSize = true;
			this.ContextMenu9.Location = new global::System.Drawing.Point(23, 211);
			this.ContextMenu9.Name = "ContextMenu9";
			this.ContextMenu9.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu9.TabIndex = 17;
			this.ContextMenu10.AutoSize = true;
			this.ContextMenu10.Location = new global::System.Drawing.Point(23, 234);
			this.ContextMenu10.Name = "ContextMenu10";
			this.ContextMenu10.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu10.TabIndex = 19;
			this.ContextMenu15.AutoSize = true;
			this.ContextMenu15.Location = new global::System.Drawing.Point(23, 349);
			this.ContextMenu15.Name = "ContextMenu15";
			this.ContextMenu15.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu15.TabIndex = 26;
			this.ContextMenu16.AutoSize = true;
			this.ContextMenu16.Location = new global::System.Drawing.Point(23, 372);
			this.ContextMenu16.Name = "ContextMenu16";
			this.ContextMenu16.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu16.TabIndex = 28;
			this.ContextMenu11.AutoSize = true;
			this.ContextMenu11.Location = new global::System.Drawing.Point(23, 257);
			this.ContextMenu11.Name = "ContextMenu11";
			this.ContextMenu11.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu11.TabIndex = 21;
			this.ContextMenu17.AutoSize = true;
			this.ContextMenu17.Location = new global::System.Drawing.Point(23, 395);
			this.ContextMenu17.Name = "ContextMenu17";
			this.ContextMenu17.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu17.TabIndex = 30;
			this.ContextMenu2.AutoSize = true;
			this.ContextMenu2.Location = new global::System.Drawing.Point(23, 50);
			this.ContextMenu2.Name = "ContextMenu2";
			this.ContextMenu2.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu2.TabIndex = 4;
			this.Shift7.AutoSize = true;
			this.Shift7.Location = new global::System.Drawing.Point(289, 234);
			this.Shift7.Name = "Shift7";
			this.Shift7.Size = new global::System.Drawing.Size(15, 14);
			this.Shift7.TabIndex = 20;
			this.Shift6.AutoSize = true;
			this.Shift6.Location = new global::System.Drawing.Point(356, 211);
			this.Shift6.Name = "Shift6";
			this.Shift6.Size = new global::System.Drawing.Size(15, 14);
			this.Shift6.TabIndex = 18;
			this.Shift3.AutoSize = true;
			this.Shift3.Location = new global::System.Drawing.Point(343, 142);
			this.Shift3.Name = "Shift3";
			this.Shift3.Size = new global::System.Drawing.Size(15, 14);
			this.Shift3.TabIndex = 12;
			this.MainPanel2.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel2.Controls.Add(this.RestoreContextMenu17);
			this.MainPanel2.Controls.Add(this.panelmenu4);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu16);
			this.MainPanel2.Controls.Add(this.panelmenu3);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu15);
			this.MainPanel2.Controls.Add(this.panelmenu2);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu14);
			this.MainPanel2.Controls.Add(this.panelmenu1);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu13);
			this.MainPanel2.Controls.Add(this.linkmenu4);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu12);
			this.MainPanel2.Controls.Add(this.linkmenu2);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu11);
			this.MainPanel2.Controls.Add(this.linkmenu3);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu10);
			this.MainPanel2.Controls.Add(this.linkmenu1);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu9);
			this.MainPanel2.Controls.Add(this.checkAll2);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu8);
			this.MainPanel2.Controls.Add(this.Shift1);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu7);
			this.MainPanel2.Controls.Add(this.ContextMenu1);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu6);
			this.MainPanel2.Controls.Add(this.ContextMenu2);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu5);
			this.MainPanel2.Controls.Add(this.ContextMenu3);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu4);
			this.MainPanel2.Controls.Add(this.ContextMenu4);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu3);
			this.MainPanel2.Controls.Add(this.Shift2);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu2);
			this.MainPanel2.Controls.Add(this.ContextMenu5);
			this.MainPanel2.Controls.Add(this.RestoreContextMenu1);
			this.MainPanel2.Controls.Add(this.Shift3);
			this.MainPanel2.Controls.Add(this.ContextMenu6);
			this.MainPanel2.Controls.Add(this.Shift4);
			this.MainPanel2.Controls.Add(this.ContextMenu7);
			this.MainPanel2.Controls.Add(this.Shift5);
			this.MainPanel2.Controls.Add(this.ContextMenu8);
			this.MainPanel2.Controls.Add(this.Shift6);
			this.MainPanel2.Controls.Add(this.ContextMenu9);
			this.MainPanel2.Controls.Add(this.Shift7);
			this.MainPanel2.Controls.Add(this.ContextMenu10);
			this.MainPanel2.Controls.Add(this.Shift8);
			this.MainPanel2.Controls.Add(this.ContextMenu11);
			this.MainPanel2.Controls.Add(this.ContextMenu12);
			this.MainPanel2.Controls.Add(this.ContextMenu13);
			this.MainPanel2.Controls.Add(this.ContextMenu14);
			this.MainPanel2.Controls.Add(this.ContextMenu15);
			this.MainPanel2.Controls.Add(this.ContextMenu16);
			this.MainPanel2.Controls.Add(this.ContextMenu17);
			this.MainPanel2.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel2.Name = "MainPanel2";
			this.MainPanel2.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel2.TabIndex = 25;
			this.RestoreContextMenu17.Location = new global::System.Drawing.Point(2, 397);
			this.RestoreContextMenu17.Name = "RestoreContextMenu17";
			this.RestoreContextMenu17.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu17.TabIndex = 195;
			this.RestoreContextMenu17.UseVisualStyleBackColor = true;
			this.RestoreContextMenu17.Click += new global::System.EventHandler(this.RestoreContextMenu17_Click);
			this.panelmenu4.BackColor = global::System.Drawing.Color.Transparent;
			this.panelmenu4.Controls.Add(this.Check45);
			this.panelmenu4.Controls.Add(this.Check42);
			this.panelmenu4.Controls.Add(this.Check43);
			this.panelmenu4.Controls.Add(this.Check44);
			this.panelmenu4.Controls.Add(this.Check41);
			this.panelmenu4.Font = new global::System.Drawing.Font("Tahoma", 8.25f);
			this.panelmenu4.Location = new global::System.Drawing.Point(273, 239);
			this.panelmenu4.Name = "panelmenu4";
			this.panelmenu4.Size = new global::System.Drawing.Size(176, 132);
			this.panelmenu4.TabIndex = 60;
			this.panelmenu4.Visible = false;
			this.Check45.AutoSize = true;
			this.Check45.Checked = true;
			this.Check45.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check45.Location = new global::System.Drawing.Point(12, 104);
			this.Check45.Name = "Check45";
			this.Check45.Size = new global::System.Drawing.Size(15, 14);
			this.Check45.TabIndex = 15;
			this.Check42.AutoSize = true;
			this.Check42.Checked = true;
			this.Check42.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check42.Location = new global::System.Drawing.Point(12, 35);
			this.Check42.Name = "Check42";
			this.Check42.Size = new global::System.Drawing.Size(15, 14);
			this.Check42.TabIndex = 1;
			this.Check43.AutoSize = true;
			this.Check43.Checked = true;
			this.Check43.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check43.Location = new global::System.Drawing.Point(12, 58);
			this.Check43.Name = "Check43";
			this.Check43.Size = new global::System.Drawing.Size(15, 14);
			this.Check43.TabIndex = 14;
			this.Check44.AutoSize = true;
			this.Check44.Checked = true;
			this.Check44.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check44.Location = new global::System.Drawing.Point(12, 81);
			this.Check44.Name = "Check44";
			this.Check44.Size = new global::System.Drawing.Size(15, 14);
			this.Check44.TabIndex = 3;
			this.Check41.AutoSize = true;
			this.Check41.Checked = true;
			this.Check41.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check41.Location = new global::System.Drawing.Point(12, 12);
			this.Check41.Name = "Check41";
			this.Check41.Size = new global::System.Drawing.Size(15, 14);
			this.Check41.TabIndex = 8;
			this.RestoreContextMenu16.Location = new global::System.Drawing.Point(2, 374);
			this.RestoreContextMenu16.Name = "RestoreContextMenu16";
			this.RestoreContextMenu16.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu16.TabIndex = 194;
			this.RestoreContextMenu16.UseVisualStyleBackColor = true;
			this.RestoreContextMenu16.Click += new global::System.EventHandler(this.RestoreContextMenu16_Click);
			this.panelmenu3.BackColor = global::System.Drawing.Color.Transparent;
			this.panelmenu3.Controls.Add(this.Check38);
			this.panelmenu3.Controls.Add(this.Check37);
			this.panelmenu3.Controls.Add(this.Check36);
			this.panelmenu3.Controls.Add(this.Check35);
			this.panelmenu3.Controls.Add(this.Check32);
			this.panelmenu3.Controls.Add(this.Check33);
			this.panelmenu3.Controls.Add(this.Check34);
			this.panelmenu3.Controls.Add(this.Check31);
			this.panelmenu3.Font = new global::System.Drawing.Font("Tahoma", 8.25f);
			this.panelmenu3.Location = new global::System.Drawing.Point(186, 144);
			this.panelmenu3.Name = "panelmenu3";
			this.panelmenu3.Size = new global::System.Drawing.Size(254, 204);
			this.panelmenu3.TabIndex = 59;
			this.panelmenu3.Visible = false;
			this.Check38.AutoSize = true;
			this.Check38.Checked = true;
			this.Check38.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check38.Location = new global::System.Drawing.Point(12, 173);
			this.Check38.Name = "Check38";
			this.Check38.Size = new global::System.Drawing.Size(15, 14);
			this.Check38.TabIndex = 18;
			this.Check37.AutoSize = true;
			this.Check37.Checked = true;
			this.Check37.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check37.Location = new global::System.Drawing.Point(12, 150);
			this.Check37.Name = "Check37";
			this.Check37.Size = new global::System.Drawing.Size(15, 14);
			this.Check37.TabIndex = 17;
			this.Check36.AutoSize = true;
			this.Check36.Checked = true;
			this.Check36.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check36.Location = new global::System.Drawing.Point(12, 127);
			this.Check36.Name = "Check36";
			this.Check36.Size = new global::System.Drawing.Size(15, 14);
			this.Check36.TabIndex = 16;
			this.Check35.AutoSize = true;
			this.Check35.Checked = true;
			this.Check35.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check35.Location = new global::System.Drawing.Point(12, 104);
			this.Check35.Name = "Check35";
			this.Check35.Size = new global::System.Drawing.Size(15, 14);
			this.Check35.TabIndex = 15;
			this.Check32.AutoSize = true;
			this.Check32.Checked = true;
			this.Check32.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check32.Location = new global::System.Drawing.Point(12, 35);
			this.Check32.Name = "Check32";
			this.Check32.Size = new global::System.Drawing.Size(15, 14);
			this.Check32.TabIndex = 1;
			this.Check33.AutoSize = true;
			this.Check33.Checked = true;
			this.Check33.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check33.Location = new global::System.Drawing.Point(12, 58);
			this.Check33.Name = "Check33";
			this.Check33.Size = new global::System.Drawing.Size(15, 14);
			this.Check33.TabIndex = 14;
			this.Check34.AutoSize = true;
			this.Check34.Checked = true;
			this.Check34.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check34.Location = new global::System.Drawing.Point(12, 81);
			this.Check34.Name = "Check34";
			this.Check34.Size = new global::System.Drawing.Size(15, 14);
			this.Check34.TabIndex = 3;
			this.Check31.AutoSize = true;
			this.Check31.Checked = true;
			this.Check31.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check31.Location = new global::System.Drawing.Point(12, 12);
			this.Check31.Name = "Check31";
			this.Check31.Size = new global::System.Drawing.Size(15, 14);
			this.Check31.TabIndex = 8;
			this.RestoreContextMenu15.Location = new global::System.Drawing.Point(2, 351);
			this.RestoreContextMenu15.Name = "RestoreContextMenu15";
			this.RestoreContextMenu15.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu15.TabIndex = 193;
			this.RestoreContextMenu15.UseVisualStyleBackColor = true;
			this.RestoreContextMenu15.Click += new global::System.EventHandler(this.RestoreContextMenu15_Click);
			this.panelmenu2.BackColor = global::System.Drawing.Color.Transparent;
			this.panelmenu2.Controls.Add(this.Check22);
			this.panelmenu2.Controls.Add(this.Check23);
			this.panelmenu2.Controls.Add(this.Check21);
			this.panelmenu2.Font = new global::System.Drawing.Font("Tahoma", 8.25f);
			this.panelmenu2.Location = new global::System.Drawing.Point(218, 115);
			this.panelmenu2.Name = "panelmenu2";
			this.panelmenu2.Size = new global::System.Drawing.Size(211, 87);
			this.panelmenu2.TabIndex = 60;
			this.panelmenu2.Visible = false;
			this.Check22.AutoSize = true;
			this.Check22.Checked = true;
			this.Check22.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check22.Location = new global::System.Drawing.Point(12, 35);
			this.Check22.Name = "Check22";
			this.Check22.Size = new global::System.Drawing.Size(15, 14);
			this.Check22.TabIndex = 1;
			this.Check23.AutoSize = true;
			this.Check23.Location = new global::System.Drawing.Point(12, 58);
			this.Check23.Name = "Check23";
			this.Check23.Size = new global::System.Drawing.Size(15, 14);
			this.Check23.TabIndex = 14;
			this.Check21.AutoSize = true;
			this.Check21.Checked = true;
			this.Check21.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check21.Location = new global::System.Drawing.Point(12, 12);
			this.Check21.Name = "Check21";
			this.Check21.Size = new global::System.Drawing.Size(15, 14);
			this.Check21.TabIndex = 8;
			this.RestoreContextMenu14.Location = new global::System.Drawing.Point(2, 328);
			this.RestoreContextMenu14.Name = "RestoreContextMenu14";
			this.RestoreContextMenu14.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu14.TabIndex = 192;
			this.RestoreContextMenu14.UseVisualStyleBackColor = true;
			this.RestoreContextMenu14.Click += new global::System.EventHandler(this.RestoreContextMenu14_Click);
			this.panelmenu1.BackColor = global::System.Drawing.Color.Transparent;
			this.panelmenu1.Controls.Add(this.Check1);
			this.panelmenu1.Controls.Add(this.Check2);
			this.panelmenu1.Controls.Add(this.Check3);
			this.panelmenu1.Controls.Add(this.Check4);
			this.panelmenu1.Controls.Add(this.Check5);
			this.panelmenu1.Controls.Add(this.Check6);
			this.panelmenu1.Controls.Add(this.Check7);
			this.panelmenu1.Controls.Add(this.Check8);
			this.panelmenu1.Controls.Add(this.Check9);
			this.panelmenu1.Font = new global::System.Drawing.Font("Tahoma", 8.25f);
			this.panelmenu1.Location = new global::System.Drawing.Point(216, 69);
			this.panelmenu1.Name = "panelmenu1";
			this.panelmenu1.Size = new global::System.Drawing.Size(217, 225);
			this.panelmenu1.TabIndex = 58;
			this.panelmenu1.Visible = false;
			this.Check1.AutoSize = true;
			this.Check1.Location = new global::System.Drawing.Point(12, 12);
			this.Check1.Name = "Check1";
			this.Check1.Size = new global::System.Drawing.Size(15, 14);
			this.Check1.TabIndex = 8;
			this.Check2.AutoSize = true;
			this.Check2.Checked = true;
			this.Check2.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check2.Location = new global::System.Drawing.Point(12, 35);
			this.Check2.Name = "Check2";
			this.Check2.Size = new global::System.Drawing.Size(15, 14);
			this.Check2.TabIndex = 1;
			this.Check3.AutoSize = true;
			this.Check3.Checked = true;
			this.Check3.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check3.Location = new global::System.Drawing.Point(12, 58);
			this.Check3.Name = "Check3";
			this.Check3.Size = new global::System.Drawing.Size(15, 14);
			this.Check3.TabIndex = 14;
			this.Check4.AutoSize = true;
			this.Check4.Checked = true;
			this.Check4.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check4.Location = new global::System.Drawing.Point(12, 81);
			this.Check4.Name = "Check4";
			this.Check4.Size = new global::System.Drawing.Size(15, 14);
			this.Check4.TabIndex = 3;
			this.Check5.AutoSize = true;
			this.Check5.Checked = true;
			this.Check5.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check5.Location = new global::System.Drawing.Point(12, 104);
			this.Check5.Name = "Check5";
			this.Check5.Size = new global::System.Drawing.Size(15, 14);
			this.Check5.TabIndex = 5;
			this.Check6.AutoSize = true;
			this.Check6.Location = new global::System.Drawing.Point(12, 127);
			this.Check6.Name = "Check6";
			this.Check6.Size = new global::System.Drawing.Size(15, 14);
			this.Check6.TabIndex = 6;
			this.Check7.AutoSize = true;
			this.Check7.Checked = true;
			this.Check7.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check7.Location = new global::System.Drawing.Point(12, 150);
			this.Check7.Name = "Check7";
			this.Check7.Size = new global::System.Drawing.Size(15, 14);
			this.Check7.TabIndex = 2;
			this.Check8.AutoSize = true;
			this.Check8.Checked = true;
			this.Check8.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check8.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.Check8.Location = new global::System.Drawing.Point(12, 173);
			this.Check8.Name = "Check8";
			this.Check8.Size = new global::System.Drawing.Size(15, 14);
			this.Check8.TabIndex = 7;
			this.Check9.AutoSize = true;
			this.Check9.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.Check9.Location = new global::System.Drawing.Point(12, 196);
			this.Check9.Name = "Check9";
			this.Check9.Size = new global::System.Drawing.Size(15, 14);
			this.Check9.TabIndex = 15;
			this.RestoreContextMenu13.Location = new global::System.Drawing.Point(2, 305);
			this.RestoreContextMenu13.Name = "RestoreContextMenu13";
			this.RestoreContextMenu13.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu13.TabIndex = 191;
			this.RestoreContextMenu13.UseVisualStyleBackColor = true;
			this.RestoreContextMenu13.Click += new global::System.EventHandler(this.RestoreContextMenu13_Click);
			this.linkmenu4.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.linkmenu4.LinkBehavior = global::System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkmenu4.LinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.linkmenu4.Location = new global::System.Drawing.Point(343, 373);
			this.linkmenu4.Name = "linkmenu4";
			this.linkmenu4.Size = new global::System.Drawing.Size(68, 13);
			this.linkmenu4.TabIndex = 29;
			this.linkmenu4.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.RestoreContextMenu12.Location = new global::System.Drawing.Point(2, 282);
			this.RestoreContextMenu12.Name = "RestoreContextMenu12";
			this.RestoreContextMenu12.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu12.TabIndex = 190;
			this.RestoreContextMenu12.UseVisualStyleBackColor = true;
			this.RestoreContextMenu12.Click += new global::System.EventHandler(this.RestoreContextMenu12_Click);
			this.linkmenu2.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.linkmenu2.LinkBehavior = global::System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkmenu2.LinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.linkmenu2.Location = new global::System.Drawing.Point(287, 97);
			this.linkmenu2.Name = "linkmenu2";
			this.linkmenu2.Size = new global::System.Drawing.Size(68, 13);
			this.linkmenu2.TabIndex = 8;
			this.linkmenu2.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.RestoreContextMenu11.Location = new global::System.Drawing.Point(2, 259);
			this.RestoreContextMenu11.Name = "RestoreContextMenu11";
			this.RestoreContextMenu11.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu11.TabIndex = 189;
			this.RestoreContextMenu11.UseVisualStyleBackColor = true;
			this.RestoreContextMenu11.Click += new global::System.EventHandler(this.RestoreContextMenu11_Click);
			this.linkmenu3.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.linkmenu3.LinkBehavior = global::System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkmenu3.LinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.linkmenu3.Location = new global::System.Drawing.Point(283, 350);
			this.linkmenu3.Name = "linkmenu3";
			this.linkmenu3.Size = new global::System.Drawing.Size(68, 13);
			this.linkmenu3.TabIndex = 27;
			this.linkmenu3.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.RestoreContextMenu10.Location = new global::System.Drawing.Point(2, 236);
			this.RestoreContextMenu10.Name = "RestoreContextMenu10";
			this.RestoreContextMenu10.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu10.TabIndex = 188;
			this.RestoreContextMenu10.UseVisualStyleBackColor = true;
			this.RestoreContextMenu10.Click += new global::System.EventHandler(this.RestoreContextMenu10_Click);
			this.linkmenu1.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.linkmenu1.LinkBehavior = global::System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkmenu1.LinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.linkmenu1.Location = new global::System.Drawing.Point(292, 51);
			this.linkmenu1.Name = "linkmenu1";
			this.linkmenu1.Size = new global::System.Drawing.Size(68, 13);
			this.linkmenu1.TabIndex = 5;
			this.linkmenu1.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.RestoreContextMenu9.Location = new global::System.Drawing.Point(2, 213);
			this.RestoreContextMenu9.Name = "RestoreContextMenu9";
			this.RestoreContextMenu9.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu9.TabIndex = 187;
			this.RestoreContextMenu9.UseVisualStyleBackColor = true;
			this.RestoreContextMenu9.Click += new global::System.EventHandler(this.RestoreContextMenu9_Click);
			this.RestoreContextMenu8.Location = new global::System.Drawing.Point(2, 190);
			this.RestoreContextMenu8.Name = "RestoreContextMenu8";
			this.RestoreContextMenu8.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu8.TabIndex = 186;
			this.RestoreContextMenu8.UseVisualStyleBackColor = true;
			this.RestoreContextMenu8.Click += new global::System.EventHandler(this.RestoreContextMenu8_Click);
			this.Shift1.AutoSize = true;
			this.Shift1.Location = new global::System.Drawing.Point(348, 27);
			this.Shift1.Name = "Shift1";
			this.Shift1.Size = new global::System.Drawing.Size(15, 14);
			this.Shift1.TabIndex = 3;
			this.RestoreContextMenu7.Location = new global::System.Drawing.Point(2, 167);
			this.RestoreContextMenu7.Name = "RestoreContextMenu7";
			this.RestoreContextMenu7.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu7.TabIndex = 185;
			this.RestoreContextMenu7.UseVisualStyleBackColor = true;
			this.RestoreContextMenu7.Click += new global::System.EventHandler(this.RestoreContextMenu7_Click);
			this.RestoreContextMenu6.Location = new global::System.Drawing.Point(2, 144);
			this.RestoreContextMenu6.Name = "RestoreContextMenu6";
			this.RestoreContextMenu6.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu6.TabIndex = 184;
			this.RestoreContextMenu6.UseVisualStyleBackColor = true;
			this.RestoreContextMenu6.Click += new global::System.EventHandler(this.RestoreContextMenu6_Click);
			this.RestoreContextMenu5.Location = new global::System.Drawing.Point(2, 121);
			this.RestoreContextMenu5.Name = "RestoreContextMenu5";
			this.RestoreContextMenu5.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu5.TabIndex = 183;
			this.RestoreContextMenu5.UseVisualStyleBackColor = true;
			this.RestoreContextMenu5.Click += new global::System.EventHandler(this.RestoreContextMenu5_Click);
			this.RestoreContextMenu4.Location = new global::System.Drawing.Point(2, 98);
			this.RestoreContextMenu4.Name = "RestoreContextMenu4";
			this.RestoreContextMenu4.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu4.TabIndex = 182;
			this.RestoreContextMenu4.UseVisualStyleBackColor = true;
			this.RestoreContextMenu4.Click += new global::System.EventHandler(this.RestoreContextMenu4_Click);
			this.RestoreContextMenu3.Location = new global::System.Drawing.Point(2, 75);
			this.RestoreContextMenu3.Name = "RestoreContextMenu3";
			this.RestoreContextMenu3.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu3.TabIndex = 181;
			this.RestoreContextMenu3.UseVisualStyleBackColor = true;
			this.RestoreContextMenu3.Click += new global::System.EventHandler(this.RestoreContextMenu3_Click);
			this.Shift2.AutoSize = true;
			this.Shift2.Location = new global::System.Drawing.Point(328, 119);
			this.Shift2.Name = "Shift2";
			this.Shift2.Size = new global::System.Drawing.Size(15, 14);
			this.Shift2.TabIndex = 10;
			this.RestoreContextMenu2.Location = new global::System.Drawing.Point(2, 52);
			this.RestoreContextMenu2.Name = "RestoreContextMenu2";
			this.RestoreContextMenu2.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu2.TabIndex = 180;
			this.RestoreContextMenu2.UseVisualStyleBackColor = true;
			this.RestoreContextMenu2.Click += new global::System.EventHandler(this.RestoreContextMenu2_Click);
			this.RestoreContextMenu1.Location = new global::System.Drawing.Point(2, 29);
			this.RestoreContextMenu1.Name = "RestoreContextMenu1";
			this.RestoreContextMenu1.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreContextMenu1.TabIndex = 179;
			this.RestoreContextMenu1.UseVisualStyleBackColor = true;
			this.RestoreContextMenu1.Click += new global::System.EventHandler(this.RestoreContextMenu1_Click);
			this.Shift4.AutoSize = true;
			this.Shift4.Location = new global::System.Drawing.Point(335, 165);
			this.Shift4.Name = "Shift4";
			this.Shift4.Size = new global::System.Drawing.Size(15, 14);
			this.Shift4.TabIndex = 14;
			this.ContextMenu7.AutoSize = true;
			this.ContextMenu7.Location = new global::System.Drawing.Point(23, 165);
			this.ContextMenu7.Name = "ContextMenu7";
			this.ContextMenu7.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu7.TabIndex = 13;
			this.Shift5.AutoSize = true;
			this.Shift5.Location = new global::System.Drawing.Point(355, 188);
			this.Shift5.Name = "Shift5";
			this.Shift5.Size = new global::System.Drawing.Size(15, 14);
			this.Shift5.TabIndex = 16;
			this.ContextMenu8.AutoSize = true;
			this.ContextMenu8.Location = new global::System.Drawing.Point(23, 188);
			this.ContextMenu8.Name = "ContextMenu8";
			this.ContextMenu8.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu8.TabIndex = 15;
			this.Shift8.AutoSize = true;
			this.Shift8.Location = new global::System.Drawing.Point(310, 257);
			this.Shift8.Name = "Shift8";
			this.Shift8.Size = new global::System.Drawing.Size(15, 14);
			this.Shift8.TabIndex = 22;
			this.ContextMenu13.AutoSize = true;
			this.ContextMenu13.Location = new global::System.Drawing.Point(23, 303);
			this.ContextMenu13.Name = "ContextMenu13";
			this.ContextMenu13.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu13.TabIndex = 24;
			this.ContextMenu14.AutoSize = true;
			this.ContextMenu14.Location = new global::System.Drawing.Point(23, 326);
			this.ContextMenu14.Name = "ContextMenu14";
			this.ContextMenu14.Size = new global::System.Drawing.Size(15, 14);
			this.ContextMenu14.TabIndex = 25;
			this.MainPanel3.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel3.Controls.Add(this.panelmenu6);
			this.MainPanel3.Controls.Add(this.panelmenu5);
			this.MainPanel3.Controls.Add(this.linkmenu5);
			this.MainPanel3.Controls.Add(this.checkAll3);
			this.MainPanel3.Controls.Add(this.RestoreInterface17);
			this.MainPanel3.Controls.Add(this.RestoreInterface16);
			this.MainPanel3.Controls.Add(this.RestoreInterface15);
			this.MainPanel3.Controls.Add(this.Interface1);
			this.MainPanel3.Controls.Add(this.RestoreInterface14);
			this.MainPanel3.Controls.Add(this.Interface2);
			this.MainPanel3.Controls.Add(this.RestoreInterface13);
			this.MainPanel3.Controls.Add(this.Interface3);
			this.MainPanel3.Controls.Add(this.RestoreInterface12);
			this.MainPanel3.Controls.Add(this.Interface4);
			this.MainPanel3.Controls.Add(this.RestoreInterface11);
			this.MainPanel3.Controls.Add(this.InterfaceFolder);
			this.MainPanel3.Controls.Add(this.RestoreInterface10);
			this.MainPanel3.Controls.Add(this.Interface5);
			this.MainPanel3.Controls.Add(this.RestoreInterface9);
			this.MainPanel3.Controls.Add(this.Interface6);
			this.MainPanel3.Controls.Add(this.RestoreInterface8);
			this.MainPanel3.Controls.Add(this.Interface7);
			this.MainPanel3.Controls.Add(this.RestoreInterface7);
			this.MainPanel3.Controls.Add(this.Interface8);
			this.MainPanel3.Controls.Add(this.RestoreInterface6);
			this.MainPanel3.Controls.Add(this.Interface9);
			this.MainPanel3.Controls.Add(this.RestoreInterface5);
			this.MainPanel3.Controls.Add(this.Interface10);
			this.MainPanel3.Controls.Add(this.RestoreInterface4);
			this.MainPanel3.Controls.Add(this.Interface11);
			this.MainPanel3.Controls.Add(this.RestoreInterface3);
			this.MainPanel3.Controls.Add(this.linkmenu6);
			this.MainPanel3.Controls.Add(this.RestoreInterface2);
			this.MainPanel3.Controls.Add(this.Interface12);
			this.MainPanel3.Controls.Add(this.RestoreInterface1);
			this.MainPanel3.Controls.Add(this.Interface13);
			this.MainPanel3.Controls.Add(this.Interface14);
			this.MainPanel3.Controls.Add(this.Interface15);
			this.MainPanel3.Controls.Add(this.Interface16);
			this.MainPanel3.Controls.Add(this.Interface17);
			this.MainPanel3.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel3.Name = "MainPanel3";
			this.MainPanel3.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel3.TabIndex = 26;
			this.panelmenu6.BackColor = global::System.Drawing.Color.Transparent;
			this.panelmenu6.Controls.Add(this.Check70);
			this.panelmenu6.Controls.Add(this.Check69);
			this.panelmenu6.Controls.Add(this.Check68);
			this.panelmenu6.Controls.Add(this.Check67);
			this.panelmenu6.Controls.Add(this.Check66);
			this.panelmenu6.Controls.Add(this.Check65);
			this.panelmenu6.Controls.Add(this.Check64);
			this.panelmenu6.Controls.Add(this.Check63);
			this.panelmenu6.Controls.Add(this.Check62);
			this.panelmenu6.Controls.Add(this.Check61);
			this.panelmenu6.Font = new global::System.Drawing.Font("Tahoma", 8.25f);
			this.panelmenu6.Location = new global::System.Drawing.Point(156, 30);
			this.panelmenu6.Name = "panelmenu6";
			this.panelmenu6.Size = new global::System.Drawing.Size(280, 248);
			this.panelmenu6.TabIndex = 77;
			this.panelmenu6.Visible = false;
			this.Check70.AutoSize = true;
			this.Check70.Checked = true;
			this.Check70.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check70.Location = new global::System.Drawing.Point(12, 219);
			this.Check70.Name = "Check70";
			this.Check70.Size = new global::System.Drawing.Size(15, 14);
			this.Check70.TabIndex = 19;
			this.Check69.AutoSize = true;
			this.Check69.Checked = true;
			this.Check69.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check69.Location = new global::System.Drawing.Point(12, 196);
			this.Check69.Name = "Check69";
			this.Check69.Size = new global::System.Drawing.Size(15, 14);
			this.Check69.TabIndex = 18;
			this.Check68.AutoSize = true;
			this.Check68.Checked = true;
			this.Check68.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check68.Location = new global::System.Drawing.Point(12, 173);
			this.Check68.Name = "Check68";
			this.Check68.Size = new global::System.Drawing.Size(15, 14);
			this.Check68.TabIndex = 17;
			this.Check67.AutoSize = true;
			this.Check67.Checked = true;
			this.Check67.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check67.Location = new global::System.Drawing.Point(12, 150);
			this.Check67.Name = "Check67";
			this.Check67.Size = new global::System.Drawing.Size(15, 14);
			this.Check67.TabIndex = 16;
			this.Check66.AutoSize = true;
			this.Check66.Checked = true;
			this.Check66.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check66.Location = new global::System.Drawing.Point(12, 127);
			this.Check66.Name = "Check66";
			this.Check66.Size = new global::System.Drawing.Size(15, 14);
			this.Check66.TabIndex = 15;
			this.Check65.AutoSize = true;
			this.Check65.Checked = true;
			this.Check65.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check65.Location = new global::System.Drawing.Point(12, 104);
			this.Check65.Name = "Check65";
			this.Check65.Size = new global::System.Drawing.Size(15, 14);
			this.Check65.TabIndex = 5;
			this.Check64.AutoSize = true;
			this.Check64.Checked = true;
			this.Check64.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check64.Location = new global::System.Drawing.Point(12, 81);
			this.Check64.Name = "Check64";
			this.Check64.Size = new global::System.Drawing.Size(15, 14);
			this.Check64.TabIndex = 3;
			this.Check63.AutoSize = true;
			this.Check63.Checked = true;
			this.Check63.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check63.Location = new global::System.Drawing.Point(12, 58);
			this.Check63.Name = "Check63";
			this.Check63.Size = new global::System.Drawing.Size(15, 14);
			this.Check63.TabIndex = 14;
			this.Check62.AutoSize = true;
			this.Check62.Checked = true;
			this.Check62.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check62.Location = new global::System.Drawing.Point(12, 35);
			this.Check62.Name = "Check62";
			this.Check62.Size = new global::System.Drawing.Size(15, 14);
			this.Check62.TabIndex = 1;
			this.Check61.AutoSize = true;
			this.Check61.Checked = true;
			this.Check61.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check61.Location = new global::System.Drawing.Point(12, 12);
			this.Check61.Name = "Check61";
			this.Check61.Size = new global::System.Drawing.Size(15, 14);
			this.Check61.TabIndex = 8;
			this.panelmenu5.BackColor = global::System.Drawing.Color.Transparent;
			this.panelmenu5.Controls.Add(this.Check56);
			this.panelmenu5.Controls.Add(this.Check55);
			this.panelmenu5.Controls.Add(this.Check54);
			this.panelmenu5.Controls.Add(this.Check53);
			this.panelmenu5.Controls.Add(this.Check52);
			this.panelmenu5.Controls.Add(this.Check51);
			this.panelmenu5.Font = new global::System.Drawing.Font("Tahoma", 8.25f);
			this.panelmenu5.Location = new global::System.Drawing.Point(71, 136);
			this.panelmenu5.Name = "panelmenu5";
			this.panelmenu5.Size = new global::System.Drawing.Size(174, 156);
			this.panelmenu5.TabIndex = 78;
			this.panelmenu5.Visible = false;
			this.Check56.AutoSize = true;
			this.Check56.Checked = true;
			this.Check56.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check56.Location = new global::System.Drawing.Point(12, 127);
			this.Check56.Name = "Check56";
			this.Check56.Size = new global::System.Drawing.Size(15, 14);
			this.Check56.TabIndex = 15;
			this.Check55.AutoSize = true;
			this.Check55.Checked = true;
			this.Check55.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check55.Location = new global::System.Drawing.Point(12, 104);
			this.Check55.Name = "Check55";
			this.Check55.Size = new global::System.Drawing.Size(15, 14);
			this.Check55.TabIndex = 5;
			this.Check54.AutoSize = true;
			this.Check54.Checked = true;
			this.Check54.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check54.Location = new global::System.Drawing.Point(12, 81);
			this.Check54.Name = "Check54";
			this.Check54.Size = new global::System.Drawing.Size(15, 14);
			this.Check54.TabIndex = 3;
			this.Check53.AutoSize = true;
			this.Check53.Checked = true;
			this.Check53.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check53.Location = new global::System.Drawing.Point(12, 58);
			this.Check53.Name = "Check53";
			this.Check53.Size = new global::System.Drawing.Size(15, 14);
			this.Check53.TabIndex = 14;
			this.Check52.AutoSize = true;
			this.Check52.Checked = true;
			this.Check52.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check52.Location = new global::System.Drawing.Point(12, 35);
			this.Check52.Name = "Check52";
			this.Check52.Size = new global::System.Drawing.Size(15, 14);
			this.Check52.TabIndex = 1;
			this.Check51.AutoSize = true;
			this.Check51.Checked = true;
			this.Check51.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.Check51.Location = new global::System.Drawing.Point(12, 12);
			this.Check51.Name = "Check51";
			this.Check51.Size = new global::System.Drawing.Size(15, 14);
			this.Check51.TabIndex = 8;
			this.linkmenu5.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.linkmenu5.LinkBehavior = global::System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkmenu5.LinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.linkmenu5.Location = new global::System.Drawing.Point(338, 8);
			this.linkmenu5.Name = "linkmenu5";
			this.linkmenu5.Size = new global::System.Drawing.Size(68, 13);
			this.linkmenu5.TabIndex = 213;
			this.linkmenu5.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.checkAll3.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.checkAll3.AutoSize = true;
			this.checkAll3.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checkAll3.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.checkAll3.LinkColor = global::System.Drawing.Color.White;
			this.checkAll3.Location = new global::System.Drawing.Point(3, 0);
			this.checkAll3.Name = "checkAll3";
			this.checkAll3.Size = new global::System.Drawing.Size(0, 13);
			this.checkAll3.TabIndex = 1;
			this.checkAll3.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel3_LinkClicked);
			this.RestoreInterface17.Location = new global::System.Drawing.Point(2, 397);
			this.RestoreInterface17.Name = "RestoreInterface17";
			this.RestoreInterface17.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface17.TabIndex = 212;
			this.RestoreInterface17.UseVisualStyleBackColor = true;
			this.RestoreInterface17.Click += new global::System.EventHandler(this.RestoreInterface17_Click);
			this.RestoreInterface16.Location = new global::System.Drawing.Point(2, 374);
			this.RestoreInterface16.Name = "RestoreInterface16";
			this.RestoreInterface16.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface16.TabIndex = 211;
			this.RestoreInterface16.UseVisualStyleBackColor = true;
			this.RestoreInterface16.Click += new global::System.EventHandler(this.RestoreInterface16_Click);
			this.RestoreInterface15.Location = new global::System.Drawing.Point(2, 351);
			this.RestoreInterface15.Name = "RestoreInterface15";
			this.RestoreInterface15.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface15.TabIndex = 210;
			this.RestoreInterface15.UseVisualStyleBackColor = true;
			this.RestoreInterface15.Click += new global::System.EventHandler(this.RestoreInterface15_Click);
			this.Interface1.AutoSize = true;
			this.Interface1.Location = new global::System.Drawing.Point(23, 27);
			this.Interface1.Name = "Interface1";
			this.Interface1.Size = new global::System.Drawing.Size(15, 14);
			this.Interface1.TabIndex = 2;
			this.RestoreInterface14.Location = new global::System.Drawing.Point(2, 328);
			this.RestoreInterface14.Name = "RestoreInterface14";
			this.RestoreInterface14.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface14.TabIndex = 209;
			this.RestoreInterface14.UseVisualStyleBackColor = true;
			this.RestoreInterface14.Click += new global::System.EventHandler(this.RestoreInterface14_Click);
			this.Interface2.AutoSize = true;
			this.Interface2.Location = new global::System.Drawing.Point(23, 50);
			this.Interface2.Name = "Interface2";
			this.Interface2.Size = new global::System.Drawing.Size(15, 14);
			this.Interface2.TabIndex = 3;
			this.RestoreInterface13.Location = new global::System.Drawing.Point(2, 305);
			this.RestoreInterface13.Name = "RestoreInterface13";
			this.RestoreInterface13.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface13.TabIndex = 208;
			this.RestoreInterface13.UseVisualStyleBackColor = true;
			this.RestoreInterface13.Click += new global::System.EventHandler(this.RestoreInterface13_Click);
			this.Interface3.AutoSize = true;
			this.Interface3.Location = new global::System.Drawing.Point(23, 73);
			this.Interface3.Name = "Interface3";
			this.Interface3.Size = new global::System.Drawing.Size(15, 14);
			this.Interface3.TabIndex = 4;
			this.RestoreInterface12.Location = new global::System.Drawing.Point(2, 282);
			this.RestoreInterface12.Name = "RestoreInterface12";
			this.RestoreInterface12.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface12.TabIndex = 207;
			this.RestoreInterface12.UseVisualStyleBackColor = true;
			this.RestoreInterface12.Click += new global::System.EventHandler(this.RestoreInterface12_Click);
			this.Interface4.AutoSize = true;
			this.Interface4.Location = new global::System.Drawing.Point(23, 96);
			this.Interface4.Name = "Interface4";
			this.Interface4.Size = new global::System.Drawing.Size(15, 14);
			this.Interface4.TabIndex = 5;
			this.RestoreInterface11.Location = new global::System.Drawing.Point(2, 259);
			this.RestoreInterface11.Name = "RestoreInterface11";
			this.RestoreInterface11.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface11.TabIndex = 206;
			this.RestoreInterface11.UseVisualStyleBackColor = true;
			this.RestoreInterface11.Click += new global::System.EventHandler(this.RestoreInterface11_Click);
			this.InterfaceFolder.AutoSize = true;
			this.InterfaceFolder.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.InterfaceFolder.ForeColor = global::System.Drawing.Color.White;
			this.InterfaceFolder.Location = new global::System.Drawing.Point(294, 96);
			this.InterfaceFolder.Name = "InterfaceFolder";
			this.InterfaceFolder.Size = new global::System.Drawing.Size(15, 14);
			this.InterfaceFolder.TabIndex = 5;
			this.InterfaceFolder.UseVisualStyleBackColor = false;
			this.RestoreInterface10.Location = new global::System.Drawing.Point(2, 236);
			this.RestoreInterface10.Name = "RestoreInterface10";
			this.RestoreInterface10.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface10.TabIndex = 205;
			this.RestoreInterface10.UseVisualStyleBackColor = true;
			this.RestoreInterface10.Click += new global::System.EventHandler(this.RestoreInterface10_Click);
			this.Interface5.AutoSize = true;
			this.Interface5.Location = new global::System.Drawing.Point(23, 119);
			this.Interface5.Name = "Interface5";
			this.Interface5.Size = new global::System.Drawing.Size(15, 14);
			this.Interface5.TabIndex = 6;
			this.RestoreInterface9.Location = new global::System.Drawing.Point(2, 213);
			this.RestoreInterface9.Name = "RestoreInterface9";
			this.RestoreInterface9.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface9.TabIndex = 204;
			this.RestoreInterface9.UseVisualStyleBackColor = true;
			this.RestoreInterface9.Click += new global::System.EventHandler(this.RestoreInterface9_Click);
			this.Interface6.AutoSize = true;
			this.Interface6.Location = new global::System.Drawing.Point(23, 142);
			this.Interface6.Name = "Interface6";
			this.Interface6.Size = new global::System.Drawing.Size(15, 14);
			this.Interface6.TabIndex = 7;
			this.RestoreInterface8.Location = new global::System.Drawing.Point(2, 190);
			this.RestoreInterface8.Name = "RestoreInterface8";
			this.RestoreInterface8.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface8.TabIndex = 203;
			this.RestoreInterface8.UseVisualStyleBackColor = true;
			this.RestoreInterface8.Click += new global::System.EventHandler(this.RestoreInterface8_Click);
			this.Interface7.AutoSize = true;
			this.Interface7.Location = new global::System.Drawing.Point(23, 165);
			this.Interface7.Name = "Interface7";
			this.Interface7.Size = new global::System.Drawing.Size(15, 14);
			this.Interface7.TabIndex = 8;
			this.RestoreInterface7.Location = new global::System.Drawing.Point(2, 167);
			this.RestoreInterface7.Name = "RestoreInterface7";
			this.RestoreInterface7.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface7.TabIndex = 202;
			this.RestoreInterface7.UseVisualStyleBackColor = true;
			this.RestoreInterface7.Click += new global::System.EventHandler(this.RestoreInterface7_Click);
			this.Interface8.AutoSize = true;
			this.Interface8.Location = new global::System.Drawing.Point(23, 188);
			this.Interface8.Name = "Interface8";
			this.Interface8.Size = new global::System.Drawing.Size(15, 14);
			this.Interface8.TabIndex = 9;
			this.RestoreInterface6.Location = new global::System.Drawing.Point(2, 144);
			this.RestoreInterface6.Name = "RestoreInterface6";
			this.RestoreInterface6.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface6.TabIndex = 201;
			this.RestoreInterface6.UseVisualStyleBackColor = true;
			this.RestoreInterface6.Click += new global::System.EventHandler(this.RestoreInterface6_Click);
			this.Interface9.AutoSize = true;
			this.Interface9.Location = new global::System.Drawing.Point(23, 211);
			this.Interface9.Name = "Interface9";
			this.Interface9.Size = new global::System.Drawing.Size(15, 14);
			this.Interface9.TabIndex = 10;
			this.RestoreInterface5.Location = new global::System.Drawing.Point(2, 121);
			this.RestoreInterface5.Name = "RestoreInterface5";
			this.RestoreInterface5.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface5.TabIndex = 200;
			this.RestoreInterface5.UseVisualStyleBackColor = true;
			this.RestoreInterface5.Click += new global::System.EventHandler(this.RestoreInterface5_Click);
			this.Interface10.AutoSize = true;
			this.Interface10.Location = new global::System.Drawing.Point(23, 234);
			this.Interface10.Name = "Interface10";
			this.Interface10.Size = new global::System.Drawing.Size(15, 14);
			this.Interface10.TabIndex = 11;
			this.RestoreInterface4.Location = new global::System.Drawing.Point(2, 98);
			this.RestoreInterface4.Name = "RestoreInterface4";
			this.RestoreInterface4.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface4.TabIndex = 199;
			this.RestoreInterface4.UseVisualStyleBackColor = true;
			this.RestoreInterface4.Click += new global::System.EventHandler(this.RestoreInterface4_Click);
			this.Interface11.AutoSize = true;
			this.Interface11.Location = new global::System.Drawing.Point(23, 257);
			this.Interface11.Name = "Interface11";
			this.Interface11.Size = new global::System.Drawing.Size(15, 14);
			this.Interface11.TabIndex = 12;
			this.RestoreInterface3.Location = new global::System.Drawing.Point(2, 75);
			this.RestoreInterface3.Name = "RestoreInterface3";
			this.RestoreInterface3.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface3.TabIndex = 198;
			this.RestoreInterface3.UseVisualStyleBackColor = true;
			this.RestoreInterface3.Click += new global::System.EventHandler(this.RestoreInterface3_Click);
			this.linkmenu6.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.linkmenu6.LinkBehavior = global::System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkmenu6.LinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.linkmenu6.Location = new global::System.Drawing.Point(290, 286);
			this.linkmenu6.Name = "linkmenu6";
			this.linkmenu6.Size = new global::System.Drawing.Size(68, 13);
			this.linkmenu6.TabIndex = 14;
			this.linkmenu6.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.RestoreInterface2.Location = new global::System.Drawing.Point(2, 52);
			this.RestoreInterface2.Name = "RestoreInterface2";
			this.RestoreInterface2.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface2.TabIndex = 197;
			this.RestoreInterface2.UseVisualStyleBackColor = true;
			this.RestoreInterface2.Click += new global::System.EventHandler(this.RestoreInterface2_Click);
			this.Interface12.AutoSize = true;
			this.Interface12.Location = new global::System.Drawing.Point(23, 280);
			this.Interface12.Name = "Interface12";
			this.Interface12.Size = new global::System.Drawing.Size(15, 14);
			this.Interface12.TabIndex = 13;
			this.RestoreInterface1.Location = new global::System.Drawing.Point(2, 29);
			this.RestoreInterface1.Name = "RestoreInterface1";
			this.RestoreInterface1.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreInterface1.TabIndex = 196;
			this.RestoreInterface1.UseVisualStyleBackColor = true;
			this.RestoreInterface1.Click += new global::System.EventHandler(this.RestoreInterface1_Click);
			this.Interface13.AutoSize = true;
			this.Interface13.Location = new global::System.Drawing.Point(23, 303);
			this.Interface13.Name = "Interface13";
			this.Interface13.Size = new global::System.Drawing.Size(15, 14);
			this.Interface13.TabIndex = 15;
			this.Interface14.AutoSize = true;
			this.Interface14.Location = new global::System.Drawing.Point(23, 326);
			this.Interface14.Name = "Interface14";
			this.Interface14.Size = new global::System.Drawing.Size(15, 14);
			this.Interface14.TabIndex = 16;
			this.Interface15.AutoSize = true;
			this.Interface15.Location = new global::System.Drawing.Point(23, 349);
			this.Interface15.Name = "Interface15";
			this.Interface15.Size = new global::System.Drawing.Size(15, 14);
			this.Interface15.TabIndex = 17;
			this.Interface16.AutoSize = true;
			this.Interface16.Location = new global::System.Drawing.Point(23, 372);
			this.Interface16.Name = "Interface16";
			this.Interface16.Size = new global::System.Drawing.Size(15, 14);
			this.Interface16.TabIndex = 18;
			this.Interface17.AutoSize = true;
			this.Interface17.Location = new global::System.Drawing.Point(23, 395);
			this.Interface17.Name = "Interface17";
			this.Interface17.Size = new global::System.Drawing.Size(15, 14);
			this.Interface17.TabIndex = 19;
			this.System14.AutoSize = true;
			this.System14.ForeColor = global::System.Drawing.Color.White;
			this.System14.Location = new global::System.Drawing.Point(23, 326);
			this.System14.Name = "System14";
			this.System14.Size = new global::System.Drawing.Size(15, 14);
			this.System14.TabIndex = 1;
			this.System15.AutoSize = true;
			this.System15.ForeColor = global::System.Drawing.Color.White;
			this.System15.Location = new global::System.Drawing.Point(23, 349);
			this.System15.Name = "System15";
			this.System15.Size = new global::System.Drawing.Size(15, 14);
			this.System15.TabIndex = 1;
			this.MainPanel4.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel4.Controls.Add(this.RestoreSystem17);
			this.MainPanel4.Controls.Add(this.System1);
			this.MainPanel4.Controls.Add(this.RestoreSystem16);
			this.MainPanel4.Controls.Add(this.System2);
			this.MainPanel4.Controls.Add(this.RestoreSystem15);
			this.MainPanel4.Controls.Add(this.System3);
			this.MainPanel4.Controls.Add(this.RestoreSystem14);
			this.MainPanel4.Controls.Add(this.System4);
			this.MainPanel4.Controls.Add(this.RestoreSystem13);
			this.MainPanel4.Controls.Add(this.System5);
			this.MainPanel4.Controls.Add(this.RestoreSystem12);
			this.MainPanel4.Controls.Add(this.System6);
			this.MainPanel4.Controls.Add(this.RestoreSystem11);
			this.MainPanel4.Controls.Add(this.System7);
			this.MainPanel4.Controls.Add(this.RestoreSystem10);
			this.MainPanel4.Controls.Add(this.System8);
			this.MainPanel4.Controls.Add(this.RestoreSystem9);
			this.MainPanel4.Controls.Add(this.System9);
			this.MainPanel4.Controls.Add(this.RestoreSystem8);
			this.MainPanel4.Controls.Add(this.AntiZapret);
			this.MainPanel4.Controls.Add(this.RestoreSystem7);
			this.MainPanel4.Controls.Add(this.System10);
			this.MainPanel4.Controls.Add(this.RestoreSystem6);
			this.MainPanel4.Controls.Add(this.System11);
			this.MainPanel4.Controls.Add(this.RestoreSystem5);
			this.MainPanel4.Controls.Add(this.System12);
			this.MainPanel4.Controls.Add(this.RestoreSystem4);
			this.MainPanel4.Controls.Add(this.System13);
			this.MainPanel4.Controls.Add(this.RestoreSystem3);
			this.MainPanel4.Controls.Add(this.System14);
			this.MainPanel4.Controls.Add(this.RestoreSystem2);
			this.MainPanel4.Controls.Add(this.System15);
			this.MainPanel4.Controls.Add(this.RestoreSystem1);
			this.MainPanel4.Controls.Add(this.System16);
			this.MainPanel4.Controls.Add(this.System17);
			this.MainPanel4.Controls.Add(this.checkAll4);
			this.MainPanel4.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel4.Name = "MainPanel4";
			this.MainPanel4.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel4.TabIndex = 27;
			this.RestoreSystem17.Location = new global::System.Drawing.Point(2, 397);
			this.RestoreSystem17.Name = "RestoreSystem17";
			this.RestoreSystem17.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem17.TabIndex = 229;
			this.RestoreSystem17.UseVisualStyleBackColor = true;
			this.RestoreSystem17.Click += new global::System.EventHandler(this.RestoreSystem17_Click);
			this.System1.AutoSize = true;
			this.System1.ForeColor = global::System.Drawing.Color.White;
			this.System1.Location = new global::System.Drawing.Point(23, 27);
			this.System1.Name = "System1";
			this.System1.Size = new global::System.Drawing.Size(15, 14);
			this.System1.TabIndex = 1;
			this.RestoreSystem16.Location = new global::System.Drawing.Point(2, 374);
			this.RestoreSystem16.Name = "RestoreSystem16";
			this.RestoreSystem16.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem16.TabIndex = 228;
			this.RestoreSystem16.UseVisualStyleBackColor = true;
			this.RestoreSystem16.Click += new global::System.EventHandler(this.RestoreSystem16_Click);
			this.System2.AutoSize = true;
			this.System2.ForeColor = global::System.Drawing.Color.White;
			this.System2.Location = new global::System.Drawing.Point(23, 50);
			this.System2.Name = "System2";
			this.System2.Size = new global::System.Drawing.Size(15, 14);
			this.System2.TabIndex = 1;
			this.RestoreSystem15.Location = new global::System.Drawing.Point(2, 351);
			this.RestoreSystem15.Name = "RestoreSystem15";
			this.RestoreSystem15.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem15.TabIndex = 227;
			this.RestoreSystem15.UseVisualStyleBackColor = true;
			this.RestoreSystem15.Click += new global::System.EventHandler(this.RestoreSystem15_Click);
			this.System3.AutoSize = true;
			this.System3.ForeColor = global::System.Drawing.Color.White;
			this.System3.Location = new global::System.Drawing.Point(23, 73);
			this.System3.Name = "System3";
			this.System3.Size = new global::System.Drawing.Size(15, 14);
			this.System3.TabIndex = 1;
			this.RestoreSystem14.Location = new global::System.Drawing.Point(2, 328);
			this.RestoreSystem14.Name = "RestoreSystem14";
			this.RestoreSystem14.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem14.TabIndex = 226;
			this.RestoreSystem14.UseVisualStyleBackColor = true;
			this.RestoreSystem14.Click += new global::System.EventHandler(this.RestoreSystem14_Click);
			this.System4.AutoSize = true;
			this.System4.ForeColor = global::System.Drawing.Color.White;
			this.System4.Location = new global::System.Drawing.Point(23, 96);
			this.System4.Name = "System4";
			this.System4.Size = new global::System.Drawing.Size(15, 14);
			this.System4.TabIndex = 1;
			this.RestoreSystem13.Location = new global::System.Drawing.Point(2, 305);
			this.RestoreSystem13.Name = "RestoreSystem13";
			this.RestoreSystem13.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem13.TabIndex = 225;
			this.RestoreSystem13.UseVisualStyleBackColor = true;
			this.RestoreSystem13.Click += new global::System.EventHandler(this.RestoreSystem13_Click);
			this.System5.AutoSize = true;
			this.System5.ForeColor = global::System.Drawing.Color.White;
			this.System5.Location = new global::System.Drawing.Point(23, 119);
			this.System5.Name = "System5";
			this.System5.Size = new global::System.Drawing.Size(15, 14);
			this.System5.TabIndex = 1;
			this.RestoreSystem12.Location = new global::System.Drawing.Point(2, 282);
			this.RestoreSystem12.Name = "RestoreSystem12";
			this.RestoreSystem12.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem12.TabIndex = 224;
			this.RestoreSystem12.UseVisualStyleBackColor = true;
			this.RestoreSystem12.Click += new global::System.EventHandler(this.RestoreSystem12_Click);
			this.System6.AutoSize = true;
			this.System6.ForeColor = global::System.Drawing.Color.White;
			this.System6.Location = new global::System.Drawing.Point(23, 142);
			this.System6.Name = "System6";
			this.System6.Size = new global::System.Drawing.Size(15, 14);
			this.System6.TabIndex = 1;
			this.RestoreSystem11.Location = new global::System.Drawing.Point(2, 259);
			this.RestoreSystem11.Name = "RestoreSystem11";
			this.RestoreSystem11.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem11.TabIndex = 223;
			this.RestoreSystem11.UseVisualStyleBackColor = true;
			this.RestoreSystem11.Click += new global::System.EventHandler(this.RestoreSystem11_Click);
			this.System7.AutoSize = true;
			this.System7.ForeColor = global::System.Drawing.Color.White;
			this.System7.Location = new global::System.Drawing.Point(23, 165);
			this.System7.Name = "System7";
			this.System7.Size = new global::System.Drawing.Size(15, 14);
			this.System7.TabIndex = 1;
			this.RestoreSystem10.Location = new global::System.Drawing.Point(2, 236);
			this.RestoreSystem10.Name = "RestoreSystem10";
			this.RestoreSystem10.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem10.TabIndex = 222;
			this.RestoreSystem10.UseVisualStyleBackColor = true;
			this.RestoreSystem10.Click += new global::System.EventHandler(this.RestoreSystem10_Click);
			this.System8.AutoSize = true;
			this.System8.ForeColor = global::System.Drawing.Color.White;
			this.System8.Location = new global::System.Drawing.Point(23, 188);
			this.System8.Name = "System8";
			this.System8.Size = new global::System.Drawing.Size(15, 14);
			this.System8.TabIndex = 1;
			this.RestoreSystem9.Location = new global::System.Drawing.Point(2, 213);
			this.RestoreSystem9.Name = "RestoreSystem9";
			this.RestoreSystem9.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem9.TabIndex = 221;
			this.RestoreSystem9.UseVisualStyleBackColor = true;
			this.RestoreSystem9.Click += new global::System.EventHandler(this.RestoreSystem9_Click);
			this.System9.AutoSize = true;
			this.System9.ForeColor = global::System.Drawing.Color.White;
			this.System9.Location = new global::System.Drawing.Point(23, 211);
			this.System9.Name = "System9";
			this.System9.Size = new global::System.Drawing.Size(15, 14);
			this.System9.TabIndex = 1;
			this.RestoreSystem8.Location = new global::System.Drawing.Point(2, 190);
			this.RestoreSystem8.Name = "RestoreSystem8";
			this.RestoreSystem8.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem8.TabIndex = 220;
			this.RestoreSystem8.UseVisualStyleBackColor = true;
			this.RestoreSystem8.Click += new global::System.EventHandler(this.RestoreSystem8_Click);
			this.AntiZapret.AutoSize = true;
			this.AntiZapret.Location = new global::System.Drawing.Point(281, 234);
			this.AntiZapret.Name = "AntiZapret";
			this.AntiZapret.Size = new global::System.Drawing.Size(15, 14);
			this.AntiZapret.TabIndex = 94;
			this.RestoreSystem7.Location = new global::System.Drawing.Point(2, 167);
			this.RestoreSystem7.Name = "RestoreSystem7";
			this.RestoreSystem7.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem7.TabIndex = 219;
			this.RestoreSystem7.UseVisualStyleBackColor = true;
			this.RestoreSystem7.Click += new global::System.EventHandler(this.RestoreSystem7_Click);
			this.System10.AutoSize = true;
			this.System10.ForeColor = global::System.Drawing.Color.White;
			this.System10.Location = new global::System.Drawing.Point(23, 234);
			this.System10.Name = "System10";
			this.System10.Size = new global::System.Drawing.Size(15, 14);
			this.System10.TabIndex = 1;
			this.RestoreSystem6.Location = new global::System.Drawing.Point(2, 144);
			this.RestoreSystem6.Name = "RestoreSystem6";
			this.RestoreSystem6.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem6.TabIndex = 218;
			this.RestoreSystem6.UseVisualStyleBackColor = true;
			this.RestoreSystem6.Click += new global::System.EventHandler(this.RestoreSystem6_Click);
			this.System11.AutoSize = true;
			this.System11.ForeColor = global::System.Drawing.Color.White;
			this.System11.Location = new global::System.Drawing.Point(23, 257);
			this.System11.Name = "System11";
			this.System11.Size = new global::System.Drawing.Size(15, 14);
			this.System11.TabIndex = 1;
			this.RestoreSystem5.Location = new global::System.Drawing.Point(2, 121);
			this.RestoreSystem5.Name = "RestoreSystem5";
			this.RestoreSystem5.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem5.TabIndex = 217;
			this.RestoreSystem5.UseVisualStyleBackColor = true;
			this.RestoreSystem5.Click += new global::System.EventHandler(this.RestoreSystem5_Click);
			this.System12.AutoSize = true;
			this.System12.ForeColor = global::System.Drawing.Color.White;
			this.System12.Location = new global::System.Drawing.Point(23, 280);
			this.System12.Name = "System12";
			this.System12.Size = new global::System.Drawing.Size(15, 14);
			this.System12.TabIndex = 1;
			this.RestoreSystem4.Location = new global::System.Drawing.Point(2, 98);
			this.RestoreSystem4.Name = "RestoreSystem4";
			this.RestoreSystem4.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem4.TabIndex = 216;
			this.RestoreSystem4.UseVisualStyleBackColor = true;
			this.RestoreSystem4.Click += new global::System.EventHandler(this.RestoreSystem4_Click);
			this.System13.AutoSize = true;
			this.System13.ForeColor = global::System.Drawing.Color.White;
			this.System13.Location = new global::System.Drawing.Point(23, 303);
			this.System13.Name = "System13";
			this.System13.Size = new global::System.Drawing.Size(15, 14);
			this.System13.TabIndex = 1;
			this.RestoreSystem3.Location = new global::System.Drawing.Point(2, 75);
			this.RestoreSystem3.Name = "RestoreSystem3";
			this.RestoreSystem3.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem3.TabIndex = 215;
			this.RestoreSystem3.UseVisualStyleBackColor = true;
			this.RestoreSystem3.Click += new global::System.EventHandler(this.RestoreSystem3_Click);
			this.RestoreSystem2.Location = new global::System.Drawing.Point(2, 52);
			this.RestoreSystem2.Name = "RestoreSystem2";
			this.RestoreSystem2.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem2.TabIndex = 214;
			this.RestoreSystem2.UseVisualStyleBackColor = true;
			this.RestoreSystem2.Click += new global::System.EventHandler(this.RestoreSystem2_Click);
			this.RestoreSystem1.Location = new global::System.Drawing.Point(2, 29);
			this.RestoreSystem1.Name = "RestoreSystem1";
			this.RestoreSystem1.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreSystem1.TabIndex = 213;
			this.RestoreSystem1.UseVisualStyleBackColor = true;
			this.RestoreSystem1.Click += new global::System.EventHandler(this.RestoreSystem1_Click);
			this.System16.AutoSize = true;
			this.System16.ForeColor = global::System.Drawing.Color.White;
			this.System16.Location = new global::System.Drawing.Point(23, 372);
			this.System16.Name = "System16";
			this.System16.Size = new global::System.Drawing.Size(15, 14);
			this.System16.TabIndex = 1;
			this.System17.AutoSize = true;
			this.System17.ForeColor = global::System.Drawing.Color.White;
			this.System17.Location = new global::System.Drawing.Point(23, 395);
			this.System17.Name = "System17";
			this.System17.Size = new global::System.Drawing.Size(15, 14);
			this.System17.TabIndex = 1;
			this.checkAll4.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.checkAll4.AutoSize = true;
			this.checkAll4.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checkAll4.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.checkAll4.LinkColor = global::System.Drawing.Color.White;
			this.checkAll4.Location = new global::System.Drawing.Point(3, 0);
			this.checkAll4.Name = "checkAll4";
			this.checkAll4.Size = new global::System.Drawing.Size(0, 13);
			this.checkAll4.TabIndex = 0;
			this.checkAll4.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel4_LinkClicked);
			this.ApplyButton.AutoSize = true;
			this.ApplyButton.BackColor = global::System.Drawing.Color.Transparent;
			this.ApplyButton.Font = new global::System.Drawing.Font("Calibri", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.ApplyButton.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.ApplyButton.Location = new global::System.Drawing.Point(12, 9);
			this.ApplyButton.Name = "ApplyButton";
			this.ApplyButton.Size = new global::System.Drawing.Size(0, 15);
			this.ApplyButton.TabIndex = 29;
			this.ApplyButton.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.Header_MouseDown);
			this.tooltip.AutoPopDelay = 30000;
			this.tooltip.InitialDelay = 40;
			this.tooltip.ReshowDelay = 100;
			this.AddToApply.Location = new global::System.Drawing.Point(169, 401);
			this.AddToApply.Name = "AddToApply";
			this.AddToApply.Size = new global::System.Drawing.Size(15, 14);
			this.AddToApply.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.AddToApply.TabIndex = 196;
			this.AddToApply.TabStop = false;
			this.AddToApply.Visible = false;
			this.AddToApply.Click += new global::System.EventHandler(this.AddToApply_Click);
			this.MinimizeIcon.BackColor = global::System.Drawing.Color.Transparent;
			this.MinimizeIcon.BackgroundImage = global::Class89.Bitmap_37;
			this.MinimizeIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.MinimizeIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
			this.MinimizeIcon.FlatAppearance.BorderSize = 0;
			this.MinimizeIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
			this.MinimizeIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
			this.MinimizeIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.MinimizeIcon.Location = new global::System.Drawing.Point(549, 5);
			this.MinimizeIcon.Name = "MinimizeIcon";
			this.MinimizeIcon.Size = new global::System.Drawing.Size(22, 22);
			this.MinimizeIcon.TabIndex = 13;
			this.MinimizeIcon.UseVisualStyleBackColor = false;
			this.MinimizeIcon.Click += new global::System.EventHandler(this.MinimizeIcon_Click);
			this.PlayIcon.BackColor = global::System.Drawing.Color.Transparent;
			this.PlayIcon.BackgroundImage = global::Class89.Bitmap_44;
			this.PlayIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.PlayIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
			this.PlayIcon.FlatAppearance.BorderSize = 0;
			this.PlayIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
			this.PlayIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
			this.PlayIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.PlayIcon.Location = new global::System.Drawing.Point(584, 5);
			this.PlayIcon.Name = "PlayIcon";
			this.PlayIcon.Size = new global::System.Drawing.Size(22, 22);
			this.PlayIcon.TabIndex = 14;
			this.PlayIcon.UseVisualStyleBackColor = false;
			this.PlayIcon.Click += new global::System.EventHandler(this.PlayIcon_Click);
			this.MainPanel1.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality17);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality16);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality15);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality14);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality13);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality12);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality11);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality10);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality9);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality8);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality7);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality6);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality5);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality4);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality3);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality2);
			this.MainPanel1.Controls.Add(this.RestoreConfidentiality1);
			this.MainPanel1.Controls.Add(this.Confidentiality1);
			this.MainPanel1.Controls.Add(this.Confidentiality2);
			this.MainPanel1.Controls.Add(this.Confidentiality3);
			this.MainPanel1.Controls.Add(this.Confidentiality4);
			this.MainPanel1.Controls.Add(this.Confidentiality5);
			this.MainPanel1.Controls.Add(this.Confidentiality6);
			this.MainPanel1.Controls.Add(this.Confidentiality7);
			this.MainPanel1.Controls.Add(this.Confidentiality8);
			this.MainPanel1.Controls.Add(this.Confidentiality9);
			this.MainPanel1.Controls.Add(this.Confidentiality10);
			this.MainPanel1.Controls.Add(this.Confidentiality11);
			this.MainPanel1.Controls.Add(this.Confidentiality12);
			this.MainPanel1.Controls.Add(this.Confidentiality13);
			this.MainPanel1.Controls.Add(this.Confidentiality14);
			this.MainPanel1.Controls.Add(this.Confidentiality15);
			this.MainPanel1.Controls.Add(this.Confidentiality16);
			this.MainPanel1.Controls.Add(this.Confidentiality17);
			this.MainPanel1.Controls.Add(this.checkAll1);
			this.MainPanel1.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel1.Name = "MainPanel1";
			this.MainPanel1.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel1.TabIndex = 37;
			this.RestoreConfidentiality17.Location = new global::System.Drawing.Point(2, 397);
			this.RestoreConfidentiality17.Name = "RestoreConfidentiality17";
			this.RestoreConfidentiality17.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality17.TabIndex = 34;
			this.RestoreConfidentiality17.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality17.Click += new global::System.EventHandler(this.RestoreConfidentiality17_Click);
			this.RestoreConfidentiality16.Location = new global::System.Drawing.Point(2, 374);
			this.RestoreConfidentiality16.Name = "RestoreConfidentiality16";
			this.RestoreConfidentiality16.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality16.TabIndex = 33;
			this.RestoreConfidentiality16.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality16.Click += new global::System.EventHandler(this.RestoreConfidentiality16_Click);
			this.RestoreConfidentiality15.Location = new global::System.Drawing.Point(2, 351);
			this.RestoreConfidentiality15.Name = "RestoreConfidentiality15";
			this.RestoreConfidentiality15.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality15.TabIndex = 32;
			this.RestoreConfidentiality15.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality15.Click += new global::System.EventHandler(this.RestoreConfidentiality15_Click);
			this.RestoreConfidentiality14.Location = new global::System.Drawing.Point(2, 328);
			this.RestoreConfidentiality14.Name = "RestoreConfidentiality14";
			this.RestoreConfidentiality14.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality14.TabIndex = 31;
			this.RestoreConfidentiality14.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality14.Click += new global::System.EventHandler(this.RestoreConfidentiality14_Click);
			this.RestoreConfidentiality13.Location = new global::System.Drawing.Point(2, 305);
			this.RestoreConfidentiality13.Name = "RestoreConfidentiality13";
			this.RestoreConfidentiality13.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality13.TabIndex = 30;
			this.RestoreConfidentiality13.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality13.Click += new global::System.EventHandler(this.RestoreConfidentiality13_Click);
			this.RestoreConfidentiality12.Location = new global::System.Drawing.Point(2, 282);
			this.RestoreConfidentiality12.Name = "RestoreConfidentiality12";
			this.RestoreConfidentiality12.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality12.TabIndex = 29;
			this.RestoreConfidentiality12.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality12.Click += new global::System.EventHandler(this.RestoreConfidentiality12_Click);
			this.RestoreConfidentiality11.Location = new global::System.Drawing.Point(2, 259);
			this.RestoreConfidentiality11.Name = "RestoreConfidentiality11";
			this.RestoreConfidentiality11.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality11.TabIndex = 28;
			this.RestoreConfidentiality11.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality11.Click += new global::System.EventHandler(this.RestoreConfidentiality11_Click);
			this.RestoreConfidentiality10.Location = new global::System.Drawing.Point(2, 236);
			this.RestoreConfidentiality10.Name = "RestoreConfidentiality10";
			this.RestoreConfidentiality10.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality10.TabIndex = 27;
			this.RestoreConfidentiality10.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality10.Click += new global::System.EventHandler(this.RestoreConfidentiality10_Click);
			this.RestoreConfidentiality9.Location = new global::System.Drawing.Point(2, 213);
			this.RestoreConfidentiality9.Name = "RestoreConfidentiality9";
			this.RestoreConfidentiality9.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality9.TabIndex = 26;
			this.RestoreConfidentiality9.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality9.Click += new global::System.EventHandler(this.RestoreConfidentiality9_Click);
			this.RestoreConfidentiality8.Location = new global::System.Drawing.Point(2, 190);
			this.RestoreConfidentiality8.Name = "RestoreConfidentiality8";
			this.RestoreConfidentiality8.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality8.TabIndex = 25;
			this.RestoreConfidentiality8.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality8.Click += new global::System.EventHandler(this.RestoreConfidentiality8_Click);
			this.RestoreConfidentiality7.Location = new global::System.Drawing.Point(2, 167);
			this.RestoreConfidentiality7.Name = "RestoreConfidentiality7";
			this.RestoreConfidentiality7.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality7.TabIndex = 24;
			this.RestoreConfidentiality7.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality7.Click += new global::System.EventHandler(this.RestoreConfidentiality7_Click);
			this.RestoreConfidentiality6.Location = new global::System.Drawing.Point(2, 144);
			this.RestoreConfidentiality6.Name = "RestoreConfidentiality6";
			this.RestoreConfidentiality6.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality6.TabIndex = 23;
			this.RestoreConfidentiality6.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality6.Click += new global::System.EventHandler(this.RestoreConfidentiality6_Click);
			this.RestoreConfidentiality5.Location = new global::System.Drawing.Point(2, 121);
			this.RestoreConfidentiality5.Name = "RestoreConfidentiality5";
			this.RestoreConfidentiality5.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality5.TabIndex = 22;
			this.RestoreConfidentiality5.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality5.Click += new global::System.EventHandler(this.RestoreConfidentiality5_Click);
			this.RestoreConfidentiality4.Location = new global::System.Drawing.Point(2, 98);
			this.RestoreConfidentiality4.Name = "RestoreConfidentiality4";
			this.RestoreConfidentiality4.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality4.TabIndex = 21;
			this.RestoreConfidentiality4.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality4.Click += new global::System.EventHandler(this.RestoreConfidentiality4_Click);
			this.RestoreConfidentiality3.Location = new global::System.Drawing.Point(2, 75);
			this.RestoreConfidentiality3.Name = "RestoreConfidentiality3";
			this.RestoreConfidentiality3.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality3.TabIndex = 20;
			this.RestoreConfidentiality3.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality3.Click += new global::System.EventHandler(this.RestoreConfidentiality3_Click);
			this.RestoreConfidentiality2.Location = new global::System.Drawing.Point(2, 52);
			this.RestoreConfidentiality2.Name = "RestoreConfidentiality2";
			this.RestoreConfidentiality2.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality2.TabIndex = 19;
			this.RestoreConfidentiality2.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality2.Click += new global::System.EventHandler(this.RestoreConfidentiality2_Click);
			this.RestoreConfidentiality1.Location = new global::System.Drawing.Point(2, 29);
			this.RestoreConfidentiality1.Name = "RestoreConfidentiality1";
			this.RestoreConfidentiality1.Size = new global::System.Drawing.Size(13, 13);
			this.RestoreConfidentiality1.TabIndex = 0;
			this.RestoreConfidentiality1.UseVisualStyleBackColor = true;
			this.RestoreConfidentiality1.Click += new global::System.EventHandler(this.RestoreConfidentiality1_Click);
			this.Confidentiality1.AutoSize = true;
			this.Confidentiality1.Location = new global::System.Drawing.Point(23, 27);
			this.Confidentiality1.Name = "Confidentiality1";
			this.Confidentiality1.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality1.TabIndex = 2;
			this.Confidentiality2.AutoSize = true;
			this.Confidentiality2.Location = new global::System.Drawing.Point(23, 50);
			this.Confidentiality2.Name = "Confidentiality2";
			this.Confidentiality2.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality2.TabIndex = 3;
			this.Confidentiality3.AutoSize = true;
			this.Confidentiality3.Location = new global::System.Drawing.Point(23, 73);
			this.Confidentiality3.Name = "Confidentiality3";
			this.Confidentiality3.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality3.TabIndex = 4;
			this.Confidentiality4.AutoSize = true;
			this.Confidentiality4.Location = new global::System.Drawing.Point(23, 96);
			this.Confidentiality4.Name = "Confidentiality4";
			this.Confidentiality4.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality4.TabIndex = 5;
			this.Confidentiality5.AutoSize = true;
			this.Confidentiality5.Location = new global::System.Drawing.Point(23, 119);
			this.Confidentiality5.Name = "Confidentiality5";
			this.Confidentiality5.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality5.TabIndex = 6;
			this.Confidentiality6.AutoSize = true;
			this.Confidentiality6.Location = new global::System.Drawing.Point(23, 142);
			this.Confidentiality6.Name = "Confidentiality6";
			this.Confidentiality6.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality6.TabIndex = 7;
			this.Confidentiality7.AutoSize = true;
			this.Confidentiality7.Location = new global::System.Drawing.Point(23, 165);
			this.Confidentiality7.Name = "Confidentiality7";
			this.Confidentiality7.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality7.TabIndex = 8;
			this.Confidentiality8.AutoSize = true;
			this.Confidentiality8.Location = new global::System.Drawing.Point(23, 188);
			this.Confidentiality8.Name = "Confidentiality8";
			this.Confidentiality8.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality8.TabIndex = 9;
			this.Confidentiality9.AutoSize = true;
			this.Confidentiality9.Location = new global::System.Drawing.Point(23, 211);
			this.Confidentiality9.Name = "Confidentiality9";
			this.Confidentiality9.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality9.TabIndex = 10;
			this.Confidentiality10.AutoSize = true;
			this.Confidentiality10.Location = new global::System.Drawing.Point(23, 234);
			this.Confidentiality10.Name = "Confidentiality10";
			this.Confidentiality10.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality10.TabIndex = 11;
			this.Confidentiality11.AutoSize = true;
			this.Confidentiality11.Location = new global::System.Drawing.Point(23, 257);
			this.Confidentiality11.Name = "Confidentiality11";
			this.Confidentiality11.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality11.TabIndex = 12;
			this.Confidentiality12.AutoSize = true;
			this.Confidentiality12.Location = new global::System.Drawing.Point(23, 280);
			this.Confidentiality12.Name = "Confidentiality12";
			this.Confidentiality12.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality12.TabIndex = 13;
			this.Confidentiality13.AutoSize = true;
			this.Confidentiality13.Location = new global::System.Drawing.Point(23, 303);
			this.Confidentiality13.Name = "Confidentiality13";
			this.Confidentiality13.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality13.TabIndex = 14;
			this.Confidentiality14.AutoSize = true;
			this.Confidentiality14.Location = new global::System.Drawing.Point(23, 326);
			this.Confidentiality14.Name = "Confidentiality14";
			this.Confidentiality14.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality14.TabIndex = 15;
			this.Confidentiality15.AutoSize = true;
			this.Confidentiality15.Location = new global::System.Drawing.Point(23, 349);
			this.Confidentiality15.Name = "Confidentiality15";
			this.Confidentiality15.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality15.TabIndex = 16;
			this.Confidentiality16.AutoSize = true;
			this.Confidentiality16.Location = new global::System.Drawing.Point(23, 372);
			this.Confidentiality16.Name = "Confidentiality16";
			this.Confidentiality16.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality16.TabIndex = 17;
			this.Confidentiality17.AutoSize = true;
			this.Confidentiality17.Location = new global::System.Drawing.Point(23, 395);
			this.Confidentiality17.Name = "Confidentiality17";
			this.Confidentiality17.Size = new global::System.Drawing.Size(15, 14);
			this.Confidentiality17.TabIndex = 18;
			this.checkAll1.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.checkAll1.AutoSize = true;
			this.checkAll1.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checkAll1.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.checkAll1.LinkColor = global::System.Drawing.Color.White;
			this.checkAll1.Location = new global::System.Drawing.Point(3, 0);
			this.checkAll1.Name = "checkAll1";
			this.checkAll1.Size = new global::System.Drawing.Size(0, 13);
			this.checkAll1.TabIndex = 1;
			this.checkAll1.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel1_LinkClicked);
			this.MainPanel6.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel6.Controls.Add(this.CleanerLog);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner1);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner2);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner3);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner4);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner5);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner6);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner7);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner8);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner9);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner10);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner11);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner12);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner13);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner14);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner15);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner16);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner17);
			this.MainPanel6.Controls.Add(this.checkBoxCleaner18);
			this.MainPanel6.Controls.Add(this.checkAll5);
			this.MainPanel6.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel6.Name = "MainPanel6";
			this.MainPanel6.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel6.TabIndex = 39;
			this.CleanerLog.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.CleanerLog.BackColor = global::System.Drawing.Color.Transparent;
			this.CleanerLog.Font = new global::System.Drawing.Font("Verdana", 12.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.CleanerLog.ForeColor = global::System.Drawing.Color.White;
			this.CleanerLog.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.CleanerLog.LinkColor = global::System.Drawing.Color.FromArgb(103, 137, 178);
			this.CleanerLog.Location = new global::System.Drawing.Point(63, 397);
			this.CleanerLog.Name = "CleanerLog";
			this.CleanerLog.Size = new global::System.Drawing.Size(330, 20);
			this.CleanerLog.TabIndex = 177;
			this.CleanerLog.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.checkBoxCleaner1.AutoSize = true;
			this.checkBoxCleaner1.BackColor = global::System.Drawing.Color.Transparent;
			this.checkBoxCleaner1.Checked = true;
			this.checkBoxCleaner1.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner1.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner1.Location = new global::System.Drawing.Point(15, 21);
			this.checkBoxCleaner1.Name = "checkBoxCleaner1";
			this.checkBoxCleaner1.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner1.TabIndex = 1;
			this.checkBoxCleaner1.UseVisualStyleBackColor = false;
			this.checkBoxCleaner2.AutoSize = true;
			this.checkBoxCleaner2.Checked = true;
			this.checkBoxCleaner2.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner2.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner2.Location = new global::System.Drawing.Point(15, 42);
			this.checkBoxCleaner2.Name = "checkBoxCleaner2";
			this.checkBoxCleaner2.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner2.TabIndex = 1;
			this.checkBoxCleaner3.AutoSize = true;
			this.checkBoxCleaner3.Checked = true;
			this.checkBoxCleaner3.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner3.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner3.Location = new global::System.Drawing.Point(15, 63);
			this.checkBoxCleaner3.Name = "checkBoxCleaner3";
			this.checkBoxCleaner3.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner3.TabIndex = 1;
			this.checkBoxCleaner4.AutoSize = true;
			this.checkBoxCleaner4.Checked = true;
			this.checkBoxCleaner4.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner4.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner4.Location = new global::System.Drawing.Point(15, 84);
			this.checkBoxCleaner4.Name = "checkBoxCleaner4";
			this.checkBoxCleaner4.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner4.TabIndex = 1;
			this.checkBoxCleaner5.AutoSize = true;
			this.checkBoxCleaner5.Checked = true;
			this.checkBoxCleaner5.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner5.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner5.Location = new global::System.Drawing.Point(15, 105);
			this.checkBoxCleaner5.Name = "checkBoxCleaner5";
			this.checkBoxCleaner5.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner5.TabIndex = 1;
			this.checkBoxCleaner6.AutoSize = true;
			this.checkBoxCleaner6.Checked = true;
			this.checkBoxCleaner6.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner6.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner6.Location = new global::System.Drawing.Point(15, 126);
			this.checkBoxCleaner6.Name = "checkBoxCleaner6";
			this.checkBoxCleaner6.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner6.TabIndex = 1;
			this.checkBoxCleaner7.AutoSize = true;
			this.checkBoxCleaner7.Checked = true;
			this.checkBoxCleaner7.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner7.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner7.Location = new global::System.Drawing.Point(15, 147);
			this.checkBoxCleaner7.Name = "checkBoxCleaner7";
			this.checkBoxCleaner7.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner7.TabIndex = 1;
			this.checkBoxCleaner8.AutoSize = true;
			this.checkBoxCleaner8.Checked = true;
			this.checkBoxCleaner8.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner8.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner8.Location = new global::System.Drawing.Point(15, 168);
			this.checkBoxCleaner8.Name = "checkBoxCleaner8";
			this.checkBoxCleaner8.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner8.TabIndex = 1;
			this.checkBoxCleaner9.AutoSize = true;
			this.checkBoxCleaner9.Checked = true;
			this.checkBoxCleaner9.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner9.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner9.Location = new global::System.Drawing.Point(15, 189);
			this.checkBoxCleaner9.Name = "checkBoxCleaner9";
			this.checkBoxCleaner9.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner9.TabIndex = 1;
			this.checkBoxCleaner10.AutoSize = true;
			this.checkBoxCleaner10.Checked = true;
			this.checkBoxCleaner10.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner10.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner10.Location = new global::System.Drawing.Point(15, 210);
			this.checkBoxCleaner10.Name = "checkBoxCleaner10";
			this.checkBoxCleaner10.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner10.TabIndex = 1;
			this.checkBoxCleaner11.AutoSize = true;
			this.checkBoxCleaner11.Checked = true;
			this.checkBoxCleaner11.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner11.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner11.Location = new global::System.Drawing.Point(15, 231);
			this.checkBoxCleaner11.Name = "checkBoxCleaner11";
			this.checkBoxCleaner11.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner11.TabIndex = 178;
			this.checkBoxCleaner12.AutoSize = true;
			this.checkBoxCleaner12.Checked = true;
			this.checkBoxCleaner12.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner12.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner12.Location = new global::System.Drawing.Point(15, 252);
			this.checkBoxCleaner12.Name = "checkBoxCleaner12";
			this.checkBoxCleaner12.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner12.TabIndex = 1;
			this.checkBoxCleaner13.AutoSize = true;
			this.checkBoxCleaner13.Checked = true;
			this.checkBoxCleaner13.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner13.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner13.Location = new global::System.Drawing.Point(15, 273);
			this.checkBoxCleaner13.Name = "checkBoxCleaner13";
			this.checkBoxCleaner13.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner13.TabIndex = 1;
			this.checkBoxCleaner14.AutoSize = true;
			this.checkBoxCleaner14.Checked = true;
			this.checkBoxCleaner14.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner14.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner14.Location = new global::System.Drawing.Point(15, 294);
			this.checkBoxCleaner14.Name = "checkBoxCleaner14";
			this.checkBoxCleaner14.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner14.TabIndex = 1;
			this.checkBoxCleaner15.AutoSize = true;
			this.checkBoxCleaner15.Checked = true;
			this.checkBoxCleaner15.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner15.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner15.Location = new global::System.Drawing.Point(15, 315);
			this.checkBoxCleaner15.Name = "checkBoxCleaner15";
			this.checkBoxCleaner15.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner15.TabIndex = 1;
			this.checkBoxCleaner16.AutoSize = true;
			this.checkBoxCleaner16.Checked = true;
			this.checkBoxCleaner16.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.checkBoxCleaner16.ForeColor = global::System.Drawing.Color.White;
			this.checkBoxCleaner16.Location = new global::System.Drawing.Point(15, 336);
			this.checkBoxCleaner16.Name = "checkBoxCleaner16";
			this.checkBoxCleaner16.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner16.TabIndex = 1;
			this.checkBoxCleaner17.AutoSize = true;
			this.checkBoxCleaner17.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.checkBoxCleaner17.Location = new global::System.Drawing.Point(15, 357);
			this.checkBoxCleaner17.Name = "checkBoxCleaner17";
			this.checkBoxCleaner17.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner17.TabIndex = 1;
			this.checkBoxCleaner18.AutoSize = true;
			this.checkBoxCleaner18.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.checkBoxCleaner18.Location = new global::System.Drawing.Point(15, 378);
			this.checkBoxCleaner18.Name = "checkBoxCleaner18";
			this.checkBoxCleaner18.Size = new global::System.Drawing.Size(15, 14);
			this.checkBoxCleaner18.TabIndex = 1;
			this.checkAll5.ActiveLinkColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.checkAll5.AutoSize = true;
			this.checkAll5.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checkAll5.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.checkAll5.LinkColor = global::System.Drawing.Color.White;
			this.checkAll5.Location = new global::System.Drawing.Point(3, 0);
			this.checkAll5.Name = "checkAll5";
			this.checkAll5.Size = new global::System.Drawing.Size(0, 13);
			this.checkAll5.TabIndex = 0;
			this.checkAll5.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel5_LinkClicked);
			this.MainPanel7.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel7.Controls.Add(this.Feedback_del);
			this.MainPanel7.Controls.Add(this.Feedback_);
			this.MainPanel7.Controls.Add(this.OfficeHub_del);
			this.MainPanel7.Controls.Add(this.OfficeHub_);
			this.MainPanel7.Controls.Add(this.Photos_del);
			this.MainPanel7.Controls.Add(this.Photos_);
			this.MainPanel7.Controls.Add(this.Getstarted_del);
			this.MainPanel7.Controls.Add(this.Getstarted_);
			this.MainPanel7.Controls.Add(this.Skype_del);
			this.MainPanel7.Controls.Add(this.Skype_);
			this.MainPanel7.Controls.Add(this.Communications_del);
			this.MainPanel7.Controls.Add(this.Communications_);
			this.MainPanel7.Controls.Add(this.GetHelp_del);
			this.MainPanel7.Controls.Add(this.GetHelp_);
			this.MainPanel7.Controls.Add(this.BingWeather_del);
			this.MainPanel7.Controls.Add(this.BingWeather_);
			this.MainPanel7.Controls.Add(this.Sketch_del);
			this.MainPanel7.Controls.Add(this.Sketch_);
			this.MainPanel7.Controls.Add(this.ZuneMusic_del);
			this.MainPanel7.Controls.Add(this.ZuneMusic_);
			this.MainPanel7.Controls.Add(this.People_del);
			this.MainPanel7.Controls.Add(this.People_);
			this.MainPanel7.Controls.Add(this.ZuneVideo_del);
			this.MainPanel7.Controls.Add(this.ZuneVideo_);
			this.MainPanel7.Controls.Add(this.WindowsMaps_del);
			this.MainPanel7.Controls.Add(this.WindowsMaps_);
			this.MainPanel7.Controls.Add(this.WindowsCamera_del);
			this.MainPanel7.Controls.Add(this.WindowsCamera_);
			this.MainPanel7.Controls.Add(this.Recorder_del);
			this.MainPanel7.Controls.Add(this.Recorder_);
			this.MainPanel7.Controls.Add(this.WindowsAlarms_del);
			this.MainPanel7.Controls.Add(this.WindowsAlarms_);
			this.MainPanel7.Controls.Add(this.Xbox_del);
			this.MainPanel7.Controls.Add(this.Xbox_);
			this.MainPanel7.Controls.Add(this.StickyNotes_del);
			this.MainPanel7.Controls.Add(this.StickyNotes_);
			this.MainPanel7.Controls.Add(this.MixedReality_del);
			this.MainPanel7.Controls.Add(this.MixedReality_);
			this.MainPanel7.Controls.Add(this.Paint_del);
			this.MainPanel7.Controls.Add(this.Paint_);
			this.MainPanel7.Controls.Add(this.OneNote_del);
			this.MainPanel7.Controls.Add(this.OneNote_);
			this.MainPanel7.Controls.Add(this.Solitaire_del);
			this.MainPanel7.Controls.Add(this.Solitaire_);
			this.MainPanel7.Controls.Add(this.Viewer_del);
			this.MainPanel7.Controls.Add(this.Viewer_);
			this.MainPanel7.Controls.Add(this.WindowsStore_del);
			this.MainPanel7.Controls.Add(this.WindowsStore_);
			this.MainPanel7.Controls.Add(this.Feedback_text);
			this.MainPanel7.Controls.Add(this.OfficeHub_text);
			this.MainPanel7.Controls.Add(this.Photos_text);
			this.MainPanel7.Controls.Add(this.Getstarted_text);
			this.MainPanel7.Controls.Add(this.Skype_text);
			this.MainPanel7.Controls.Add(this.Communications_text);
			this.MainPanel7.Controls.Add(this.GetHelp_text);
			this.MainPanel7.Controls.Add(this.BingWeather_text);
			this.MainPanel7.Controls.Add(this.Sketch_text);
			this.MainPanel7.Controls.Add(this.ZuneMusic_text);
			this.MainPanel7.Controls.Add(this.People_text);
			this.MainPanel7.Controls.Add(this.ZuneVideo_text);
			this.MainPanel7.Controls.Add(this.WindowsMaps_text);
			this.MainPanel7.Controls.Add(this.WindowsCamera_text);
			this.MainPanel7.Controls.Add(this.Recorder_text);
			this.MainPanel7.Controls.Add(this.WindowsAlarms_text);
			this.MainPanel7.Controls.Add(this.Xbox_text);
			this.MainPanel7.Controls.Add(this.StickyNotes_text);
			this.MainPanel7.Controls.Add(this.MixedReality_text);
			this.MainPanel7.Controls.Add(this.Paint_text);
			this.MainPanel7.Controls.Add(this.OneNote_text);
			this.MainPanel7.Controls.Add(this.Solitaire_text);
			this.MainPanel7.Controls.Add(this.Viewer_text);
			this.MainPanel7.Controls.Add(this.WindowsStore_text);
			this.MainPanel7.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel7.Name = "MainPanel7";
			this.MainPanel7.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel7.TabIndex = 42;
			this.Feedback_del.Location = new global::System.Drawing.Point(442, 315);
			this.Feedback_del.Name = "Feedback_del";
			this.Feedback_del.Size = new global::System.Drawing.Size(24, 23);
			this.Feedback_del.TabIndex = 203;
			this.Feedback_del.Tag = "";
			this.Feedback_del.UseVisualStyleBackColor = false;
			this.Feedback_.FlatAppearance.BorderSize = 0;
			this.Feedback_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Feedback_.Location = new global::System.Drawing.Point(395, 319);
			this.Feedback_.Name = "Feedback_";
			this.Feedback_.Size = new global::System.Drawing.Size(65, 65);
			this.Feedback_.TabIndex = 204;
			this.Feedback_.UseVisualStyleBackColor = true;
			this.OfficeHub_del.Location = new global::System.Drawing.Point(364, 315);
			this.OfficeHub_del.Name = "OfficeHub_del";
			this.OfficeHub_del.Size = new global::System.Drawing.Size(24, 23);
			this.OfficeHub_del.TabIndex = 201;
			this.OfficeHub_del.Tag = "";
			this.OfficeHub_del.UseVisualStyleBackColor = false;
			this.OfficeHub_.FlatAppearance.BorderSize = 0;
			this.OfficeHub_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.OfficeHub_.Location = new global::System.Drawing.Point(317, 319);
			this.OfficeHub_.Name = "OfficeHub_";
			this.OfficeHub_.Size = new global::System.Drawing.Size(65, 65);
			this.OfficeHub_.TabIndex = 202;
			this.OfficeHub_.UseVisualStyleBackColor = true;
			this.Photos_del.Location = new global::System.Drawing.Point(286, 315);
			this.Photos_del.Name = "Photos_del";
			this.Photos_del.Size = new global::System.Drawing.Size(24, 23);
			this.Photos_del.TabIndex = 199;
			this.Photos_del.Tag = "";
			this.Photos_del.UseVisualStyleBackColor = false;
			this.Photos_.FlatAppearance.BorderSize = 0;
			this.Photos_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Photos_.Location = new global::System.Drawing.Point(239, 319);
			this.Photos_.Name = "Photos_";
			this.Photos_.Size = new global::System.Drawing.Size(65, 65);
			this.Photos_.TabIndex = 200;
			this.Photos_.UseVisualStyleBackColor = true;
			this.Getstarted_del.Location = new global::System.Drawing.Point(208, 315);
			this.Getstarted_del.Name = "Getstarted_del";
			this.Getstarted_del.Size = new global::System.Drawing.Size(24, 23);
			this.Getstarted_del.TabIndex = 197;
			this.Getstarted_del.Tag = "";
			this.Getstarted_del.UseVisualStyleBackColor = false;
			this.Getstarted_.FlatAppearance.BorderSize = 0;
			this.Getstarted_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Getstarted_.Location = new global::System.Drawing.Point(161, 319);
			this.Getstarted_.Name = "Getstarted_";
			this.Getstarted_.Size = new global::System.Drawing.Size(65, 65);
			this.Getstarted_.TabIndex = 198;
			this.Getstarted_.UseVisualStyleBackColor = true;
			this.Skype_del.Location = new global::System.Drawing.Point(130, 315);
			this.Skype_del.Name = "Skype_del";
			this.Skype_del.Size = new global::System.Drawing.Size(24, 23);
			this.Skype_del.TabIndex = 195;
			this.Skype_del.Tag = "";
			this.Skype_del.UseVisualStyleBackColor = false;
			this.Skype_.FlatAppearance.BorderSize = 0;
			this.Skype_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Skype_.Location = new global::System.Drawing.Point(83, 319);
			this.Skype_.Name = "Skype_";
			this.Skype_.Size = new global::System.Drawing.Size(65, 65);
			this.Skype_.TabIndex = 196;
			this.Skype_.UseVisualStyleBackColor = true;
			this.Communications_del.Location = new global::System.Drawing.Point(52, 315);
			this.Communications_del.Name = "Communications_del";
			this.Communications_del.Size = new global::System.Drawing.Size(24, 23);
			this.Communications_del.TabIndex = 193;
			this.Communications_del.Tag = "";
			this.Communications_del.UseVisualStyleBackColor = false;
			this.Communications_.FlatAppearance.BorderSize = 0;
			this.Communications_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Communications_.Location = new global::System.Drawing.Point(5, 319);
			this.Communications_.Name = "Communications_";
			this.Communications_.Size = new global::System.Drawing.Size(65, 65);
			this.Communications_.TabIndex = 194;
			this.Communications_.UseVisualStyleBackColor = true;
			this.GetHelp_del.Location = new global::System.Drawing.Point(442, 214);
			this.GetHelp_del.Name = "GetHelp_del";
			this.GetHelp_del.Size = new global::System.Drawing.Size(24, 23);
			this.GetHelp_del.TabIndex = 191;
			this.GetHelp_del.Tag = "";
			this.GetHelp_del.UseVisualStyleBackColor = false;
			this.GetHelp_.FlatAppearance.BorderSize = 0;
			this.GetHelp_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GetHelp_.Location = new global::System.Drawing.Point(395, 218);
			this.GetHelp_.Name = "GetHelp_";
			this.GetHelp_.Size = new global::System.Drawing.Size(65, 65);
			this.GetHelp_.TabIndex = 192;
			this.GetHelp_.UseVisualStyleBackColor = true;
			this.BingWeather_del.Location = new global::System.Drawing.Point(364, 214);
			this.BingWeather_del.Name = "BingWeather_del";
			this.BingWeather_del.Size = new global::System.Drawing.Size(24, 23);
			this.BingWeather_del.TabIndex = 189;
			this.BingWeather_del.Tag = "";
			this.BingWeather_del.UseVisualStyleBackColor = false;
			this.BingWeather_.FlatAppearance.BorderSize = 0;
			this.BingWeather_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.BingWeather_.Location = new global::System.Drawing.Point(317, 218);
			this.BingWeather_.Name = "BingWeather_";
			this.BingWeather_.Size = new global::System.Drawing.Size(65, 65);
			this.BingWeather_.TabIndex = 190;
			this.BingWeather_.UseVisualStyleBackColor = true;
			this.Sketch_del.Location = new global::System.Drawing.Point(286, 214);
			this.Sketch_del.Name = "Sketch_del";
			this.Sketch_del.Size = new global::System.Drawing.Size(24, 23);
			this.Sketch_del.TabIndex = 187;
			this.Sketch_del.Tag = "";
			this.Sketch_del.UseVisualStyleBackColor = false;
			this.Sketch_.FlatAppearance.BorderSize = 0;
			this.Sketch_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Sketch_.Location = new global::System.Drawing.Point(239, 218);
			this.Sketch_.Name = "Sketch_";
			this.Sketch_.Size = new global::System.Drawing.Size(65, 65);
			this.Sketch_.TabIndex = 188;
			this.Sketch_.UseVisualStyleBackColor = true;
			this.ZuneMusic_del.Location = new global::System.Drawing.Point(208, 214);
			this.ZuneMusic_del.Name = "ZuneMusic_del";
			this.ZuneMusic_del.Size = new global::System.Drawing.Size(24, 23);
			this.ZuneMusic_del.TabIndex = 185;
			this.ZuneMusic_del.Tag = "";
			this.ZuneMusic_del.UseVisualStyleBackColor = false;
			this.ZuneMusic_.FlatAppearance.BorderSize = 0;
			this.ZuneMusic_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ZuneMusic_.Location = new global::System.Drawing.Point(161, 218);
			this.ZuneMusic_.Name = "ZuneMusic_";
			this.ZuneMusic_.Size = new global::System.Drawing.Size(65, 65);
			this.ZuneMusic_.TabIndex = 186;
			this.ZuneMusic_.UseVisualStyleBackColor = true;
			this.People_del.Location = new global::System.Drawing.Point(130, 214);
			this.People_del.Name = "People_del";
			this.People_del.Size = new global::System.Drawing.Size(24, 23);
			this.People_del.TabIndex = 183;
			this.People_del.Tag = "";
			this.People_del.UseVisualStyleBackColor = false;
			this.People_.FlatAppearance.BorderSize = 0;
			this.People_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.People_.Location = new global::System.Drawing.Point(83, 218);
			this.People_.Name = "People_";
			this.People_.Size = new global::System.Drawing.Size(65, 65);
			this.People_.TabIndex = 184;
			this.People_.UseVisualStyleBackColor = true;
			this.ZuneVideo_del.Location = new global::System.Drawing.Point(52, 214);
			this.ZuneVideo_del.Name = "ZuneVideo_del";
			this.ZuneVideo_del.Size = new global::System.Drawing.Size(24, 23);
			this.ZuneVideo_del.TabIndex = 181;
			this.ZuneVideo_del.Tag = "";
			this.ZuneVideo_del.UseVisualStyleBackColor = false;
			this.ZuneVideo_.FlatAppearance.BorderSize = 0;
			this.ZuneVideo_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ZuneVideo_.Location = new global::System.Drawing.Point(5, 218);
			this.ZuneVideo_.Name = "ZuneVideo_";
			this.ZuneVideo_.Size = new global::System.Drawing.Size(65, 65);
			this.ZuneVideo_.TabIndex = 182;
			this.ZuneVideo_.UseVisualStyleBackColor = true;
			this.WindowsMaps_del.Location = new global::System.Drawing.Point(442, 113);
			this.WindowsMaps_del.Name = "WindowsMaps_del";
			this.WindowsMaps_del.Size = new global::System.Drawing.Size(24, 23);
			this.WindowsMaps_del.TabIndex = 179;
			this.WindowsMaps_del.Tag = "";
			this.WindowsMaps_del.UseVisualStyleBackColor = false;
			this.WindowsMaps_.FlatAppearance.BorderSize = 0;
			this.WindowsMaps_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.WindowsMaps_.Location = new global::System.Drawing.Point(395, 117);
			this.WindowsMaps_.Name = "WindowsMaps_";
			this.WindowsMaps_.Size = new global::System.Drawing.Size(65, 65);
			this.WindowsMaps_.TabIndex = 180;
			this.WindowsMaps_.UseVisualStyleBackColor = true;
			this.WindowsCamera_del.Location = new global::System.Drawing.Point(364, 113);
			this.WindowsCamera_del.Name = "WindowsCamera_del";
			this.WindowsCamera_del.Size = new global::System.Drawing.Size(24, 23);
			this.WindowsCamera_del.TabIndex = 177;
			this.WindowsCamera_del.Tag = "";
			this.WindowsCamera_del.UseVisualStyleBackColor = false;
			this.WindowsCamera_.FlatAppearance.BorderSize = 0;
			this.WindowsCamera_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.WindowsCamera_.Location = new global::System.Drawing.Point(317, 117);
			this.WindowsCamera_.Name = "WindowsCamera_";
			this.WindowsCamera_.Size = new global::System.Drawing.Size(65, 65);
			this.WindowsCamera_.TabIndex = 178;
			this.WindowsCamera_.UseVisualStyleBackColor = true;
			this.Recorder_del.Location = new global::System.Drawing.Point(286, 113);
			this.Recorder_del.Name = "Recorder_del";
			this.Recorder_del.Size = new global::System.Drawing.Size(24, 23);
			this.Recorder_del.TabIndex = 175;
			this.Recorder_del.Tag = "";
			this.Recorder_del.UseVisualStyleBackColor = false;
			this.Recorder_.FlatAppearance.BorderSize = 0;
			this.Recorder_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Recorder_.Location = new global::System.Drawing.Point(239, 117);
			this.Recorder_.Name = "Recorder_";
			this.Recorder_.Size = new global::System.Drawing.Size(65, 65);
			this.Recorder_.TabIndex = 176;
			this.Recorder_.UseVisualStyleBackColor = true;
			this.WindowsAlarms_del.Location = new global::System.Drawing.Point(208, 113);
			this.WindowsAlarms_del.Name = "WindowsAlarms_del";
			this.WindowsAlarms_del.Size = new global::System.Drawing.Size(24, 23);
			this.WindowsAlarms_del.TabIndex = 173;
			this.WindowsAlarms_del.Tag = "";
			this.WindowsAlarms_del.UseVisualStyleBackColor = false;
			this.WindowsAlarms_.FlatAppearance.BorderSize = 0;
			this.WindowsAlarms_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.WindowsAlarms_.Location = new global::System.Drawing.Point(161, 117);
			this.WindowsAlarms_.Name = "WindowsAlarms_";
			this.WindowsAlarms_.Size = new global::System.Drawing.Size(65, 65);
			this.WindowsAlarms_.TabIndex = 174;
			this.WindowsAlarms_.UseVisualStyleBackColor = true;
			this.Xbox_del.Location = new global::System.Drawing.Point(131, 113);
			this.Xbox_del.Name = "Xbox_del";
			this.Xbox_del.Size = new global::System.Drawing.Size(24, 23);
			this.Xbox_del.TabIndex = 171;
			this.Xbox_del.Tag = "";
			this.Xbox_del.UseVisualStyleBackColor = false;
			this.Xbox_.FlatAppearance.BorderSize = 0;
			this.Xbox_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Xbox_.Location = new global::System.Drawing.Point(83, 117);
			this.Xbox_.Name = "Xbox_";
			this.Xbox_.Size = new global::System.Drawing.Size(65, 65);
			this.Xbox_.TabIndex = 172;
			this.Xbox_.UseVisualStyleBackColor = true;
			this.StickyNotes_del.Location = new global::System.Drawing.Point(52, 113);
			this.StickyNotes_del.Name = "StickyNotes_del";
			this.StickyNotes_del.Size = new global::System.Drawing.Size(24, 23);
			this.StickyNotes_del.TabIndex = 169;
			this.StickyNotes_del.Tag = "";
			this.StickyNotes_del.UseVisualStyleBackColor = false;
			this.StickyNotes_.FlatAppearance.BorderSize = 0;
			this.StickyNotes_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.StickyNotes_.Location = new global::System.Drawing.Point(5, 117);
			this.StickyNotes_.Name = "StickyNotes_";
			this.StickyNotes_.Size = new global::System.Drawing.Size(65, 65);
			this.StickyNotes_.TabIndex = 170;
			this.StickyNotes_.UseVisualStyleBackColor = true;
			this.MixedReality_del.Location = new global::System.Drawing.Point(442, 12);
			this.MixedReality_del.Name = "MixedReality_del";
			this.MixedReality_del.Size = new global::System.Drawing.Size(24, 23);
			this.MixedReality_del.TabIndex = 167;
			this.MixedReality_del.Tag = "";
			this.MixedReality_del.UseVisualStyleBackColor = false;
			this.MixedReality_.FlatAppearance.BorderSize = 0;
			this.MixedReality_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.MixedReality_.Location = new global::System.Drawing.Point(395, 16);
			this.MixedReality_.Name = "MixedReality_";
			this.MixedReality_.Size = new global::System.Drawing.Size(65, 65);
			this.MixedReality_.TabIndex = 168;
			this.MixedReality_.UseVisualStyleBackColor = true;
			this.Paint_del.Location = new global::System.Drawing.Point(364, 12);
			this.Paint_del.Name = "Paint_del";
			this.Paint_del.Size = new global::System.Drawing.Size(24, 23);
			this.Paint_del.TabIndex = 165;
			this.Paint_del.Tag = "";
			this.Paint_del.UseVisualStyleBackColor = false;
			this.Paint_.FlatAppearance.BorderSize = 0;
			this.Paint_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Paint_.Location = new global::System.Drawing.Point(317, 16);
			this.Paint_.Name = "Paint_";
			this.Paint_.Size = new global::System.Drawing.Size(65, 65);
			this.Paint_.TabIndex = 166;
			this.Paint_.UseVisualStyleBackColor = true;
			this.OneNote_del.Location = new global::System.Drawing.Point(286, 12);
			this.OneNote_del.Name = "OneNote_del";
			this.OneNote_del.Size = new global::System.Drawing.Size(24, 23);
			this.OneNote_del.TabIndex = 163;
			this.OneNote_del.Tag = "";
			this.OneNote_del.UseVisualStyleBackColor = false;
			this.OneNote_.FlatAppearance.BorderSize = 0;
			this.OneNote_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.OneNote_.Location = new global::System.Drawing.Point(239, 16);
			this.OneNote_.Name = "OneNote_";
			this.OneNote_.Size = new global::System.Drawing.Size(65, 65);
			this.OneNote_.TabIndex = 164;
			this.OneNote_.UseVisualStyleBackColor = true;
			this.Solitaire_del.Location = new global::System.Drawing.Point(208, 12);
			this.Solitaire_del.Name = "Solitaire_del";
			this.Solitaire_del.Size = new global::System.Drawing.Size(24, 23);
			this.Solitaire_del.TabIndex = 161;
			this.Solitaire_del.Tag = "";
			this.Solitaire_del.UseVisualStyleBackColor = false;
			this.Solitaire_.FlatAppearance.BorderSize = 0;
			this.Solitaire_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Solitaire_.Location = new global::System.Drawing.Point(161, 16);
			this.Solitaire_.Name = "Solitaire_";
			this.Solitaire_.Size = new global::System.Drawing.Size(65, 65);
			this.Solitaire_.TabIndex = 162;
			this.Solitaire_.UseVisualStyleBackColor = true;
			this.Viewer_del.Location = new global::System.Drawing.Point(130, 12);
			this.Viewer_del.Name = "Viewer_del";
			this.Viewer_del.Size = new global::System.Drawing.Size(24, 23);
			this.Viewer_del.TabIndex = 159;
			this.Viewer_del.Tag = "";
			this.Viewer_del.UseVisualStyleBackColor = false;
			this.Viewer_.FlatAppearance.BorderSize = 0;
			this.Viewer_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Viewer_.Location = new global::System.Drawing.Point(83, 16);
			this.Viewer_.Name = "Viewer_";
			this.Viewer_.Size = new global::System.Drawing.Size(65, 65);
			this.Viewer_.TabIndex = 160;
			this.Viewer_.UseVisualStyleBackColor = true;
			this.WindowsStore_del.Location = new global::System.Drawing.Point(52, 12);
			this.WindowsStore_del.Name = "WindowsStore_del";
			this.WindowsStore_del.Size = new global::System.Drawing.Size(24, 23);
			this.WindowsStore_del.TabIndex = 43;
			this.WindowsStore_del.Tag = "";
			this.WindowsStore_del.UseVisualStyleBackColor = false;
			this.WindowsStore_.FlatAppearance.BorderSize = 0;
			this.WindowsStore_.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.WindowsStore_.Location = new global::System.Drawing.Point(5, 16);
			this.WindowsStore_.Name = "WindowsStore_";
			this.WindowsStore_.Size = new global::System.Drawing.Size(65, 65);
			this.WindowsStore_.TabIndex = 158;
			this.WindowsStore_.UseVisualStyleBackColor = true;
			this.Feedback_text.AutoSize = true;
			this.Feedback_text.Location = new global::System.Drawing.Point(393, 387);
			this.Feedback_text.Name = "Feedback_text";
			this.Feedback_text.Size = new global::System.Drawing.Size(0, 13);
			this.Feedback_text.TabIndex = 276;
			this.OfficeHub_text.AutoSize = true;
			this.OfficeHub_text.Location = new global::System.Drawing.Point(315, 387);
			this.OfficeHub_text.Name = "OfficeHub_text";
			this.OfficeHub_text.Size = new global::System.Drawing.Size(0, 13);
			this.OfficeHub_text.TabIndex = 275;
			this.Photos_text.AutoSize = true;
			this.Photos_text.Location = new global::System.Drawing.Point(237, 387);
			this.Photos_text.Name = "Photos_text";
			this.Photos_text.Size = new global::System.Drawing.Size(0, 13);
			this.Photos_text.TabIndex = 274;
			this.Getstarted_text.AutoSize = true;
			this.Getstarted_text.Location = new global::System.Drawing.Point(159, 387);
			this.Getstarted_text.Name = "Getstarted_text";
			this.Getstarted_text.Size = new global::System.Drawing.Size(0, 13);
			this.Getstarted_text.TabIndex = 273;
			this.Skype_text.AutoSize = true;
			this.Skype_text.Location = new global::System.Drawing.Point(81, 387);
			this.Skype_text.Name = "Skype_text";
			this.Skype_text.Size = new global::System.Drawing.Size(0, 13);
			this.Skype_text.TabIndex = 272;
			this.Communications_text.AutoSize = true;
			this.Communications_text.Location = new global::System.Drawing.Point(3, 387);
			this.Communications_text.Name = "Communications_text";
			this.Communications_text.Size = new global::System.Drawing.Size(0, 13);
			this.Communications_text.TabIndex = 271;
			this.GetHelp_text.AutoSize = true;
			this.GetHelp_text.Location = new global::System.Drawing.Point(393, 286);
			this.GetHelp_text.Name = "GetHelp_text";
			this.GetHelp_text.Size = new global::System.Drawing.Size(0, 13);
			this.GetHelp_text.TabIndex = 270;
			this.BingWeather_text.AutoSize = true;
			this.BingWeather_text.Location = new global::System.Drawing.Point(315, 286);
			this.BingWeather_text.Name = "BingWeather_text";
			this.BingWeather_text.Size = new global::System.Drawing.Size(0, 13);
			this.BingWeather_text.TabIndex = 269;
			this.Sketch_text.AutoSize = true;
			this.Sketch_text.Location = new global::System.Drawing.Point(237, 286);
			this.Sketch_text.Name = "Sketch_text";
			this.Sketch_text.Size = new global::System.Drawing.Size(0, 13);
			this.Sketch_text.TabIndex = 268;
			this.ZuneMusic_text.AutoSize = true;
			this.ZuneMusic_text.Location = new global::System.Drawing.Point(159, 286);
			this.ZuneMusic_text.Name = "ZuneMusic_text";
			this.ZuneMusic_text.Size = new global::System.Drawing.Size(0, 13);
			this.ZuneMusic_text.TabIndex = 267;
			this.People_text.AutoSize = true;
			this.People_text.Location = new global::System.Drawing.Point(81, 286);
			this.People_text.Name = "People_text";
			this.People_text.Size = new global::System.Drawing.Size(0, 13);
			this.People_text.TabIndex = 266;
			this.ZuneVideo_text.AutoSize = true;
			this.ZuneVideo_text.Location = new global::System.Drawing.Point(1, 286);
			this.ZuneVideo_text.Name = "ZuneVideo_text";
			this.ZuneVideo_text.Size = new global::System.Drawing.Size(0, 13);
			this.ZuneVideo_text.TabIndex = 265;
			this.WindowsMaps_text.AutoSize = true;
			this.WindowsMaps_text.Location = new global::System.Drawing.Point(393, 185);
			this.WindowsMaps_text.Name = "WindowsMaps_text";
			this.WindowsMaps_text.Size = new global::System.Drawing.Size(0, 13);
			this.WindowsMaps_text.TabIndex = 264;
			this.WindowsCamera_text.AutoSize = true;
			this.WindowsCamera_text.Location = new global::System.Drawing.Point(315, 185);
			this.WindowsCamera_text.Name = "WindowsCamera_text";
			this.WindowsCamera_text.Size = new global::System.Drawing.Size(0, 13);
			this.WindowsCamera_text.TabIndex = 263;
			this.Recorder_text.AutoSize = true;
			this.Recorder_text.Location = new global::System.Drawing.Point(237, 185);
			this.Recorder_text.Name = "Recorder_text";
			this.Recorder_text.Size = new global::System.Drawing.Size(0, 13);
			this.Recorder_text.TabIndex = 262;
			this.WindowsAlarms_text.AutoSize = true;
			this.WindowsAlarms_text.Location = new global::System.Drawing.Point(159, 185);
			this.WindowsAlarms_text.Name = "WindowsAlarms_text";
			this.WindowsAlarms_text.Size = new global::System.Drawing.Size(0, 13);
			this.WindowsAlarms_text.TabIndex = 261;
			this.Xbox_text.AutoSize = true;
			this.Xbox_text.Location = new global::System.Drawing.Point(81, 185);
			this.Xbox_text.Name = "Xbox_text";
			this.Xbox_text.Size = new global::System.Drawing.Size(0, 13);
			this.Xbox_text.TabIndex = 260;
			this.StickyNotes_text.AutoSize = true;
			this.StickyNotes_text.Location = new global::System.Drawing.Point(3, 185);
			this.StickyNotes_text.Name = "StickyNotes_text";
			this.StickyNotes_text.Size = new global::System.Drawing.Size(0, 13);
			this.StickyNotes_text.TabIndex = 259;
			this.MixedReality_text.AutoSize = true;
			this.MixedReality_text.Location = new global::System.Drawing.Point(393, 84);
			this.MixedReality_text.Name = "MixedReality_text";
			this.MixedReality_text.Size = new global::System.Drawing.Size(0, 13);
			this.MixedReality_text.TabIndex = 258;
			this.Paint_text.AutoSize = true;
			this.Paint_text.Location = new global::System.Drawing.Point(315, 84);
			this.Paint_text.Name = "Paint_text";
			this.Paint_text.Size = new global::System.Drawing.Size(0, 13);
			this.Paint_text.TabIndex = 257;
			this.OneNote_text.AutoSize = true;
			this.OneNote_text.Location = new global::System.Drawing.Point(237, 84);
			this.OneNote_text.Name = "OneNote_text";
			this.OneNote_text.Size = new global::System.Drawing.Size(0, 13);
			this.OneNote_text.TabIndex = 256;
			this.Solitaire_text.AutoSize = true;
			this.Solitaire_text.Location = new global::System.Drawing.Point(159, 84);
			this.Solitaire_text.Name = "Solitaire_text";
			this.Solitaire_text.Size = new global::System.Drawing.Size(0, 13);
			this.Solitaire_text.TabIndex = 255;
			this.Viewer_text.AutoSize = true;
			this.Viewer_text.Location = new global::System.Drawing.Point(81, 84);
			this.Viewer_text.Name = "Viewer_text";
			this.Viewer_text.Size = new global::System.Drawing.Size(0, 13);
			this.Viewer_text.TabIndex = 254;
			this.WindowsStore_text.AutoSize = true;
			this.WindowsStore_text.Location = new global::System.Drawing.Point(3, 84);
			this.WindowsStore_text.Name = "WindowsStore_text";
			this.WindowsStore_text.Size = new global::System.Drawing.Size(0, 13);
			this.WindowsStore_text.TabIndex = 253;
			this.MainPanelServ1.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanelServ1.Controls.Add(this.Serv16);
			this.MainPanelServ1.Controls.Add(this.Serv15);
			this.MainPanelServ1.Controls.Add(this.Serv14);
			this.MainPanelServ1.Controls.Add(this.Serv13);
			this.MainPanelServ1.Controls.Add(this.Serv12);
			this.MainPanelServ1.Controls.Add(this.Serv11);
			this.MainPanelServ1.Controls.Add(this.Serv10);
			this.MainPanelServ1.Controls.Add(this.Serv9);
			this.MainPanelServ1.Controls.Add(this.Serv8);
			this.MainPanelServ1.Controls.Add(this.Serv7);
			this.MainPanelServ1.Controls.Add(this.Serv6);
			this.MainPanelServ1.Controls.Add(this.Serv5);
			this.MainPanelServ1.Controls.Add(this.Serv4);
			this.MainPanelServ1.Controls.Add(this.Serv3);
			this.MainPanelServ1.Controls.Add(this.Serv2);
			this.MainPanelServ1.Controls.Add(this.Serv1);
			this.MainPanelServ1.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanelServ1.Name = "MainPanelServ1";
			this.MainPanelServ1.Size = new global::System.Drawing.Size(410, 374);
			this.MainPanelServ1.TabIndex = 28;
			this.Serv16.AutoSize = true;
			this.Serv16.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv16.Location = new global::System.Drawing.Point(8, 350);
			this.Serv16.Name = "Serv16";
			this.Serv16.Size = new global::System.Drawing.Size(0, 13);
			this.Serv16.TabIndex = 15;
			this.Serv15.AutoSize = true;
			this.Serv15.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv15.Location = new global::System.Drawing.Point(8, 327);
			this.Serv15.Name = "Serv15";
			this.Serv15.Size = new global::System.Drawing.Size(0, 13);
			this.Serv15.TabIndex = 14;
			this.Serv14.AutoSize = true;
			this.Serv14.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv14.Location = new global::System.Drawing.Point(8, 304);
			this.Serv14.Name = "Serv14";
			this.Serv14.Size = new global::System.Drawing.Size(0, 13);
			this.Serv14.TabIndex = 13;
			this.Serv13.AutoSize = true;
			this.Serv13.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv13.Location = new global::System.Drawing.Point(8, 281);
			this.Serv13.Name = "Serv13";
			this.Serv13.Size = new global::System.Drawing.Size(0, 13);
			this.Serv13.TabIndex = 12;
			this.Serv12.AutoSize = true;
			this.Serv12.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv12.Location = new global::System.Drawing.Point(8, 258);
			this.Serv12.Name = "Serv12";
			this.Serv12.Size = new global::System.Drawing.Size(0, 13);
			this.Serv12.TabIndex = 11;
			this.Serv11.AutoSize = true;
			this.Serv11.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv11.Location = new global::System.Drawing.Point(8, 235);
			this.Serv11.Name = "Serv11";
			this.Serv11.Size = new global::System.Drawing.Size(0, 13);
			this.Serv11.TabIndex = 10;
			this.Serv10.AutoSize = true;
			this.Serv10.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv10.Location = new global::System.Drawing.Point(8, 212);
			this.Serv10.Name = "Serv10";
			this.Serv10.Size = new global::System.Drawing.Size(0, 13);
			this.Serv10.TabIndex = 9;
			this.Serv9.AutoSize = true;
			this.Serv9.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv9.Location = new global::System.Drawing.Point(8, 189);
			this.Serv9.Name = "Serv9";
			this.Serv9.Size = new global::System.Drawing.Size(0, 13);
			this.Serv9.TabIndex = 8;
			this.Serv8.AutoSize = true;
			this.Serv8.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv8.Location = new global::System.Drawing.Point(8, 166);
			this.Serv8.Name = "Serv8";
			this.Serv8.Size = new global::System.Drawing.Size(0, 13);
			this.Serv8.TabIndex = 7;
			this.Serv7.AutoSize = true;
			this.Serv7.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv7.Location = new global::System.Drawing.Point(8, 143);
			this.Serv7.Name = "Serv7";
			this.Serv7.Size = new global::System.Drawing.Size(0, 13);
			this.Serv7.TabIndex = 6;
			this.Serv6.AutoSize = true;
			this.Serv6.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv6.Location = new global::System.Drawing.Point(8, 120);
			this.Serv6.Name = "Serv6";
			this.Serv6.Size = new global::System.Drawing.Size(0, 13);
			this.Serv6.TabIndex = 5;
			this.Serv5.AutoSize = true;
			this.Serv5.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv5.Location = new global::System.Drawing.Point(8, 97);
			this.Serv5.Name = "Serv5";
			this.Serv5.Size = new global::System.Drawing.Size(0, 13);
			this.Serv5.TabIndex = 4;
			this.Serv4.AutoSize = true;
			this.Serv4.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv4.Location = new global::System.Drawing.Point(8, 74);
			this.Serv4.Name = "Serv4";
			this.Serv4.Size = new global::System.Drawing.Size(0, 13);
			this.Serv4.TabIndex = 3;
			this.Serv3.AutoSize = true;
			this.Serv3.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv3.Location = new global::System.Drawing.Point(8, 51);
			this.Serv3.Name = "Serv3";
			this.Serv3.Size = new global::System.Drawing.Size(0, 13);
			this.Serv3.TabIndex = 2;
			this.Serv2.AutoSize = true;
			this.Serv2.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv2.Location = new global::System.Drawing.Point(8, 28);
			this.Serv2.Name = "Serv2";
			this.Serv2.Size = new global::System.Drawing.Size(0, 13);
			this.Serv2.TabIndex = 1;
			this.Serv1.AutoSize = true;
			this.Serv1.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv1.Location = new global::System.Drawing.Point(8, 5);
			this.Serv1.Name = "Serv1";
			this.Serv1.Size = new global::System.Drawing.Size(0, 13);
			this.Serv1.TabIndex = 0;
			this.ServPanelChoice.BackColor = global::System.Drawing.Color.FromArgb(45, 79, 116);
			this.ServPanelChoice.Controls.Add(this.ServList);
			this.ServPanelChoice.Controls.Add(this.ServCancel);
			this.ServPanelChoice.Controls.Add(this.ServNo);
			this.ServPanelChoice.Controls.Add(this.ServYes);
			this.ServPanelChoice.Location = new global::System.Drawing.Point(430, 473);
			this.ServPanelChoice.Name = "ServPanelChoice";
			this.ServPanelChoice.Size = new global::System.Drawing.Size(265, 28);
			this.ServPanelChoice.TabIndex = 20;
			this.ServPanelChoice.Visible = false;
			this.ServList.FlatAppearance.BorderColor = global::System.Drawing.Color.Black;
			this.ServList.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ServList.ForeColor = global::System.Drawing.Color.FromArgb(248, 248, 248);
			this.ServList.Location = new global::System.Drawing.Point(237, 0);
			this.ServList.Name = "ServList";
			this.ServList.Size = new global::System.Drawing.Size(28, 28);
			this.ServList.TabIndex = 3;
			this.ServList.TabStop = false;
			this.ServList.Text = "≡";
			this.ServList.UseVisualStyleBackColor = true;
			this.ServCancel.FlatAppearance.BorderColor = global::System.Drawing.Color.Black;
			this.ServCancel.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ServCancel.ForeColor = global::System.Drawing.Color.FromArgb(248, 248, 248);
			this.ServCancel.Location = new global::System.Drawing.Point(158, 0);
			this.ServCancel.Name = "ServCancel";
			this.ServCancel.Size = new global::System.Drawing.Size(80, 28);
			this.ServCancel.TabIndex = 2;
			this.ServCancel.TabStop = false;
			this.ServCancel.UseVisualStyleBackColor = true;
			this.ServCancel.Click += new global::System.EventHandler(this.ServCancel_Click);
			this.ServNo.FlatAppearance.BorderColor = global::System.Drawing.Color.Black;
			this.ServNo.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ServNo.ForeColor = global::System.Drawing.Color.FromArgb(248, 248, 248);
			this.ServNo.Location = new global::System.Drawing.Point(79, 0);
			this.ServNo.Name = "ServNo";
			this.ServNo.Size = new global::System.Drawing.Size(80, 28);
			this.ServNo.TabIndex = 1;
			this.ServNo.TabStop = false;
			this.ServNo.UseVisualStyleBackColor = true;
			this.ServNo.Click += new global::System.EventHandler(this.ServNo_Click);
			this.ServYes.FlatAppearance.BorderColor = global::System.Drawing.Color.Black;
			this.ServYes.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ServYes.ForeColor = global::System.Drawing.Color.FromArgb(248, 248, 248);
			this.ServYes.Location = new global::System.Drawing.Point(0, 0);
			this.ServYes.Name = "ServYes";
			this.ServYes.Size = new global::System.Drawing.Size(80, 28);
			this.ServYes.TabIndex = 0;
			this.ServYes.TabStop = false;
			this.ServYes.UseVisualStyleBackColor = true;
			this.ServYes.Click += new global::System.EventHandler(this.ServYes_Click);
			this.MainPanelServ2.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanelServ2.Controls.Add(this.Serv18);
			this.MainPanelServ2.Controls.Add(this.Serv17);
			this.MainPanelServ2.Controls.Add(this.Serv19);
			this.MainPanelServ2.Controls.Add(this.Serv20);
			this.MainPanelServ2.Controls.Add(this.Serv21);
			this.MainPanelServ2.Controls.Add(this.Serv32);
			this.MainPanelServ2.Controls.Add(this.Serv22);
			this.MainPanelServ2.Controls.Add(this.Serv31);
			this.MainPanelServ2.Controls.Add(this.Serv23);
			this.MainPanelServ2.Controls.Add(this.Serv30);
			this.MainPanelServ2.Controls.Add(this.Serv24);
			this.MainPanelServ2.Controls.Add(this.Serv29);
			this.MainPanelServ2.Controls.Add(this.Serv25);
			this.MainPanelServ2.Controls.Add(this.Serv28);
			this.MainPanelServ2.Controls.Add(this.Serv26);
			this.MainPanelServ2.Controls.Add(this.Serv27);
			this.MainPanelServ2.Location = new global::System.Drawing.Point(642, 45);
			this.MainPanelServ2.Name = "MainPanelServ2";
			this.MainPanelServ2.Size = new global::System.Drawing.Size(470, 374);
			this.MainPanelServ2.TabIndex = 29;
			this.Serv18.AutoSize = true;
			this.Serv18.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv18.Location = new global::System.Drawing.Point(8, 28);
			this.Serv18.Name = "Serv18";
			this.Serv18.Size = new global::System.Drawing.Size(0, 13);
			this.Serv18.TabIndex = 46;
			this.Serv17.AutoSize = true;
			this.Serv17.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv17.Location = new global::System.Drawing.Point(8, 5);
			this.Serv17.Name = "Serv17";
			this.Serv17.Size = new global::System.Drawing.Size(0, 13);
			this.Serv17.TabIndex = 16;
			this.Serv19.AutoSize = true;
			this.Serv19.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv19.Location = new global::System.Drawing.Point(8, 51);
			this.Serv19.Name = "Serv19";
			this.Serv19.Size = new global::System.Drawing.Size(0, 13);
			this.Serv19.TabIndex = 30;
			this.Serv20.AutoSize = true;
			this.Serv20.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv20.Location = new global::System.Drawing.Point(8, 74);
			this.Serv20.Name = "Serv20";
			this.Serv20.Size = new global::System.Drawing.Size(0, 13);
			this.Serv20.TabIndex = 31;
			this.Serv21.AutoSize = true;
			this.Serv21.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv21.Location = new global::System.Drawing.Point(8, 97);
			this.Serv21.Name = "Serv21";
			this.Serv21.Size = new global::System.Drawing.Size(0, 13);
			this.Serv21.TabIndex = 32;
			this.Serv32.AutoSize = true;
			this.Serv32.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv32.Location = new global::System.Drawing.Point(8, 350);
			this.Serv32.Name = "Serv32";
			this.Serv32.Size = new global::System.Drawing.Size(0, 13);
			this.Serv32.TabIndex = 43;
			this.Serv22.AutoSize = true;
			this.Serv22.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv22.Location = new global::System.Drawing.Point(8, 120);
			this.Serv22.Name = "Serv22";
			this.Serv22.Size = new global::System.Drawing.Size(0, 13);
			this.Serv22.TabIndex = 33;
			this.Serv31.AutoSize = true;
			this.Serv31.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv31.Location = new global::System.Drawing.Point(8, 327);
			this.Serv31.Name = "Serv31";
			this.Serv31.Size = new global::System.Drawing.Size(0, 13);
			this.Serv31.TabIndex = 42;
			this.Serv23.AutoSize = true;
			this.Serv23.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv23.Location = new global::System.Drawing.Point(8, 143);
			this.Serv23.Name = "Serv23";
			this.Serv23.Size = new global::System.Drawing.Size(0, 13);
			this.Serv23.TabIndex = 34;
			this.Serv30.AutoSize = true;
			this.Serv30.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv30.Location = new global::System.Drawing.Point(8, 304);
			this.Serv30.Name = "Serv30";
			this.Serv30.Size = new global::System.Drawing.Size(0, 13);
			this.Serv30.TabIndex = 41;
			this.Serv24.AutoSize = true;
			this.Serv24.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv24.Location = new global::System.Drawing.Point(8, 166);
			this.Serv24.Name = "Serv24";
			this.Serv24.Size = new global::System.Drawing.Size(0, 13);
			this.Serv24.TabIndex = 35;
			this.Serv29.AutoSize = true;
			this.Serv29.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv29.Location = new global::System.Drawing.Point(8, 281);
			this.Serv29.Name = "Serv29";
			this.Serv29.Size = new global::System.Drawing.Size(0, 13);
			this.Serv29.TabIndex = 40;
			this.Serv25.AutoSize = true;
			this.Serv25.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv25.Location = new global::System.Drawing.Point(8, 189);
			this.Serv25.Name = "Serv25";
			this.Serv25.Size = new global::System.Drawing.Size(0, 13);
			this.Serv25.TabIndex = 36;
			this.Serv28.AutoSize = true;
			this.Serv28.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv28.Location = new global::System.Drawing.Point(8, 258);
			this.Serv28.Name = "Serv28";
			this.Serv28.Size = new global::System.Drawing.Size(0, 13);
			this.Serv28.TabIndex = 39;
			this.Serv26.AutoSize = true;
			this.Serv26.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv26.Location = new global::System.Drawing.Point(8, 212);
			this.Serv26.Name = "Serv26";
			this.Serv26.Size = new global::System.Drawing.Size(0, 13);
			this.Serv26.TabIndex = 37;
			this.Serv27.AutoSize = true;
			this.Serv27.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.Serv27.Location = new global::System.Drawing.Point(8, 235);
			this.Serv27.Name = "Serv27";
			this.Serv27.Size = new global::System.Drawing.Size(0, 13);
			this.Serv27.TabIndex = 38;
			this.mainTimer.Interval = 7;
			this.mainTimer.Tick += new global::System.EventHandler(this.Timer_Tick);
			this.MainPanel8.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel8.Controls.Add(this.MainPanel8Line2);
			this.MainPanel8.Controls.Add(this.MainPanel8Line1);
			this.MainPanel8.Controls.Add(this.autorunpanel);
			this.MainPanel8.Controls.Add(this.StartupBlueNotWorking);
			this.MainPanel8.Controls.Add(this.StartupGrayTip);
			this.MainPanel8.Controls.Add(this.StartupBlueWorking);
			this.MainPanel8.Controls.Add(this.StartupYellowTip);
			this.MainPanel8.Controls.Add(this.StartupBottomTip);
			this.MainPanel8.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel8.Name = "MainPanel8";
			this.MainPanel8.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel8.TabIndex = 158;
			this.MainPanel8Line2.BackColor = global::System.Drawing.Color.FromArgb(9, 0, 125);
			this.MainPanel8Line2.Location = new global::System.Drawing.Point(15, 369);
			this.MainPanel8Line2.Name = "MainPanel8Line2";
			this.MainPanel8Line2.Size = new global::System.Drawing.Size(440, 1);
			this.MainPanel8Line2.TabIndex = 161;
			this.MainPanel8Line2.TabStop = false;
			this.MainPanel8Line1.BackColor = global::System.Drawing.Color.FromArgb(9, 0, 125);
			this.MainPanel8Line1.Location = new global::System.Drawing.Point(15, 57);
			this.MainPanel8Line1.Name = "MainPanel8Line1";
			this.MainPanel8Line1.Size = new global::System.Drawing.Size(440, 1);
			this.MainPanel8Line1.TabIndex = 160;
			this.MainPanel8Line1.TabStop = false;
			this.autorunpanel.AllowDrop = true;
			this.autorunpanel.AutoScroll = true;
			this.autorunpanel.Location = new global::System.Drawing.Point(5, 73);
			this.autorunpanel.Name = "autorunpanel";
			this.autorunpanel.Size = new global::System.Drawing.Size(460, 290);
			this.autorunpanel.TabIndex = 159;
			this.autorunpanel.DragDrop += new global::System.Windows.Forms.DragEventHandler(this.Autorunpanel_DragDrop);
			this.autorunpanel.DragEnter += new global::System.Windows.Forms.DragEventHandler(this.Autorunpanel_DragEnter);
			this.StartupBlueNotWorking.AutoSize = true;
			this.StartupBlueNotWorking.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.StartupBlueNotWorking.Location = new global::System.Drawing.Point(219, 26);
			this.StartupBlueNotWorking.Name = "StartupBlueNotWorking";
			this.StartupBlueNotWorking.Size = new global::System.Drawing.Size(0, 13);
			this.StartupBlueNotWorking.TabIndex = 69;
			this.StartupGrayTip.AutoSize = true;
			this.StartupGrayTip.ForeColor = global::System.Drawing.Color.FromArgb(157, 167, 175);
			this.StartupGrayTip.Location = new global::System.Drawing.Point(33, 26);
			this.StartupGrayTip.Name = "StartupGrayTip";
			this.StartupGrayTip.Size = new global::System.Drawing.Size(0, 13);
			this.StartupGrayTip.TabIndex = 68;
			this.StartupBlueWorking.AutoSize = true;
			this.StartupBlueWorking.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.StartupBlueWorking.Location = new global::System.Drawing.Point(230, 8);
			this.StartupBlueWorking.Name = "StartupBlueWorking";
			this.StartupBlueWorking.Size = new global::System.Drawing.Size(0, 13);
			this.StartupBlueWorking.TabIndex = 67;
			this.StartupYellowTip.AutoSize = true;
			this.StartupYellowTip.ForeColor = global::System.Drawing.Color.FromArgb(227, 206, 129);
			this.StartupYellowTip.Location = new global::System.Drawing.Point(36, 8);
			this.StartupYellowTip.Name = "StartupYellowTip";
			this.StartupYellowTip.Size = new global::System.Drawing.Size(0, 13);
			this.StartupYellowTip.TabIndex = 66;
			this.StartupBottomTip.AutoSize = true;
			this.StartupBottomTip.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.StartupBottomTip.Location = new global::System.Drawing.Point(64, 386);
			this.StartupBottomTip.Name = "StartupBottomTip";
			this.StartupBottomTip.Size = new global::System.Drawing.Size(0, 13);
			this.StartupBottomTip.TabIndex = 65;
			this.StartupBottomTip.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.MainPanel11.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel11.Controls.Add(this.PersonalPanelPlate);
			this.MainPanel11.Controls.Add(this.showip);
			this.MainPanel11.Controls.Add(this.pctype);
			this.MainPanel11.Controls.Add(this._os);
			this.MainPanel11.Controls.Add(this._os1);
			this.MainPanel11.Controls.Add(this._mother);
			this.MainPanel11.Controls.Add(this._mother1);
			this.MainPanel11.Controls.Add(this._cpu);
			this.MainPanel11.Controls.Add(this._cpu1);
			this.MainPanel11.Controls.Add(this._gpu);
			this.MainPanel11.Controls.Add(this._gpu1);
			this.MainPanel11.Controls.Add(this._monitor);
			this.MainPanel11.Controls.Add(this._monitor1);
			this.MainPanel11.Controls.Add(this._ram);
			this.MainPanel11.Controls.Add(this._ram1);
			this.MainPanel11.Controls.Add(this._drive);
			this.MainPanel11.Controls.Add(this._drive1);
			this.MainPanel11.Controls.Add(this._usb);
			this.MainPanel11.Controls.Add(this._usb1);
			this.MainPanel11.Controls.Add(this._pctime);
			this.MainPanel11.Controls.Add(this._pctime1);
			this.MainPanel11.Controls.Add(this._ip);
			this.MainPanel11.Controls.Add(this._ip1);
			this.MainPanel11.Controls.Add(this._speed);
			this.MainPanel11.Controls.Add(this._speed1);
			this.MainPanel11.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel11.Name = "MainPanel11";
			this.MainPanel11.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel11.TabIndex = 169;
			this.PersonalPanelPlate.Controls.Add(this.PersonalPanelPlateLabel);
			this.PersonalPanelPlate.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.PersonalPanelPlate.Location = new global::System.Drawing.Point(57, 371);
			this.PersonalPanelPlate.Name = "PersonalPanelPlate";
			this.PersonalPanelPlate.Size = new global::System.Drawing.Size(340, 50);
			this.PersonalPanelPlate.TabIndex = 185;
			this.PersonalPanelPlate.Visible = false;
			this.PersonalPanelPlateLabel.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.PersonalPanelPlateLabel.Font = new global::System.Drawing.Font("Verdana", 12.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.PersonalPanelPlateLabel.ForeColor = global::System.Drawing.Color.FromArgb(130, 182, 225);
			this.PersonalPanelPlateLabel.Location = new global::System.Drawing.Point(25, 16);
			this.PersonalPanelPlateLabel.Name = "PersonalPanelPlateLabel";
			this.PersonalPanelPlateLabel.Size = new global::System.Drawing.Size(291, 23);
			this.PersonalPanelPlateLabel.TabIndex = 0;
			this.PersonalPanelPlateLabel.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.showip.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.showip.AutoSize = true;
			this.showip.LinkBehavior = global::System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.showip.LinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.showip.Location = new global::System.Drawing.Point(203, 242);
			this.showip.Name = "showip";
			this.showip.Size = new global::System.Drawing.Size(0, 13);
			this.showip.TabIndex = 184;
			this.pctype.AutoSize = true;
			this.pctype.Font = new global::System.Drawing.Font("Calibri", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.pctype.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.pctype.Location = new global::System.Drawing.Point(5, 7);
			this.pctype.Name = "pctype";
			this.pctype.Size = new global::System.Drawing.Size(0, 19);
			this.pctype.TabIndex = 183;
			this._os.AutoSize = true;
			this._os.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._os.Location = new global::System.Drawing.Point(24, 42);
			this._os.Name = "_os";
			this._os.Size = new global::System.Drawing.Size(0, 13);
			this._os.TabIndex = 66;
			this._os1.AutoSize = true;
			this._os1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._os1.Location = new global::System.Drawing.Point(155, 42);
			this._os1.Name = "_os1";
			this._os1.Size = new global::System.Drawing.Size(19, 13);
			this._os1.TabIndex = 67;
			this._os1.Text = "...";
			this._mother.AutoSize = true;
			this._mother.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._mother.Location = new global::System.Drawing.Point(24, 64);
			this._mother.Name = "_mother";
			this._mother.Size = new global::System.Drawing.Size(0, 13);
			this._mother.TabIndex = 54;
			this._mother1.AutoSize = true;
			this._mother1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._mother1.Location = new global::System.Drawing.Point(155, 64);
			this._mother1.Name = "_mother1";
			this._mother1.Size = new global::System.Drawing.Size(19, 13);
			this._mother1.TabIndex = 55;
			this._mother1.Text = "...";
			this._cpu.AutoSize = true;
			this._cpu.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._cpu.Location = new global::System.Drawing.Point(24, 86);
			this._cpu.Name = "_cpu";
			this._cpu.Size = new global::System.Drawing.Size(0, 13);
			this._cpu.TabIndex = 56;
			this._cpu1.AutoSize = true;
			this._cpu1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._cpu1.Location = new global::System.Drawing.Point(155, 86);
			this._cpu1.Name = "_cpu1";
			this._cpu1.Size = new global::System.Drawing.Size(19, 13);
			this._cpu1.TabIndex = 57;
			this._cpu1.Text = "...";
			this._gpu.AutoSize = true;
			this._gpu.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._gpu.Location = new global::System.Drawing.Point(24, 108);
			this._gpu.Name = "_gpu";
			this._gpu.Size = new global::System.Drawing.Size(0, 13);
			this._gpu.TabIndex = 58;
			this._gpu1.AutoSize = true;
			this._gpu1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._gpu1.Location = new global::System.Drawing.Point(155, 108);
			this._gpu1.Name = "_gpu1";
			this._gpu1.Size = new global::System.Drawing.Size(19, 13);
			this._gpu1.TabIndex = 59;
			this._gpu1.Text = "...";
			this._monitor.AutoSize = true;
			this._monitor.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._monitor.Location = new global::System.Drawing.Point(24, 130);
			this._monitor.Name = "_monitor";
			this._monitor.Size = new global::System.Drawing.Size(0, 13);
			this._monitor.TabIndex = 60;
			this._monitor1.AutoSize = true;
			this._monitor1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._monitor1.Location = new global::System.Drawing.Point(155, 130);
			this._monitor1.Name = "_monitor1";
			this._monitor1.Size = new global::System.Drawing.Size(19, 13);
			this._monitor1.TabIndex = 61;
			this._monitor1.Text = "...";
			this._ram.AutoSize = true;
			this._ram.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this._ram.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._ram.Location = new global::System.Drawing.Point(24, 152);
			this._ram.Name = "_ram";
			this._ram.Size = new global::System.Drawing.Size(0, 13);
			this._ram.TabIndex = 64;
			this._ram1.AutoSize = true;
			this._ram1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._ram1.Location = new global::System.Drawing.Point(155, 152);
			this._ram1.Name = "_ram1";
			this._ram1.Size = new global::System.Drawing.Size(19, 13);
			this._ram1.TabIndex = 65;
			this._ram1.Text = "...";
			this._drive.AutoSize = true;
			this._drive.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._drive.Location = new global::System.Drawing.Point(24, 174);
			this._drive.Name = "_drive";
			this._drive.Size = new global::System.Drawing.Size(0, 13);
			this._drive.TabIndex = 176;
			this._drive1.AutoSize = true;
			this._drive1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._drive1.Location = new global::System.Drawing.Point(155, 174);
			this._drive1.Name = "_drive1";
			this._drive1.Size = new global::System.Drawing.Size(19, 13);
			this._drive1.TabIndex = 177;
			this._drive1.Text = "...";
			this._usb.AutoSize = true;
			this._usb.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this._usb.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._usb.Location = new global::System.Drawing.Point(24, 196);
			this._usb.Name = "_usb";
			this._usb.Size = new global::System.Drawing.Size(0, 13);
			this._usb.TabIndex = 180;
			this._usb1.AutoSize = true;
			this._usb1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._usb1.Location = new global::System.Drawing.Point(155, 196);
			this._usb1.Name = "_usb1";
			this._usb1.Size = new global::System.Drawing.Size(19, 13);
			this._usb1.TabIndex = 181;
			this._usb1.Text = "...";
			this._pctime.AutoSize = true;
			this._pctime.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._pctime.Location = new global::System.Drawing.Point(24, 218);
			this._pctime.Name = "_pctime";
			this._pctime.Size = new global::System.Drawing.Size(0, 13);
			this._pctime.TabIndex = 51;
			this._pctime1.AutoSize = true;
			this._pctime1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._pctime1.Location = new global::System.Drawing.Point(155, 218);
			this._pctime1.Name = "_pctime1";
			this._pctime1.Size = new global::System.Drawing.Size(19, 13);
			this._pctime1.TabIndex = 52;
			this._pctime1.Text = "...";
			this._ip.AutoSize = true;
			this._ip.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._ip.Location = new global::System.Drawing.Point(24, 240);
			this._ip.Name = "_ip";
			this._ip.Size = new global::System.Drawing.Size(0, 13);
			this._ip.TabIndex = 49;
			this._ip1.AutoSize = true;
			this._ip1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._ip1.Location = new global::System.Drawing.Point(155, 240);
			this._ip1.Name = "_ip1";
			this._ip1.Size = new global::System.Drawing.Size(19, 13);
			this._ip1.TabIndex = 50;
			this._ip1.Text = "...";
			this._speed.AutoSize = true;
			this._speed.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._speed.Location = new global::System.Drawing.Point(24, 262);
			this._speed.Name = "_speed";
			this._speed.Size = new global::System.Drawing.Size(0, 13);
			this._speed.TabIndex = 62;
			this._speed1.AutoSize = true;
			this._speed1.ForeColor = global::System.Drawing.Color.AliceBlue;
			this._speed1.Location = new global::System.Drawing.Point(155, 262);
			this._speed1.Name = "_speed1";
			this._speed1.Size = new global::System.Drawing.Size(19, 13);
			this._speed1.TabIndex = 63;
			this._speed1.Text = "...";
			this.AboutIcon.BackColor = global::System.Drawing.Color.Transparent;
			this.AboutIcon.BackgroundImage = global::Class89.Bitmap_10;
			this.AboutIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.AboutIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
			this.AboutIcon.FlatAppearance.BorderSize = 0;
			this.AboutIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
			this.AboutIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
			this.AboutIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.AboutIcon.Location = new global::System.Drawing.Point(646, 5);
			this.AboutIcon.Name = "AboutIcon";
			this.AboutIcon.Size = new global::System.Drawing.Size(22, 22);
			this.AboutIcon.TabIndex = 16;
			this.AboutIcon.UseVisualStyleBackColor = false;
			this.AboutIcon.Click += new global::System.EventHandler(this.AboutIcon_Click);
			this.CloseIcon.BackColor = global::System.Drawing.Color.Transparent;
			this.CloseIcon.BackgroundImage = global::Class89.Bitmap_17;
			this.CloseIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.CloseIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
			this.CloseIcon.FlatAppearance.BorderSize = 0;
			this.CloseIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
			this.CloseIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
			this.CloseIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.CloseIcon.Location = new global::System.Drawing.Point(677, 5);
			this.CloseIcon.Name = "CloseIcon";
			this.CloseIcon.Size = new global::System.Drawing.Size(22, 22);
			this.CloseIcon.TabIndex = 17;
			this.CloseIcon.UseVisualStyleBackColor = false;
			this.CloseIcon.Click += new global::System.EventHandler(this.CloseIcon_Click);
			this.MainPanel10.AutoScroll = true;
			this.MainPanel10.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel10.Controls.Add(this.scanner);
			this.MainPanel10.Controls.Add(this.PleaseWaitVT);
			this.MainPanel10.Controls.Add(this.MainPanel10Line2);
			this.MainPanel10.Controls.Add(this.MainPanel10Line1);
			this.MainPanel10.Controls.Add(this.DropFileHereVT);
			this.MainPanel10.Controls.Add(this.panelVT);
			this.MainPanel10.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel10.Name = "MainPanel10";
			this.MainPanel10.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel10.TabIndex = 171;
			this.MainPanel10.Tag = "feedback";
			this.scanner.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.scanner.Image = global::Class89.Bitmap_65;
			this.scanner.Location = new global::System.Drawing.Point(198, 87);
			this.scanner.Name = "scanner";
			this.scanner.Size = new global::System.Drawing.Size(64, 64);
			this.scanner.TabIndex = 175;
			this.scanner.TabStop = false;
			this.scanner.Visible = false;
			this.PleaseWaitVT.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.PleaseWaitVT.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.PleaseWaitVT.Location = new global::System.Drawing.Point(34, 199);
			this.PleaseWaitVT.Name = "PleaseWaitVT";
			this.PleaseWaitVT.Size = new global::System.Drawing.Size(392, 107);
			this.PleaseWaitVT.TabIndex = 173;
			this.PleaseWaitVT.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.PleaseWaitVT.Visible = false;
			this.MainPanel10Line2.BackColor = global::System.Drawing.Color.FromArgb(9, 0, 125);
			this.MainPanel10Line2.Location = new global::System.Drawing.Point(0, 390);
			this.MainPanel10Line2.Name = "MainPanel10Line2";
			this.MainPanel10Line2.Size = new global::System.Drawing.Size(470, 1);
			this.MainPanel10Line2.TabIndex = 174;
			this.MainPanel10Line2.TabStop = false;
			this.MainPanel10Line1.BackColor = global::System.Drawing.Color.FromArgb(9, 0, 125);
			this.MainPanel10Line1.Location = new global::System.Drawing.Point(0, 28);
			this.MainPanel10Line1.Name = "MainPanel10Line1";
			this.MainPanel10Line1.Size = new global::System.Drawing.Size(470, 1);
			this.MainPanel10Line1.TabIndex = 173;
			this.MainPanel10Line1.TabStop = false;
			this.DropFileHereVT.BackColor = global::System.Drawing.Color.Transparent;
			this.DropFileHereVT.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.DropFileHereVT.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.DropFileHereVT.Location = new global::System.Drawing.Point(55, -1);
			this.DropFileHereVT.Name = "DropFileHereVT";
			this.DropFileHereVT.Size = new global::System.Drawing.Size(347, 20);
			this.DropFileHereVT.TabIndex = 172;
			this.DropFileHereVT.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.panelVT.AllowDrop = true;
			this.panelVT.AutoScroll = true;
			this.panelVT.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.panelVT.Location = new global::System.Drawing.Point(0, 34);
			this.panelVT.Name = "panelVT";
			this.panelVT.Size = new global::System.Drawing.Size(470, 350);
			this.panelVT.TabIndex = 172;
			this.panelVT.Click += new global::System.EventHandler(this.PanelVT_Click);
			this.panelVT.DragDrop += new global::System.Windows.Forms.DragEventHandler(this.PanelVT_DragDrop);
			this.panelVT.DragEnter += new global::System.Windows.Forms.DragEventHandler(this.PanelVT_DragEnter);
			this.MainPanel9.BackColor = global::System.Drawing.Color.Transparent;
			this.MainPanel9.Controls.Add(this.panelLog);
			this.MainPanel9.Controls.Add(this.panelChoice);
			this.MainPanel9.Controls.Add(this.PanelDragnDropArea);
			this.MainPanel9.Controls.Add(this.restore1);
			this.MainPanel9.Controls.Add(this.compress1);
			this.MainPanel9.Controls.Add(this.OptRadioButton1);
			this.MainPanel9.Controls.Add(this.OptRadioButton2);
			this.MainPanel9.Controls.Add(this.OptRadioButton3);
			this.MainPanel9.Controls.Add(this.OptRadioButton4);
			this.MainPanel9.Controls.Add(this.restore2);
			this.MainPanel9.Controls.Add(this.compress2);
			this.MainPanel9.Controls.Add(this.restore3);
			this.MainPanel9.Controls.Add(this.compress3);
			this.MainPanel9.Controls.Add(this.compress4);
			this.MainPanel9.Controls.Add(this.compress5);
			this.MainPanel9.Controls.Add(this.checker4);
			this.MainPanel9.Controls.Add(this.checker3);
			this.MainPanel9.Controls.Add(this.checker2);
			this.MainPanel9.Controls.Add(this.checker1);
			this.MainPanel9.Controls.Add(this.checker5);
			this.MainPanel9.Controls.Add(this.progressBar2);
			this.MainPanel9.Controls.Add(this.progressBar5);
			this.MainPanel9.Controls.Add(this.tip5);
			this.MainPanel9.Controls.Add(this.progressBar1);
			this.MainPanel9.Controls.Add(this.progressBar4);
			this.MainPanel9.Controls.Add(this.tip4);
			this.MainPanel9.Controls.Add(this.ChooseCompression);
			this.MainPanel9.Controls.Add(this.progressBar3);
			this.MainPanel9.Controls.Add(this.tip3);
			this.MainPanel9.Controls.Add(this.tip1);
			this.MainPanel9.Controls.Add(this.tip2);
			this.MainPanel9.Controls.Add(this.long4);
			this.MainPanel9.Controls.Add(this.long3);
			this.MainPanel9.Controls.Add(this.long2);
			this.MainPanel9.Controls.Add(this.long1);
			this.MainPanel9.Controls.Add(this.tip6);
			this.MainPanel9.Controls.Add(this.long5);
			this.MainPanel9.Controls.Add(this.Counter3);
			this.MainPanel9.Controls.Add(this.Counter1);
			this.MainPanel9.Location = new global::System.Drawing.Point(232, 45);
			this.MainPanel9.Name = "MainPanel9";
			this.MainPanel9.Size = new global::System.Drawing.Size(470, 424);
			this.MainPanel9.TabIndex = 162;
			this.panelLog.AutoScroll = true;
			this.panelLog.BackColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
			this.panelLog.Controls.Add(this.DupesProgressBar);
			this.panelLog.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.panelLog.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.panelLog.Location = new global::System.Drawing.Point(0, 0);
			this.panelLog.Name = "panelLog";
			this.panelLog.Size = new global::System.Drawing.Size(470, 360);
			this.panelLog.TabIndex = 80;
			this.panelLog.Visible = false;
			this.DupesProgressBar.Location = new global::System.Drawing.Point(25, 42);
			this.DupesProgressBar.Name = "DupesProgressBar";
			this.DupesProgressBar.Size = new global::System.Drawing.Size(420, 3);
			this.DupesProgressBar.TabIndex = 0;
			this.DupesProgressBar.Visible = false;
			this.panelChoice.Controls.Add(this.panelChoiceLine);
			this.panelChoice.Controls.Add(this.buttonNo);
			this.panelChoice.Controls.Add(this.buttonYes);
			this.panelChoice.Location = new global::System.Drawing.Point(0, 359);
			this.panelChoice.Name = "panelChoice";
			this.panelChoice.Size = new global::System.Drawing.Size(470, 63);
			this.panelChoice.TabIndex = 81;
			this.panelChoice.Visible = false;
			this.panelChoiceLine.AutoSize = true;
			this.panelChoiceLine.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.panelChoiceLine.Location = new global::System.Drawing.Point(2, -11);
			this.panelChoiceLine.Name = "panelChoiceLine";
			this.panelChoiceLine.Size = new global::System.Drawing.Size(469, 13);
			this.panelChoiceLine.TabIndex = 78;
			this.panelChoiceLine.Text = "_____________________________________________________________________________";
			this.buttonNo.BackColor = global::System.Drawing.SystemColors.Control;
			this.buttonNo.FlatAppearance.BorderSize = 0;
			this.buttonNo.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
			this.buttonNo.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.buttonNo.Location = new global::System.Drawing.Point(238, 21);
			this.buttonNo.Name = "buttonNo";
			this.buttonNo.Size = new global::System.Drawing.Size(102, 22);
			this.buttonNo.TabIndex = 13;
			this.buttonNo.TabStop = false;
			this.buttonNo.UseVisualStyleBackColor = false;
			this.buttonNo.Click += new global::System.EventHandler(this.ButtonNo_Click);
			this.buttonYes.BackColor = global::System.Drawing.SystemColors.Control;
			this.buttonYes.Enabled = false;
			this.buttonYes.FlatAppearance.BorderSize = 0;
			this.buttonYes.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
			this.buttonYes.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.buttonYes.Location = new global::System.Drawing.Point(130, 21);
			this.buttonYes.Name = "buttonYes";
			this.buttonYes.Size = new global::System.Drawing.Size(102, 22);
			this.buttonYes.TabIndex = 12;
			this.buttonYes.TabStop = false;
			this.buttonYes.UseVisualStyleBackColor = false;
			this.buttonYes.Click += new global::System.EventHandler(this.ButtonYes_Click);
			this.PanelDragnDropArea.AllowDrop = true;
			this.PanelDragnDropArea.Controls.Add(this.OptDragText);
			this.PanelDragnDropArea.Location = new global::System.Drawing.Point(316, 354);
			this.PanelDragnDropArea.Name = "PanelDragnDropArea";
			this.PanelDragnDropArea.Size = new global::System.Drawing.Size(150, 50);
			this.PanelDragnDropArea.TabIndex = 79;
			this.PanelDragnDropArea.Click += new global::System.EventHandler(this.PanelDragnDropArea_Click);
			this.PanelDragnDropArea.DragDrop += new global::System.Windows.Forms.DragEventHandler(this.PanelDragnDropArea_DragDrop);
			this.PanelDragnDropArea.DragEnter += new global::System.Windows.Forms.DragEventHandler(this.PanelDragnDropArea_DragEnter);
			this.PanelDragnDropArea.DragLeave += new global::System.EventHandler(this.PanelDragnDropArea_DragLeave);
			this.OptDragText.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.OptDragText.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.OptDragText.Location = new global::System.Drawing.Point(16, 12);
			this.OptDragText.Name = "OptDragText";
			this.OptDragText.Size = new global::System.Drawing.Size(119, 26);
			this.OptDragText.TabIndex = 80;
			this.OptDragText.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.OptDragText.Click += new global::System.EventHandler(this.OptDragText_Click);
			this.restore1.BackColor = global::System.Drawing.Color.FromArgb(216, 229, 240);
			this.restore1.BackgroundImage = global::Class89.Bitmap_51;
			this.restore1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Center;
			this.restore1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.restore1.Location = new global::System.Drawing.Point(303, 15);
			this.restore1.Name = "restore1";
			this.restore1.Size = new global::System.Drawing.Size(32, 32);
			this.restore1.TabIndex = 1;
			this.restore1.UseCompatibleTextRendering = true;
			this.restore1.UseVisualStyleBackColor = false;
			this.restore1.Click += new global::System.EventHandler(this.Restore1_Click);
			this.compress1.BackColor = global::System.Drawing.Color.FromArgb(216, 229, 240);
			this.compress1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.compress1.Location = new global::System.Drawing.Point(340, 15);
			this.compress1.Name = "compress1";
			this.compress1.Size = new global::System.Drawing.Size(126, 32);
			this.compress1.TabIndex = 1;
			this.compress1.UseVisualStyleBackColor = false;
			this.compress1.Click += new global::System.EventHandler(this.Compress1_Click);
			this.OptRadioButton1.AutoSize = true;
			this.OptRadioButton1.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.OptRadioButton1.Location = new global::System.Drawing.Point(154, 55);
			this.OptRadioButton1.Name = "OptRadioButton1";
			this.OptRadioButton1.Size = new global::System.Drawing.Size(14, 13);
			this.OptRadioButton1.TabIndex = 1;
			this.OptRadioButton1.TabStop = true;
			this.OptRadioButton2.AutoSize = true;
			this.OptRadioButton2.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.OptRadioButton2.Location = new global::System.Drawing.Point(222, 55);
			this.OptRadioButton2.Name = "OptRadioButton2";
			this.OptRadioButton2.Size = new global::System.Drawing.Size(14, 13);
			this.OptRadioButton2.TabIndex = 1;
			this.OptRadioButton2.TabStop = true;
			this.OptRadioButton3.AutoSize = true;
			this.OptRadioButton3.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.OptRadioButton3.Location = new global::System.Drawing.Point(297, 55);
			this.OptRadioButton3.Name = "OptRadioButton3";
			this.OptRadioButton3.Size = new global::System.Drawing.Size(14, 13);
			this.OptRadioButton3.TabIndex = 1;
			this.OptRadioButton3.TabStop = true;
			this.OptRadioButton4.AutoSize = true;
			this.OptRadioButton4.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.OptRadioButton4.Location = new global::System.Drawing.Point(371, 55);
			this.OptRadioButton4.Name = "OptRadioButton4";
			this.OptRadioButton4.Size = new global::System.Drawing.Size(14, 13);
			this.OptRadioButton4.TabIndex = 1;
			this.OptRadioButton4.TabStop = true;
			this.restore2.BackColor = global::System.Drawing.Color.FromArgb(216, 229, 240);
			this.restore2.BackgroundImage = global::Class89.Bitmap_51;
			this.restore2.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Center;
			this.restore2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.restore2.Location = new global::System.Drawing.Point(303, 99);
			this.restore2.Name = "restore2";
			this.restore2.Size = new global::System.Drawing.Size(32, 32);
			this.restore2.TabIndex = 1;
			this.restore2.UseCompatibleTextRendering = true;
			this.restore2.UseVisualStyleBackColor = false;
			this.restore2.Click += new global::System.EventHandler(this.Restore2_Click);
			this.compress2.BackColor = global::System.Drawing.Color.FromArgb(216, 229, 240);
			this.compress2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.compress2.Location = new global::System.Drawing.Point(340, 99);
			this.compress2.Name = "compress2";
			this.compress2.Size = new global::System.Drawing.Size(126, 32);
			this.compress2.TabIndex = 1;
			this.compress2.UseVisualStyleBackColor = false;
			this.compress2.Click += new global::System.EventHandler(this.Compress2_Click);
			this.restore3.BackColor = global::System.Drawing.Color.FromArgb(216, 229, 240);
			this.restore3.BackgroundImage = global::Class89.Bitmap_51;
			this.restore3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Center;
			this.restore3.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.restore3.Location = new global::System.Drawing.Point(303, 164);
			this.restore3.Name = "restore3";
			this.restore3.Size = new global::System.Drawing.Size(32, 32);
			this.restore3.TabIndex = 1;
			this.restore3.UseCompatibleTextRendering = true;
			this.restore3.UseVisualStyleBackColor = false;
			this.restore3.Click += new global::System.EventHandler(this.Restore3_Click);
			this.compress3.BackColor = global::System.Drawing.Color.FromArgb(216, 229, 240);
			this.compress3.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.compress3.Location = new global::System.Drawing.Point(340, 164);
			this.compress3.Name = "compress3";
			this.compress3.Size = new global::System.Drawing.Size(126, 32);
			this.compress3.TabIndex = 1;
			this.compress3.UseVisualStyleBackColor = false;
			this.compress3.Click += new global::System.EventHandler(this.Compress3_Click);
			this.compress4.BackColor = global::System.Drawing.Color.FromArgb(216, 229, 240);
			this.compress4.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.compress4.Location = new global::System.Drawing.Point(340, 228);
			this.compress4.Name = "compress4";
			this.compress4.Size = new global::System.Drawing.Size(126, 32);
			this.compress4.TabIndex = 1;
			this.compress4.UseVisualStyleBackColor = false;
			this.compress4.Click += new global::System.EventHandler(this.Compress4_Click);
			this.compress5.BackColor = global::System.Drawing.Color.FromArgb(216, 229, 240);
			this.compress5.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.compress5.Location = new global::System.Drawing.Point(340, 292);
			this.compress5.Name = "compress5";
			this.compress5.Size = new global::System.Drawing.Size(126, 32);
			this.compress5.TabIndex = 1;
			this.compress5.UseVisualStyleBackColor = false;
			this.compress5.Click += new global::System.EventHandler(this.Compress5_Click);
			this.checker4.AutoSize = true;
			this.checker4.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checker4.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.checker4.Location = new global::System.Drawing.Point(4, 249);
			this.checker4.Name = "checker4";
			this.checker4.Size = new global::System.Drawing.Size(0, 13);
			this.checker4.TabIndex = 70;
			this.checker3.AutoSize = true;
			this.checker3.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checker3.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.checker3.Location = new global::System.Drawing.Point(4, 185);
			this.checker3.Name = "checker3";
			this.checker3.Size = new global::System.Drawing.Size(0, 13);
			this.checker3.TabIndex = 64;
			this.checker2.AutoSize = true;
			this.checker2.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checker2.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.checker2.Location = new global::System.Drawing.Point(4, 121);
			this.checker2.Name = "checker2";
			this.checker2.Size = new global::System.Drawing.Size(0, 13);
			this.checker2.TabIndex = 41;
			this.checker1.AutoSize = true;
			this.checker1.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checker1.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.checker1.Location = new global::System.Drawing.Point(4, 36);
			this.checker1.Name = "checker1";
			this.checker1.Size = new global::System.Drawing.Size(0, 13);
			this.checker1.TabIndex = 63;
			this.checker5.AutoSize = true;
			this.checker5.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.checker5.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.checker5.Location = new global::System.Drawing.Point(4, 313);
			this.checker5.Name = "checker5";
			this.checker5.Size = new global::System.Drawing.Size(0, 13);
			this.checker5.TabIndex = 76;
			this.progressBar2.Location = new global::System.Drawing.Point(276, 107);
			this.progressBar2.Maximum = 1800;
			this.progressBar2.Name = "progressBar2";
			this.progressBar2.Size = new global::System.Drawing.Size(189, 18);
			this.progressBar2.TabIndex = 44;
			this.progressBar2.Visible = false;
			this.progressBar5.Location = new global::System.Drawing.Point(276, 300);
			this.progressBar5.Maximum = 60;
			this.progressBar5.Name = "progressBar5";
			this.progressBar5.Size = new global::System.Drawing.Size(190, 18);
			this.progressBar5.TabIndex = 74;
			this.progressBar5.Visible = false;
			this.tip5.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.tip5.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.tip5.Location = new global::System.Drawing.Point(4, 287);
			this.tip5.Name = "tip5";
			this.tip5.Size = new global::System.Drawing.Size(337, 39);
			this.tip5.TabIndex = 72;
			this.tip5.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.progressBar1.Location = new global::System.Drawing.Point(276, 23);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new global::System.Drawing.Size(190, 18);
			this.progressBar1.TabIndex = 50;
			this.progressBar1.Visible = false;
			this.progressBar4.Location = new global::System.Drawing.Point(276, 236);
			this.progressBar4.Maximum = 1800;
			this.progressBar4.Name = "progressBar4";
			this.progressBar4.Size = new global::System.Drawing.Size(190, 18);
			this.progressBar4.TabIndex = 67;
			this.progressBar4.Visible = false;
			this.tip4.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.tip4.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.tip4.Location = new global::System.Drawing.Point(4, 223);
			this.tip4.Name = "tip4";
			this.tip4.Size = new global::System.Drawing.Size(336, 39);
			this.tip4.TabIndex = 65;
			this.tip4.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.ChooseCompression.AutoSize = true;
			this.ChooseCompression.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.ChooseCompression.Location = new global::System.Drawing.Point(4, 57);
			this.ChooseCompression.Name = "ChooseCompression";
			this.ChooseCompression.Size = new global::System.Drawing.Size(0, 13);
			this.ChooseCompression.TabIndex = 57;
			this.ChooseCompression.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.progressBar3.Location = new global::System.Drawing.Point(276, 172);
			this.progressBar3.Name = "progressBar3";
			this.progressBar3.Size = new global::System.Drawing.Size(190, 18);
			this.progressBar3.TabIndex = 60;
			this.progressBar3.Visible = false;
			this.tip3.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.tip3.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.tip3.Location = new global::System.Drawing.Point(4, 159);
			this.tip3.Name = "tip3";
			this.tip3.Size = new global::System.Drawing.Size(300, 39);
			this.tip3.TabIndex = 58;
			this.tip3.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.tip1.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.tip1.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.tip1.Location = new global::System.Drawing.Point(4, 10);
			this.tip1.Name = "tip1";
			this.tip1.Size = new global::System.Drawing.Size(302, 39);
			this.tip1.TabIndex = 48;
			this.tip1.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.tip2.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.tip2.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.tip2.Location = new global::System.Drawing.Point(4, 95);
			this.tip2.Name = "tip2";
			this.tip2.Size = new global::System.Drawing.Size(300, 39);
			this.tip2.TabIndex = 36;
			this.tip2.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.long4.AutoSize = true;
			this.long4.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.long4.Location = new global::System.Drawing.Point(1, 262);
			this.long4.Name = "long4";
			this.long4.Size = new global::System.Drawing.Size(469, 13);
			this.long4.TabIndex = 69;
			this.long4.Text = "_____________________________________________________________________________";
			this.long3.AutoSize = true;
			this.long3.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.long3.Location = new global::System.Drawing.Point(1, 198);
			this.long3.Name = "long3";
			this.long3.Size = new global::System.Drawing.Size(469, 13);
			this.long3.TabIndex = 62;
			this.long3.Text = "_____________________________________________________________________________";
			this.long2.AutoSize = true;
			this.long2.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.long2.Location = new global::System.Drawing.Point(1, 134);
			this.long2.Name = "long2";
			this.long2.Size = new global::System.Drawing.Size(469, 13);
			this.long2.TabIndex = 47;
			this.long2.Text = "_____________________________________________________________________________";
			this.long1.AutoSize = true;
			this.long1.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.long1.Location = new global::System.Drawing.Point(1, 70);
			this.long1.Name = "long1";
			this.long1.Size = new global::System.Drawing.Size(469, 13);
			this.long1.TabIndex = 52;
			this.long1.Text = "_____________________________________________________________________________";
			this.tip6.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.tip6.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.tip6.Location = new global::System.Drawing.Point(4, 351);
			this.tip6.Name = "tip6";
			this.tip6.Size = new global::System.Drawing.Size(314, 55);
			this.tip6.TabIndex = 78;
			this.tip6.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.long5.AutoSize = true;
			this.long5.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.long5.Location = new global::System.Drawing.Point(1, 326);
			this.long5.Name = "long5";
			this.long5.Size = new global::System.Drawing.Size(469, 13);
			this.long5.TabIndex = 77;
			this.long5.Text = "_____________________________________________________________________________";
			this.Counter3.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.Counter3.Location = new global::System.Drawing.Point(308, 150);
			this.Counter3.Name = "Counter3";
			this.Counter3.Size = new global::System.Drawing.Size(130, 16);
			this.Counter3.TabIndex = 82;
			this.Counter3.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.Counter1.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.Counter1.Location = new global::System.Drawing.Point(308, 2);
			this.Counter1.Name = "Counter1";
			this.Counter1.Size = new global::System.Drawing.Size(130, 16);
			this.Counter1.TabIndex = 84;
			this.Counter1.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.SettingsIcon.BackColor = global::System.Drawing.Color.Transparent;
			this.SettingsIcon.BackgroundImage = global::Class89.Bitmap_56;
			this.SettingsIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.SettingsIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
			this.SettingsIcon.FlatAppearance.BorderSize = 0;
			this.SettingsIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
			this.SettingsIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
			this.SettingsIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SettingsIcon.Location = new global::System.Drawing.Point(616, 5);
			this.SettingsIcon.Name = "SettingsIcon";
			this.SettingsIcon.Size = new global::System.Drawing.Size(22, 22);
			this.SettingsIcon.TabIndex = 15;
			this.SettingsIcon.UseVisualStyleBackColor = false;
			this.SettingsIcon.Click += new global::System.EventHandler(this.SettingsIcon_Click);
			this.CleanerMainPanel.Controls.Add(this.CloseCleaner);
			this.CleanerMainPanel.Controls.Add(this.HeaderCleanerLog);
			this.CleanerMainPanel.Controls.Add(this.CleanerMainPanel2);
			this.CleanerMainPanel.Location = new global::System.Drawing.Point(0, 0);
			this.CleanerMainPanel.Name = "CleanerMainPanel";
			this.CleanerMainPanel.Size = new global::System.Drawing.Size(710, 480);
			this.CleanerMainPanel.TabIndex = 177;
			this.CleanerMainPanel.Visible = false;
			this.CloseCleaner.BackColor = global::System.Drawing.Color.Transparent;
			this.CloseCleaner.BackgroundImage = global::Class89.Bitmap_17;
			this.CloseCleaner.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.CloseCleaner.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
			this.CloseCleaner.FlatAppearance.BorderSize = 0;
			this.CloseCleaner.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
			this.CloseCleaner.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
			this.CloseCleaner.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.CloseCleaner.Location = new global::System.Drawing.Point(677, 5);
			this.CloseCleaner.Name = "CloseCleaner";
			this.CloseCleaner.Size = new global::System.Drawing.Size(22, 22);
			this.CloseCleaner.TabIndex = 33;
			this.CloseCleaner.UseVisualStyleBackColor = false;
			this.HeaderCleanerLog.AutoSize = true;
			this.HeaderCleanerLog.BackColor = global::System.Drawing.Color.Transparent;
			this.HeaderCleanerLog.Font = new global::System.Drawing.Font("Calibri", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.HeaderCleanerLog.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.HeaderCleanerLog.Location = new global::System.Drawing.Point(12, 9);
			this.HeaderCleanerLog.Name = "HeaderCleanerLog";
			this.HeaderCleanerLog.Size = new global::System.Drawing.Size(0, 15);
			this.HeaderCleanerLog.TabIndex = 31;
			this.CleanerMainPanel2.Controls.Add(this.Table);
			this.CleanerMainPanel2.Location = new global::System.Drawing.Point(12, 33);
			this.CleanerMainPanel2.Name = "CleanerMainPanel2";
			this.CleanerMainPanel2.Size = new global::System.Drawing.Size(686, 435);
			this.CleanerMainPanel2.TabIndex = 32;
			this.Table.AllowUserToAddRows = false;
			this.Table.AllowUserToDeleteRows = false;
			this.Table.AllowUserToOrderColumns = true;
			this.Table.AllowUserToResizeRows = false;
			this.Table.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.Table.ColumnHeadersBorderStyle = global::System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
			this.Table.ColumnHeadersHeightSizeMode = global::System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.Table.Columns.AddRange(new global::System.Windows.Forms.DataGridViewColumn[]
			{
				this.Column1,
				this.Column2,
				this.Column3
			});
			dataGridViewCellStyle.Alignment = global::System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = global::System.Drawing.SystemColors.Window;
			dataGridViewCellStyle.Font = new global::System.Drawing.Font("Tahoma", 8.25f);
			dataGridViewCellStyle.ForeColor = global::System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle.SelectionBackColor = global::System.Drawing.Color.FromArgb(52, 98, 137);
			dataGridViewCellStyle.SelectionForeColor = global::System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = global::System.Windows.Forms.DataGridViewTriState.False;
			this.Table.DefaultCellStyle = dataGridViewCellStyle;
			this.Table.EnableHeadersVisualStyles = false;
			this.Table.GridColor = global::System.Drawing.Color.FromArgb(41, 67, 85);
			this.Table.Location = new global::System.Drawing.Point(0, 0);
			this.Table.Name = "Table";
			this.Table.ReadOnly = true;
			this.Table.RowHeadersVisible = false;
			this.Table.RowTemplate.DefaultCellStyle.ForeColor = global::System.Drawing.Color.FromArgb(178, 198, 211);
			this.Table.RowTemplate.DefaultCellStyle.NullValue = null;
			this.Table.Size = new global::System.Drawing.Size(686, 435);
			this.Table.TabIndex = 1;
			this.Column1.HeaderText = "";
			this.Column1.Name = "Column1";
			this.Column1.ReadOnly = true;
			this.Column1.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.Column1.Width = 20;
			this.Column2.HeaderText = "";
			this.Column2.Name = "Column2";
			this.Column2.ReadOnly = true;
			this.Column2.Width = 20;
			this.Column3.HeaderText = "";
			this.Column3.Name = "Column3";
			this.Column3.ReadOnly = true;
			this.Column3.Width = 20;
			this.PanelOffer.BackColor = global::System.Drawing.Color.Transparent;
			this.PanelOffer.Location = new global::System.Drawing.Point(1000, 38);
			this.PanelOffer.Name = "PanelOffer";
			this.PanelOffer.Size = new global::System.Drawing.Size(710, 442);
			this.PanelOffer.TabIndex = 80;
			this.HeaderPanel.Controls.Add(this.ApplyButton);
			this.HeaderPanel.Controls.Add(this.MinimizeIcon);
			this.HeaderPanel.Controls.Add(this.PlayIcon);
			this.HeaderPanel.Controls.Add(this.SettingsIcon);
			this.HeaderPanel.Controls.Add(this.AboutIcon);
			this.HeaderPanel.Controls.Add(this.CloseIcon);
			this.HeaderPanel.Location = new global::System.Drawing.Point(0, 0);
			this.HeaderPanel.Name = "HeaderPanel";
			this.HeaderPanel.Size = new global::System.Drawing.Size(710, 38);
			this.HeaderPanel.TabIndex = 178;
			this.LeftPanel.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.LeftPanel.Controls.Add(this.TipDefault);
			this.LeftPanel.Controls.Add(this.Apply);
			this.LeftPanel.Controls.Add(this.ResAllButton);
			this.LeftPanel.Controls.Add(this.RemAllButton);
			this.LeftPanel.Controls.Add(this.LogoutRestartRequired);
			this.LeftPanel.Controls.Add(this.AddToApply);
			this.LeftPanel.Controls.Add(this.LeftMenu11);
			this.LeftPanel.Controls.Add(this.LeftMenu10);
			this.LeftPanel.Controls.Add(this.LeftMenu9);
			this.LeftPanel.Controls.Add(this.LeftMenu8);
			this.LeftPanel.Controls.Add(this.LeftMenu7);
			this.LeftPanel.Controls.Add(this.LeftMenu6);
			this.LeftPanel.Controls.Add(this.LeftMenu5);
			this.LeftPanel.Controls.Add(this.LeftMenu4);
			this.LeftPanel.Controls.Add(this.LeftMenu3);
			this.LeftPanel.Controls.Add(this.LeftMenu2);
			this.LeftPanel.Controls.Add(this.LeftMenu1);
			this.LeftPanel.Controls.Add(this.dot3);
			this.LeftPanel.Controls.Add(this.dot2);
			this.LeftPanel.Controls.Add(this.dot1);
			this.LeftPanel.Controls.Add(this.ButtonBack);
			this.LeftPanel.Location = new global::System.Drawing.Point(0, 38);
			this.LeftPanel.Name = "LeftPanel";
			this.LeftPanel.Size = new global::System.Drawing.Size(226, 442);
			this.LeftPanel.TabIndex = 179;
			this.TipDefault.AutoSize = true;
			this.TipDefault.BackColor = global::System.Drawing.Color.Transparent;
			this.TipDefault.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.TipDefault.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.TipDefault.Location = new global::System.Drawing.Point(13, 222);
			this.TipDefault.MaximumSize = new global::System.Drawing.Size(196, 0);
			this.TipDefault.Name = "TipDefault";
			this.TipDefault.Size = new global::System.Drawing.Size(0, 13);
			this.TipDefault.TabIndex = 188;
			this.Apply.BackColor = global::System.Drawing.SystemColors.Control;
			this.Apply.FlatAppearance.BorderSize = 0;
			this.Apply.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
			this.Apply.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.Apply.Location = new global::System.Drawing.Point(51, 397);
			this.Apply.Name = "Apply";
			this.Apply.Size = new global::System.Drawing.Size(110, 22);
			this.Apply.TabIndex = 186;
			this.Apply.UseVisualStyleBackColor = false;
			this.Apply.Click += new global::System.EventHandler(this.Apply_Click);
			this.ResAllButton.BackColor = global::System.Drawing.SystemColors.Control;
			this.ResAllButton.FlatAppearance.BorderSize = 0;
			this.ResAllButton.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
			this.ResAllButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ResAllButton.Location = new global::System.Drawing.Point(16, 370);
			this.ResAllButton.Name = "ResAllButton";
			this.ResAllButton.Size = new global::System.Drawing.Size(180, 22);
			this.ResAllButton.TabIndex = 192;
			this.ResAllButton.UseVisualStyleBackColor = false;
			this.ResAllButton.Visible = false;
			this.ResAllButton.Click += new global::System.EventHandler(this.ResAllButton_Click);
			this.RemAllButton.BackColor = global::System.Drawing.SystemColors.Control;
			this.RemAllButton.FlatAppearance.BorderSize = 0;
			this.RemAllButton.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
			this.RemAllButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.RemAllButton.Location = new global::System.Drawing.Point(16, 342);
			this.RemAllButton.Name = "RemAllButton";
			this.RemAllButton.Size = new global::System.Drawing.Size(180, 22);
			this.RemAllButton.TabIndex = 191;
			this.RemAllButton.UseVisualStyleBackColor = false;
			this.RemAllButton.Visible = false;
			this.RemAllButton.Click += new global::System.EventHandler(this.RemAllButton_Click);
			this.LogoutRestartRequired.BackColor = global::System.Drawing.Color.Transparent;
			this.LogoutRestartRequired.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LogoutRestartRequired.ForeColor = global::System.Drawing.Color.FromArgb(53, 58, 77);
			this.LogoutRestartRequired.Location = new global::System.Drawing.Point(6, 370);
			this.LogoutRestartRequired.Name = "LogoutRestartRequired";
			this.LogoutRestartRequired.Size = new global::System.Drawing.Size(202, 13);
			this.LogoutRestartRequired.TabIndex = 190;
			this.LogoutRestartRequired.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.LogoutRestartRequired.Visible = false;
			this.LeftMenu11.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu11.AutoSize = true;
			this.LeftMenu11.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu11.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu11.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu11.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu11.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu11.Location = new global::System.Drawing.Point(19, 199);
			this.LeftMenu11.Name = "LeftMenu11";
			this.LeftMenu11.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu11.TabIndex = 187;
			this.LeftMenu11.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu11_LinkClicked);
			this.LeftMenu10.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu10.AutoSize = true;
			this.LeftMenu10.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu10.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu10.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu10.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu10.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu10.Location = new global::System.Drawing.Point(19, 180);
			this.LeftMenu10.Name = "LeftMenu10";
			this.LeftMenu10.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu10.TabIndex = 185;
			this.LeftMenu10.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu10_LinkClicked);
			this.LeftMenu9.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu9.AutoSize = true;
			this.LeftMenu9.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu9.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu9.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu9.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu9.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu9.Location = new global::System.Drawing.Point(19, 161);
			this.LeftMenu9.Name = "LeftMenu9";
			this.LeftMenu9.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu9.TabIndex = 184;
			this.LeftMenu9.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu9_LinkClicked);
			this.LeftMenu8.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu8.AutoSize = true;
			this.LeftMenu8.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu8.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu8.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu8.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu8.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu8.Location = new global::System.Drawing.Point(19, 142);
			this.LeftMenu8.Name = "LeftMenu8";
			this.LeftMenu8.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu8.TabIndex = 183;
			this.LeftMenu8.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu8_LinkClicked);
			this.LeftMenu7.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu7.AutoSize = true;
			this.LeftMenu7.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu7.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu7.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu7.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu7.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu7.Location = new global::System.Drawing.Point(19, 123);
			this.LeftMenu7.Name = "LeftMenu7";
			this.LeftMenu7.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu7.TabIndex = 182;
			this.LeftMenu7.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu7_LinkClicked);
			this.LeftMenu6.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu6.AutoSize = true;
			this.LeftMenu6.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu6.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu6.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu6.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu6.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu6.Location = new global::System.Drawing.Point(19, 104);
			this.LeftMenu6.Name = "LeftMenu6";
			this.LeftMenu6.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu6.TabIndex = 181;
			this.LeftMenu6.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu6_LinkClicked);
			this.LeftMenu5.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu5.AutoSize = true;
			this.LeftMenu5.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu5.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu5.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu5.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu5.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu5.Location = new global::System.Drawing.Point(19, 85);
			this.LeftMenu5.Name = "LeftMenu5";
			this.LeftMenu5.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu5.TabIndex = 180;
			this.LeftMenu5.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu5_LinkClicked);
			this.LeftMenu4.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu4.AutoSize = true;
			this.LeftMenu4.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu4.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu4.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu4.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu4.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu4.Location = new global::System.Drawing.Point(19, 66);
			this.LeftMenu4.Name = "LeftMenu4";
			this.LeftMenu4.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu4.TabIndex = 179;
			this.LeftMenu4.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu4_LinkClicked);
			this.LeftMenu3.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu3.AutoSize = true;
			this.LeftMenu3.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu3.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu3.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu3.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu3.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu3.Location = new global::System.Drawing.Point(19, 47);
			this.LeftMenu3.Name = "LeftMenu3";
			this.LeftMenu3.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu3.TabIndex = 178;
			this.LeftMenu3.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu3_LinkClicked);
			this.LeftMenu2.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu2.AutoSize = true;
			this.LeftMenu2.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu2.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu2.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu2.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu2.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu2.Location = new global::System.Drawing.Point(19, 28);
			this.LeftMenu2.Name = "LeftMenu2";
			this.LeftMenu2.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu2.TabIndex = 177;
			this.LeftMenu2.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu2_LinkClicked);
			this.LeftMenu1.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.LeftMenu1.AutoSize = true;
			this.LeftMenu1.BackColor = global::System.Drawing.Color.Transparent;
			this.LeftMenu1.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.LeftMenu1.ForeColor = global::System.Drawing.Color.White;
			this.LeftMenu1.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.LeftMenu1.LinkColor = global::System.Drawing.Color.White;
			this.LeftMenu1.Location = new global::System.Drawing.Point(19, 9);
			this.LeftMenu1.Name = "LeftMenu1";
			this.LeftMenu1.Size = new global::System.Drawing.Size(0, 14);
			this.LeftMenu1.TabIndex = 176;
			this.LeftMenu1.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LeftMenu1_LinkClicked);
			this.dot3.BackColor = global::System.Drawing.Color.FromArgb(14, 23, 35);
			this.dot3.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.dot3.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.dot3.Location = new global::System.Drawing.Point(144, 397);
			this.dot3.Name = "dot3";
			this.dot3.Size = new global::System.Drawing.Size(10, 22);
			this.dot3.TabIndex = 195;
			this.dot3.Text = ".";
			this.dot3.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.dot2.BackColor = global::System.Drawing.Color.FromArgb(14, 23, 35);
			this.dot2.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.dot2.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.dot2.Location = new global::System.Drawing.Point(140, 397);
			this.dot2.Name = "dot2";
			this.dot2.Size = new global::System.Drawing.Size(10, 22);
			this.dot2.TabIndex = 194;
			this.dot2.Text = ".";
			this.dot2.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.dot1.BackColor = global::System.Drawing.Color.FromArgb(14, 23, 35);
			this.dot1.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.dot1.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.dot1.Location = new global::System.Drawing.Point(136, 397);
			this.dot1.Name = "dot1";
			this.dot1.Size = new global::System.Drawing.Size(10, 22);
			this.dot1.TabIndex = 193;
			this.dot1.Text = ".";
			this.dot1.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.ButtonBack.BackColor = global::System.Drawing.Color.FromArgb(14, 23, 35);
			this.ButtonBack.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.ButtonBack.ForeColor = global::System.Drawing.Color.FromArgb(144, 177, 219);
			this.ButtonBack.Location = new global::System.Drawing.Point(51, 397);
			this.ButtonBack.Name = "ButtonBack";
			this.ButtonBack.Size = new global::System.Drawing.Size(110, 22);
			this.ButtonBack.TabIndex = 189;
			this.ButtonBack.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.ServDownPanel.BackColor = global::System.Drawing.Color.Transparent;
			this.ServDownPanel.Controls.Add(this.ServStepsLabel);
			this.ServDownPanel.Controls.Add(this.ServProgressBar);
			this.ServDownPanel.Location = new global::System.Drawing.Point(232, 419);
			this.ServDownPanel.Name = "ServDownPanel";
			this.ServDownPanel.Size = new global::System.Drawing.Size(470, 50);
			this.ServDownPanel.TabIndex = 180;
			this.ServDownPanel.Visible = false;
			this.ServStepsLabel.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.ServStepsLabel.Location = new global::System.Drawing.Point(37, 23);
			this.ServStepsLabel.Name = "ServStepsLabel";
			this.ServStepsLabel.Size = new global::System.Drawing.Size(396, 18);
			this.ServStepsLabel.TabIndex = 1;
			this.ServStepsLabel.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.ServProgressBar.Location = new global::System.Drawing.Point(25, 11);
			this.ServProgressBar.Maximum = 32;
			this.ServProgressBar.Name = "ServProgressBar";
			this.ServProgressBar.Size = new global::System.Drawing.Size(420, 3);
			this.ServProgressBar.TabIndex = 0;
			this.OffDefender.Location = new global::System.Drawing.Point(475, -6);
			this.OffDefender.Name = "OffDefender";
			this.OffDefender.Size = new global::System.Drawing.Size(58, 50);
			this.OffDefender.TabIndex = 181;
			this.OffDefender.Visible = false;
			this.PersonalPanel.BackColor = global::System.Drawing.Color.Transparent;
			this.PersonalPanel.Controls.Add(this.FlowPanel);
			this.PersonalPanel.Controls.Add(this.PersonalPanelHeaderPanel);
			this.PersonalPanel.Location = new global::System.Drawing.Point(0, 0);
			this.PersonalPanel.Name = "PersonalPanel";
			this.PersonalPanel.Size = new global::System.Drawing.Size(710, 480);
			this.PersonalPanel.TabIndex = 182;
			this.PersonalPanel.Visible = false;
			this.FlowPanel.AutoScroll = true;
			this.FlowPanel.Location = new global::System.Drawing.Point(5, 40);
			this.FlowPanel.Name = "FlowPanel";
			this.FlowPanel.Size = new global::System.Drawing.Size(700, 436);
			this.FlowPanel.TabIndex = 1;
			this.PersonalPanelHeaderPanel.BackColor = global::System.Drawing.Color.Transparent;
			this.PersonalPanelHeaderPanel.Controls.Add(this.CloseRecommendations);
			this.PersonalPanelHeaderPanel.Controls.Add(this.PersonalPanelHeaderLabel);
			this.PersonalPanelHeaderPanel.Location = new global::System.Drawing.Point(0, 0);
			this.PersonalPanelHeaderPanel.Name = "PersonalPanelHeaderPanel";
			this.PersonalPanelHeaderPanel.Size = new global::System.Drawing.Size(710, 38);
			this.PersonalPanelHeaderPanel.TabIndex = 0;
			this.CloseRecommendations.BackColor = global::System.Drawing.Color.Transparent;
			this.CloseRecommendations.BackgroundImage = global::Class89.Bitmap_17;
			this.CloseRecommendations.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.CloseRecommendations.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
			this.CloseRecommendations.FlatAppearance.BorderSize = 0;
			this.CloseRecommendations.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
			this.CloseRecommendations.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
			this.CloseRecommendations.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.CloseRecommendations.Location = new global::System.Drawing.Point(677, 5);
			this.CloseRecommendations.Name = "CloseRecommendations";
			this.CloseRecommendations.Size = new global::System.Drawing.Size(22, 22);
			this.CloseRecommendations.TabIndex = 34;
			this.CloseRecommendations.UseVisualStyleBackColor = false;
			this.PersonalPanelHeaderLabel.AutoSize = true;
			this.PersonalPanelHeaderLabel.BackColor = global::System.Drawing.Color.Transparent;
			this.PersonalPanelHeaderLabel.Font = new global::System.Drawing.Font("Calibri", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
			this.PersonalPanelHeaderLabel.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
			this.PersonalPanelHeaderLabel.Location = new global::System.Drawing.Point(12, 9);
			this.PersonalPanelHeaderLabel.Name = "PersonalPanelHeaderLabel";
			this.PersonalPanelHeaderLabel.Size = new global::System.Drawing.Size(0, 15);
			this.PersonalPanelHeaderLabel.TabIndex = 30;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
			base.ClientSize = new global::System.Drawing.Size(710, 480);
			base.Controls.Add(this.PanelOffer);
			base.Controls.Add(this.CleanerMainPanel);
			base.Controls.Add(this.PersonalPanel);
			base.Controls.Add(this.OffDefender);
			base.Controls.Add(this.ServPanelChoice);
			base.Controls.Add(this.MainPanel11);
			base.Controls.Add(this.MainPanel10);
			base.Controls.Add(this.MainPanel9);
			base.Controls.Add(this.MainPanel8);
			base.Controls.Add(this.MainPanel7);
			base.Controls.Add(this.MainPanel6);
			base.Controls.Add(this.ServDownPanel);
			base.Controls.Add(this.MainPanelServ2);
			base.Controls.Add(this.HeaderPanel);
			base.Controls.Add(this.LeftPanel);
			base.Controls.Add(this.MainPanelServ1);
			base.Controls.Add(this.MainPanel4);
			base.Controls.Add(this.MainPanel3);
			base.Controls.Add(this.MainPanel2);
			base.Controls.Add(this.MainPanel1);
			this.DoubleBuffered = true;
			this.Font = new global::System.Drawing.Font("Tahoma", 8.25f);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.KeyPreview = true;
			this.MaximumSize = new global::System.Drawing.Size(710, 480);
			base.Name = "Form1";
			base.Opacity = 0.0;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Win 10 Tweaker";
			base.TransparencyKey = global::System.Drawing.Color.FromArgb(9, 0, 125);
			base.Load += new global::System.EventHandler(this.LinkLabel6_LinkClicked);
			base.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
			this.MainPanel2.ResumeLayout(false);
			this.MainPanel2.PerformLayout();
			this.panelmenu4.ResumeLayout(false);
			this.panelmenu4.PerformLayout();
			this.panelmenu3.ResumeLayout(false);
			this.panelmenu3.PerformLayout();
			this.panelmenu2.ResumeLayout(false);
			this.panelmenu2.PerformLayout();
			this.panelmenu1.ResumeLayout(false);
			this.panelmenu1.PerformLayout();
			this.MainPanel3.ResumeLayout(false);
			this.MainPanel3.PerformLayout();
			this.panelmenu6.ResumeLayout(false);
			this.panelmenu6.PerformLayout();
			this.panelmenu5.ResumeLayout(false);
			this.panelmenu5.PerformLayout();
			this.MainPanel4.ResumeLayout(false);
			this.MainPanel4.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.AddToApply).EndInit();
			this.MainPanel1.ResumeLayout(false);
			this.MainPanel1.PerformLayout();
			this.MainPanel6.ResumeLayout(false);
			this.MainPanel6.PerformLayout();
			this.MainPanel7.ResumeLayout(false);
			this.MainPanel7.PerformLayout();
			this.MainPanelServ1.ResumeLayout(false);
			this.MainPanelServ1.PerformLayout();
			this.ServPanelChoice.ResumeLayout(false);
			this.MainPanelServ2.ResumeLayout(false);
			this.MainPanelServ2.PerformLayout();
			this.MainPanel8.ResumeLayout(false);
			this.MainPanel8.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.MainPanel8Line2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.MainPanel8Line1).EndInit();
			this.MainPanel11.ResumeLayout(false);
			this.MainPanel11.PerformLayout();
			this.PersonalPanelPlate.ResumeLayout(false);
			this.MainPanel10.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.scanner).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.MainPanel10Line2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.MainPanel10Line1).EndInit();
			this.MainPanel9.ResumeLayout(false);
			this.MainPanel9.PerformLayout();
			this.panelLog.ResumeLayout(false);
			this.panelChoice.ResumeLayout(false);
			this.panelChoice.PerformLayout();
			this.PanelDragnDropArea.ResumeLayout(false);
			this.CleanerMainPanel.ResumeLayout(false);
			this.CleanerMainPanel.PerformLayout();
			this.CleanerMainPanel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.Table).EndInit();
			this.HeaderPanel.ResumeLayout(false);
			this.HeaderPanel.PerformLayout();
			this.LeftPanel.ResumeLayout(false);
			this.LeftPanel.PerformLayout();
			this.ServDownPanel.ResumeLayout(false);
			this.PersonalPanel.ResumeLayout(false);
			this.PersonalPanelHeaderPanel.ResumeLayout(false);
			this.PersonalPanelHeaderPanel.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x040004F5 RID: 1269
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040004F6 RID: 1270
		private global::System.Windows.Forms.LinkLabel checkAll2;

		// Token: 0x040004F7 RID: 1271
		private global::System.Windows.Forms.CheckBox ContextMenu17;

		// Token: 0x040004F8 RID: 1272
		private global::System.Windows.Forms.CheckBox ContextMenu16;

		// Token: 0x040004F9 RID: 1273
		private global::System.Windows.Forms.CheckBox ContextMenu15;

		// Token: 0x040004FA RID: 1274
		private global::System.Windows.Forms.CheckBox ContextMenu13;

		// Token: 0x040004FB RID: 1275
		private global::System.Windows.Forms.CheckBox ContextMenu12;

		// Token: 0x040004FC RID: 1276
		private global::System.Windows.Forms.CheckBox ContextMenu11;

		// Token: 0x040004FD RID: 1277
		private global::System.Windows.Forms.CheckBox ContextMenu10;

		// Token: 0x040004FE RID: 1278
		private global::System.Windows.Forms.CheckBox ContextMenu9;

		// Token: 0x040004FF RID: 1279
		private global::System.Windows.Forms.CheckBox ContextMenu6;

		// Token: 0x04000500 RID: 1280
		private global::System.Windows.Forms.CheckBox ContextMenu5;

		// Token: 0x04000501 RID: 1281
		private global::System.Windows.Forms.CheckBox ContextMenu4;

		// Token: 0x04000502 RID: 1282
		private global::System.Windows.Forms.CheckBox ContextMenu1;

		// Token: 0x04000503 RID: 1283
		private global::System.Windows.Forms.Panel MainPanel11;

		// Token: 0x04000504 RID: 1284
		private global::System.Windows.Forms.Panel MainPanel10;

		// Token: 0x04000505 RID: 1285
		private global::System.Windows.Forms.Panel MainPanel9;

		// Token: 0x04000506 RID: 1286
		private global::System.Windows.Forms.Panel MainPanel8;

		// Token: 0x04000507 RID: 1287
		private global::System.Windows.Forms.Panel MainPanel7;

		// Token: 0x04000508 RID: 1288
		private global::System.Windows.Forms.Panel MainPanel6;

		// Token: 0x04000509 RID: 1289
		private global::System.Windows.Forms.Panel MainPanel4;

		// Token: 0x0400050A RID: 1290
		private global::System.Windows.Forms.Panel MainPanel3;

		// Token: 0x0400050B RID: 1291
		private global::System.Windows.Forms.Panel MainPanel2;

		// Token: 0x0400050C RID: 1292
		private global::System.Windows.Forms.Panel MainPanel1;

		// Token: 0x0400050D RID: 1293
		private global::System.Windows.Forms.LinkLabel checkAll3;

		// Token: 0x0400050E RID: 1294
		private global::System.Windows.Forms.CheckBox ContextMenu14;

		// Token: 0x0400050F RID: 1295
		private global::System.Windows.Forms.LinkLabel checkAll4;

		// Token: 0x04000510 RID: 1296
		private global::System.Windows.Forms.CheckBox System17;

		// Token: 0x04000511 RID: 1297
		private global::System.Windows.Forms.CheckBox System16;

		// Token: 0x04000512 RID: 1298
		private global::System.Windows.Forms.CheckBox System15;

		// Token: 0x04000513 RID: 1299
		private global::System.Windows.Forms.CheckBox System14;

		// Token: 0x04000514 RID: 1300
		private global::System.Windows.Forms.CheckBox System13;

		// Token: 0x04000515 RID: 1301
		private global::System.Windows.Forms.CheckBox System12;

		// Token: 0x04000516 RID: 1302
		private global::System.Windows.Forms.CheckBox System11;

		// Token: 0x04000517 RID: 1303
		private global::System.Windows.Forms.CheckBox System10;

		// Token: 0x04000518 RID: 1304
		private global::System.Windows.Forms.CheckBox System9;

		// Token: 0x04000519 RID: 1305
		private global::System.Windows.Forms.CheckBox System8;

		// Token: 0x0400051A RID: 1306
		private global::System.Windows.Forms.CheckBox System7;

		// Token: 0x0400051B RID: 1307
		private global::System.Windows.Forms.CheckBox System6;

		// Token: 0x0400051C RID: 1308
		private global::System.Windows.Forms.CheckBox System5;

		// Token: 0x0400051D RID: 1309
		private global::System.Windows.Forms.CheckBox System4;

		// Token: 0x0400051E RID: 1310
		private global::System.Windows.Forms.CheckBox System3;

		// Token: 0x0400051F RID: 1311
		private global::System.Windows.Forms.CheckBox System2;

		// Token: 0x04000520 RID: 1312
		private global::System.Windows.Forms.CheckBox System1;

		// Token: 0x04000521 RID: 1313
		private global::System.Windows.Forms.CheckBox Shift8;

		// Token: 0x04000522 RID: 1314
		private global::System.Windows.Forms.CheckBox Shift7;

		// Token: 0x04000523 RID: 1315
		private global::System.Windows.Forms.CheckBox Shift6;

		// Token: 0x04000524 RID: 1316
		private global::System.Windows.Forms.CheckBox Shift5;

		// Token: 0x04000525 RID: 1317
		private global::System.Windows.Forms.CheckBox Shift4;

		// Token: 0x04000526 RID: 1318
		private global::System.Windows.Forms.CheckBox Shift3;

		// Token: 0x04000527 RID: 1319
		private global::System.Windows.Forms.CheckBox Shift2;

		// Token: 0x04000528 RID: 1320
		private global::System.Windows.Forms.CheckBox Shift1;

		// Token: 0x04000529 RID: 1321
		private global::System.Windows.Forms.ToolTip tooltip;

		// Token: 0x0400052A RID: 1322
		private global::System.Windows.Forms.CheckBox Interface17;

		// Token: 0x0400052B RID: 1323
		private global::System.Windows.Forms.CheckBox Interface16;

		// Token: 0x0400052C RID: 1324
		private global::System.Windows.Forms.CheckBox Interface15;

		// Token: 0x0400052D RID: 1325
		private global::System.Windows.Forms.CheckBox Interface14;

		// Token: 0x0400052E RID: 1326
		private global::System.Windows.Forms.CheckBox Interface13;

		// Token: 0x0400052F RID: 1327
		private global::System.Windows.Forms.CheckBox Interface12;

		// Token: 0x04000530 RID: 1328
		private global::System.Windows.Forms.CheckBox Interface11;

		// Token: 0x04000531 RID: 1329
		private global::System.Windows.Forms.CheckBox Interface10;

		// Token: 0x04000532 RID: 1330
		private global::System.Windows.Forms.CheckBox Interface9;

		// Token: 0x04000533 RID: 1331
		private global::System.Windows.Forms.CheckBox Interface8;

		// Token: 0x04000534 RID: 1332
		private global::System.Windows.Forms.CheckBox Interface7;

		// Token: 0x04000535 RID: 1333
		private global::System.Windows.Forms.CheckBox Interface6;

		// Token: 0x04000536 RID: 1334
		private global::System.Windows.Forms.CheckBox Interface5;

		// Token: 0x04000537 RID: 1335
		private global::System.Windows.Forms.CheckBox InterfaceFolder;

		// Token: 0x04000538 RID: 1336
		private global::System.Windows.Forms.CheckBox Interface4;

		// Token: 0x04000539 RID: 1337
		private global::System.Windows.Forms.CheckBox Interface3;

		// Token: 0x0400053A RID: 1338
		private global::System.Windows.Forms.CheckBox Interface2;

		// Token: 0x0400053B RID: 1339
		private global::System.Windows.Forms.CheckBox Interface1;

		// Token: 0x0400053C RID: 1340
		private global::System.Windows.Forms.LinkLabel linkmenu1;

		// Token: 0x0400053D RID: 1341
		private global::GClass10 panelmenu1;

		// Token: 0x0400053E RID: 1342
		private global::System.Windows.Forms.CheckBox Check9;

		// Token: 0x0400053F RID: 1343
		private global::System.Windows.Forms.CheckBox Check8;

		// Token: 0x04000540 RID: 1344
		private global::System.Windows.Forms.CheckBox Check7;

		// Token: 0x04000541 RID: 1345
		private global::System.Windows.Forms.CheckBox Check6;

		// Token: 0x04000542 RID: 1346
		private global::System.Windows.Forms.CheckBox Check5;

		// Token: 0x04000543 RID: 1347
		private global::System.Windows.Forms.CheckBox Check4;

		// Token: 0x04000544 RID: 1348
		private global::System.Windows.Forms.CheckBox Check3;

		// Token: 0x04000545 RID: 1349
		private global::System.Windows.Forms.CheckBox Check2;

		// Token: 0x04000546 RID: 1350
		private global::System.Windows.Forms.CheckBox Check1;

		// Token: 0x04000547 RID: 1351
		private global::GClass10 panelmenu3;

		// Token: 0x04000548 RID: 1352
		private global::System.Windows.Forms.CheckBox Check37;

		// Token: 0x04000549 RID: 1353
		private global::System.Windows.Forms.CheckBox Check35;

		// Token: 0x0400054A RID: 1354
		private global::System.Windows.Forms.CheckBox Check34;

		// Token: 0x0400054B RID: 1355
		private global::System.Windows.Forms.CheckBox Check33;

		// Token: 0x0400054C RID: 1356
		private global::System.Windows.Forms.CheckBox Check32;

		// Token: 0x0400054D RID: 1357
		private global::System.Windows.Forms.CheckBox Check31;

		// Token: 0x0400054E RID: 1358
		private global::System.Windows.Forms.LinkLabel linkmenu3;

		// Token: 0x0400054F RID: 1359
		private global::System.Windows.Forms.LinkLabel linkmenu2;

		// Token: 0x04000550 RID: 1360
		private global::GClass10 panelmenu2;

		// Token: 0x04000551 RID: 1361
		private global::System.Windows.Forms.CheckBox Check23;

		// Token: 0x04000552 RID: 1362
		private global::System.Windows.Forms.CheckBox Check22;

		// Token: 0x04000553 RID: 1363
		private global::System.Windows.Forms.CheckBox Check21;

		// Token: 0x04000554 RID: 1364
		private global::System.Windows.Forms.CheckBox Confidentiality17;

		// Token: 0x04000555 RID: 1365
		private global::System.Windows.Forms.CheckBox Confidentiality16;

		// Token: 0x04000556 RID: 1366
		private global::System.Windows.Forms.CheckBox Confidentiality15;

		// Token: 0x04000557 RID: 1367
		private global::System.Windows.Forms.CheckBox Confidentiality14;

		// Token: 0x04000558 RID: 1368
		private global::System.Windows.Forms.CheckBox Confidentiality13;

		// Token: 0x04000559 RID: 1369
		private global::System.Windows.Forms.CheckBox Confidentiality12;

		// Token: 0x0400055A RID: 1370
		private global::System.Windows.Forms.CheckBox Confidentiality11;

		// Token: 0x0400055B RID: 1371
		private global::System.Windows.Forms.CheckBox Confidentiality10;

		// Token: 0x0400055C RID: 1372
		private global::System.Windows.Forms.CheckBox Confidentiality9;

		// Token: 0x0400055D RID: 1373
		private global::System.Windows.Forms.CheckBox Confidentiality8;

		// Token: 0x0400055E RID: 1374
		private global::System.Windows.Forms.CheckBox Confidentiality7;

		// Token: 0x0400055F RID: 1375
		private global::System.Windows.Forms.CheckBox Confidentiality6;

		// Token: 0x04000560 RID: 1376
		private global::System.Windows.Forms.CheckBox Confidentiality5;

		// Token: 0x04000561 RID: 1377
		private global::System.Windows.Forms.CheckBox Confidentiality4;

		// Token: 0x04000562 RID: 1378
		private global::System.Windows.Forms.CheckBox Confidentiality3;

		// Token: 0x04000563 RID: 1379
		private global::System.Windows.Forms.CheckBox Confidentiality2;

		// Token: 0x04000564 RID: 1380
		private global::System.Windows.Forms.CheckBox Confidentiality1;

		// Token: 0x04000565 RID: 1381
		private global::System.Windows.Forms.LinkLabel checkAll1;

		// Token: 0x04000566 RID: 1382
		private global::System.Windows.Forms.LinkLabel checkAll5;

		// Token: 0x04000567 RID: 1383
		private global::GClass10 panelmenu6;

		// Token: 0x04000568 RID: 1384
		private global::System.Windows.Forms.CheckBox Check69;

		// Token: 0x04000569 RID: 1385
		private global::System.Windows.Forms.CheckBox Check68;

		// Token: 0x0400056A RID: 1386
		private global::System.Windows.Forms.CheckBox Check67;

		// Token: 0x0400056B RID: 1387
		private global::System.Windows.Forms.CheckBox Check66;

		// Token: 0x0400056C RID: 1388
		private global::System.Windows.Forms.CheckBox Check65;

		// Token: 0x0400056D RID: 1389
		private global::System.Windows.Forms.CheckBox Check64;

		// Token: 0x0400056E RID: 1390
		private global::System.Windows.Forms.CheckBox Check63;

		// Token: 0x0400056F RID: 1391
		private global::System.Windows.Forms.CheckBox Check62;

		// Token: 0x04000570 RID: 1392
		private global::System.Windows.Forms.CheckBox Check61;

		// Token: 0x04000571 RID: 1393
		private global::System.Windows.Forms.LinkLabel linkmenu6;

		// Token: 0x04000572 RID: 1394
		private global::System.Windows.Forms.CheckBox checkBoxCleaner1;

		// Token: 0x04000573 RID: 1395
		private global::System.Windows.Forms.CheckBox checkBoxCleaner2;

		// Token: 0x04000574 RID: 1396
		private global::System.Windows.Forms.CheckBox checkBoxCleaner4;

		// Token: 0x04000575 RID: 1397
		private global::System.Windows.Forms.CheckBox checkBoxCleaner5;

		// Token: 0x04000576 RID: 1398
		private global::System.Windows.Forms.CheckBox checkBoxCleaner6;

		// Token: 0x04000577 RID: 1399
		private global::System.Windows.Forms.CheckBox checkBoxCleaner7;

		// Token: 0x04000578 RID: 1400
		private global::System.Windows.Forms.CheckBox checkBoxCleaner8;

		// Token: 0x04000579 RID: 1401
		private global::System.Windows.Forms.CheckBox checkBoxCleaner9;

		// Token: 0x0400057A RID: 1402
		private global::System.Windows.Forms.CheckBox checkBoxCleaner10;

		// Token: 0x0400057B RID: 1403
		private global::System.Windows.Forms.CheckBox checkBoxCleaner11;

		// Token: 0x0400057C RID: 1404
		private global::System.Windows.Forms.CheckBox checkBoxCleaner12;

		// Token: 0x0400057D RID: 1405
		private global::System.Windows.Forms.CheckBox checkBoxCleaner13;

		// Token: 0x0400057E RID: 1406
		private global::System.Windows.Forms.CheckBox checkBoxCleaner14;

		// Token: 0x0400057F RID: 1407
		private global::System.Windows.Forms.CheckBox checkBoxCleaner15;

		// Token: 0x04000580 RID: 1408
		private global::System.Windows.Forms.CheckBox checkBoxCleaner16;

		// Token: 0x04000581 RID: 1409
		private global::System.Windows.Forms.CheckBox checkBoxCleaner17;

		// Token: 0x04000582 RID: 1410
		private global::System.Windows.Forms.CheckBox checkBoxCleaner18;

		// Token: 0x04000583 RID: 1411
		private global::System.Windows.Forms.Panel ServDownPanel;

		// Token: 0x04000584 RID: 1412
		private global::System.Windows.Forms.Panel MainPanelServ1;

		// Token: 0x04000585 RID: 1413
		private global::System.Windows.Forms.Panel MainPanelServ2;

		// Token: 0x04000586 RID: 1414
		private global::System.Windows.Forms.Label StartupBlueNotWorking;

		// Token: 0x04000587 RID: 1415
		private global::System.Windows.Forms.Label StartupGrayTip;

		// Token: 0x04000588 RID: 1416
		private global::System.Windows.Forms.Label StartupBlueWorking;

		// Token: 0x04000589 RID: 1417
		private global::System.Windows.Forms.Label StartupYellowTip;

		// Token: 0x0400058A RID: 1418
		private global::System.Windows.Forms.Label StartupBottomTip;

		// Token: 0x0400058B RID: 1419
		private global::System.Windows.Forms.Panel autorunpanel;

		// Token: 0x0400058C RID: 1420
		private global::System.Windows.Forms.PictureBox MainPanel8Line1;

		// Token: 0x0400058D RID: 1421
		private global::System.Windows.Forms.PictureBox MainPanel8Line2;

		// Token: 0x0400058E RID: 1422
		private global::System.Windows.Forms.CheckBox checkBoxCleaner3;

		// Token: 0x0400058F RID: 1423
		private global::System.Windows.Forms.LinkLabel linkmenu4;

		// Token: 0x04000590 RID: 1424
		private global::GClass10 panelmenu4;

		// Token: 0x04000591 RID: 1425
		private global::System.Windows.Forms.CheckBox Check45;

		// Token: 0x04000592 RID: 1426
		private global::System.Windows.Forms.CheckBox Check42;

		// Token: 0x04000593 RID: 1427
		private global::System.Windows.Forms.CheckBox Check43;

		// Token: 0x04000594 RID: 1428
		private global::System.Windows.Forms.CheckBox Check44;

		// Token: 0x04000595 RID: 1429
		private global::System.Windows.Forms.CheckBox Check41;

		// Token: 0x04000596 RID: 1430
		private global::System.Windows.Forms.CheckBox Check38;

		// Token: 0x04000597 RID: 1431
		private global::System.Windows.Forms.CheckBox Check36;

		// Token: 0x04000598 RID: 1432
		private global::System.Windows.Forms.Timer mainTimer;

		// Token: 0x04000599 RID: 1433
		private global::System.Windows.Forms.Label _speed1;

		// Token: 0x0400059A RID: 1434
		private global::System.Windows.Forms.Label _speed;

		// Token: 0x0400059B RID: 1435
		private global::System.Windows.Forms.Label _monitor1;

		// Token: 0x0400059C RID: 1436
		private global::System.Windows.Forms.Label _monitor;

		// Token: 0x0400059D RID: 1437
		private global::System.Windows.Forms.Label _gpu1;

		// Token: 0x0400059E RID: 1438
		private global::System.Windows.Forms.Label _gpu;

		// Token: 0x0400059F RID: 1439
		private global::System.Windows.Forms.Label _cpu1;

		// Token: 0x040005A0 RID: 1440
		private global::System.Windows.Forms.Label _cpu;

		// Token: 0x040005A1 RID: 1441
		private global::System.Windows.Forms.Label _mother1;

		// Token: 0x040005A2 RID: 1442
		private global::System.Windows.Forms.Label _mother;

		// Token: 0x040005A3 RID: 1443
		private global::System.Windows.Forms.Label _pctime1;

		// Token: 0x040005A4 RID: 1444
		private global::System.Windows.Forms.Label _pctime;

		// Token: 0x040005A5 RID: 1445
		private global::System.Windows.Forms.Label _ip1;

		// Token: 0x040005A6 RID: 1446
		private global::System.Windows.Forms.Label _ip;

		// Token: 0x040005A7 RID: 1447
		private global::System.Windows.Forms.Label _ram1;

		// Token: 0x040005A8 RID: 1448
		private global::System.Windows.Forms.Label _ram;

		// Token: 0x040005A9 RID: 1449
		private global::System.Windows.Forms.Label _os1;

		// Token: 0x040005AA RID: 1450
		private global::System.Windows.Forms.Label _os;

		// Token: 0x040005AB RID: 1451
		private global::System.Windows.Forms.Label _drive;

		// Token: 0x040005AC RID: 1452
		private global::System.Windows.Forms.Label _drive1;

		// Token: 0x040005AD RID: 1453
		private global::System.Windows.Forms.Label _usb;

		// Token: 0x040005AE RID: 1454
		private global::System.Windows.Forms.Label _usb1;

		// Token: 0x040005AF RID: 1455
		private global::System.Windows.Forms.Label pctype;

		// Token: 0x040005B0 RID: 1456
		private global::System.Windows.Forms.Button MinimizeIcon;

		// Token: 0x040005B1 RID: 1457
		private global::System.Windows.Forms.Button PlayIcon;

		// Token: 0x040005B2 RID: 1458
		private global::System.Windows.Forms.Button AboutIcon;

		// Token: 0x040005B3 RID: 1459
		private global::System.Windows.Forms.Button CloseIcon;

		// Token: 0x040005B4 RID: 1460
		private global::System.Windows.Forms.Label ApplyButton;

		// Token: 0x040005B5 RID: 1461
		private global::System.Windows.Forms.Label DropFileHereVT;

		// Token: 0x040005B6 RID: 1462
		private global::System.Windows.Forms.PictureBox MainPanel10Line2;

		// Token: 0x040005B7 RID: 1463
		private global::System.Windows.Forms.PictureBox MainPanel10Line1;

		// Token: 0x040005B8 RID: 1464
		private global::System.Windows.Forms.PictureBox scanner;

		// Token: 0x040005B9 RID: 1465
		private global::System.Windows.Forms.CheckBox ContextMenu7;

		// Token: 0x040005BA RID: 1466
		private global::System.Windows.Forms.CheckBox ContextMenu8;

		// Token: 0x040005BB RID: 1467
		private global::System.Windows.Forms.LinkLabel showip;

		// Token: 0x040005BC RID: 1468
		private global::System.Windows.Forms.CheckBox AntiZapret;

		// Token: 0x040005BD RID: 1469
		private global::System.Windows.Forms.Button WindowsStore_del;

		// Token: 0x040005BE RID: 1470
		private global::System.Windows.Forms.Panel PanelDragnDropArea;

		// Token: 0x040005BF RID: 1471
		private global::System.Windows.Forms.Label OptDragText;

		// Token: 0x040005C0 RID: 1472
		private global::System.Windows.Forms.RadioButton OptRadioButton1;

		// Token: 0x040005C1 RID: 1473
		private global::System.Windows.Forms.RadioButton OptRadioButton2;

		// Token: 0x040005C2 RID: 1474
		private global::System.Windows.Forms.RadioButton OptRadioButton3;

		// Token: 0x040005C3 RID: 1475
		private global::System.Windows.Forms.RadioButton OptRadioButton4;

		// Token: 0x040005C4 RID: 1476
		private global::System.Windows.Forms.Button restore3;

		// Token: 0x040005C5 RID: 1477
		private global::System.Windows.Forms.Button restore2;

		// Token: 0x040005C6 RID: 1478
		private global::System.Windows.Forms.Button restore1;

		// Token: 0x040005C7 RID: 1479
		private global::System.Windows.Forms.Button compress5;

		// Token: 0x040005C8 RID: 1480
		private global::System.Windows.Forms.Button compress4;

		// Token: 0x040005C9 RID: 1481
		private global::System.Windows.Forms.Button compress3;

		// Token: 0x040005CA RID: 1482
		private global::System.Windows.Forms.Button compress2;

		// Token: 0x040005CB RID: 1483
		private global::System.Windows.Forms.Button compress1;

		// Token: 0x040005CC RID: 1484
		private global::System.Windows.Forms.Label checker5;

		// Token: 0x040005CD RID: 1485
		private global::System.Windows.Forms.Label checker4;

		// Token: 0x040005CE RID: 1486
		private global::System.Windows.Forms.Label checker3;

		// Token: 0x040005CF RID: 1487
		private global::System.Windows.Forms.Label checker2;

		// Token: 0x040005D0 RID: 1488
		private global::System.Windows.Forms.Label checker1;

		// Token: 0x040005D1 RID: 1489
		private global::System.Windows.Forms.ProgressBar progressBar5;

		// Token: 0x040005D2 RID: 1490
		private global::System.Windows.Forms.ProgressBar progressBar4;

		// Token: 0x040005D3 RID: 1491
		private global::System.Windows.Forms.ProgressBar progressBar3;

		// Token: 0x040005D4 RID: 1492
		private global::System.Windows.Forms.ProgressBar progressBar2;

		// Token: 0x040005D5 RID: 1493
		private global::System.Windows.Forms.ProgressBar progressBar1;

		// Token: 0x040005D6 RID: 1494
		private global::System.Windows.Forms.Label ChooseCompression;

		// Token: 0x040005D7 RID: 1495
		private global::System.Windows.Forms.Label tip6;

		// Token: 0x040005D8 RID: 1496
		private global::System.Windows.Forms.Label tip5;

		// Token: 0x040005D9 RID: 1497
		private global::System.Windows.Forms.Label tip4;

		// Token: 0x040005DA RID: 1498
		private global::System.Windows.Forms.Label tip3;

		// Token: 0x040005DB RID: 1499
		private global::System.Windows.Forms.Label tip2;

		// Token: 0x040005DC RID: 1500
		private global::System.Windows.Forms.Label tip1;

		// Token: 0x040005DD RID: 1501
		private global::System.Windows.Forms.Label long4;

		// Token: 0x040005DE RID: 1502
		private global::System.Windows.Forms.Label long3;

		// Token: 0x040005DF RID: 1503
		private global::System.Windows.Forms.Label long2;

		// Token: 0x040005E0 RID: 1504
		private global::System.Windows.Forms.Label long1;

		// Token: 0x040005E1 RID: 1505
		private global::System.Windows.Forms.Label long5;

		// Token: 0x040005E2 RID: 1506
		private global::GClass11 PanelOffer;

		// Token: 0x040005E3 RID: 1507
		private global::System.Windows.Forms.Panel panelChoice;

		// Token: 0x040005E4 RID: 1508
		private global::System.Windows.Forms.Button buttonNo;

		// Token: 0x040005E5 RID: 1509
		private global::System.Windows.Forms.Button buttonYes;

		// Token: 0x040005E6 RID: 1510
		private global::System.Windows.Forms.Label panelChoiceLine;

		// Token: 0x040005E7 RID: 1511
		private global::System.Windows.Forms.Button SettingsIcon;

		// Token: 0x040005E8 RID: 1512
		private global::System.Windows.Forms.CheckBox ContextMenu2;

		// Token: 0x040005E9 RID: 1513
		private global::System.Windows.Forms.CheckBox ContextMenu3;

		// Token: 0x040005EA RID: 1514
		private global::System.Windows.Forms.Button RestoreConfidentiality17;

		// Token: 0x040005EB RID: 1515
		private global::System.Windows.Forms.Button RestoreConfidentiality16;

		// Token: 0x040005EC RID: 1516
		private global::System.Windows.Forms.Button RestoreConfidentiality15;

		// Token: 0x040005ED RID: 1517
		private global::System.Windows.Forms.Button RestoreConfidentiality14;

		// Token: 0x040005EE RID: 1518
		private global::System.Windows.Forms.Button RestoreConfidentiality13;

		// Token: 0x040005EF RID: 1519
		private global::System.Windows.Forms.Button RestoreConfidentiality12;

		// Token: 0x040005F0 RID: 1520
		private global::System.Windows.Forms.Button RestoreConfidentiality11;

		// Token: 0x040005F1 RID: 1521
		private global::System.Windows.Forms.Button RestoreConfidentiality10;

		// Token: 0x040005F2 RID: 1522
		private global::System.Windows.Forms.Button RestoreConfidentiality9;

		// Token: 0x040005F3 RID: 1523
		private global::System.Windows.Forms.Button RestoreConfidentiality8;

		// Token: 0x040005F4 RID: 1524
		private global::System.Windows.Forms.Button RestoreConfidentiality7;

		// Token: 0x040005F5 RID: 1525
		private global::System.Windows.Forms.Button RestoreConfidentiality6;

		// Token: 0x040005F6 RID: 1526
		private global::System.Windows.Forms.Button RestoreConfidentiality5;

		// Token: 0x040005F7 RID: 1527
		private global::System.Windows.Forms.Button RestoreConfidentiality4;

		// Token: 0x040005F8 RID: 1528
		private global::System.Windows.Forms.Button RestoreConfidentiality3;

		// Token: 0x040005F9 RID: 1529
		private global::System.Windows.Forms.Button RestoreConfidentiality2;

		// Token: 0x040005FA RID: 1530
		private global::System.Windows.Forms.Button RestoreConfidentiality1;

		// Token: 0x040005FB RID: 1531
		private global::System.Windows.Forms.Button RestoreContextMenu17;

		// Token: 0x040005FC RID: 1532
		private global::System.Windows.Forms.Button RestoreContextMenu16;

		// Token: 0x040005FD RID: 1533
		private global::System.Windows.Forms.Button RestoreContextMenu15;

		// Token: 0x040005FE RID: 1534
		private global::System.Windows.Forms.Button RestoreContextMenu14;

		// Token: 0x040005FF RID: 1535
		private global::System.Windows.Forms.Button RestoreContextMenu13;

		// Token: 0x04000600 RID: 1536
		private global::System.Windows.Forms.Button RestoreContextMenu12;

		// Token: 0x04000601 RID: 1537
		private global::System.Windows.Forms.Button RestoreContextMenu11;

		// Token: 0x04000602 RID: 1538
		private global::System.Windows.Forms.Button RestoreContextMenu10;

		// Token: 0x04000603 RID: 1539
		private global::System.Windows.Forms.Button RestoreContextMenu9;

		// Token: 0x04000604 RID: 1540
		private global::System.Windows.Forms.Button RestoreContextMenu8;

		// Token: 0x04000605 RID: 1541
		private global::System.Windows.Forms.Button RestoreContextMenu7;

		// Token: 0x04000606 RID: 1542
		private global::System.Windows.Forms.Button RestoreContextMenu6;

		// Token: 0x04000607 RID: 1543
		private global::System.Windows.Forms.Button RestoreContextMenu5;

		// Token: 0x04000608 RID: 1544
		private global::System.Windows.Forms.Button RestoreContextMenu4;

		// Token: 0x04000609 RID: 1545
		private global::System.Windows.Forms.Button RestoreContextMenu3;

		// Token: 0x0400060A RID: 1546
		private global::System.Windows.Forms.Button RestoreContextMenu2;

		// Token: 0x0400060B RID: 1547
		private global::System.Windows.Forms.Button RestoreContextMenu1;

		// Token: 0x0400060C RID: 1548
		private global::System.Windows.Forms.Button RestoreInterface17;

		// Token: 0x0400060D RID: 1549
		private global::System.Windows.Forms.Button RestoreInterface16;

		// Token: 0x0400060E RID: 1550
		private global::System.Windows.Forms.Button RestoreInterface15;

		// Token: 0x0400060F RID: 1551
		private global::System.Windows.Forms.Button RestoreInterface14;

		// Token: 0x04000610 RID: 1552
		private global::System.Windows.Forms.Button RestoreInterface13;

		// Token: 0x04000611 RID: 1553
		private global::System.Windows.Forms.Button RestoreInterface12;

		// Token: 0x04000612 RID: 1554
		private global::System.Windows.Forms.Button RestoreInterface11;

		// Token: 0x04000613 RID: 1555
		private global::System.Windows.Forms.Button RestoreInterface10;

		// Token: 0x04000614 RID: 1556
		private global::System.Windows.Forms.Button RestoreInterface9;

		// Token: 0x04000615 RID: 1557
		private global::System.Windows.Forms.Button RestoreInterface8;

		// Token: 0x04000616 RID: 1558
		private global::System.Windows.Forms.Button RestoreInterface7;

		// Token: 0x04000617 RID: 1559
		private global::System.Windows.Forms.Button RestoreInterface6;

		// Token: 0x04000618 RID: 1560
		private global::System.Windows.Forms.Button RestoreInterface5;

		// Token: 0x04000619 RID: 1561
		private global::System.Windows.Forms.Button RestoreInterface4;

		// Token: 0x0400061A RID: 1562
		private global::System.Windows.Forms.Button RestoreInterface3;

		// Token: 0x0400061B RID: 1563
		private global::System.Windows.Forms.Button RestoreInterface2;

		// Token: 0x0400061C RID: 1564
		private global::System.Windows.Forms.Button RestoreInterface1;

		// Token: 0x0400061D RID: 1565
		private global::System.Windows.Forms.Button RestoreSystem17;

		// Token: 0x0400061E RID: 1566
		private global::System.Windows.Forms.Button RestoreSystem16;

		// Token: 0x0400061F RID: 1567
		private global::System.Windows.Forms.Button RestoreSystem15;

		// Token: 0x04000620 RID: 1568
		private global::System.Windows.Forms.Button RestoreSystem14;

		// Token: 0x04000621 RID: 1569
		private global::System.Windows.Forms.Button RestoreSystem13;

		// Token: 0x04000622 RID: 1570
		private global::System.Windows.Forms.Button RestoreSystem12;

		// Token: 0x04000623 RID: 1571
		private global::System.Windows.Forms.Button RestoreSystem11;

		// Token: 0x04000624 RID: 1572
		private global::System.Windows.Forms.Button RestoreSystem10;

		// Token: 0x04000625 RID: 1573
		private global::System.Windows.Forms.Button RestoreSystem9;

		// Token: 0x04000626 RID: 1574
		private global::System.Windows.Forms.Button RestoreSystem8;

		// Token: 0x04000627 RID: 1575
		private global::System.Windows.Forms.Button RestoreSystem7;

		// Token: 0x04000628 RID: 1576
		private global::System.Windows.Forms.Button RestoreSystem6;

		// Token: 0x04000629 RID: 1577
		private global::System.Windows.Forms.Button RestoreSystem5;

		// Token: 0x0400062A RID: 1578
		private global::System.Windows.Forms.Button RestoreSystem4;

		// Token: 0x0400062B RID: 1579
		private global::System.Windows.Forms.Button RestoreSystem3;

		// Token: 0x0400062C RID: 1580
		private global::System.Windows.Forms.Button RestoreSystem2;

		// Token: 0x0400062D RID: 1581
		private global::System.Windows.Forms.Button RestoreSystem1;

		// Token: 0x0400062E RID: 1582
		private global::System.Windows.Forms.Panel panelLog;

		// Token: 0x0400062F RID: 1583
		private global::System.Windows.Forms.Button WindowsStore_;

		// Token: 0x04000630 RID: 1584
		private global::System.Windows.Forms.Button Feedback_del;

		// Token: 0x04000631 RID: 1585
		private global::System.Windows.Forms.Button Feedback_;

		// Token: 0x04000632 RID: 1586
		private global::System.Windows.Forms.Button OfficeHub_del;

		// Token: 0x04000633 RID: 1587
		private global::System.Windows.Forms.Button OfficeHub_;

		// Token: 0x04000634 RID: 1588
		private global::System.Windows.Forms.Button Photos_del;

		// Token: 0x04000635 RID: 1589
		private global::System.Windows.Forms.Button Photos_;

		// Token: 0x04000636 RID: 1590
		private global::System.Windows.Forms.Button Getstarted_del;

		// Token: 0x04000637 RID: 1591
		private global::System.Windows.Forms.Button Getstarted_;

		// Token: 0x04000638 RID: 1592
		private global::System.Windows.Forms.Button Skype_del;

		// Token: 0x04000639 RID: 1593
		private global::System.Windows.Forms.Button Skype_;

		// Token: 0x0400063A RID: 1594
		private global::System.Windows.Forms.Button Communications_del;

		// Token: 0x0400063B RID: 1595
		private global::System.Windows.Forms.Button Communications_;

		// Token: 0x0400063C RID: 1596
		private global::System.Windows.Forms.Button GetHelp_del;

		// Token: 0x0400063D RID: 1597
		private global::System.Windows.Forms.Button GetHelp_;

		// Token: 0x0400063E RID: 1598
		private global::System.Windows.Forms.Button BingWeather_del;

		// Token: 0x0400063F RID: 1599
		private global::System.Windows.Forms.Button BingWeather_;

		// Token: 0x04000640 RID: 1600
		private global::System.Windows.Forms.Button Sketch_del;

		// Token: 0x04000641 RID: 1601
		private global::System.Windows.Forms.Button Sketch_;

		// Token: 0x04000642 RID: 1602
		private global::System.Windows.Forms.Button ZuneMusic_del;

		// Token: 0x04000643 RID: 1603
		private global::System.Windows.Forms.Button ZuneMusic_;

		// Token: 0x04000644 RID: 1604
		private global::System.Windows.Forms.Button People_del;

		// Token: 0x04000645 RID: 1605
		private global::System.Windows.Forms.Button People_;

		// Token: 0x04000646 RID: 1606
		private global::System.Windows.Forms.Button ZuneVideo_del;

		// Token: 0x04000647 RID: 1607
		private global::System.Windows.Forms.Button ZuneVideo_;

		// Token: 0x04000648 RID: 1608
		private global::System.Windows.Forms.Button WindowsMaps_del;

		// Token: 0x04000649 RID: 1609
		private global::System.Windows.Forms.Button WindowsMaps_;

		// Token: 0x0400064A RID: 1610
		private global::System.Windows.Forms.Button WindowsCamera_del;

		// Token: 0x0400064B RID: 1611
		private global::System.Windows.Forms.Button WindowsCamera_;

		// Token: 0x0400064C RID: 1612
		private global::System.Windows.Forms.Button Recorder_del;

		// Token: 0x0400064D RID: 1613
		private global::System.Windows.Forms.Button Recorder_;

		// Token: 0x0400064E RID: 1614
		private global::System.Windows.Forms.Button WindowsAlarms_del;

		// Token: 0x0400064F RID: 1615
		private global::System.Windows.Forms.Button WindowsAlarms_;

		// Token: 0x04000650 RID: 1616
		private global::System.Windows.Forms.Button Xbox_del;

		// Token: 0x04000651 RID: 1617
		private global::System.Windows.Forms.Button Xbox_;

		// Token: 0x04000652 RID: 1618
		private global::System.Windows.Forms.Button StickyNotes_del;

		// Token: 0x04000653 RID: 1619
		private global::System.Windows.Forms.Button StickyNotes_;

		// Token: 0x04000654 RID: 1620
		private global::System.Windows.Forms.Button MixedReality_del;

		// Token: 0x04000655 RID: 1621
		private global::System.Windows.Forms.Button MixedReality_;

		// Token: 0x04000656 RID: 1622
		private global::System.Windows.Forms.Button Paint_del;

		// Token: 0x04000657 RID: 1623
		private global::System.Windows.Forms.Button Paint_;

		// Token: 0x04000658 RID: 1624
		private global::System.Windows.Forms.Button OneNote_del;

		// Token: 0x04000659 RID: 1625
		private global::System.Windows.Forms.Button OneNote_;

		// Token: 0x0400065A RID: 1626
		private global::System.Windows.Forms.Button Solitaire_del;

		// Token: 0x0400065B RID: 1627
		private global::System.Windows.Forms.Button Solitaire_;

		// Token: 0x0400065C RID: 1628
		private global::System.Windows.Forms.Button Viewer_del;

		// Token: 0x0400065D RID: 1629
		private global::System.Windows.Forms.Button Viewer_;

		// Token: 0x0400065E RID: 1630
		private global::System.Windows.Forms.Label Feedback_text;

		// Token: 0x0400065F RID: 1631
		private global::System.Windows.Forms.Label OfficeHub_text;

		// Token: 0x04000660 RID: 1632
		private global::System.Windows.Forms.Label Photos_text;

		// Token: 0x04000661 RID: 1633
		private global::System.Windows.Forms.Label Getstarted_text;

		// Token: 0x04000662 RID: 1634
		private global::System.Windows.Forms.Label Skype_text;

		// Token: 0x04000663 RID: 1635
		private global::System.Windows.Forms.Label Communications_text;

		// Token: 0x04000664 RID: 1636
		private global::System.Windows.Forms.Label GetHelp_text;

		// Token: 0x04000665 RID: 1637
		private global::System.Windows.Forms.Label BingWeather_text;

		// Token: 0x04000666 RID: 1638
		private global::System.Windows.Forms.Label Sketch_text;

		// Token: 0x04000667 RID: 1639
		private global::System.Windows.Forms.Label ZuneMusic_text;

		// Token: 0x04000668 RID: 1640
		private global::System.Windows.Forms.Label People_text;

		// Token: 0x04000669 RID: 1641
		private global::System.Windows.Forms.Label ZuneVideo_text;

		// Token: 0x0400066A RID: 1642
		private global::System.Windows.Forms.Label WindowsMaps_text;

		// Token: 0x0400066B RID: 1643
		private global::System.Windows.Forms.Label WindowsCamera_text;

		// Token: 0x0400066C RID: 1644
		private global::System.Windows.Forms.Label Recorder_text;

		// Token: 0x0400066D RID: 1645
		private global::System.Windows.Forms.Label WindowsAlarms_text;

		// Token: 0x0400066E RID: 1646
		private global::System.Windows.Forms.Label Xbox_text;

		// Token: 0x0400066F RID: 1647
		private global::System.Windows.Forms.Label StickyNotes_text;

		// Token: 0x04000670 RID: 1648
		private global::System.Windows.Forms.Label MixedReality_text;

		// Token: 0x04000671 RID: 1649
		private global::System.Windows.Forms.Label Paint_text;

		// Token: 0x04000672 RID: 1650
		private global::System.Windows.Forms.Label OneNote_text;

		// Token: 0x04000673 RID: 1651
		private global::System.Windows.Forms.Label Solitaire_text;

		// Token: 0x04000674 RID: 1652
		private global::System.Windows.Forms.Label Viewer_text;

		// Token: 0x04000675 RID: 1653
		private global::System.Windows.Forms.Label WindowsStore_text;

		// Token: 0x04000676 RID: 1654
		public global::System.Windows.Forms.Panel panelVT;

		// Token: 0x04000677 RID: 1655
		public global::System.Windows.Forms.Label PleaseWaitVT;

		// Token: 0x04000678 RID: 1656
		private global::System.Windows.Forms.Label Counter3;

		// Token: 0x04000679 RID: 1657
		private global::System.Windows.Forms.Label Counter1;

		// Token: 0x0400067A RID: 1658
		private global::System.Windows.Forms.LinkLabel CleanerLog;

		// Token: 0x0400067B RID: 1659
		private global::System.Windows.Forms.ProgressBar DupesProgressBar;

		// Token: 0x0400067C RID: 1660
		private global::System.Windows.Forms.Panel CleanerMainPanel;

		// Token: 0x0400067D RID: 1661
		private global::System.Windows.Forms.Panel CleanerMainPanel2;

		// Token: 0x0400067E RID: 1662
		private global::System.Windows.Forms.DataGridView Table;

		// Token: 0x0400067F RID: 1663
		public global::System.Windows.Forms.Label HeaderCleanerLog;

		// Token: 0x04000680 RID: 1664
		private global::System.Windows.Forms.Button CloseCleaner;

		// Token: 0x04000681 RID: 1665
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column1;

		// Token: 0x04000682 RID: 1666
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column2;

		// Token: 0x04000683 RID: 1667
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Column3;

		// Token: 0x04000684 RID: 1668
		private global::System.Windows.Forms.Label Serv32;

		// Token: 0x04000685 RID: 1669
		private global::System.Windows.Forms.Label Serv31;

		// Token: 0x04000686 RID: 1670
		private global::System.Windows.Forms.Label Serv30;

		// Token: 0x04000687 RID: 1671
		private global::System.Windows.Forms.Label Serv29;

		// Token: 0x04000688 RID: 1672
		private global::System.Windows.Forms.Label Serv28;

		// Token: 0x04000689 RID: 1673
		private global::System.Windows.Forms.Label Serv27;

		// Token: 0x0400068A RID: 1674
		private global::System.Windows.Forms.Label Serv26;

		// Token: 0x0400068B RID: 1675
		private global::System.Windows.Forms.Label Serv25;

		// Token: 0x0400068C RID: 1676
		private global::System.Windows.Forms.Label Serv24;

		// Token: 0x0400068D RID: 1677
		private global::System.Windows.Forms.Label Serv23;

		// Token: 0x0400068E RID: 1678
		private global::System.Windows.Forms.Label Serv22;

		// Token: 0x0400068F RID: 1679
		private global::System.Windows.Forms.Label Serv21;

		// Token: 0x04000690 RID: 1680
		private global::System.Windows.Forms.Label Serv20;

		// Token: 0x04000691 RID: 1681
		private global::System.Windows.Forms.Label Serv19;

		// Token: 0x04000692 RID: 1682
		private global::System.Windows.Forms.Label Serv18;

		// Token: 0x04000693 RID: 1683
		private global::System.Windows.Forms.Label Serv17;

		// Token: 0x04000694 RID: 1684
		private global::System.Windows.Forms.Label Serv16;

		// Token: 0x04000695 RID: 1685
		private global::System.Windows.Forms.Label Serv15;

		// Token: 0x04000696 RID: 1686
		private global::System.Windows.Forms.Label Serv14;

		// Token: 0x04000697 RID: 1687
		private global::System.Windows.Forms.Label Serv13;

		// Token: 0x04000698 RID: 1688
		private global::System.Windows.Forms.Label Serv12;

		// Token: 0x04000699 RID: 1689
		private global::System.Windows.Forms.Label Serv11;

		// Token: 0x0400069A RID: 1690
		private global::System.Windows.Forms.Label Serv10;

		// Token: 0x0400069B RID: 1691
		private global::System.Windows.Forms.Label Serv9;

		// Token: 0x0400069C RID: 1692
		private global::System.Windows.Forms.Label Serv8;

		// Token: 0x0400069D RID: 1693
		private global::System.Windows.Forms.Label Serv7;

		// Token: 0x0400069E RID: 1694
		private global::System.Windows.Forms.Label Serv6;

		// Token: 0x0400069F RID: 1695
		private global::System.Windows.Forms.Label Serv5;

		// Token: 0x040006A0 RID: 1696
		private global::System.Windows.Forms.Label Serv4;

		// Token: 0x040006A1 RID: 1697
		private global::System.Windows.Forms.Label Serv3;

		// Token: 0x040006A2 RID: 1698
		private global::System.Windows.Forms.Label Serv2;

		// Token: 0x040006A3 RID: 1699
		private global::System.Windows.Forms.Label Serv1;

		// Token: 0x040006A4 RID: 1700
		private global::System.Windows.Forms.Panel ServPanelChoice;

		// Token: 0x040006A5 RID: 1701
		private global::System.Windows.Forms.Button ServCancel;

		// Token: 0x040006A6 RID: 1702
		private global::System.Windows.Forms.Button ServNo;

		// Token: 0x040006A7 RID: 1703
		private global::System.Windows.Forms.Button ServYes;

		// Token: 0x040006A8 RID: 1704
		private global::System.Windows.Forms.Panel HeaderPanel;

		// Token: 0x040006A9 RID: 1705
		private global::System.Windows.Forms.Panel LeftPanel;

		// Token: 0x040006AA RID: 1706
		private global::System.Windows.Forms.Label LogoutRestartRequired;

		// Token: 0x040006AB RID: 1707
		private global::System.Windows.Forms.Label TipDefault;

		// Token: 0x040006AC RID: 1708
		private global::System.Windows.Forms.PictureBox AddToApply;

		// Token: 0x040006AD RID: 1709
		private global::System.Windows.Forms.Button ResAllButton;

		// Token: 0x040006AE RID: 1710
		private global::System.Windows.Forms.Button RemAllButton;

		// Token: 0x040006AF RID: 1711
		private global::System.Windows.Forms.LinkLabel LeftMenu11;

		// Token: 0x040006B0 RID: 1712
		private global::System.Windows.Forms.LinkLabel LeftMenu10;

		// Token: 0x040006B1 RID: 1713
		private global::System.Windows.Forms.LinkLabel LeftMenu9;

		// Token: 0x040006B2 RID: 1714
		private global::System.Windows.Forms.LinkLabel LeftMenu8;

		// Token: 0x040006B3 RID: 1715
		private global::System.Windows.Forms.LinkLabel LeftMenu7;

		// Token: 0x040006B4 RID: 1716
		private global::System.Windows.Forms.LinkLabel LeftMenu6;

		// Token: 0x040006B5 RID: 1717
		private global::System.Windows.Forms.LinkLabel LeftMenu5;

		// Token: 0x040006B6 RID: 1718
		private global::System.Windows.Forms.LinkLabel LeftMenu4;

		// Token: 0x040006B7 RID: 1719
		private global::System.Windows.Forms.LinkLabel LeftMenu3;

		// Token: 0x040006B8 RID: 1720
		private global::System.Windows.Forms.LinkLabel LeftMenu2;

		// Token: 0x040006B9 RID: 1721
		private global::System.Windows.Forms.LinkLabel LeftMenu1;

		// Token: 0x040006BA RID: 1722
		private global::System.Windows.Forms.Button Apply;

		// Token: 0x040006BB RID: 1723
		private global::System.Windows.Forms.Label dot3;

		// Token: 0x040006BC RID: 1724
		private global::System.Windows.Forms.Label dot2;

		// Token: 0x040006BD RID: 1725
		private global::System.Windows.Forms.Label dot1;

		// Token: 0x040006BE RID: 1726
		private global::System.Windows.Forms.Label ButtonBack;

		// Token: 0x040006BF RID: 1727
		private global::System.Windows.Forms.Label ServStepsLabel;

		// Token: 0x040006C0 RID: 1728
		private global::System.Windows.Forms.ProgressBar ServProgressBar;

		// Token: 0x040006C1 RID: 1729
		private global::System.Windows.Forms.Button ServList;

		// Token: 0x040006C2 RID: 1730
		private global::System.Windows.Forms.CheckBox Check70;

		// Token: 0x040006C3 RID: 1731
		private global::GClass11 OffDefender;

		// Token: 0x040006C4 RID: 1732
		private global::GClass10 panelmenu5;

		// Token: 0x040006C5 RID: 1733
		private global::System.Windows.Forms.CheckBox Check55;

		// Token: 0x040006C6 RID: 1734
		private global::System.Windows.Forms.CheckBox Check54;

		// Token: 0x040006C7 RID: 1735
		private global::System.Windows.Forms.CheckBox Check53;

		// Token: 0x040006C8 RID: 1736
		private global::System.Windows.Forms.CheckBox Check52;

		// Token: 0x040006C9 RID: 1737
		private global::System.Windows.Forms.CheckBox Check51;

		// Token: 0x040006CA RID: 1738
		private global::System.Windows.Forms.CheckBox Check56;

		// Token: 0x040006CB RID: 1739
		private global::System.Windows.Forms.LinkLabel linkmenu5;

		// Token: 0x040006CC RID: 1740
		private global::System.Windows.Forms.Panel PersonalPanelPlate;

		// Token: 0x040006CD RID: 1741
		private global::System.Windows.Forms.Label PersonalPanelPlateLabel;

		// Token: 0x040006CE RID: 1742
		private global::System.Windows.Forms.Panel PersonalPanel;

		// Token: 0x040006CF RID: 1743
		private global::System.Windows.Forms.Panel PersonalPanelHeaderPanel;

		// Token: 0x040006D0 RID: 1744
		private global::System.Windows.Forms.Label PersonalPanelHeaderLabel;

		// Token: 0x040006D1 RID: 1745
		private global::System.Windows.Forms.Button CloseRecommendations;

		// Token: 0x040006D2 RID: 1746
		private global::System.Windows.Forms.FlowLayoutPanel FlowPanel;
	}
}
