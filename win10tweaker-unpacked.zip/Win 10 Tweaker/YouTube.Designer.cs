﻿// Token: 0x0200018E RID: 398
public partial class YouTube : global::GForm0
{
	// Token: 0x06001393 RID: 5011 RVA: 0x0006CBA8 File Offset: 0x0006ADA8
	private void InitializeComponent()
	{
		this.HeaderPanel = new global::System.Windows.Forms.Panel();
		this.CloseIcon = new global::System.Windows.Forms.Button();
		this.Header = new global::System.Windows.Forms.Label();
		this.YouTubePic1 = new global::System.Windows.Forms.PictureBox();
		this.YouTubeMainLabel1 = new global::System.Windows.Forms.LinkLabel();
		this.YouTubePic3 = new global::System.Windows.Forms.PictureBox();
		this.YouTubePic4 = new global::System.Windows.Forms.PictureBox();
		this.YouTubePic2 = new global::System.Windows.Forms.PictureBox();
		this.YouTubeMiniLabel1 = new global::System.Windows.Forms.LinkLabel();
		this.YouTubeMiniLabel2 = new global::System.Windows.Forms.LinkLabel();
		this.YouTubeMainLabel2 = new global::System.Windows.Forms.LinkLabel();
		this.YouTubeMiniLabel3 = new global::System.Windows.Forms.LinkLabel();
		this.YouTubeMainLabel3 = new global::System.Windows.Forms.LinkLabel();
		this.YouTubeMiniLabel4 = new global::System.Windows.Forms.LinkLabel();
		this.YouTubeMainLabel4 = new global::System.Windows.Forms.LinkLabel();
		this.HeaderPanel.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.YouTubePic1).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.YouTubePic3).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.YouTubePic4).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.YouTubePic2).BeginInit();
		base.SuspendLayout();
		this.HeaderPanel.Controls.Add(this.CloseIcon);
		this.HeaderPanel.Controls.Add(this.Header);
		this.HeaderPanel.Location = new global::System.Drawing.Point(0, 0);
		this.HeaderPanel.Margin = new global::System.Windows.Forms.Padding(0);
		this.HeaderPanel.Name = "HeaderPanel";
		this.HeaderPanel.Size = new global::System.Drawing.Size(630, 38);
		this.HeaderPanel.TabIndex = 181;
		this.CloseIcon.BackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.BackgroundImage = global::Class89.Bitmap_17;
		this.CloseIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.CloseIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
		this.CloseIcon.FlatAppearance.BorderSize = 0;
		this.CloseIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.CloseIcon.Location = new global::System.Drawing.Point(597, 5);
		this.CloseIcon.Name = "CloseIcon";
		this.CloseIcon.Size = new global::System.Drawing.Size(22, 22);
		this.CloseIcon.TabIndex = 32;
		this.CloseIcon.TabStop = false;
		this.CloseIcon.UseVisualStyleBackColor = false;
		this.Header.AutoSize = true;
		this.Header.BackColor = global::System.Drawing.Color.Transparent;
		this.Header.Font = new global::System.Drawing.Font("Calibri", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.Header.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.Header.Location = new global::System.Drawing.Point(12, 9);
		this.Header.Name = "Header";
		this.Header.Size = new global::System.Drawing.Size(0, 15);
		this.Header.TabIndex = 31;
		this.YouTubePic1.BackgroundImage = global::Class89.Bitmap_75;
		this.YouTubePic1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.YouTubePic1.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.YouTubePic1.Location = new global::System.Drawing.Point(12, 47);
		this.YouTubePic1.Name = "YouTubePic1";
		this.YouTubePic1.Size = new global::System.Drawing.Size(134, 76);
		this.YouTubePic1.TabIndex = 182;
		this.YouTubePic1.TabStop = false;
		this.YouTubeMainLabel1.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.YouTubeMainLabel1.AutoSize = true;
		this.YouTubeMainLabel1.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.YouTubeMainLabel1.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
		this.YouTubeMainLabel1.LinkColor = global::System.Drawing.Color.FromArgb(129, 181, 224);
		this.YouTubeMainLabel1.Location = new global::System.Drawing.Point(152, 62);
		this.YouTubeMainLabel1.Name = "YouTubeMainLabel1";
		this.YouTubeMainLabel1.Size = new global::System.Drawing.Size(0, 18);
		this.YouTubeMainLabel1.TabIndex = 183;
		this.YouTubePic3.BackgroundImage = global::Class89.Bitmap_77;
		this.YouTubePic3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.YouTubePic3.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.YouTubePic3.Location = new global::System.Drawing.Point(12, 211);
		this.YouTubePic3.Name = "YouTubePic3";
		this.YouTubePic3.Size = new global::System.Drawing.Size(134, 76);
		this.YouTubePic3.TabIndex = 182;
		this.YouTubePic3.TabStop = false;
		this.YouTubePic4.BackgroundImage = global::Class89.Bitmap_78;
		this.YouTubePic4.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.YouTubePic4.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.YouTubePic4.Location = new global::System.Drawing.Point(12, 293);
		this.YouTubePic4.Name = "YouTubePic4";
		this.YouTubePic4.Size = new global::System.Drawing.Size(134, 76);
		this.YouTubePic4.TabIndex = 182;
		this.YouTubePic4.TabStop = false;
		this.YouTubePic2.BackgroundImage = global::Class89.Bitmap_76;
		this.YouTubePic2.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.YouTubePic2.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.YouTubePic2.Location = new global::System.Drawing.Point(12, 129);
		this.YouTubePic2.Name = "YouTubePic2";
		this.YouTubePic2.Size = new global::System.Drawing.Size(134, 76);
		this.YouTubePic2.TabIndex = 182;
		this.YouTubePic2.TabStop = false;
		this.YouTubeMiniLabel1.ActiveLinkColor = global::System.Drawing.Color.FromArgb(149, 167, 183);
		this.YouTubeMiniLabel1.AutoSize = true;
		this.YouTubeMiniLabel1.Font = new global::System.Drawing.Font("Arial", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.YouTubeMiniLabel1.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
		this.YouTubeMiniLabel1.LinkColor = global::System.Drawing.Color.FromArgb(149, 167, 183);
		this.YouTubeMiniLabel1.Location = new global::System.Drawing.Point(152, 80);
		this.YouTubeMiniLabel1.Name = "YouTubeMiniLabel1";
		this.YouTubeMiniLabel1.Size = new global::System.Drawing.Size(0, 16);
		this.YouTubeMiniLabel1.TabIndex = 184;
		this.YouTubeMiniLabel2.ActiveLinkColor = global::System.Drawing.Color.FromArgb(149, 167, 183);
		this.YouTubeMiniLabel2.AutoSize = true;
		this.YouTubeMiniLabel2.Font = new global::System.Drawing.Font("Arial", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.YouTubeMiniLabel2.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
		this.YouTubeMiniLabel2.LinkColor = global::System.Drawing.Color.FromArgb(149, 167, 183);
		this.YouTubeMiniLabel2.Location = new global::System.Drawing.Point(152, 162);
		this.YouTubeMiniLabel2.Name = "YouTubeMiniLabel2";
		this.YouTubeMiniLabel2.Size = new global::System.Drawing.Size(0, 16);
		this.YouTubeMiniLabel2.TabIndex = 186;
		this.YouTubeMainLabel2.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.YouTubeMainLabel2.AutoSize = true;
		this.YouTubeMainLabel2.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.YouTubeMainLabel2.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
		this.YouTubeMainLabel2.LinkColor = global::System.Drawing.Color.FromArgb(129, 181, 224);
		this.YouTubeMainLabel2.Location = new global::System.Drawing.Point(152, 144);
		this.YouTubeMainLabel2.Name = "YouTubeMainLabel2";
		this.YouTubeMainLabel2.Size = new global::System.Drawing.Size(0, 18);
		this.YouTubeMainLabel2.TabIndex = 185;
		this.YouTubeMiniLabel3.ActiveLinkColor = global::System.Drawing.Color.FromArgb(149, 167, 183);
		this.YouTubeMiniLabel3.AutoSize = true;
		this.YouTubeMiniLabel3.Font = new global::System.Drawing.Font("Arial", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.YouTubeMiniLabel3.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
		this.YouTubeMiniLabel3.LinkColor = global::System.Drawing.Color.FromArgb(149, 167, 183);
		this.YouTubeMiniLabel3.Location = new global::System.Drawing.Point(152, 241);
		this.YouTubeMiniLabel3.Name = "YouTubeMiniLabel3";
		this.YouTubeMiniLabel3.Size = new global::System.Drawing.Size(0, 16);
		this.YouTubeMiniLabel3.TabIndex = 188;
		this.YouTubeMainLabel3.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.YouTubeMainLabel3.AutoSize = true;
		this.YouTubeMainLabel3.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.YouTubeMainLabel3.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
		this.YouTubeMainLabel3.LinkColor = global::System.Drawing.Color.FromArgb(129, 181, 224);
		this.YouTubeMainLabel3.Location = new global::System.Drawing.Point(152, 223);
		this.YouTubeMainLabel3.Name = "YouTubeMainLabel3";
		this.YouTubeMainLabel3.Size = new global::System.Drawing.Size(0, 18);
		this.YouTubeMainLabel3.TabIndex = 187;
		this.YouTubeMiniLabel4.ActiveLinkColor = global::System.Drawing.Color.FromArgb(149, 167, 183);
		this.YouTubeMiniLabel4.AutoSize = true;
		this.YouTubeMiniLabel4.Font = new global::System.Drawing.Font("Arial", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.YouTubeMiniLabel4.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
		this.YouTubeMiniLabel4.LinkColor = global::System.Drawing.Color.FromArgb(149, 167, 183);
		this.YouTubeMiniLabel4.Location = new global::System.Drawing.Point(152, 325);
		this.YouTubeMiniLabel4.Name = "YouTubeMiniLabel4";
		this.YouTubeMiniLabel4.Size = new global::System.Drawing.Size(0, 16);
		this.YouTubeMiniLabel4.TabIndex = 190;
		this.YouTubeMainLabel4.ActiveLinkColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.YouTubeMainLabel4.AutoSize = true;
		this.YouTubeMainLabel4.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.YouTubeMainLabel4.LinkBehavior = global::System.Windows.Forms.LinkBehavior.NeverUnderline;
		this.YouTubeMainLabel4.LinkColor = global::System.Drawing.Color.FromArgb(129, 181, 224);
		this.YouTubeMainLabel4.Location = new global::System.Drawing.Point(152, 307);
		this.YouTubeMainLabel4.Name = "YouTubeMainLabel4";
		this.YouTubeMainLabel4.Size = new global::System.Drawing.Size(0, 18);
		this.YouTubeMainLabel4.TabIndex = 189;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
		base.ClientSize = new global::System.Drawing.Size(630, 380);
		base.Controls.Add(this.YouTubeMiniLabel4);
		base.Controls.Add(this.YouTubeMainLabel4);
		base.Controls.Add(this.YouTubeMiniLabel3);
		base.Controls.Add(this.YouTubeMainLabel3);
		base.Controls.Add(this.YouTubeMiniLabel2);
		base.Controls.Add(this.YouTubeMainLabel2);
		base.Controls.Add(this.YouTubeMiniLabel1);
		base.Controls.Add(this.YouTubePic1);
		base.Controls.Add(this.YouTubePic2);
		base.Controls.Add(this.YouTubePic3);
		base.Controls.Add(this.YouTubeMainLabel1);
		base.Controls.Add(this.YouTubePic4);
		base.Controls.Add(this.HeaderPanel);
		this.DoubleBuffered = true;
		this.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "YouTube";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		base.Load += new global::System.EventHandler(this.YouTube_Load);
		this.HeaderPanel.ResumeLayout(false);
		this.HeaderPanel.PerformLayout();
		((global::System.ComponentModel.ISupportInitialize)this.YouTubePic1).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.YouTubePic3).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.YouTubePic4).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.YouTubePic2).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400094F RID: 2383
	private global::System.Windows.Forms.Panel HeaderPanel;

	// Token: 0x04000950 RID: 2384
	private global::System.Windows.Forms.Label Header;

	// Token: 0x04000951 RID: 2385
	private global::System.Windows.Forms.Button CloseIcon;

	// Token: 0x04000952 RID: 2386
	private global::System.Windows.Forms.PictureBox YouTubePic1;

	// Token: 0x04000953 RID: 2387
	private global::System.Windows.Forms.PictureBox YouTubePic3;

	// Token: 0x04000954 RID: 2388
	private global::System.Windows.Forms.PictureBox YouTubePic4;

	// Token: 0x04000955 RID: 2389
	private global::System.Windows.Forms.LinkLabel YouTubeMainLabel1;

	// Token: 0x04000956 RID: 2390
	private global::System.Windows.Forms.PictureBox YouTubePic2;

	// Token: 0x04000957 RID: 2391
	private global::System.Windows.Forms.LinkLabel YouTubeMiniLabel1;

	// Token: 0x04000958 RID: 2392
	private global::System.Windows.Forms.LinkLabel YouTubeMiniLabel2;

	// Token: 0x04000959 RID: 2393
	private global::System.Windows.Forms.LinkLabel YouTubeMainLabel2;

	// Token: 0x0400095A RID: 2394
	private global::System.Windows.Forms.LinkLabel YouTubeMiniLabel3;

	// Token: 0x0400095B RID: 2395
	private global::System.Windows.Forms.LinkLabel YouTubeMainLabel3;

	// Token: 0x0400095C RID: 2396
	private global::System.Windows.Forms.LinkLabel YouTubeMiniLabel4;

	// Token: 0x0400095D RID: 2397
	private global::System.Windows.Forms.LinkLabel YouTubeMainLabel4;
}
