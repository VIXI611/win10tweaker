﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A8 RID: 424
[CoClass(typeof(object))]
[TypeIdentifier]
[CompilerGenerated]
[Guid("286E6F1B-7113-4355-9562-96B7E9D64C54")]
[ComImport]
public interface GInterface11 : GInterface8
{
}
