﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x0200019E RID: 414
[DefaultMember("Title")]
[TypeIdentifier]
[CompilerGenerated]
[Guid("BBCBDE60-C3FF-11CE-8350-444553540000")]
[ComImport]
public interface GInterface1
{
	// Token: 0x17000104 RID: 260
	// (get) Token: 0x0600143C RID: 5180
	[DispId(0)]
	string String_0 { [DispId(0)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.BStr)] get; }

	// Token: 0x0600143D RID: 5181
	void _VtblGap1_4();

	// Token: 0x0600143E RID: 5182
	[DispId(1610743813)]
	[MethodImpl(MethodImplOptions.InternalCall)]
	[return: MarshalAs(UnmanagedType.Interface)]
	GInterface2 imethod_0([MarshalAs(UnmanagedType.BStr)] [In] string string_0);
}
