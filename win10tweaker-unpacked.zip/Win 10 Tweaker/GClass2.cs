﻿using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

// Token: 0x0200004B RID: 75
public class GClass2
{
	// Token: 0x17000007 RID: 7
	// (get) Token: 0x06000387 RID: 903 RVA: 0x00017640 File Offset: 0x00015840
	public static GClass2 GClass2_0
	{
		get
		{
			if (GClass2.gclass2_0 == null)
			{
				object obj = GClass2.object_0;
				lock (obj)
				{
					if (GClass2.gclass2_0 == null)
					{
						GClass2.gclass2_0 = new GClass2();
					}
				}
			}
			return GClass2.gclass2_0;
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x06000388 RID: 904 RVA: 0x0000388C File Offset: 0x00001A8C
	public string String_0
	{
		get
		{
			return "Software\\Microsoft\\Windows\\CurrentVersion";
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000389 RID: 905 RVA: 0x00003893 File Offset: 0x00001A93
	public string String_1
	{
		get
		{
			return "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
		}
	}

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x0600038A RID: 906 RVA: 0x0000389A File Offset: 0x00001A9A
	public string String_2
	{
		get
		{
			return "SYSTEM\\CurrentControlSet\\Services";
		}
	}

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x0600038B RID: 907 RVA: 0x000176A0 File Offset: 0x000158A0
	public string String_3
	{
		get
		{
			string result;
			if ((result = this.string_0) == null)
			{
				result = (this.string_0 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_1).GetValue("ProductName").ToString());
			}
			return result;
		}
	}

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x0600038C RID: 908 RVA: 0x000038A1 File Offset: 0x00001AA1
	public bool Boolean_0
	{
		get
		{
			return Environment.Is64BitOperatingSystem;
		}
	}

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x0600038D RID: 909 RVA: 0x000176E4 File Offset: 0x000158E4
	public string String_4
	{
		get
		{
			string result;
			if ((result = this.string_1) == null)
			{
				result = (this.string_1 = string.Format("({0} build {1})", Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_1).GetValue("ReleaseId"), Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_1).GetValue("CurrentBuild")));
			}
			return result;
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x0600038E RID: 910 RVA: 0x000038A8 File Offset: 0x00001AA8
	public bool Boolean_1
	{
		get
		{
			return SystemInformation.PowerStatus.BatteryChargeStatus == BatteryChargeStatus.NoSystemBattery;
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x0600038F RID: 911 RVA: 0x0001774C File Offset: 0x0001594C
	public RegistryKey RegistryKey_0
	{
		get
		{
			RegistryKey result;
			if ((result = this.registryKey_0) == null)
			{
				result = (this.registryKey_0 = Registry.CurrentUser.CreateSubKey("Software\\Win 10 Tweaker"));
			}
			return result;
		}
	}

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x06000390 RID: 912 RVA: 0x0001777C File Offset: 0x0001597C
	public string String_5
	{
		get
		{
			string result;
			if ((result = this.string_2) == null)
			{
				result = (this.string_2 = CultureInfo.CurrentCulture.ToString());
			}
			return result;
		}
	}

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000391 RID: 913 RVA: 0x000177A8 File Offset: 0x000159A8
	public string String_6
	{
		get
		{
			string result;
			if ((result = this.string_3) == null)
			{
				result = (this.string_3 = "");
			}
			return result;
		}
	}

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x06000392 RID: 914 RVA: 0x000038BB File Offset: 0x00001ABB
	public string String_7
	{
		get
		{
			return "https://win10tweaker.com/InfoChecker.php?key=exestable";
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x06000393 RID: 915 RVA: 0x000038C2 File Offset: 0x00001AC2
	public string String_8
	{
		get
		{
			return "https://win10tweaker.com/InfoChecker.php?key=exebeta";
		}
	}

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x06000394 RID: 916 RVA: 0x000177D0 File Offset: 0x000159D0
	public string String_9
	{
		get
		{
			string result;
			if ((result = this.string_4) == null)
			{
				result = (this.string_4 = Environment.UserName);
			}
			return result;
		}
	}

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x06000395 RID: 917 RVA: 0x000177F8 File Offset: 0x000159F8
	public string String_10
	{
		get
		{
			string result;
			if ((result = this.string_5) == null)
			{
				result = (this.string_5 = AppDomain.CurrentDomain.FriendlyName);
			}
			return result;
		}
	}

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000396 RID: 918 RVA: 0x00017824 File Offset: 0x00015A24
	public string String_11
	{
		get
		{
			string result;
			if ((result = this.string_6) == null)
			{
				result = (this.string_6 = Assembly.GetEntryAssembly().Location);
			}
			return result;
		}
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000397 RID: 919 RVA: 0x000038C9 File Offset: 0x00001AC9
	public string String_12
	{
		get
		{
			return this.string_6;
		}
	}

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x06000398 RID: 920 RVA: 0x00017850 File Offset: 0x00015A50
	public string String_13
	{
		get
		{
			string result;
			if ((result = this.string_8) == null)
			{
				result = (this.string_8 = Environment.GetFolderPath(Environment.SpecialFolder.Startup));
			}
			return result;
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x06000399 RID: 921 RVA: 0x00017878 File Offset: 0x00015A78
	public string String_14
	{
		get
		{
			string result;
			if ((result = this.string_9) == null)
			{
				result = (this.string_9 = Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup));
			}
			return result;
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x0600039A RID: 922 RVA: 0x000178A0 File Offset: 0x00015AA0
	public string String_15
	{
		get
		{
			string result;
			if ((result = this.string_10) == null)
			{
				result = (this.string_10 = Path.GetPathRoot(Environment.SystemDirectory));
			}
			return result;
		}
	}

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x0600039B RID: 923 RVA: 0x000178CC File Offset: 0x00015ACC
	public string String_16
	{
		get
		{
			string result;
			if ((result = this.string_11) == null)
			{
				result = (this.string_11 = Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop\\WindowMetrics").GetValue("AppliedDPI").ToString());
			}
			return result;
		}
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x0600039C RID: 924 RVA: 0x000038D1 File Offset: 0x00001AD1
	public string String_17
	{
		get
		{
			return this.method_1("FirewallName");
		}
	}

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x0600039D RID: 925 RVA: 0x0001790C File Offset: 0x00015B0C
	public Color Color_0
	{
		get
		{
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "DarkSkin")
			{
				this.color_3 = this.color_5;
				return this.color_3;
			}
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SkySkin")
			{
				this.color_3 = this.color_6;
				return this.color_3;
			}
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() == "SeaSkin")
			{
				this.color_3 = this.color_7;
				return this.color_3;
			}
			return this.color_3;
		}
	}

	// Token: 0x0600039E RID: 926 RVA: 0x000179C8 File Offset: 0x00015BC8
	private string method_0()
	{
		if (GClass2.GClass2_0.RegistryKey_0.GetValue("Language") == null)
		{
			if (!GClass2.GClass2_0.String_5.StartsWith("ru-"))
			{
				if (GClass2.GClass2_0.String_5 == "uk-UA")
				{
					this.string_13 = "Ukrainian";
				}
				else if (!(GClass2.GClass2_0.String_5 == "de-DE"))
				{
					this.string_14 = "English";
				}
				else
				{
					this.string_13 = "Deutsch";
				}
			}
			else
			{
				this.string_13 = "Russian";
			}
		}
		else
		{
			this.string_13 = GClass2.GClass2_0.RegistryKey_0.GetValue("Language").ToString();
		}
		return this.string_13;
	}

	// Token: 0x0600039F RID: 927 RVA: 0x00017A88 File Offset: 0x00015C88
	public string method_1(string string_15)
	{
		string text;
		if ((text = this.string_13) == null)
		{
			text = (this.string_13 = this.method_0());
		}
		this.string_14 = text;
		if (this.string_14 == "Russian")
		{
			return GClass15.GClass15_0.dictionary_0[string_15];
		}
		if (this.string_14 == "English")
		{
			return GClass15.GClass15_0.dictionary_1[string_15];
		}
		if (!(this.string_14 == "Ukrainian"))
		{
		}
		return GClass15.GClass15_0.dictionary_1[string_15];
	}

	// Token: 0x060003A2 RID: 930 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_1)
	{
		Monitor.Enter(object_1, ref bool_1);
	}

	// Token: 0x060003A3 RID: 931 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_2(RegistryKey registryKey_1, string string_15)
	{
		return registryKey_1.OpenSubKey(string_15);
	}

	// Token: 0x060003A5 RID: 933 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_3(RegistryKey registryKey_1, string string_15)
	{
		return registryKey_1.GetValue(string_15);
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_4(object object_1)
	{
		return object_1.ToString();
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x000038A1 File Offset: 0x00001AA1
	static bool smethod_5()
	{
		return Environment.Is64BitOperatingSystem;
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x00002FFC File Offset: 0x000011FC
	static string smethod_6(string string_15, object object_1, object object_2)
	{
		return string.Format(string_15, object_1, object_2);
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x000038FA File Offset: 0x00001AFA
	static PowerStatus smethod_7()
	{
		return SystemInformation.PowerStatus;
	}

	// Token: 0x060003AA RID: 938 RVA: 0x00003901 File Offset: 0x00001B01
	static BatteryChargeStatus smethod_8(PowerStatus powerStatus_0)
	{
		return powerStatus_0.BatteryChargeStatus;
	}

	// Token: 0x060003AB RID: 939 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_9(RegistryKey registryKey_1, string string_15)
	{
		return registryKey_1.CreateSubKey(string_15);
	}

	// Token: 0x060003AC RID: 940 RVA: 0x00003909 File Offset: 0x00001B09
	static CultureInfo smethod_10()
	{
		return CultureInfo.CurrentCulture;
	}

	// Token: 0x060003AD RID: 941 RVA: 0x00003910 File Offset: 0x00001B10
	static string smethod_11()
	{
		return Environment.UserName;
	}

	// Token: 0x060003AE RID: 942 RVA: 0x00003917 File Offset: 0x00001B17
	static AppDomain smethod_12()
	{
		return AppDomain.CurrentDomain;
	}

	// Token: 0x060003AF RID: 943 RVA: 0x0000391E File Offset: 0x00001B1E
	static string smethod_13(AppDomain appDomain_0)
	{
		return appDomain_0.FriendlyName;
	}

	// Token: 0x060003B0 RID: 944 RVA: 0x00003926 File Offset: 0x00001B26
	static Assembly smethod_14()
	{
		return Assembly.GetEntryAssembly();
	}

	// Token: 0x060003B1 RID: 945 RVA: 0x0000392D File Offset: 0x00001B2D
	static string smethod_15(Assembly assembly_0)
	{
		return assembly_0.Location;
	}

	// Token: 0x060003B2 RID: 946 RVA: 0x00003935 File Offset: 0x00001B35
	static string smethod_16(Environment.SpecialFolder specialFolder_0)
	{
		return Environment.GetFolderPath(specialFolder_0);
	}

	// Token: 0x060003B3 RID: 947 RVA: 0x0000393D File Offset: 0x00001B3D
	static string smethod_17()
	{
		return Environment.SystemDirectory;
	}

	// Token: 0x060003B4 RID: 948 RVA: 0x00003944 File Offset: 0x00001B44
	static string smethod_18(string string_15)
	{
		return Path.GetPathRoot(string_15);
	}

	// Token: 0x060003B5 RID: 949 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_19(string string_15, string string_16)
	{
		return string_15 == string_16;
	}

	// Token: 0x060003B6 RID: 950 RVA: 0x000036C8 File Offset: 0x000018C8
	static bool smethod_20(string string_15, string string_16)
	{
		return string_15.StartsWith(string_16);
	}

	// Token: 0x060003B7 RID: 951 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_21()
	{
		return new object();
	}

	// Token: 0x040001C3 RID: 451
	private static volatile GClass2 gclass2_0;

	// Token: 0x040001C4 RID: 452
	private static readonly object object_0 = new object();

	// Token: 0x040001C5 RID: 453
	public string string_0;

	// Token: 0x040001C6 RID: 454
	public string string_1;

	// Token: 0x040001C7 RID: 455
	public RegistryKey registryKey_0;

	// Token: 0x040001C8 RID: 456
	public string string_2;

	// Token: 0x040001C9 RID: 457
	public bool bool_0 = true;

	// Token: 0x040001CA RID: 458
	public string string_3;

	// Token: 0x040001CB RID: 459
	public string string_4;

	// Token: 0x040001CC RID: 460
	public string string_5;

	// Token: 0x040001CD RID: 461
	public string string_6;

	// Token: 0x040001CE RID: 462
	public string string_7;

	// Token: 0x040001CF RID: 463
	public string string_8;

	// Token: 0x040001D0 RID: 464
	public string string_9;

	// Token: 0x040001D1 RID: 465
	public string string_10;

	// Token: 0x040001D2 RID: 466
	public string string_11;

	// Token: 0x040001D3 RID: 467
	public int int_0;

	// Token: 0x040001D4 RID: 468
	public int int_1;

	// Token: 0x040001D5 RID: 469
	public string string_12 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options";

	// Token: 0x040001D6 RID: 470
	public Color color_0 = Color.White;

	// Token: 0x040001D7 RID: 471
	public Color color_1 = Color.FromArgb(227, 206, 129);

	// Token: 0x040001D8 RID: 472
	public Color color_2 = Color.FromArgb(157, 167, 175);

	// Token: 0x040001D9 RID: 473
	public Color color_3 = Color.FromArgb(23, 28, 42);

	// Token: 0x040001DA RID: 474
	public static Color color_4 = Color.FromArgb(39, 49, 68);

	// Token: 0x040001DB RID: 475
	public Color color_5 = Color.FromArgb(23, 28, 42);

	// Token: 0x040001DC RID: 476
	public Color color_6 = Color.FromArgb(10, 39, 67);

	// Token: 0x040001DD RID: 477
	public Color color_7 = Color.FromArgb(10, 46, 64);

	// Token: 0x040001DE RID: 478
	public Color color_8 = GClass2.color_4;

	// Token: 0x040001DF RID: 479
	public Color color_9 = Color.FromArgb(18, 70, 108);

	// Token: 0x040001E0 RID: 480
	public Color color_10 = Color.FromArgb(33, 75, 90);

	// Token: 0x040001E1 RID: 481
	public string string_13;

	// Token: 0x040001E2 RID: 482
	public string string_14;
}
