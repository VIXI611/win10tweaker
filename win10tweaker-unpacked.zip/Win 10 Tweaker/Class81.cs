﻿using System;
using System.Diagnostics;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Windows.Forms;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x02000185 RID: 389
internal static class Class81
{
	// Token: 0x0600130E RID: 4878 RVA: 0x0006AB30 File Offset: 0x00068D30
	[STAThread]
	private static void smethod_0()
	{
		Class81.smethod_1();
		string text = Environment.CommandLine;
		if (!text.Contains("/command:"))
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form1());
			return;
		}
		if (text.Contains("/supertoken"))
		{
			text = text.Replace("/supertoken ", "");
			GClass14.bool_0 = true;
			GClass14.smethod_3("TrustedInstaller.exe", false, text);
			return;
		}
		text = text.Replace("/command:", "");
		text = text.Replace("\"", "");
		string fileName;
		string arguments;
		bool flag;
		if (GClass14.smethod_1(text, out fileName, out arguments, out flag))
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = fileName,
				Arguments = arguments,
				WindowStyle = (flag ? ProcessWindowStyle.Normal : ProcessWindowStyle.Hidden)
			});
			return;
		}
	}

	// Token: 0x0600130F RID: 4879 RVA: 0x0006ABF8 File Offset: 0x00068DF8
	public static void smethod_1()
	{
		foreach (string string_ in new string[]
		{
			"SeRestorePrivilege",
			"SeBackupPrivilege",
			"SeTakeOwnershipPrivilege"
		})
		{
			IntPtr zero = IntPtr.Zero;
			GClass6.OpenProcessToken(GClass6.GetCurrentProcess(), 40, ref zero);
			GClass6.GStruct2 gstruct;
			gstruct.int_0 = 1;
			gstruct.long_0 = 0L;
			gstruct.int_1 = 2;
			GClass6.LookupPrivilegeValue(null, string_, ref gstruct.long_0);
			GClass6.AdjustTokenPrivileges(zero, false, ref gstruct, 0, IntPtr.Zero, IntPtr.Zero);
		}
		try
		{
			RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Win 10 Tweaker", RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.TakeOwnership);
			RegistrySecurity accessControl = registryKey.GetAccessControl();
			accessControl.SetOwner(new NTAccount(Environment.UserName));
			registryKey.SetAccessControl(accessControl);
			RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("Software\\Win 10 Tweaker", RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.ChangePermissions);
			RegistryAccessRule registryAccessRule = new RegistryAccessRule(Environment.UserName, RegistryRights.FullControl, AccessControlType.Allow);
			accessControl.SetAccessRule(registryAccessRule);
			RegistrySecurity registrySecurity = new RegistrySecurity();
			registrySecurity.AddAccessRule(registryAccessRule);
			registryKey2.SetAccessControl(registrySecurity);
		}
		catch
		{
		}
	}

	// Token: 0x06001310 RID: 4880 RVA: 0x0000920C File Offset: 0x0000740C
	static string smethod_2()
	{
		return Environment.CommandLine;
	}

	// Token: 0x06001311 RID: 4881 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_3(string string_0, string string_1)
	{
		return string_0.Contains(string_1);
	}

	// Token: 0x06001312 RID: 4882 RVA: 0x00009213 File Offset: 0x00007413
	static void smethod_4()
	{
		Application.EnableVisualStyles();
	}

	// Token: 0x06001313 RID: 4883 RVA: 0x0000921A File Offset: 0x0000741A
	static void smethod_5(bool bool_0)
	{
		Application.SetCompatibleTextRenderingDefault(bool_0);
	}

	// Token: 0x06001314 RID: 4884 RVA: 0x00009222 File Offset: 0x00007422
	static void smethod_6(Form form_0)
	{
		Application.Run(form_0);
	}

	// Token: 0x06001315 RID: 4885 RVA: 0x000033D1 File Offset: 0x000015D1
	static string smethod_7(string string_0, string string_1, string string_2)
	{
		return string_0.Replace(string_1, string_2);
	}

	// Token: 0x06001316 RID: 4886 RVA: 0x00003100 File Offset: 0x00001300
	static ProcessStartInfo smethod_8()
	{
		return new ProcessStartInfo();
	}

	// Token: 0x06001317 RID: 4887 RVA: 0x00003107 File Offset: 0x00001307
	static void smethod_9(ProcessStartInfo processStartInfo_0, string string_0)
	{
		processStartInfo_0.FileName = string_0;
	}

	// Token: 0x06001318 RID: 4888 RVA: 0x00003110 File Offset: 0x00001310
	static void smethod_10(ProcessStartInfo processStartInfo_0, string string_0)
	{
		processStartInfo_0.Arguments = string_0;
	}

	// Token: 0x06001319 RID: 4889 RVA: 0x00003119 File Offset: 0x00001319
	static void smethod_11(ProcessStartInfo processStartInfo_0, ProcessWindowStyle processWindowStyle_0)
	{
		processStartInfo_0.WindowStyle = processWindowStyle_0;
	}

	// Token: 0x0600131A RID: 4890 RVA: 0x00003122 File Offset: 0x00001322
	static Process smethod_12(ProcessStartInfo processStartInfo_0)
	{
		return Process.Start(processStartInfo_0);
	}

	// Token: 0x0600131B RID: 4891 RVA: 0x00003D65 File Offset: 0x00001F65
	static RegistryKey smethod_13(RegistryKey registryKey_0, string string_0, RegistryKeyPermissionCheck registryKeyPermissionCheck_0, RegistryRights registryRights_0)
	{
		return registryKey_0.OpenSubKey(string_0, registryKeyPermissionCheck_0, registryRights_0);
	}

	// Token: 0x0600131C RID: 4892 RVA: 0x00003D70 File Offset: 0x00001F70
	static RegistrySecurity smethod_14(RegistryKey registryKey_0)
	{
		return registryKey_0.GetAccessControl();
	}

	// Token: 0x0600131D RID: 4893 RVA: 0x00003910 File Offset: 0x00001B10
	static string smethod_15()
	{
		return Environment.UserName;
	}

	// Token: 0x0600131E RID: 4894 RVA: 0x00003D78 File Offset: 0x00001F78
	static NTAccount smethod_16(string string_0)
	{
		return new NTAccount(string_0);
	}

	// Token: 0x0600131F RID: 4895 RVA: 0x00003D80 File Offset: 0x00001F80
	static void smethod_17(ObjectSecurity objectSecurity_0, IdentityReference identityReference_0)
	{
		objectSecurity_0.SetOwner(identityReference_0);
	}

	// Token: 0x06001320 RID: 4896 RVA: 0x00003D89 File Offset: 0x00001F89
	static void smethod_18(RegistryKey registryKey_0, RegistrySecurity registrySecurity_0)
	{
		registryKey_0.SetAccessControl(registrySecurity_0);
	}

	// Token: 0x06001321 RID: 4897 RVA: 0x00003D92 File Offset: 0x00001F92
	static RegistryAccessRule smethod_19(string string_0, RegistryRights registryRights_0, AccessControlType accessControlType_0)
	{
		return new RegistryAccessRule(string_0, registryRights_0, accessControlType_0);
	}

	// Token: 0x06001322 RID: 4898 RVA: 0x00003D9C File Offset: 0x00001F9C
	static void smethod_20(RegistrySecurity registrySecurity_0, RegistryAccessRule registryAccessRule_0)
	{
		registrySecurity_0.SetAccessRule(registryAccessRule_0);
	}

	// Token: 0x06001323 RID: 4899 RVA: 0x00003DA5 File Offset: 0x00001FA5
	static RegistrySecurity smethod_21()
	{
		return new RegistrySecurity();
	}

	// Token: 0x06001324 RID: 4900 RVA: 0x00003DAC File Offset: 0x00001FAC
	static void smethod_22(RegistrySecurity registrySecurity_0, RegistryAccessRule registryAccessRule_0)
	{
		registrySecurity_0.AddAccessRule(registryAccessRule_0);
	}
}
