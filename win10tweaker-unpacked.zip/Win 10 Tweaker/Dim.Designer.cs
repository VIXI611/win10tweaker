﻿// Token: 0x02000078 RID: 120
public partial class Dim : global::System.Windows.Forms.Form
{
	// Token: 0x060005CF RID: 1487 RVA: 0x0001BEA0 File Offset: 0x0001A0A0
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.wait = new global::System.Windows.Forms.Label();
		base.SuspendLayout();
		this.timer_0.Tick += new global::System.EventHandler(this.method_0);
		this.wait.AutoSize = true;
		this.wait.Location = new global::System.Drawing.Point(0, 0);
		this.wait.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.wait.Name = "wait";
		this.wait.Size = new global::System.Drawing.Size(0, 72);
		this.wait.TabIndex = 0;
		this.wait.Visible = false;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(38f, 72f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.Black;
		base.ClientSize = new global::System.Drawing.Size(300, 300);
		base.Controls.Add(this.wait);
		this.Font = new global::System.Drawing.Font("Arial", 48f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.ForeColor = global::System.Drawing.Color.White;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Margin = new global::System.Windows.Forms.Padding(19, 17, 19, 17);
		base.Name = "Dim";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.Manual;
		base.Load += new global::System.EventHandler(this.Dim_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400026E RID: 622
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x0400026F RID: 623
	private global::System.Windows.Forms.Timer timer_0;

	// Token: 0x04000270 RID: 624
	private global::System.Windows.Forms.Label wait;
}
