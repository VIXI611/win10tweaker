﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x020000DA RID: 218
internal partial class Form3 : Form1
{
	// Token: 0x17000093 RID: 147
	// (get) Token: 0x06000A8A RID: 2698 RVA: 0x00038388 File Offset: 0x00036588
	public static Form3 Form3_0
	{
		get
		{
			if (Form3.form3_0 == null)
			{
				object obj = Form3.object_0;
				lock (obj)
				{
					if (Form3.form3_0 == null)
					{
						Form3.form3_0 = new Form3();
					}
				}
			}
			return Form3.form3_0;
		}
	}

	// Token: 0x06000A8B RID: 2699 RVA: 0x00005983 File Offset: 0x00003B83
	public bool method_19()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\AdvertisingInfo").smethod_0("Enabled", "0", false);
	}

	// Token: 0x06000A8C RID: 2700 RVA: 0x000059B3 File Offset: 0x00003BB3
	public bool method_20()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\SettingSync\\Groups\\Accessibility").smethod_0("Enabled", "0", false);
	}

	// Token: 0x06000A8D RID: 2701 RVA: 0x000059E3 File Offset: 0x00003BE3
	public bool method_21()
	{
		return Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\AutoLogger-Diagtrack-Listener").smethod_0("Start", "0", false);
	}

	// Token: 0x06000A8E RID: 2702 RVA: 0x00005A04 File Offset: 0x00003C04
	public bool method_22()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\NvTelemetryContainer").smethod_0("Start", "4", true);
	}

	// Token: 0x06000A8F RID: 2703 RVA: 0x000383E8 File Offset: 0x000365E8
	public bool method_23()
	{
		bool result = false;
		string text = Process.Start(new ProcessStartInfo
		{
			FileName = "cmd.exe",
			Arguments = "/c chcp 65001 & schtasks /TN \\Microsoft\\Windows\\Maintenance\\WinSAT",
			UseShellExecute = false,
			RedirectStandardOutput = true,
			CreateNoWindow = true
		}).StandardOutput.ReadToEnd();
		if (!(text.Contains("isable") & !GClass2.GClass2_0.String_3.Contains("7")))
		{
			if (!text.Contains("N/A"))
			{
				result = true;
			}
		}
		else
		{
			result = true;
		}
		return result;
	}

	// Token: 0x06000A90 RID: 2704 RVA: 0x00005A34 File Offset: 0x00003C34
	public bool method_24()
	{
		return GClass2.GClass2_0.String_3.Contains("Home") || Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat").smethod_0("DisableInventory", "1", false);
	}

	// Token: 0x06000A91 RID: 2705 RVA: 0x00005A6D File Offset: 0x00003C6D
	public bool method_25()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\DataCollection").smethod_0("AllowTelemetry", "0", false);
	}

	// Token: 0x06000A92 RID: 2706 RVA: 0x00005A9D File Offset: 0x00003C9D
	public bool method_26()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\TabletPC").smethod_0("PreventHandwritingDataSharing", "1", false);
	}

	// Token: 0x06000A93 RID: 2707 RVA: 0x00038470 File Offset: 0x00036670
	public bool method_27()
	{
		string path = GClass13.string_7 + "\\drivers\\etc\\hosts";
		return (File.Exists(path) ? File.ReadAllText(path) : "").Contains("telemetry");
	}

	// Token: 0x06000A94 RID: 2708 RVA: 0x00005ABE File Offset: 0x00003CBE
	public bool method_28()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat").smethod_0("DisableUAR", "1", false);
	}

	// Token: 0x06000A95 RID: 2709 RVA: 0x00005ADF File Offset: 0x00003CDF
	public bool method_29()
	{
		return GClass2.GClass2_0.String_3.Contains("Home") || Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors").smethod_0("DisableWindowsLocationProvider", "1", false);
	}

	// Token: 0x06000A96 RID: 2710 RVA: 0x00005B18 File Offset: 0x00003D18
	public bool method_30()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Siuf\\Rules").smethod_0("NumberOfSIUFInPeriod", "0", false);
	}

	// Token: 0x06000A97 RID: 2711 RVA: 0x00005B39 File Offset: 0x00003D39
	public bool method_31()
	{
		return GClass2.GClass2_0.String_3.Contains("Home") || Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Speech").smethod_0("AllowSpeechModelUpdate", "0", false);
	}

	// Token: 0x06000A98 RID: 2712 RVA: 0x00005B72 File Offset: 0x00003D72
	public bool method_32()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\CDPUserSvc").smethod_0("Start", "4", false);
	}

	// Token: 0x06000A99 RID: 2713 RVA: 0x00005BA2 File Offset: 0x00003DA2
	public bool method_33()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System").smethod_0("AllowExperimentation", "0", false);
	}

	// Token: 0x06000A9A RID: 2714 RVA: 0x00005BC3 File Offset: 0x00003DC3
	public bool method_34()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\DiagTrack") == null;
	}

	// Token: 0x06000A9B RID: 2715 RVA: 0x00005BE6 File Offset: 0x00003DE6
	public bool method_35()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_2 + "\\diagnosticshub.standardcollector.service").smethod_0("Start", "4", false);
	}

	// Token: 0x06000A9C RID: 2716 RVA: 0x00005C16 File Offset: 0x00003E16
	public bool method_36()
	{
		return Registry.ClassesRoot.OpenSubKey("*\\shell\\runas") != null;
	}

	// Token: 0x06000A9D RID: 2717 RVA: 0x00005C2A File Offset: 0x00003E2A
	public bool method_37()
	{
		return Registry.ClassesRoot.OpenSubKey("*\\shell\\runas").smethod_1("Extended", false);
	}

	// Token: 0x06000A9E RID: 2718 RVA: 0x00005C46 File Offset: 0x00003E46
	public bool method_38()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\SerServices") != null;
	}

	// Token: 0x06000A9F RID: 2719 RVA: 0x00005C5A File Offset: 0x00003E5A
	public bool method_39()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\AdministrativeTools") != null;
	}

	// Token: 0x06000AA0 RID: 2720 RVA: 0x00005C6E File Offset: 0x00003E6E
	public bool method_40()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\SafeMode") != null;
	}

	// Token: 0x06000AA1 RID: 2721 RVA: 0x00005C82 File Offset: 0x00003E82
	public bool method_41()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\DeviceManager") != null;
	}

	// Token: 0x06000AA2 RID: 2722 RVA: 0x00005C96 File Offset: 0x00003E96
	public bool method_42()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\ControlPanel") != null;
	}

	// Token: 0x06000AA3 RID: 2723 RVA: 0x00005CAA File Offset: 0x00003EAA
	public bool method_43()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\ProgramsAndFeatures") != null;
	}

	// Token: 0x06000AA4 RID: 2724 RVA: 0x00005CBE File Offset: 0x00003EBE
	public bool method_44()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\LocalGroupPolicyEditor") != null;
	}

	// Token: 0x06000AA5 RID: 2725 RVA: 0x00005CD2 File Offset: 0x00003ED2
	public bool method_45()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\RegRegistry") != null;
	}

	// Token: 0x06000AA6 RID: 2726 RVA: 0x00005CE6 File Offset: 0x00003EE6
	public bool method_46()
	{
		return this.method_38();
	}

	// Token: 0x06000AA7 RID: 2727 RVA: 0x00005CEE File Offset: 0x00003EEE
	public bool method_47()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\DiskManagement") != null;
	}

	// Token: 0x06000AA8 RID: 2728 RVA: 0x00005D02 File Offset: 0x00003F02
	public bool method_48()
	{
		return Registry.ClassesRoot.OpenSubKey("DesktopBackground\\Shell\\cmd") != null;
	}

	// Token: 0x06000AA9 RID: 2729 RVA: 0x000384AC File Offset: 0x000366AC
	public bool method_49()
	{
		bool flag = Registry.ClassesRoot.OpenSubKey(".cmd\\ShellNew") != null;
		RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey(".reg\\ShellNew");
		RegistryKey registryKey2 = Registry.ClassesRoot.OpenSubKey(".vbs\\ShellNew");
		return flag || registryKey != null || registryKey2 != null;
	}

	// Token: 0x06000AAA RID: 2730 RVA: 0x00005D16 File Offset: 0x00003F16
	public bool method_50()
	{
		return Registry.ClassesRoot.OpenSubKey(".cmd\\ShellNew") != null;
	}

	// Token: 0x06000AAB RID: 2731 RVA: 0x00005D2A File Offset: 0x00003F2A
	public bool method_51()
	{
		return Registry.ClassesRoot.OpenSubKey(".reg\\ShellNew") != null;
	}

	// Token: 0x06000AAC RID: 2732 RVA: 0x00005D3E File Offset: 0x00003F3E
	public bool method_52()
	{
		return Registry.ClassesRoot.OpenSubKey(".vbs\\ShellNew") != null;
	}

	// Token: 0x06000AAD RID: 2733 RVA: 0x00005D52 File Offset: 0x00003F52
	public bool method_53()
	{
		return Registry.ClassesRoot.OpenSubKey("Directory\\shell\\SuperHidden") != null;
	}

	// Token: 0x06000AAE RID: 2734 RVA: 0x00005D66 File Offset: 0x00003F66
	public bool method_54()
	{
		return Registry.ClassesRoot.OpenSubKey("Directory\\shell\\SuperHidden").smethod_1("Extended", false);
	}

	// Token: 0x06000AAF RID: 2735 RVA: 0x00005D82 File Offset: 0x00003F82
	public bool method_55()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\SystemFileAssociations\\.jpg\\shell\\CopyImageToClipboard") != null;
	}

	// Token: 0x06000AB0 RID: 2736 RVA: 0x00005D96 File Offset: 0x00003F96
	public bool method_56()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\SystemFileAssociations\\.jpg\\shell\\CopyImageToClipboard").smethod_1("Extended", false);
	}

	// Token: 0x06000AB1 RID: 2737 RVA: 0x00005DB2 File Offset: 0x00003FB2
	public bool method_57()
	{
		return File.Exists(GClass13.string_6 + "\\ImgurUp.exe");
	}

	// Token: 0x06000AB2 RID: 2738 RVA: 0x00005DC8 File Offset: 0x00003FC8
	public bool method_58()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\SystemFileAssociations\\.bmp\\shell\\" + GClass2.GClass2_0.method_1("UploadOnImgur")).smethod_1("Extended", false);
	}

	// Token: 0x06000AB3 RID: 2739 RVA: 0x00005DF8 File Offset: 0x00003FF8
	public bool method_59()
	{
		return File.Exists(GClass13.string_6 + "\\Uploadee.exe");
	}

	// Token: 0x06000AB4 RID: 2740 RVA: 0x00005E0E File Offset: 0x0000400E
	public bool method_60()
	{
		return Registry.CurrentUser.OpenSubKey("*\\Shell\\Upload.ee").smethod_1("Extended", false);
	}

	// Token: 0x06000AB5 RID: 2741 RVA: 0x00005E2A File Offset: 0x0000402A
	public bool method_61()
	{
		return Registry.ClassesRoot.OpenSubKey("exefile\\shell\\Firewall_Allow") != null;
	}

	// Token: 0x06000AB6 RID: 2742 RVA: 0x00005E3E File Offset: 0x0000403E
	public bool method_62()
	{
		return Registry.ClassesRoot.OpenSubKey("exefile\\shell\\Firewall_Allow").smethod_1("Extended", false);
	}

	// Token: 0x06000AB7 RID: 2743 RVA: 0x00005E5A File Offset: 0x0000405A
	public bool method_63()
	{
		return Registry.ClassesRoot.OpenSubKey("Directory\\shell\\EmptyThisFolder") != null;
	}

	// Token: 0x06000AB8 RID: 2744 RVA: 0x00005E6E File Offset: 0x0000406E
	public bool method_64()
	{
		return Registry.ClassesRoot.OpenSubKey("Directory\\shell\\EmptyThisFolder").smethod_1("Extended", false);
	}

	// Token: 0x06000AB9 RID: 2745 RVA: 0x00005E8A File Offset: 0x0000408A
	public bool method_65()
	{
		return Registry.ClassesRoot.OpenSubKey("*\\shell\\CreateSymbolicLink") != null;
	}

	// Token: 0x06000ABA RID: 2746 RVA: 0x00005E9E File Offset: 0x0000409E
	public bool method_66()
	{
		return Registry.ClassesRoot.OpenSubKey("*\\shell\\CreateSymbolicLink").smethod_1("Extended", false);
	}

	// Token: 0x06000ABB RID: 2747 RVA: 0x00005EBA File Offset: 0x000040BA
	public bool method_67()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Classes\\MSInfoFile") != null;
	}

	// Token: 0x06000ABC RID: 2748 RVA: 0x00005ECE File Offset: 0x000040CE
	public bool method_68()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\WMP11.AssocFile.MP3\\shell\\Enqueue").smethod_1("LegacyDisable", false);
	}

	// Token: 0x06000ABD RID: 2749 RVA: 0x00005EEA File Offset: 0x000040EA
	public bool method_69()
	{
		return Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop").smethod_0("MenuShowDelay", "20", false);
	}

	// Token: 0x06000ABE RID: 2750 RVA: 0x00005F0B File Offset: 0x0000410B
	public bool method_70()
	{
		return Registry.ClassesRoot.OpenSubKey("CLSID\\{596AB062-B4D2-4215-9F74-E9109B0A8153}") == null;
	}

	// Token: 0x06000ABF RID: 2751 RVA: 0x00005F1F File Offset: 0x0000411F
	public bool method_71()
	{
		return this.method_70();
	}

	// Token: 0x06000AC0 RID: 2752 RVA: 0x00005F27 File Offset: 0x00004127
	public bool method_72()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\SystemFileAssociations\\.bmp\\Shell\\3D Edit") == null;
	}

	// Token: 0x06000AC1 RID: 2753 RVA: 0x00005F3B File Offset: 0x0000413B
	public bool method_73()
	{
		return Registry.ClassesRoot.OpenSubKey("CLSID\\{470C0EBD-5D73-4d58-9CED-E91E22E23282}") == null;
	}

	// Token: 0x06000AC2 RID: 2754 RVA: 0x00005F4F File Offset: 0x0000414F
	public bool method_74()
	{
		return Registry.ClassesRoot.OpenSubKey("Folder\\shell\\pintohome") == null;
	}

	// Token: 0x06000AC3 RID: 2755 RVA: 0x00005F63 File Offset: 0x00004163
	public bool method_75()
	{
		return Registry.ClassesRoot.OpenSubKey("SystemFileAssociations\\Directory.Audio\\shellex\\ContextMenuHandlers\\WMPShopMusic") == null;
	}

	// Token: 0x06000AC4 RID: 2756 RVA: 0x00005F77 File Offset: 0x00004177
	public bool method_76()
	{
		return Registry.ClassesRoot.OpenSubKey("*\\shellex\\ContextMenuHandlers\\ModernSharing") == null;
	}

	// Token: 0x06000AC5 RID: 2757 RVA: 0x00005F8B File Offset: 0x0000418B
	public bool method_77()
	{
		return Registry.ClassesRoot.OpenSubKey("CLSID\\{7AD84985-87B4-4a16-BE58-8B72A5B390F7}") == null;
	}

	// Token: 0x06000AC6 RID: 2758 RVA: 0x00005F9F File Offset: 0x0000419F
	public bool method_78()
	{
		return Registry.ClassesRoot.OpenSubKey("Folder\\shellex\\ContextMenuHandlers\\Library Location") == null;
	}

	// Token: 0x06000AC7 RID: 2759 RVA: 0x00005FB3 File Offset: 0x000041B3
	public bool method_79()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\.bmp\\ShellNew") == null;
	}

	// Token: 0x06000AC8 RID: 2760 RVA: 0x00005FC7 File Offset: 0x000041C7
	public bool method_80()
	{
		return this.method_79();
	}

	// Token: 0x06000AC9 RID: 2761 RVA: 0x00005FCF File Offset: 0x000041CF
	public bool method_81()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\.contact\\ShellNew") == null;
	}

	// Token: 0x06000ACA RID: 2762 RVA: 0x00005FE3 File Offset: 0x000041E3
	public bool method_82()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\.rtf\\ShellNew") == null;
	}

	// Token: 0x06000ACB RID: 2763 RVA: 0x00005FF7 File Offset: 0x000041F7
	public bool method_83()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\.zip\\CompressedFolder\\ShellNew") == null;
	}

	// Token: 0x06000ACC RID: 2764 RVA: 0x0000600B File Offset: 0x0000420B
	public bool method_84()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\Briefcase\\ShellNew") == null;
	}

	// Token: 0x06000ACD RID: 2765 RVA: 0x0000601F File Offset: 0x0000421F
	public bool method_85()
	{
		return Registry.ClassesRoot.OpenSubKey("DesktopBackground\\Shell\\Display") == null;
	}

	// Token: 0x06000ACE RID: 2766 RVA: 0x000384F4 File Offset: 0x000366F4
	public bool method_86()
	{
		RegistryKey registryKey = Registry.Users.OpenSubKey(".DEFAULT\\Control Panel\\Colors");
		if (registryKey == null)
		{
			return false;
		}
		object value = registryKey.GetValue("InfoWindow");
		bool? flag = (value != null) ? new bool?(value.ToString().Contains("246")) : null;
		return flag.GetValueOrDefault() & flag != null;
	}

	// Token: 0x06000ACF RID: 2767 RVA: 0x00038558 File Offset: 0x00036758
	public bool method_87()
	{
		RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_1 + "\\Fonts");
		if (registryKey == null)
		{
			return false;
		}
		object value = registryKey.GetValue("Segoe UI (TrueType)");
		bool? flag = (value != null) ? new bool?(value.ToString().Contains("segoeui.ttf")) : null;
		return !flag.GetValueOrDefault() & flag != null;
	}

	// Token: 0x06000AD0 RID: 2768 RVA: 0x00006033 File Offset: 0x00004233
	public bool method_88()
	{
		return Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop\\WindowMetrics").smethod_0("CaptionWidth", "-270", false);
	}

	// Token: 0x06000AD1 RID: 2769 RVA: 0x00006054 File Offset: 0x00004254
	public bool method_89()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\MyComputer\\NameSpace\\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}") == null;
	}

	// Token: 0x06000AD2 RID: 2770 RVA: 0x00006077 File Offset: 0x00004277
	public bool method_90()
	{
		return !Directory.Exists(GClass13.string_2 + "\\3D Objects");
	}

	// Token: 0x06000AD3 RID: 2771 RVA: 0x000385CC File Offset: 0x000367CC
	public bool method_91()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_3.Contains("10") ? Class56.Class56_0.List_1[0] : Class56.Class56_0.List_4[0]) == null;
	}

	// Token: 0x06000AD4 RID: 2772 RVA: 0x00006090 File Offset: 0x00004290
	public bool method_92()
	{
		return this.method_91();
	}

	// Token: 0x06000AD5 RID: 2773 RVA: 0x00038620 File Offset: 0x00036820
	public bool method_93()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_3.Contains("10") ? Class56.Class56_0.List_1[1] : Class56.Class56_0.List_4[1]) == null;
	}

	// Token: 0x06000AD6 RID: 2774 RVA: 0x00038674 File Offset: 0x00036874
	public bool method_94()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_3.Contains("10") ? Class56.Class56_0.List_1[2] : Class56.Class56_0.List_4[2]) == null;
	}

	// Token: 0x06000AD7 RID: 2775 RVA: 0x000386C8 File Offset: 0x000368C8
	public bool method_95()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_3.Contains("10") ? Class56.Class56_0.List_1[3] : Class56.Class56_0.List_4[3]) == null;
	}

	// Token: 0x06000AD8 RID: 2776 RVA: 0x0003871C File Offset: 0x0003691C
	public bool method_96()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_3.Contains("10") ? Class56.Class56_0.List_1[4] : Class56.Class56_0.List_4[4]) == null;
	}

	// Token: 0x06000AD9 RID: 2777 RVA: 0x00038770 File Offset: 0x00036970
	public bool method_97()
	{
		return Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_3.Contains("10") ? Class56.Class56_0.List_1[5] : Class56.Class56_0.List_4[5]) == null;
	}

	// Token: 0x06000ADA RID: 2778 RVA: 0x00006098 File Offset: 0x00004298
	public bool method_98()
	{
		return File.Exists(GClass13.string_6 + "\\Blank.ico");
	}

	// Token: 0x06000ADB RID: 2779 RVA: 0x000060AE File Offset: 0x000042AE
	public bool method_99()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer").smethod_0("Link", "00000000", false);
	}

	// Token: 0x06000ADC RID: 2780 RVA: 0x000060DE File Offset: 0x000042DE
	public bool method_100()
	{
		return Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop").smethod_0("CursorBlinkRate", "250", false);
	}

	// Token: 0x06000ADD RID: 2781 RVA: 0x000060FF File Offset: 0x000042FF
	public bool method_101()
	{
		return Registry.CurrentUser.OpenSubKey("Control Panel\\Mouse").smethod_0("MouseHoverTime", "20", false);
	}

	// Token: 0x06000ADE RID: 2782 RVA: 0x00006120 File Offset: 0x00004320
	public bool method_102()
	{
		return File.Exists(GClass13.string_7 + "\\imageres.dll_bak");
	}

	// Token: 0x06000ADF RID: 2783 RVA: 0x00006136 File Offset: 0x00004336
	public bool method_103()
	{
		return Registry.CurrentUser.OpenSubKey("Control Panel\\Cursors").smethod_1("Cursors Backup", false);
	}

	// Token: 0x06000AE0 RID: 2784 RVA: 0x00006152 File Offset: 0x00004352
	public bool method_104()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced").smethod_0("HideFileExt", "0", false);
	}

	// Token: 0x06000AE1 RID: 2785 RVA: 0x00006182 File Offset: 0x00004382
	public bool method_105()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Modules\\GlobalSettings\\Sizer").smethod_0("PageSpaceControlSizer", "AD000000000000000000000063040000", false);
	}

	// Token: 0x06000AE2 RID: 2786 RVA: 0x000061B2 File Offset: 0x000043B2
	public bool method_106()
	{
		return this.method_104();
	}

	// Token: 0x06000AE3 RID: 2787 RVA: 0x000061BA File Offset: 0x000043BA
	public bool method_107()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced").smethod_0("LaunchTo", "1", false);
	}

	// Token: 0x06000AE4 RID: 2788 RVA: 0x000061EA File Offset: 0x000043EA
	public bool method_108()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced").smethod_0("HideDrivesWithNoMedia", "0", false);
	}

	// Token: 0x06000AE5 RID: 2789 RVA: 0x0000621A File Offset: 0x0000441A
	public bool method_109()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced").smethod_0("HideMergeConflicts", "0", false);
	}

	// Token: 0x06000AE6 RID: 2790 RVA: 0x0000624A File Offset: 0x0000444A
	public bool method_110()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Notepad").smethod_0("StatusBar", "1", false);
	}

	// Token: 0x06000AE7 RID: 2791 RVA: 0x0000626B File Offset: 0x0000446B
	public bool method_111()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\SystemFileAssociations\\video").smethod_0("Treatment", "0", false);
	}

	// Token: 0x06000AE8 RID: 2792 RVA: 0x0000628C File Offset: 0x0000448C
	public bool method_112()
	{
		return Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\FileSystem").smethod_0("LongPathsEnabled", "1", false);
	}

	// Token: 0x06000AE9 RID: 2793 RVA: 0x000062AD File Offset: 0x000044AD
	public bool method_113()
	{
		return File.Exists(GClass13.string_7 + "\\InputSwitch.dll_bak");
	}

	// Token: 0x06000AEA RID: 2794 RVA: 0x000062C3 File Offset: 0x000044C3
	public bool method_114()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer").smethod_0("EnableAutoTray", "0", false);
	}

	// Token: 0x06000AEB RID: 2795 RVA: 0x000062F3 File Offset: 0x000044F3
	public bool method_115()
	{
		return Registry.CurrentUser.OpenSubKey("Console\\%SystemRoot%_system32_cmd.exe").smethod_0("FaceName", "Lucida Console", false);
	}

	// Token: 0x06000AEC RID: 2796 RVA: 0x00006314 File Offset: 0x00004514
	public bool method_116()
	{
		return Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop\\WindowMetrics").smethod_0("ScrollHeight", "-210", false);
	}

	// Token: 0x06000AED RID: 2797 RVA: 0x00006335 File Offset: 0x00004535
	public bool method_117()
	{
		return Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\DWM").smethod_0("AnimationsShiftKey", "1", false);
	}

	// Token: 0x06000AEE RID: 2798 RVA: 0x00006356 File Offset: 0x00004556
	public bool method_118()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\HideDesktopIcons\\NewStartPanel").smethod_0("{20D04FE0-3AEA-1069-A2D8-08002B30309D}", "0", false);
	}

	// Token: 0x06000AEF RID: 2799 RVA: 0x00006386 File Offset: 0x00004586
	public bool method_119()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Advanced").smethod_0("PersistBrowsers", "1", false);
	}

	// Token: 0x06000AF0 RID: 2800 RVA: 0x000063B6 File Offset: 0x000045B6
	public bool method_120()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Notifications\\Settings\\Windows.SystemToast.SecurityAndMaintenance").smethod_0("Enabled", "0", false);
	}

	// Token: 0x06000AF1 RID: 2801 RVA: 0x000063E6 File Offset: 0x000045E6
	public bool method_121()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Internet Settings\\Zones\\3").smethod_0("1806", "0", false);
	}

	// Token: 0x06000AF2 RID: 2802 RVA: 0x000387C4 File Offset: 0x000369C4
	public bool method_122()
	{
		if (!GClass2.GClass2_0.String_3.Contains("10"))
		{
			return Directory.Exists(GClass13.string_11 + "\\Microsoft\\Windows Defender");
		}
		return Registry.LocalMachine.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\Windows Defender").smethod_0("DisableAntiSpyware", "1", false);
	}

	// Token: 0x06000AF3 RID: 2803 RVA: 0x00006416 File Offset: 0x00004616
	public bool method_123()
	{
		return Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\System").smethod_0("EnableLUA", "0", false);
	}

	// Token: 0x06000AF4 RID: 2804 RVA: 0x00006446 File Offset: 0x00004646
	public bool method_124()
	{
		return Registry.CurrentUser.CreateSubKey("Keyboard Layout\\Toggle").smethod_0("Hotkey", "2", false);
	}

	// Token: 0x06000AF5 RID: 2805 RVA: 0x00006467 File Offset: 0x00004667
	public bool method_125()
	{
		return Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\7516b95f-f776-4464-8c53-06167f40cc99\\8EC4B3A5-6868-48c2-BE75-4F3044BE88A7").smethod_0("Attributes", "2", false);
	}

	// Token: 0x06000AF6 RID: 2806 RVA: 0x00006488 File Offset: 0x00004688
	public bool method_126()
	{
		if (GClass2.GClass2_0.String_3.Contains("7"))
		{
			return !Form3.smethod_303("CorruptionDetector", "N/A");
		}
		return Form3.smethod_303("RunFullMemoryDiagnostic", "isable");
	}

	// Token: 0x06000AF7 RID: 2807 RVA: 0x0003881C File Offset: 0x00036A1C
	public bool method_127()
	{
		return Process.Start(new ProcessStartInfo
		{
			FileName = "cmd.exe",
			Arguments = "/c netsh int ipv6 isatap show state",
			UseShellExecute = false,
			RedirectStandardOutput = true,
			CreateNoWindow = true
		}).StandardOutput.ReadToEnd().Contains("isable");
	}

	// Token: 0x06000AF8 RID: 2808 RVA: 0x000064C2 File Offset: 0x000046C2
	public bool method_128()
	{
		return Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search").smethod_0("DisableWebSearch", "1", false);
	}

	// Token: 0x06000AF9 RID: 2809 RVA: 0x00038874 File Offset: 0x00036A74
	public bool method_129()
	{
		RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Internet Explorer\\Main");
		if (registryKey == null)
		{
			return false;
		}
		object value = registryKey.GetValue("Start Page");
		bool? flag = (value != null) ? new bool?(value.ToString().Contains("google")) : null;
		return flag.GetValueOrDefault() & flag != null;
	}

	// Token: 0x06000AFA RID: 2810 RVA: 0x000388D8 File Offset: 0x00036AD8
	public bool method_130()
	{
		RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Internet Settings");
		if (registryKey == null)
		{
			return false;
		}
		object value = registryKey.GetValue("AutoConfigURL");
		bool? flag = (value != null) ? new bool?(value.ToString().Contains("antizapret")) : null;
		return flag.GetValueOrDefault() & flag != null;
	}

	// Token: 0x06000AFB RID: 2811 RVA: 0x000064E3 File Offset: 0x000046E3
	public bool method_131()
	{
		return File.Exists(GClass13.string_6 + "\\Rebofresh.vbs");
	}

	// Token: 0x06000AFC RID: 2812 RVA: 0x000064F9 File Offset: 0x000046F9
	public bool method_132()
	{
		return Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management").smethod_0("LargeSystemCache", "1", false);
	}

	// Token: 0x06000AFD RID: 2813 RVA: 0x0000651A File Offset: 0x0000471A
	public bool method_133()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\Serialize").smethod_0("Startupdelayinmsec", "0", false);
	}

	// Token: 0x06000AFE RID: 2814 RVA: 0x0000654A File Offset: 0x0000474A
	public bool method_134()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer").smethod_0("ShowRecent", "0", false);
	}

	// Token: 0x06000AFF RID: 2815 RVA: 0x0000657A File Offset: 0x0000477A
	public bool method_135()
	{
		return Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\AutoplayHandlers").smethod_0("DisableAutoplay", "1", false);
	}

	// Token: 0x06000B00 RID: 2816 RVA: 0x0003894C File Offset: 0x00036B4C
	public bool method_136()
	{
		RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey("Applications\\photoviewer.dll\\shell\\open");
		if (registryKey == null)
		{
			return false;
		}
		object value = registryKey.GetValue("MuiVerb");
		bool? flag = (value != null) ? new bool?(value.ToString().Contains("photoviewer")) : null;
		return flag.GetValueOrDefault() & flag != null;
	}

	// Token: 0x06000B01 RID: 2817 RVA: 0x000389B0 File Offset: 0x00036BB0
	public bool method_137()
	{
		RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey("CLSID\\{018D5C66-4533-4307-9B53-224DE2ED1FE6}");
		RegistryKey registryKey2 = Registry.ClassesRoot.OpenSubKey("Wow6432Node\\CLSID\\{018D5C66-4533-4307-9B53-224DE2ED1FE6}");
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			return registryKey == null & registryKey2 == null;
		}
		return !GClass2.GClass2_0.String_3.Contains("7") && !File.Exists(GClass13.string_7 + "\\SkyDrive.exe");
	}

	// Token: 0x06000B04 RID: 2820 RVA: 0x00038A2C File Offset: 0x00036C2C
	[CompilerGenerated]
	internal static bool smethod_303(string string_0, string string_1)
	{
		return Process.Start(new ProcessStartInfo
		{
			FileName = "cmd",
			Arguments = "/c chcp 65001 & schtasks /TN \\Microsoft\\Windows\\MemoryDiagnostic\\" + string_0,
			UseShellExecute = false,
			RedirectStandardOutput = true,
			CreateNoWindow = true
		}).StandardOutput.ReadToEnd().Contains(string_1);
	}

	// Token: 0x06000B05 RID: 2821 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_304(object object_1, ref bool bool_1)
	{
		Monitor.Enter(object_1, ref bool_1);
	}

	// Token: 0x06000B06 RID: 2822 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_305(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000B07 RID: 2823 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_306(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x06000B08 RID: 2824 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_307(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.OpenSubKey(string_0);
	}

	// Token: 0x06000B09 RID: 2825 RVA: 0x00003100 File Offset: 0x00001300
	static ProcessStartInfo smethod_308()
	{
		return new ProcessStartInfo();
	}

	// Token: 0x06000B0A RID: 2826 RVA: 0x00003107 File Offset: 0x00001307
	static void smethod_309(ProcessStartInfo processStartInfo_0, string string_0)
	{
		processStartInfo_0.FileName = string_0;
	}

	// Token: 0x06000B0B RID: 2827 RVA: 0x00003110 File Offset: 0x00001310
	static void smethod_310(ProcessStartInfo processStartInfo_0, string string_0)
	{
		processStartInfo_0.Arguments = string_0;
	}

	// Token: 0x06000B0C RID: 2828 RVA: 0x000065B6 File Offset: 0x000047B6
	static void smethod_311(ProcessStartInfo processStartInfo_0, bool bool_1)
	{
		processStartInfo_0.UseShellExecute = bool_1;
	}

	// Token: 0x06000B0D RID: 2829 RVA: 0x000065BF File Offset: 0x000047BF
	static void smethod_312(ProcessStartInfo processStartInfo_0, bool bool_1)
	{
		processStartInfo_0.RedirectStandardOutput = bool_1;
	}

	// Token: 0x06000B0E RID: 2830 RVA: 0x000065C8 File Offset: 0x000047C8
	static void smethod_313(ProcessStartInfo processStartInfo_0, bool bool_1)
	{
		processStartInfo_0.CreateNoWindow = bool_1;
	}

	// Token: 0x06000B0F RID: 2831 RVA: 0x00003122 File Offset: 0x00001322
	static Process smethod_314(ProcessStartInfo processStartInfo_0)
	{
		return Process.Start(processStartInfo_0);
	}

	// Token: 0x06000B10 RID: 2832 RVA: 0x000065D1 File Offset: 0x000047D1
	static StreamReader smethod_315(Process process_0)
	{
		return process_0.StandardOutput;
	}

	// Token: 0x06000B11 RID: 2833 RVA: 0x000065D9 File Offset: 0x000047D9
	static string smethod_316(TextReader textReader_0)
	{
		return textReader_0.ReadToEnd();
	}

	// Token: 0x06000B12 RID: 2834 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_317(string string_0, string string_1)
	{
		return string_0.Contains(string_1);
	}

	// Token: 0x06000B13 RID: 2835 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_318(string string_0)
	{
		return File.Exists(string_0);
	}

	// Token: 0x06000B14 RID: 2836 RVA: 0x00003CE7 File Offset: 0x00001EE7
	static string smethod_319(string string_0)
	{
		return File.ReadAllText(string_0);
	}

	// Token: 0x06000B15 RID: 2837 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_320(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x06000B16 RID: 2838 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_321(object object_1)
	{
		return object_1.ToString();
	}

	// Token: 0x06000B17 RID: 2839 RVA: 0x00002EE5 File Offset: 0x000010E5
	static bool smethod_322(string string_0)
	{
		return Directory.Exists(string_0);
	}

	// Token: 0x06000B18 RID: 2840 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_323(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x06000B19 RID: 2841 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_324()
	{
		return new object();
	}

	// Token: 0x04000471 RID: 1137
	private static volatile Form3 form3_0;

	// Token: 0x04000472 RID: 1138
	private static readonly object object_0 = new object();
}
