﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

// Token: 0x02000030 RID: 48
internal class Class14
{
	// Token: 0x17000004 RID: 4
	// (get) Token: 0x060001CC RID: 460 RVA: 0x0001166C File Offset: 0x0000F86C
	public static Class14 Class14_0
	{
		get
		{
			if (Class14.class14_0 == null)
			{
				object obj = Class14.object_0;
				lock (obj)
				{
					if (Class14.class14_0 == null)
					{
						Class14.class14_0 = new Class14();
					}
				}
			}
			return Class14.class14_0;
		}
	}

	// Token: 0x060001CD RID: 461 RVA: 0x000116CC File Offset: 0x0000F8CC
	public void method_0()
	{
		Process process = Process.GetProcesses().FirstOrDefault(new Func<Process, bool>(Class14.<>c.<>9.method_0));
		if (process != null)
		{
			process.Kill();
		}
		Process.Start(new ProcessStartInfo
		{
			FileName = "taskkill",
			Arguments = "/f /im explorer.exe",
			WindowStyle = ProcessWindowStyle.Hidden
		});
	}

	// Token: 0x060001CE RID: 462 RVA: 0x000030BB File Offset: 0x000012BB
	private void method_1()
	{
		Process.Start("explorer");
	}

	// Token: 0x060001CF RID: 463 RVA: 0x00011738 File Offset: 0x0000F938
	public Task method_2()
	{
		Class14.Struct23 @struct;
		@struct.asyncTaskMethodBuilder_0 = AsyncTaskMethodBuilder.Create();
		@struct.class14_0 = this;
		@struct.int_0 = -1;
		@struct.asyncTaskMethodBuilder_0.Start<Class14.Struct23>(ref @struct);
		return @struct.asyncTaskMethodBuilder_0.Task;
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x0001177C File Offset: 0x0000F97C
	public void method_3()
	{
		Class14.Struct24 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.class14_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Class14.Struct24>(ref @struct);
	}

	// Token: 0x060001D3 RID: 467 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060001D4 RID: 468 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060001D5 RID: 469 RVA: 0x000030F1 File Offset: 0x000012F1
	static Process[] smethod_2()
	{
		return Process.GetProcesses();
	}

	// Token: 0x060001D6 RID: 470 RVA: 0x000030F8 File Offset: 0x000012F8
	static void smethod_3(Process process_0)
	{
		process_0.Kill();
	}

	// Token: 0x060001D7 RID: 471 RVA: 0x00003100 File Offset: 0x00001300
	static ProcessStartInfo smethod_4()
	{
		return new ProcessStartInfo();
	}

	// Token: 0x060001D8 RID: 472 RVA: 0x00003107 File Offset: 0x00001307
	static void smethod_5(ProcessStartInfo processStartInfo_0, string string_1)
	{
		processStartInfo_0.FileName = string_1;
	}

	// Token: 0x060001D9 RID: 473 RVA: 0x00003110 File Offset: 0x00001310
	static void smethod_6(ProcessStartInfo processStartInfo_0, string string_1)
	{
		processStartInfo_0.Arguments = string_1;
	}

	// Token: 0x060001DA RID: 474 RVA: 0x00003119 File Offset: 0x00001319
	static void smethod_7(ProcessStartInfo processStartInfo_0, ProcessWindowStyle processWindowStyle_0)
	{
		processStartInfo_0.WindowStyle = processWindowStyle_0;
	}

	// Token: 0x060001DB RID: 475 RVA: 0x00003122 File Offset: 0x00001322
	static Process smethod_8(ProcessStartInfo processStartInfo_0)
	{
		return Process.Start(processStartInfo_0);
	}

	// Token: 0x060001DC RID: 476 RVA: 0x00002AA6 File Offset: 0x00000CA6
	static Process smethod_9(string string_1)
	{
		return Process.Start(string_1);
	}

	// Token: 0x060001DD RID: 477 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_10(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x060001DE RID: 478 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_11()
	{
		return new object();
	}

	// Token: 0x040000DD RID: 221
	private static volatile Class14 class14_0;

	// Token: 0x040000DE RID: 222
	private static readonly object object_0 = new object();

	// Token: 0x040000DF RID: 223
	private readonly string string_0 = GClass13.string_7 + "\\imageres.dll";
}
