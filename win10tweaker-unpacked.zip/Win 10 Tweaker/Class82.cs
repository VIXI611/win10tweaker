﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000186 RID: 390
internal class Class82
{
	// Token: 0x170000A6 RID: 166
	// (get) Token: 0x06001325 RID: 4901 RVA: 0x0006AD24 File Offset: 0x00068F24
	public static Class82 Class82_0
	{
		get
		{
			if (Class82.class82_0 == null)
			{
				object obj = Class82.object_0;
				lock (obj)
				{
					if (Class82.class82_0 == null)
					{
						Class82.class82_0 = new Class82();
					}
				}
			}
			return Class82.class82_0;
		}
	}

	// Token: 0x06001326 RID: 4902 RVA: 0x0006AD84 File Offset: 0x00068F84
	public void method_0()
	{
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			Registry.CurrentUser.CreateSubKey(this.string_0).SetValue("Enabled", 0);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender!DisableAntiSpyware", "1", RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableBehaviorMonitoring", "1", RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableIOAVProtection", "1", RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableOnAccessProtection", "1", RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableRealtimeMonitoring", "1", RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableScanOnRealtimeEnable", "1", RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet!**del.SpynetReporting", "", RegistryValueKind.String);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet!SubmitSamplesConsent", "2", RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender Security Center\\Notifications!DisableNotifications", "1", RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\System!EnableSmartScreen", "0", RegistryValueKind.DWord);
			GClass6.GClass6_0.method_14("schtasks /change /tn \"\\Microsoft\\Windows\\Windows Defender\\Windows Defender Cache Maintenance\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Windows Defender\\Windows Defender Cleanup\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Windows Defender\\Windows Defender Scheduled Scan\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\Windows Defender\\Windows Defender Verification\" /disable &schtasks /change /tn \"\\Microsoft\\Windows\\ExploitGuard\\ExploitGuard MDM policy Refresh\" /disable");
			Registry.LocalMachine.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\MRT").SetValue("DontReportInfectionInformation", 1);
			string text = "SOFTWARE\\Policies\\Microsoft\\Windows Defender";
			Registry.LocalMachine.CreateSubKey(text).SetValue("DisableAntiSpyware", 1);
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Run", true))
			{
				if (registryKey != null && registryKey.GetValue("SecurityHealth") != null)
				{
					registryKey.DeleteValue("SecurityHealth");
				}
				if (registryKey != null && registryKey.GetValue("WindowsDefender") != null)
				{
					registryKey.DeleteValue("WindowsDefender");
				}
			}
			using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\CLSID\\{09A47860-11B0-4DA5-AFA5-26D86198A780}\\InprocServer32", true))
			{
				if (registryKey2 != null)
				{
					registryKey2.SetValue("", "");
				}
			}
			Registry.LocalMachine.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\System").SetValue("EnableSmartScreen", 0);
			RegistryKey registryKey3 = Registry.CurrentUser.CreateSubKey("Software\\Classes\\Local Settings\\" + GClass2.GClass2_0.String_0 + "\\AppContainer\\Storage\\microsoft.microsoftedge_8wekyb3d8bbwe\\MicrosoftEdge\\PhishingFilter");
			registryKey3.SetValue("EnabledV9", 0);
			registryKey3.SetValue("PreventOverride", 0);
			Registry.LocalMachine.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\MicrosoftEdge\\PhishingFilter").SetValue("EnabledV9", 0);
			RegistryKey registryKey4 = Registry.LocalMachine.CreateSubKey(text + "\\SmartScreen");
			registryKey4.SetValue("ConfigureAppInstallControl", "Anywhere");
			registryKey4.SetValue("ConfigureAppInstallControlEnabled", 1);
			Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\AppHost").SetValue("EnableWebContentEvaluation", 0);
			Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer").SetValue("SmartScreenEnabled", "off");
			if (Directory.Exists(GClass13.string_9 + "\\Windows Defender"))
			{
				Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\Attachments").SetValue("ScanWithAntiVirus", 0);
			}
			List<string> list = new List<string>();
			list.Add("NisSrv");
			list.Add("MSASCuiL");
			list.Add("SecurityHealthSystray");
			list.Add("SecurityHealthService");
			list.Add("smartscreen");
			list.Add("SecurityHealthSystray");
			list.Add("SecurityHealthService");
			list.Add("SecurityHealthHost");
			list.Add("MpCmdRun");
			list.Add("smartscreen");
			list.Add("MSASCuiL");
			list.Add("MpCmdRun");
			list.Add("AM_Engine");
			list.ForEach(new Action<string>(Class82.<>c.<>9.method_0));
			list.ForEach(new Action<string>(Class82.<>c.<>9.method_1));
			if (Process.GetProcessesByName("MsMpEng").Length != 0)
			{
				GClass14.smethod_0("powershell.exe -command foreach ($serv in ('WinDefend','SgrmBroker','Sense','SecurityHealthService','WdNisSvc','wscsvc')) { stop-service $serv; reg add \"HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\$serv\" /v Start /t reg_dword /d \"4\" /f }", false);
			}
			GClass14.smethod_0("powershell.exe -command foreach ($serv in ('WinDefend','SgrmBroker','Sense','SecurityHealthService','WdNisSvc','wscsvc')) { stop-service $serv; reg add \"HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\$serv\" /v Start /t reg_dword /d \"4\" /f }", false);
			Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.string_12 + "\\SecurityHealthService.exe").SetValue("Debugger", GClass13.string_7 + "\\systray.exe");
			return;
		}
		if (GClass2.GClass2_0.String_3.Contains("8"))
		{
			GClass14.smethod_0("cmd.exe /c sc stop windefend & sc stop wscsvc & sc config windefend start=disabled & sc config wscsvc start=disabled", false);
			Thread.Sleep(1000);
		}
	}

	// Token: 0x06001327 RID: 4903 RVA: 0x0006B224 File Offset: 0x00069424
	public void method_1()
	{
		if (GClass2.GClass2_0.String_3.Contains("10"))
		{
			Registry.CurrentUser.DeleteSubKeyTree(this.string_0, false);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender!DisableAntiSpyware", null, RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableBehaviorMonitoring", null, RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableIOAVProtection", null, RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableOnAccessProtection", null, RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableRealtimeMonitoring", null, RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection!DisableScanOnRealtimeEnable", null, RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet!**del.SpynetReporting", null, RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet!SubmitSamplesConsent", null, RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows Defender Security Center\\Notifications!DisableNotifications", null, RegistryValueKind.DWord);
			GClass4.smethod_9("HKLM\\Software\\Policies\\Microsoft\\Windows\\System!EnableSmartScreen", null, RegistryValueKind.DWord);
			GClass6.GClass6_0.method_14("schtasks /change /tn \"\\Microsoft\\Windows\\Windows Defender\\Windows Defender Cache Maintenance\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Windows Defender\\Windows Defender Cleanup\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Windows Defender\\Windows Defender Scheduled Scan\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\Windows Defender\\Windows Defender Verification\" /enable &schtasks /change /tn \"\\Microsoft\\Windows\\ExploitGuard\\ExploitGuard MDM policy Refresh\" /enable");
			Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Policies\\Microsoft\\MRT", false);
			Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Spynet", false);
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\CLSID\\{09A47860-11B0-4DA5-AFA5-26D86198A780}\\InprocServer32", true))
			{
				if (registryKey != null)
				{
					registryKey.SetValue("", "C:\\Program Files\\Windows Defender\\shellext.dll");
				}
			}
			using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\System", true))
			{
				if (registryKey2 != null && registryKey2.GetValue("EnableSmartScreen") != null)
				{
					registryKey2.DeleteValue("EnableSmartScreen");
				}
			}
			if (File.Exists(GClass13.string_6 + "\\System32\\SecurityHealthSystray.exe"))
			{
				Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Run").SetValue("SecurityHealth", "%windir%\\system32\\SecurityHealthSystray.exe");
			}
			Registry.CurrentUser.DeleteSubKeyTree("Software\\Classes\\Local Settings\\" + GClass2.GClass2_0.String_0 + "\\AppContainer\\Storage\\microsoft.microsoftedge_8wekyb3d8bbwe\\MicrosoftEdge\\PhishingFilter", false);
			using (RegistryKey registryKey3 = Registry.CurrentUser.OpenSubKey(GClass2.GClass2_0.String_0 + "\\AppHost", true))
			{
				if (registryKey3 != null && registryKey3.GetValue("EnableWebContentEvaluation") != null)
				{
					registryKey3.DeleteValue("EnableWebContentEvaluation");
				}
			}
			using (RegistryKey registryKey4 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Explorer", true))
			{
				if (registryKey4 != null && registryKey4.GetValue("SmartScreenEnabled") != null)
				{
					registryKey4.DeleteValue("SmartScreenEnabled");
				}
			}
			using (RegistryKey registryKey5 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\MicrosoftEdge\\PhishingFilter", true))
			{
				if (registryKey5 != null && registryKey5.GetValue("EnabledV9") != null)
				{
					registryKey5.DeleteValue("EnabledV9");
				}
			}
			using (RegistryKey registryKey6 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows Defender\\SmartScreen", true))
			{
				if (registryKey6 != null && registryKey6.GetValue("ConfigureAppInstallControl") != null)
				{
					registryKey6.DeleteValue("ConfigureAppInstallControl");
				}
				if (registryKey6 != null && registryKey6.GetValue("ConfigureAppInstallControlEnabled") != null)
				{
					registryKey6.DeleteValue("ConfigureAppInstallControlEnabled");
				}
			}
			using (RegistryKey registryKey7 = Registry.LocalMachine.OpenSubKey(GClass2.GClass2_0.String_0 + "\\Policies\\Attachments", true))
			{
				if (registryKey7 != null && registryKey7.GetValue("ScanWithAntiVirus") != null)
				{
					registryKey7.DeleteValue("ScanWithAntiVirus");
				}
			}
			GClass14.smethod_0("powershell.exe -command foreach ($serv in ('WinDefend','SgrmBroker','wscsvc')) { stop-service $serv; reg add \"HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\$serv\" /v Start /t reg_dword /d \"2\" /f };foreach ($serv in ('Sense','SecurityHealthService','WdNisSvc')) { reg add \"HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\$serv\" /v Start /t reg_dword /d \"3\" /f }", false);
			Registry.LocalMachine.DeleteSubKeyTree(GClass2.GClass2_0.string_12 + "\\SecurityHealthService.exe", false);
			return;
		}
		if (GClass2.GClass2_0.String_3.Contains("8"))
		{
			GClass14.smethod_0("cmd.exe /c sc config windefend start=auto & sc config wscsvc start=auto", false);
			Thread.Sleep(1000);
		}
	}

	// Token: 0x0600132A RID: 4906 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x0600132B RID: 4907 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x0600132C RID: 4908 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_2(string string_1, string string_2)
	{
		return string_1.Contains(string_2);
	}

	// Token: 0x0600132D RID: 4909 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_3(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x0600132E RID: 4910 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_4(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x0600132F RID: 4911 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_5(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x06001330 RID: 4912 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_6(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_1, bool_0);
	}

	// Token: 0x06001331 RID: 4913 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_7(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.GetValue(string_1);
	}

	// Token: 0x06001332 RID: 4914 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_8(RegistryKey registryKey_0, string string_1)
	{
		registryKey_0.DeleteValue(string_1);
	}

	// Token: 0x06001333 RID: 4915 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_9(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06001334 RID: 4916 RVA: 0x000043D9 File Offset: 0x000025D9
	static void smethod_10(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x06001335 RID: 4917 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_11(string string_1, string string_2, string string_3)
	{
		return string_1 + string_2 + string_3;
	}

	// Token: 0x06001336 RID: 4918 RVA: 0x00002EE5 File Offset: 0x000010E5
	static bool smethod_12(string string_1)
	{
		return Directory.Exists(string_1);
	}

	// Token: 0x06001337 RID: 4919 RVA: 0x000033EC File Offset: 0x000015EC
	static Process[] smethod_13(string string_1)
	{
		return Process.GetProcessesByName(string_1);
	}

	// Token: 0x06001338 RID: 4920 RVA: 0x00002625 File Offset: 0x00000825
	static void smethod_14(int int_0)
	{
		Thread.Sleep(int_0);
	}

	// Token: 0x06001339 RID: 4921 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_15(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_1, bool_0);
	}

	// Token: 0x0600133A RID: 4922 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_16(string string_1)
	{
		return File.Exists(string_1);
	}

	// Token: 0x0600133B RID: 4923 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_17()
	{
		return new object();
	}

	// Token: 0x04000924 RID: 2340
	private static volatile Class82 class82_0;

	// Token: 0x04000925 RID: 2341
	private static readonly object object_0 = new object();

	// Token: 0x04000926 RID: 2342
	private readonly string string_0 = GClass2.GClass2_0.String_0 + "\\Notifications\\Settings\\Windows.SystemToast.SecurityAndMaintenance";
}
