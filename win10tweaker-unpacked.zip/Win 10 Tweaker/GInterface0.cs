﻿using System;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x02000052 RID: 82
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("EA502723-A23D-11d1-A7D3-0000F87571E3")]
[ComImport]
public interface GInterface0
{
	// Token: 0x060003EF RID: 1007
	uint New([MarshalAs(UnmanagedType.LPWStr)] string domainName, [MarshalAs(UnmanagedType.LPWStr)] string displayName, uint flags);

	// Token: 0x060003F0 RID: 1008
	uint OpenDSGPO([MarshalAs(UnmanagedType.LPWStr)] string path, uint flags);

	// Token: 0x060003F1 RID: 1009
	uint OpenLocalMachineGPO(uint flags);

	// Token: 0x060003F2 RID: 1010
	uint OpenRemoteMachineGPO([MarshalAs(UnmanagedType.LPWStr)] string computerName, uint flags);

	// Token: 0x060003F3 RID: 1011
	uint Save([MarshalAs(UnmanagedType.Bool)] bool machine, [MarshalAs(UnmanagedType.Bool)] bool add, [MarshalAs(UnmanagedType.LPStruct)] Guid extension, [MarshalAs(UnmanagedType.LPStruct)] Guid app);

	// Token: 0x060003F4 RID: 1012
	uint Delete();

	// Token: 0x060003F5 RID: 1013
	uint GetName([MarshalAs(UnmanagedType.LPWStr)] StringBuilder name, int maxLength);

	// Token: 0x060003F6 RID: 1014
	uint GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] StringBuilder name, int maxLength);

	// Token: 0x060003F7 RID: 1015
	uint SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string name);

	// Token: 0x060003F8 RID: 1016
	uint GetPath([MarshalAs(UnmanagedType.LPWStr)] StringBuilder path, int maxPath);

	// Token: 0x060003F9 RID: 1017
	uint GetDSPath(uint section, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder path, int maxPath);

	// Token: 0x060003FA RID: 1018
	uint GetFileSysPath(uint section, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder path, int maxPath);

	// Token: 0x060003FB RID: 1019
	uint GetRegistryKey(uint section, out IntPtr key);

	// Token: 0x060003FC RID: 1020
	uint GetOptions(out uint options);

	// Token: 0x060003FD RID: 1021
	uint SetOptions(uint options, uint mask);

	// Token: 0x060003FE RID: 1022
	uint GetType(out IntPtr gpoType);

	// Token: 0x060003FF RID: 1023
	uint GetMachineName([MarshalAs(UnmanagedType.LPWStr)] StringBuilder name, int maxLength);

	// Token: 0x06000400 RID: 1024
	uint GetPropertySheetPages(out IntPtr pages);
}
