﻿// Token: 0x020000C4 RID: 196
public partial class Superform : global::GForm0
{
	// Token: 0x060009EB RID: 2539 RVA: 0x0002BB78 File Offset: 0x00029D78
	private void InitializeComponent()
	{
		this.CloseIcon = new global::System.Windows.Forms.Button();
		this.MainPanel = new global::System.Windows.Forms.Panel();
		this.BlockerMenu = new global::System.Windows.Forms.Button();
		this.CleanHistoryButton = new global::System.Windows.Forms.Button();
		this.CommandLine = new global::System.Windows.Forms.ComboBox();
		this.SuperButton2 = new global::System.Windows.Forms.Button();
		this.SuperButton1 = new global::System.Windows.Forms.Button();
		this.Superexe = new global::System.Windows.Forms.PictureBox();
		this.Blockexe = new global::System.Windows.Forms.PictureBox();
		this.Freezeexe = new global::System.Windows.Forms.PictureBox();
		this.Description = new global::System.Windows.Forms.Label();
		this.Header = new global::System.Windows.Forms.Label();
		this.MainPanel.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.Superexe).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Blockexe).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.Freezeexe).BeginInit();
		base.SuspendLayout();
		this.CloseIcon.BackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.BackgroundImage = global::Class89.Bitmap_17;
		this.CloseIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.CloseIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
		this.CloseIcon.FlatAppearance.BorderSize = 0;
		this.CloseIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.CloseIcon.Location = new global::System.Drawing.Point(417, 5);
		this.CloseIcon.Name = "CloseIcon";
		this.CloseIcon.Size = new global::System.Drawing.Size(22, 22);
		this.CloseIcon.TabIndex = 18;
		this.CloseIcon.UseVisualStyleBackColor = false;
		this.MainPanel.BackColor = global::System.Drawing.Color.Transparent;
		this.MainPanel.Controls.Add(this.BlockerMenu);
		this.MainPanel.Controls.Add(this.CleanHistoryButton);
		this.MainPanel.Controls.Add(this.CommandLine);
		this.MainPanel.Controls.Add(this.SuperButton2);
		this.MainPanel.Controls.Add(this.SuperButton1);
		this.MainPanel.Controls.Add(this.Superexe);
		this.MainPanel.Controls.Add(this.Blockexe);
		this.MainPanel.Controls.Add(this.Freezeexe);
		this.MainPanel.Controls.Add(this.Description);
		this.MainPanel.Location = new global::System.Drawing.Point(12, 45);
		this.MainPanel.Name = "MainPanel";
		this.MainPanel.Size = new global::System.Drawing.Size(426, 262);
		this.MainPanel.TabIndex = 19;
		this.BlockerMenu.BackgroundImage = global::Class89.Bitmap_12;
		this.BlockerMenu.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.BlockerMenu.FlatAppearance.BorderSize = 0;
		this.BlockerMenu.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.BlockerMenu.Location = new global::System.Drawing.Point(195, 94);
		this.BlockerMenu.Name = "BlockerMenu";
		this.BlockerMenu.Size = new global::System.Drawing.Size(36, 26);
		this.BlockerMenu.TabIndex = 183;
		this.BlockerMenu.UseVisualStyleBackColor = false;
		this.BlockerMenu.Visible = false;
		this.BlockerMenu.Click += new global::System.EventHandler(this.BlockerMenu_Click);
		this.CleanHistoryButton.BackColor = global::System.Drawing.SystemColors.ButtonFace;
		this.CleanHistoryButton.FlatAppearance.BorderSize = 0;
		this.CleanHistoryButton.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.CleanHistoryButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.CleanHistoryButton.Location = new global::System.Drawing.Point(7, 232);
		this.CleanHistoryButton.Name = "CleanHistoryButton";
		this.CleanHistoryButton.Size = new global::System.Drawing.Size(22, 22);
		this.CleanHistoryButton.TabIndex = 182;
		this.CleanHistoryButton.Text = "–";
		this.CleanHistoryButton.UseVisualStyleBackColor = false;
		this.CleanHistoryButton.Click += new global::System.EventHandler(this.CleanHistoryButton_Click);
		this.CommandLine.AutoCompleteMode = global::System.Windows.Forms.AutoCompleteMode.SuggestAppend;
		this.CommandLine.AutoCompleteSource = global::System.Windows.Forms.AutoCompleteSource.ListItems;
		this.CommandLine.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.CommandLine.Font = new global::System.Drawing.Font("Tahoma", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.CommandLine.Location = new global::System.Drawing.Point(35, 232);
		this.CommandLine.Name = "CommandLine";
		this.CommandLine.Size = new global::System.Drawing.Size(175, 22);
		this.CommandLine.TabIndex = 181;
		this.SuperButton2.BackColor = global::System.Drawing.SystemColors.ButtonFace;
		this.SuperButton2.FlatAppearance.BorderSize = 0;
		this.SuperButton2.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.SuperButton2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.SuperButton2.Location = new global::System.Drawing.Point(320, 232);
		this.SuperButton2.Name = "SuperButton2";
		this.SuperButton2.Size = new global::System.Drawing.Size(100, 22);
		this.SuperButton2.TabIndex = 74;
		this.SuperButton2.UseVisualStyleBackColor = false;
		this.SuperButton2.Click += new global::System.EventHandler(this.SuperButton2_Click);
		this.SuperButton1.BackColor = global::System.Drawing.SystemColors.ButtonFace;
		this.SuperButton1.FlatAppearance.BorderSize = 0;
		this.SuperButton1.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.FromArgb(162, 167, 173);
		this.SuperButton1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.SuperButton1.Location = new global::System.Drawing.Point(215, 232);
		this.SuperButton1.Name = "SuperButton1";
		this.SuperButton1.Size = new global::System.Drawing.Size(100, 22);
		this.SuperButton1.TabIndex = 73;
		this.SuperButton1.UseVisualStyleBackColor = false;
		this.SuperButton1.Click += new global::System.EventHandler(this.SuperButton1_Click);
		this.Superexe.BackColor = global::System.Drawing.Color.Transparent;
		this.Superexe.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.Superexe.Image = global::Class89.Bitmap_62;
		this.Superexe.Location = new global::System.Drawing.Point(288, 3);
		this.Superexe.Name = "Superexe";
		this.Superexe.Size = new global::System.Drawing.Size(128, 142);
		this.Superexe.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Superexe.TabIndex = 71;
		this.Superexe.TabStop = false;
		this.Superexe.Click += new global::System.EventHandler(this.Superexe_Click);
		this.Blockexe.BackColor = global::System.Drawing.Color.Transparent;
		this.Blockexe.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.Blockexe.Image = global::Class89.Bitmap_13;
		this.Blockexe.Location = new global::System.Drawing.Point(149, 3);
		this.Blockexe.Name = "Blockexe";
		this.Blockexe.Size = new global::System.Drawing.Size(128, 142);
		this.Blockexe.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Blockexe.TabIndex = 70;
		this.Blockexe.TabStop = false;
		this.Blockexe.Click += new global::System.EventHandler(this.Blockexe_Click);
		this.Freezeexe.BackColor = global::System.Drawing.Color.Transparent;
		this.Freezeexe.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.Freezeexe.Image = global::Class89.Bitmap_30;
		this.Freezeexe.Location = new global::System.Drawing.Point(10, 3);
		this.Freezeexe.Name = "Freezeexe";
		this.Freezeexe.Size = new global::System.Drawing.Size(128, 142);
		this.Freezeexe.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.Freezeexe.TabIndex = 69;
		this.Freezeexe.TabStop = false;
		this.Freezeexe.Click += new global::System.EventHandler(this.Freezeexe_Click);
		this.Description.AutoSize = true;
		this.Description.BackColor = global::System.Drawing.Color.Transparent;
		this.Description.ForeColor = global::System.Drawing.Color.AliceBlue;
		this.Description.Location = new global::System.Drawing.Point(10, 161);
		this.Description.Name = "Description";
		this.Description.Size = new global::System.Drawing.Size(0, 13);
		this.Description.TabIndex = 75;
		this.Header.AutoSize = true;
		this.Header.BackColor = global::System.Drawing.Color.Transparent;
		this.Header.Font = new global::System.Drawing.Font("Calibri", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.Header.ForeColor = global::System.Drawing.Color.FromArgb(131, 184, 228);
		this.Header.Location = new global::System.Drawing.Point(12, 9);
		this.Header.Name = "Header";
		this.Header.Size = new global::System.Drawing.Size(34, 15);
		this.Header.TabIndex = 30;
		this.Header.Text = "PWN";
		base.AcceptButton = this.SuperButton1;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
		base.ClientSize = new global::System.Drawing.Size(450, 320);
		base.Controls.Add(this.Header);
		base.Controls.Add(this.MainPanel);
		base.Controls.Add(this.CloseIcon);
		this.DoubleBuffered = true;
		this.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		this.MaximumSize = new global::System.Drawing.Size(450, 320);
		base.Name = "Superform";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.Manual;
		this.Text = "PWN";
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.Superform_Load);
		this.MainPanel.ResumeLayout(false);
		this.MainPanel.PerformLayout();
		((global::System.ComponentModel.ISupportInitialize)this.Superexe).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Blockexe).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.Freezeexe).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040003ED RID: 1005
	private global::System.Windows.Forms.Button CloseIcon;

	// Token: 0x040003EE RID: 1006
	private global::System.Windows.Forms.Panel MainPanel;

	// Token: 0x040003EF RID: 1007
	private global::System.Windows.Forms.Button SuperButton2;

	// Token: 0x040003F0 RID: 1008
	private global::System.Windows.Forms.Button SuperButton1;

	// Token: 0x040003F1 RID: 1009
	private global::System.Windows.Forms.PictureBox Superexe;

	// Token: 0x040003F2 RID: 1010
	private global::System.Windows.Forms.PictureBox Blockexe;

	// Token: 0x040003F3 RID: 1011
	private global::System.Windows.Forms.PictureBox Freezeexe;

	// Token: 0x040003F4 RID: 1012
	private global::System.Windows.Forms.Label Description;

	// Token: 0x040003F5 RID: 1013
	private global::System.Windows.Forms.Label Header;

	// Token: 0x040003F6 RID: 1014
	private global::System.Windows.Forms.ComboBox CommandLine;

	// Token: 0x040003F7 RID: 1015
	private global::System.Windows.Forms.Button CleanHistoryButton;

	// Token: 0x040003F8 RID: 1016
	private global::System.Windows.Forms.Button BlockerMenu;
}
