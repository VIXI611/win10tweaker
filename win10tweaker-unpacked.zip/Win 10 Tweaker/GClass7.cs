﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Microsoft.Win32;

// Token: 0x0200005F RID: 95
public static class GClass7
{
	// Token: 0x060004C2 RID: 1218 RVA: 0x00019630 File Offset: 0x00017830
	public static List<string> smethod_0(this RegistryKey registryKey_0, List<string> list_0 = null)
	{
		GClass7.Class28 @class = new GClass7.Class28();
		@class.registryKey_0 = registryKey_0;
		@class.list_0 = list_0;
		if (@class.list_0 == null)
		{
			@class.list_0 = new List<string>();
		}
		@class.list_0.Add(string.Format("{0}[{1}]", Environment.NewLine, @class.registryKey_0));
		if (@class.registryKey_0 != null)
		{
			@class.list_0.AddRange(@class.registryKey_0.GetValueNames().Select(new Func<string, string>(@class.method_0)));
			@class.registryKey_0.GetSubKeyNames().ToList<string>().ForEach(new Action<string>(@class.method_1));
			return @class.list_0;
		}
		@class.list_0.Clear();
		return @class.list_0;
	}

	// Token: 0x060004C3 RID: 1219 RVA: 0x000196EC File Offset: 0x000178EC
	[CompilerGenerated]
	internal static string smethod_1(RegistryKey registryKey_0, string string_0)
	{
		GClass7.Class29 @class = new GClass7.Class29();
		switch (registryKey_0.GetValueKind(string_0))
		{
		case RegistryValueKind.None:
			return "hex(0):" + BitConverter.ToString((byte[])registryKey_0.GetValue(string_0)).ToLower().Replace("-", ",");
		case RegistryValueKind.String:
			return "\"" + registryKey_0.GetValue(string_0).ToString().Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
		case RegistryValueKind.ExpandString:
			return "hex(2):" + string.Join(",", Encoding.Unicode.GetBytes(registryKey_0.GetValue(string_0).ToString()).Append(0).Select(new Func<byte, string>(GClass7.<>c.<>9.method_0)));
		case RegistryValueKind.Binary:
			return "hex:" + BitConverter.ToString((byte[])registryKey_0.GetValue(string_0)).ToLower().Replace("-", ",");
		case RegistryValueKind.DWord:
			return "dword:" + Convert.ToUInt32(registryKey_0.GetValue(string_0)).ToString("x8");
		case RegistryValueKind.MultiString:
		{
			string s = string.Join(Environment.NewLine, (string[])registryKey_0.GetValue(string_0));
			return "hex(7):" + string.Join(",", Encoding.Unicode.GetBytes(s).Append(0).Select(new Func<byte, string>(GClass7.<>c.<>9.method_1))).Replace("0d,", "").Replace("0a,", "");
		}
		case RegistryValueKind.QWord:
			@class.string_0 = Convert.ToInt64(registryKey_0.GetValue(string_0)).ToString("x16");
			return ("hex(b):" + string.Join("", Enumerable.Range(0, @class.string_0.Length / 2).Select(new Func<int, string>(@class.method_0)).Reverse<string>())).TrimEnd(new char[]
			{
				','
			});
		}
		return "";
	}

	// Token: 0x060004C4 RID: 1220 RVA: 0x00003E79 File Offset: 0x00002079
	static string smethod_2()
	{
		return Environment.NewLine;
	}

	// Token: 0x060004C5 RID: 1221 RVA: 0x00002FFC File Offset: 0x000011FC
	static string smethod_3(string string_0, object object_0, object object_1)
	{
		return string.Format(string_0, object_0, object_1);
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x00003019 File Offset: 0x00001219
	static string[] smethod_4(RegistryKey registryKey_0)
	{
		return registryKey_0.GetValueNames();
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x000030B3 File Offset: 0x000012B3
	static string[] smethod_5(RegistryKey registryKey_0)
	{
		return registryKey_0.GetSubKeyNames();
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x00003E80 File Offset: 0x00002080
	static RegistryValueKind smethod_6(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValueKind(string_0);
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_7(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_8(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x000033D1 File Offset: 0x000015D1
	static string smethod_9(string string_0, string string_1, string string_2)
	{
		return string_0.Replace(string_1, string_2);
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_10(string string_0, string string_1, string string_2)
	{
		return string_0 + string_1 + string_2;
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x00003E89 File Offset: 0x00002089
	static uint smethod_11(object object_0)
	{
		return Convert.ToUInt32(object_0);
	}

	// Token: 0x02000060 RID: 96
	[CompilerGenerated]
	private sealed class Class28
	{
		// Token: 0x060004CF RID: 1231 RVA: 0x00003E91 File Offset: 0x00002091
		internal string method_0(string string_0)
		{
			if (!string.IsNullOrWhiteSpace(string_0))
			{
				return "\"" + string_0 + "\"=" + GClass7.smethod_1(this.registryKey_0, string_0);
			}
			return "@=" + GClass7.smethod_1(this.registryKey_0, string_0);
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x00003ECE File Offset: 0x000020CE
		internal void method_1(string string_0)
		{
			this.registryKey_0.OpenSubKey(string_0).smethod_0(this.list_0);
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x00003EE8 File Offset: 0x000020E8
		static bool smethod_0(string string_0)
		{
			return string.IsNullOrWhiteSpace(string_0);
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x000033BD File Offset: 0x000015BD
		static string smethod_1(string string_0, string string_1, string string_2, string string_3)
		{
			return string_0 + string_1 + string_2 + string_3;
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x000025E0 File Offset: 0x000007E0
		static string smethod_2(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x0000307B File Offset: 0x0000127B
		static RegistryKey smethod_3(RegistryKey registryKey_1, string string_0)
		{
			return registryKey_1.OpenSubKey(string_0);
		}

		// Token: 0x0400021C RID: 540
		public RegistryKey registryKey_0;

		// Token: 0x0400021D RID: 541
		public List<string> list_0;
	}

	// Token: 0x02000061 RID: 97
	[CompilerGenerated]
	private sealed class Class29
	{
		// Token: 0x060004D6 RID: 1238 RVA: 0x00003EF0 File Offset: 0x000020F0
		internal string method_0(int int_0)
		{
			return this.string_0.Substring(int_0 * 2, 2) + ",";
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x00003B01 File Offset: 0x00001D01
		static string smethod_0(string string_1, int int_0, int int_1)
		{
			return string_1.Substring(int_0, int_1);
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x000025E0 File Offset: 0x000007E0
		static string smethod_1(string string_1, string string_2)
		{
			return string_1 + string_2;
		}

		// Token: 0x0400021E RID: 542
		public string string_0;
	}
}
