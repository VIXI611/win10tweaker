﻿// Token: 0x020000E8 RID: 232
public partial class Videoform : global::System.Windows.Forms.Form
{
	// Token: 0x06000B98 RID: 2968 RVA: 0x00039420 File Offset: 0x00037620
	private void InitializeComponent()
	{
		this.webBrowser1 = new global::System.Windows.Forms.WebBrowser();
		base.SuspendLayout();
		this.webBrowser1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.webBrowser1.Location = new global::System.Drawing.Point(0, 0);
		this.webBrowser1.MinimumSize = new global::System.Drawing.Size(20, 20);
		this.webBrowser1.Name = "webBrowser1";
		this.webBrowser1.ScrollBarsEnabled = false;
		this.webBrowser1.Size = new global::System.Drawing.Size(284, 265);
		this.webBrowser1.TabIndex = 1;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(284, 265);
		base.Controls.Add(this.webBrowser1);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Videoform";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		base.TopMost = true;
		base.ResumeLayout(false);
	}

	// Token: 0x040004A0 RID: 1184
	public global::System.Windows.Forms.WebBrowser webBrowser1;
}
