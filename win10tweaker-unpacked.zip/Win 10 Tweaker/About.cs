﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Deps;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x0200000C RID: 12
public partial class About : GForm0
{
	// Token: 0x06000057 RID: 87 RVA: 0x0000B7D4 File Offset: 0x000099D4
	private void method_1()
	{
		About.Struct5 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<About.Struct5>(ref @struct);
	}

	// Token: 0x06000058 RID: 88 RVA: 0x0000B80C File Offset: 0x00009A0C
	protected virtual void OnShown(EventArgs e)
	{
		base.OnShown(e);
		if (this.bool_1)
		{
			this.ActivateLink_LinkClicked(this.ActivateLink, null);
			if (this.bool_2)
			{
				this.AboutGetPro_Click(this.AboutGetPro, null);
			}
			if (this.string_0 != "")
			{
				this.TextBoxMain.Text = this.string_0;
			}
			this.Price.Invalidate();
		}
	}

	// Token: 0x06000059 RID: 89 RVA: 0x0000B878 File Offset: 0x00009A78
	public About(Form1 form1_1)
	{
		this.InitializeComponent();
		this.form1_0 = form1_1;
		this.CloseIcon.Click += this.method_10;
		this.GoToWebSite.Click += this.method_11;
		this.ChangeLog.Click += this.method_12;
		new List<Control>
		{
			this.HeaderPanel,
			this.Header
		}.ForEach(new Action<Control>(this.method_13));
		this.AboutDonate1.Click += this.method_15;
		this.AboutDonate2.Click += this.method_16;
		this.AboutDonate3.Click += this.method_17;
		using (IEnumerator<PictureBox> enumerator = this.MainPanel1.Controls.OfType<PictureBox>().GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				About.Class6 @class = new About.Class6();
				@class.pictureBox_0 = enumerator.Current;
				@class.pictureBox_0.MouseEnter += @class.method_0;
				@class.pictureBox_0.MouseLeave += @class.method_1;
			}
		}
		base.Controls.OfType<Panel>().ToList<Panel>().ForEach(new Action<Panel>(About.<>c.<>9.method_0));
		About.smethod_3(this.Price);
	}

	// Token: 0x0600005A RID: 90 RVA: 0x0000BA34 File Offset: 0x00009C34
	private void method_2()
	{
		GClass6.GClass6_0.method_14(string.Concat(new string[]
		{
			"Taskkill /f /im \"",
			GClass2.GClass2_0.String_10,
			"\" && Timeout /t 1 && del \"",
			GClass2.GClass2_0.String_10,
			"\" && ren new.exe \"",
			GClass2.GClass2_0.String_10,
			"\" && \"",
			GClass2.GClass2_0.String_10,
			"\""
		}));
	}

	// Token: 0x0600005B RID: 91 RVA: 0x0000BAB4 File Offset: 0x00009CB4
	public void ActivateLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		About.Struct6 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<About.Struct6>(ref @struct);
	}

	// Token: 0x0600005C RID: 92 RVA: 0x0000BAEC File Offset: 0x00009CEC
	public void CheckForUpdates_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		using (WebClient webClient = new WebClient())
		{
			if (Class26.smethod_0())
			{
				string value = webClient.DownloadString("https://win10tweaker.com/InfoChecker.php?key=Version");
				AboutWindow.Update();
				if (Convert.ToDouble(this.string_1, CultureInfo.InvariantCulture) == Convert.ToDouble(value, CultureInfo.InvariantCulture))
				{
					if (this.form1_0.Tag != null)
					{
						if (WMessageBox.smethod_3(this.method_4("NewVersionAvailable"), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
						{
							webClient.DownloadFile(webClient.DownloadString(GClass2.GClass2_0.String_7), "new.exe");
							this.method_2();
						}
					}
					else if (Application.OpenForms.OfType<About>().Any<About>())
					{
						WMessageBox.smethod_3(this.method_4("YouHaveLatestVersion"), GClass2.GClass2_0.String_6, WMessageBox.GEnum2.OK, false, "", null);
					}
				}
				else if (Convert.ToDouble(this.string_1, CultureInfo.InvariantCulture) >= Convert.ToDouble(value, CultureInfo.InvariantCulture))
				{
					if (Convert.ToDouble(this.string_1, CultureInfo.InvariantCulture) > Convert.ToDouble(value, CultureInfo.InvariantCulture) && Application.OpenForms.OfType<About>().Any<About>())
					{
						WMessageBox.smethod_3(this.method_4("YouHaveLatestVersion"), GClass2.GClass2_0.String_6, WMessageBox.GEnum2.OK, false, "", null);
					}
				}
				else if (WMessageBox.smethod_3(this.method_4("NewVersionAvailable"), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
				{
					webClient.DownloadFile(webClient.DownloadString(GClass2.GClass2_0.String_7), "new.exe");
					this.method_2();
				}
			}
			else
			{
				GClass6.GClass6_0.method_9();
			}
		}
	}

	// Token: 0x0600005D RID: 93 RVA: 0x0000BCB8 File Offset: 0x00009EB8
	private void AboutGetBeta_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		if (Class26.smethod_0())
		{
			using (WebClient webClient = new WebClient())
			{
				webClient.DownloadFile(webClient.DownloadString(GClass2.GClass2_0.String_8), "new.exe");
			}
			this.method_2();
			return;
		}
		GClass6.GClass6_0.method_9();
	}

	// Token: 0x0600005E RID: 94 RVA: 0x0000BD1C File Offset: 0x00009F1C
	public void AboutGetPro_Click(object sender, EventArgs e)
	{
		this.MainPanel3.Visible = true;
		Control textBoxMain = this.TextBoxMain;
		object value = GClass2.GClass2_0.RegistryKey_0.GetValue("email");
		textBoxMain.Text = ((value != null) ? value.ToString() : null);
		this.TextBoxMain.Focus();
	}

	// Token: 0x0600005F RID: 95 RVA: 0x0000BD6C File Offset: 0x00009F6C
	private void About_Load(object sender, EventArgs e)
	{
		About.Struct7 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<About.Struct7>(ref @struct);
	}

	// Token: 0x06000060 RID: 96 RVA: 0x0000BDA4 File Offset: 0x00009FA4
	private void AboutActivatePro_Click(object sender, EventArgs e)
	{
		this.MainPanel3.Visible = true;
		Control textBoxMain = this.TextBoxMain;
		object value = GClass2.GClass2_0.RegistryKey_0.GetValue("email");
		textBoxMain.Text = ((value != null) ? value.ToString() : null);
		this.TextBoxMain.Focus();
		this.Price.Visible = false;
		this.Header.Text = this.method_4("ActivateLink");
		this.ButtonEmail.Text = this.method_4("WMessageOK");
		this.PNotice.Text = this.method_4("EmailForActivation");
		this.PNotice.TextAlign = ContentAlignment.MiddleCenter;
		this.PNotice.MaximumSize = new Size(this.MainPanel3.Width - this.PNotice.Location.X * 2, 0);
		this.PNotice.Location = new Point((this.MainPanel3.Width - this.PNotice.Width) / 2, this.PNotice.Location.Y);
		this.bool_3 = true;
	}

	// Token: 0x06000061 RID: 97 RVA: 0x0000BEC4 File Offset: 0x0000A0C4
	private void Price_MouseEnter(object sender, EventArgs e)
	{
		About.Struct8 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<About.Struct8>(ref @struct);
	}

	// Token: 0x06000062 RID: 98 RVA: 0x0000BEFC File Offset: 0x0000A0FC
	private void Price_MouseLeave(object sender, EventArgs e)
	{
		About.Struct9 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<About.Struct9>(ref @struct);
	}

	// Token: 0x06000063 RID: 99 RVA: 0x0000BF34 File Offset: 0x0000A134
	public void method_3(Color color_0, Color color_1, Color color_2)
	{
		About.Class8 @class = new About.Class8();
		@class.about_0 = this;
		@class.color_0 = color_0;
		@class.color_1 = color_1;
		@class.color_2 = color_2;
		this.HeaderPanel.Paint += @class.method_0;
		this.HeaderPanel.Invalidate();
	}

	// Token: 0x06000064 RID: 100 RVA: 0x000028C8 File Offset: 0x00000AC8
	private string method_4(string string_2)
	{
		return GClass2.GClass2_0.method_1(string_2);
	}

	// Token: 0x06000065 RID: 101 RVA: 0x0000BF88 File Offset: 0x0000A188
	private void method_5()
	{
		About.Struct10 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<About.Struct10>(ref @struct);
	}

	// Token: 0x06000066 RID: 102 RVA: 0x0000BFC0 File Offset: 0x0000A1C0
	private void ButtonEmail_Click(object sender, EventArgs e)
	{
		About.Struct12 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<About.Struct12>(ref @struct);
	}

	// Token: 0x06000067 RID: 103 RVA: 0x0000BFF8 File Offset: 0x0000A1F8
	private bool method_6()
	{
		return !this.TextBoxMain.Text.Contains(",") && this.TextBoxMain.Text.Contains("@") && !this.TextBoxMain.Text.Contains("asd.") && !this.TextBoxMain.Text.Contains("asd@") && this.TextBoxMain.Text.Contains(".") && !this.TextBoxMain.Text.Contains(" ") && !this.TextBoxMain.Text.Contains("#") && !this.TextBoxMain.Text.EndsWith(".") && this.TextBoxMain.Text.Remove(this.TextBoxMain.Text.IndexOf("@") + 1).Length > 2;
	}

	// Token: 0x06000068 RID: 104 RVA: 0x0000C0FC File Offset: 0x0000A2FC
	private void method_7()
	{
		About.Struct13 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<About.Struct13>(ref @struct);
	}

	// Token: 0x06000069 RID: 105 RVA: 0x0000C134 File Offset: 0x0000A334
	private Task<bool> method_8(string string_2)
	{
		About.Struct14 @struct;
		@struct.asyncTaskMethodBuilder_0 = AsyncTaskMethodBuilder<bool>.Create();
		@struct.string_0 = string_2;
		@struct.int_0 = -1;
		@struct.asyncTaskMethodBuilder_0.Start<About.Struct14>(ref @struct);
		return @struct.asyncTaskMethodBuilder_0.Task;
	}

	// Token: 0x0600006A RID: 106 RVA: 0x0000C178 File Offset: 0x0000A378
	private void method_9(string string_2)
	{
		About.Struct15 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.string_0 = string_2;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<About.Struct15>(ref @struct);
	}

	// Token: 0x0600006B RID: 107 RVA: 0x000028D5 File Offset: 0x00000AD5
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600006D RID: 109 RVA: 0x000028F4 File Offset: 0x00000AF4
	[CompilerGenerated]
	private void method_10(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x0600006E RID: 110 RVA: 0x0000D3D0 File Offset: 0x0000B5D0
	[CompilerGenerated]
	private void method_11(object sender, EventArgs e)
	{
		try
		{
			Process.Start("https://win10tweaker.pro");
		}
		catch
		{
			WMessageBox.smethod_3(GClass2.GClass2_0.method_1("SysNoBrowser"), "", WMessageBox.GEnum2.OK, false, "", null);
		}
		this.method_1();
	}

	// Token: 0x0600006F RID: 111 RVA: 0x0000D428 File Offset: 0x0000B628
	[CompilerGenerated]
	private void method_12(object sender, EventArgs e)
	{
		try
		{
			Process.Start("https://win10tweaker.pro/changelog");
		}
		catch
		{
			WMessageBox.smethod_3(GClass2.GClass2_0.method_1("SysNoBrowser"), "", WMessageBox.GEnum2.OK, false, "", null);
		}
		this.method_1();
	}

	// Token: 0x06000070 RID: 112 RVA: 0x0000D480 File Offset: 0x0000B680
	[CompilerGenerated]
	private void method_13(Control control_0)
	{
		About.Class5 @class = new About.Class5();
		@class.about_0 = this;
		@class.control_0 = control_0;
		@class.control_0.MouseDown += @class.method_0;
	}

	// Token: 0x06000071 RID: 113 RVA: 0x000028FC File Offset: 0x00000AFC
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_14(ref Message message_0)
	{
		base.System.Windows.Forms.Form.WndProc(ref message_0);
	}

	// Token: 0x06000072 RID: 114 RVA: 0x0000D4B8 File Offset: 0x0000B6B8
	[CompilerGenerated]
	private void method_15(object sender, EventArgs e)
	{
		try
		{
			Process.Start("https://win10tweaker.pro/PayPal");
		}
		catch
		{
			WMessageBox.smethod_3(GClass2.GClass2_0.method_1("SysNoBrowser"), "", WMessageBox.GEnum2.OK, false, "", null);
		}
		this.method_1();
	}

	// Token: 0x06000073 RID: 115 RVA: 0x0000D510 File Offset: 0x0000B710
	[CompilerGenerated]
	private void method_16(object sender, EventArgs e)
	{
		try
		{
			Process.Start("https://win10tweaker.pro/Yandex");
		}
		catch
		{
			WMessageBox.smethod_3(GClass2.GClass2_0.method_1("SysNoBrowser"), "", WMessageBox.GEnum2.OK, false, "", null);
		}
		this.method_1();
	}

	// Token: 0x06000074 RID: 116 RVA: 0x00002905 File Offset: 0x00000B05
	[CompilerGenerated]
	private void method_17(object sender, EventArgs e)
	{
		new Bitcoin().Show();
		this.method_1();
	}

	// Token: 0x06000075 RID: 117 RVA: 0x0000D568 File Offset: 0x0000B768
	[CompilerGenerated]
	internal static void smethod_3(Panel panel_0)
	{
		typeof(Panel).method_19("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.SetProperty, null, panel_0, new object[]
		{
			true
		});
	}

	// Token: 0x06000076 RID: 118 RVA: 0x0000D5A0 File Offset: 0x0000B7A0
	[CompilerGenerated]
	private Task method_18()
	{
		About.Struct17 @struct;
		@struct.asyncTaskMethodBuilder_0 = AsyncTaskMethodBuilder.Create();
		@struct.about_0 = this;
		@struct.int_0 = -1;
		@struct.asyncTaskMethodBuilder_0.Start<About.Struct17>(ref @struct);
		return @struct.asyncTaskMethodBuilder_0.Task;
	}

	// Token: 0x06000077 RID: 119 RVA: 0x0000D5E4 File Offset: 0x0000B7E4
	[CompilerGenerated]
	internal static Task<string> smethod_4()
	{
		About.Struct16 @struct;
		@struct.asyncTaskMethodBuilder_0 = AsyncTaskMethodBuilder<string>.Create();
		@struct.int_0 = -1;
		@struct.asyncTaskMethodBuilder_0.Start<About.Struct16>(ref @struct);
		return @struct.asyncTaskMethodBuilder_0.Task;
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00002917 File Offset: 0x00000B17
	static bool smethod_5(string string_2, string string_3)
	{
		return string_2 != string_3;
	}

	// Token: 0x06000079 RID: 121 RVA: 0x00002920 File Offset: 0x00000B20
	static void smethod_6(Control control_0, string string_2)
	{
		control_0.Text = string_2;
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00002929 File Offset: 0x00000B29
	static void smethod_7(Control control_0)
	{
		control_0.Invalidate();
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00002931 File Offset: 0x00000B31
	static Assembly smethod_8()
	{
		return Assembly.GetExecutingAssembly();
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00002938 File Offset: 0x00000B38
	static AssemblyName smethod_9(Assembly assembly_0)
	{
		return assembly_0.GetName();
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00002940 File Offset: 0x00000B40
	static Version smethod_10(AssemblyName assemblyName_0)
	{
		return assemblyName_0.Version;
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00002948 File Offset: 0x00000B48
	static string smethod_11(Version version_0, int int_0)
	{
		return version_0.ToString(int_0);
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00002951 File Offset: 0x00000B51
	static void smethod_12(Control control_0, EventHandler eventHandler_0)
	{
		control_0.Click += eventHandler_0;
	}

	// Token: 0x06000080 RID: 128 RVA: 0x0000295A File Offset: 0x00000B5A
	static Control.ControlCollection smethod_13(Control control_0)
	{
		return control_0.Controls;
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00002962 File Offset: 0x00000B62
	static void smethod_14(Control control_0, EventHandler eventHandler_0)
	{
		control_0.MouseEnter += eventHandler_0;
	}

	// Token: 0x06000082 RID: 130 RVA: 0x0000296B File Offset: 0x00000B6B
	static void smethod_15(Control control_0, EventHandler eventHandler_0)
	{
		control_0.MouseLeave += eventHandler_0;
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00002974 File Offset: 0x00000B74
	static bool smethod_16(IEnumerator ienumerator_0)
	{
		return ienumerator_0.MoveNext();
	}

	// Token: 0x06000084 RID: 132 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_17(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000085 RID: 133 RVA: 0x00002984 File Offset: 0x00000B84
	static Control.ControlCollection smethod_18(Control control_0)
	{
		return control_0.Controls;
	}

	// Token: 0x06000086 RID: 134 RVA: 0x0000298C File Offset: 0x00000B8C
	static string smethod_19(string[] string_2)
	{
		return string.Concat(string_2);
	}

	// Token: 0x06000087 RID: 135 RVA: 0x00002994 File Offset: 0x00000B94
	static WebClient smethod_20()
	{
		return new WebClient();
	}

	// Token: 0x06000088 RID: 136 RVA: 0x0000299B File Offset: 0x00000B9B
	static string smethod_21(WebClient webClient_0, string string_2)
	{
		return webClient_0.DownloadString(string_2);
	}

	// Token: 0x06000089 RID: 137 RVA: 0x000029A4 File Offset: 0x00000BA4
	static void smethod_22()
	{
		AboutWindow.Update();
	}

	// Token: 0x0600008A RID: 138 RVA: 0x000029AB File Offset: 0x00000BAB
	static CultureInfo smethod_23()
	{
		return CultureInfo.InvariantCulture;
	}

	// Token: 0x0600008B RID: 139 RVA: 0x000029B2 File Offset: 0x00000BB2
	static double smethod_24(string string_2, IFormatProvider iformatProvider_0)
	{
		return Convert.ToDouble(string_2, iformatProvider_0);
	}

	// Token: 0x0600008C RID: 140 RVA: 0x000029BB File Offset: 0x00000BBB
	static object smethod_25(Control control_0)
	{
		return control_0.Tag;
	}

	// Token: 0x0600008D RID: 141 RVA: 0x000029C3 File Offset: 0x00000BC3
	static void smethod_26(WebClient webClient_0, string string_2, string string_3)
	{
		webClient_0.DownloadFile(string_2, string_3);
	}

	// Token: 0x0600008E RID: 142 RVA: 0x000029CD File Offset: 0x00000BCD
	static FormCollection smethod_27()
	{
		return Application.OpenForms;
	}

	// Token: 0x0600008F RID: 143 RVA: 0x000029D4 File Offset: 0x00000BD4
	static void smethod_28(Control control_0, bool bool_4)
	{
		control_0.Visible = bool_4;
	}

	// Token: 0x06000090 RID: 144 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_29(RegistryKey registryKey_0, string string_2)
	{
		return registryKey_0.GetValue(string_2);
	}

	// Token: 0x06000091 RID: 145 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_30(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x06000092 RID: 146 RVA: 0x000029EE File Offset: 0x00000BEE
	static bool smethod_31(Control control_0)
	{
		return control_0.Focus();
	}

	// Token: 0x06000093 RID: 147 RVA: 0x000029F6 File Offset: 0x00000BF6
	static void smethod_32(Label label_0, ContentAlignment contentAlignment_0)
	{
		label_0.TextAlign = contentAlignment_0;
	}

	// Token: 0x06000094 RID: 148 RVA: 0x000029FF File Offset: 0x00000BFF
	static int smethod_33(Control control_0)
	{
		return control_0.Width;
	}

	// Token: 0x06000095 RID: 149 RVA: 0x00002A07 File Offset: 0x00000C07
	static Point smethod_34(Control control_0)
	{
		return control_0.Location;
	}

	// Token: 0x06000096 RID: 150 RVA: 0x00002A0F File Offset: 0x00000C0F
	static void smethod_35(Control control_0, PaintEventHandler paintEventHandler_0)
	{
		control_0.Paint += paintEventHandler_0;
	}

	// Token: 0x06000097 RID: 151 RVA: 0x00002A18 File Offset: 0x00000C18
	static string smethod_36(Control control_0)
	{
		return control_0.Text;
	}

	// Token: 0x06000098 RID: 152 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_37(string string_2, string string_3)
	{
		return string_2.Contains(string_3);
	}

	// Token: 0x06000099 RID: 153 RVA: 0x00002A29 File Offset: 0x00000C29
	static bool smethod_38(string string_2, string string_3)
	{
		return string_2.EndsWith(string_3);
	}

	// Token: 0x0600009A RID: 154 RVA: 0x00002A32 File Offset: 0x00000C32
	static int smethod_39(string string_2, string string_3)
	{
		return string_2.IndexOf(string_3);
	}

	// Token: 0x0600009B RID: 155 RVA: 0x00002A3B File Offset: 0x00000C3B
	static string smethod_40(string string_2, int int_0)
	{
		return string_2.Remove(int_0);
	}

	// Token: 0x0600009C RID: 156 RVA: 0x00002A44 File Offset: 0x00000C44
	static int smethod_41(string string_2)
	{
		return string_2.Length;
	}

	// Token: 0x0600009D RID: 157 RVA: 0x00002A4C File Offset: 0x00000C4C
	static Container smethod_42()
	{
		return new Container();
	}

	// Token: 0x0600009E RID: 158 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_43()
	{
		return new Label();
	}

	// Token: 0x0600009F RID: 159 RVA: 0x00002A5A File Offset: 0x00000C5A
	static PictureBox smethod_44()
	{
		return new PictureBox();
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x00002A61 File Offset: 0x00000C61
	static ToolTip smethod_45(IContainer icontainer_1)
	{
		return new ToolTip(icontainer_1);
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x00002A69 File Offset: 0x00000C69
	static Button smethod_46()
	{
		return new Button();
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x00002A70 File Offset: 0x00000C70
	static LinkLabel smethod_47()
	{
		return new LinkLabel();
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x00002A77 File Offset: 0x00000C77
	static Panel smethod_48()
	{
		return new Panel();
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x00002A7E File Offset: 0x00000C7E
	static TextBox smethod_49()
	{
		return new TextBox();
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x00002A85 File Offset: 0x00000C85
	static void smethod_50(ISupportInitialize isupportInitialize_0)
	{
		isupportInitialize_0.BeginInit();
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x00002A8D File Offset: 0x00000C8D
	static void smethod_51(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_52(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x00002A9D File Offset: 0x00000C9D
	static void smethod_53(Control control_0, bool bool_4)
	{
		control_0.AutoSize = bool_4;
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x00002AA6 File Offset: 0x00000CA6
	static Process smethod_54(string string_2)
	{
		return Process.Start(string_2);
	}

	// Token: 0x060000AA RID: 170 RVA: 0x00002AAE File Offset: 0x00000CAE
	static void smethod_55(Control control_0, MouseEventHandler mouseEventHandler_0)
	{
		control_0.MouseDown += mouseEventHandler_0;
	}

	// Token: 0x060000AB RID: 171 RVA: 0x00002AB7 File Offset: 0x00000CB7
	static void smethod_56(Control control_0)
	{
		control_0.Show();
	}

	// Token: 0x060000AC RID: 172 RVA: 0x000025CE File Offset: 0x000007CE
	static Type smethod_57(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x060000AD RID: 173 RVA: 0x00002ABF File Offset: 0x00000CBF
	object method_19(string string_2, BindingFlags bindingFlags_0, Binder binder_0, object object_0, object[] object_1)
	{
		return base.InvokeMember(string_2, bindingFlags_0, binder_0, object_0, object_1);
	}

	// Token: 0x0400002C RID: 44
	public bool bool_1;

	// Token: 0x0400002D RID: 45
	public bool bool_2;

	// Token: 0x0400002E RID: 46
	public string string_0 = "";

	// Token: 0x0400002F RID: 47
	private bool bool_3;

	// Token: 0x04000030 RID: 48
	private readonly Form1 form1_0;

	// Token: 0x04000031 RID: 49
	private readonly string string_1 = Assembly.GetExecutingAssembly().GetName().Version.ToString(2);

	// Token: 0x0200000E RID: 14
	[CompilerGenerated]
	private sealed class Class5
	{
		// Token: 0x060000B4 RID: 180 RVA: 0x0000D714 File Offset: 0x0000B914
		internal void method_0(object sender, MouseEventArgs e)
		{
			this.control_0.Capture = false;
			this.about_0.Capture = false;
			Message message = Message.Create(this.about_0.method_1(), 161, new IntPtr(2), IntPtr.Zero);
			this.about_0.method_14(ref message);
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x00002AF5 File Offset: 0x00000CF5
		static void smethod_0(Control control_1, bool bool_0)
		{
			control_1.Capture = bool_0;
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x00002AFE File Offset: 0x00000CFE
		static void smethod_1(Control control_1, bool bool_0)
		{
			control_1.Capture = bool_0;
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x00002B07 File Offset: 0x00000D07
		IntPtr method_1()
		{
			return base.Handle;
		}

		// Token: 0x04000052 RID: 82
		public Control control_0;

		// Token: 0x04000053 RID: 83
		public About about_0;
	}

	// Token: 0x0200000F RID: 15
	[CompilerGenerated]
	private sealed class Class6
	{
		// Token: 0x060000B9 RID: 185 RVA: 0x00002B0F File Offset: 0x00000D0F
		internal void method_0(object sender, EventArgs e)
		{
			this.pictureBox_0.BackgroundImage = Class89.Bitmap_21;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00002B21 File Offset: 0x00000D21
		internal void method_1(object sender, EventArgs e)
		{
			this.pictureBox_0.BackgroundImage = null;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00002B2F File Offset: 0x00000D2F
		static void smethod_0(Control control_0, Image image_0)
		{
			control_0.BackgroundImage = image_0;
		}

		// Token: 0x04000054 RID: 84
		public PictureBox pictureBox_0;
	}

	// Token: 0x02000012 RID: 18
	[CompilerGenerated]
	private sealed class Class7
	{
		// Token: 0x060000CA RID: 202 RVA: 0x0000D918 File Offset: 0x0000BB18
		internal void method_0(object sender, PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			Point[] points = new Point[]
			{
				new Point(this.about_0.Price.Width, 0),
				new Point(0, 0),
				new Point(0, this.about_0.Price.Height),
				new Point(this.about_0.Price.Width / 2, this.about_0.Price.Height - this.about_0.Price.Height / 6),
				new Point(this.about_0.Price.Width, this.about_0.Price.Height)
			};
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.FillPolygon(new SolidBrush(Color.FromArgb(0, 144, 209)), points);
			Font font = new Font(new FontFamily((!GClass2.GClass2_0.String_3.Contains("7")) ? "Segoe UI Semilight" : "Segoe UI"), 14f, FontStyle.Regular, GraphicsUnit.Point);
			SolidBrush brush = new SolidBrush(Color.White);
			e.Graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
			e.Graphics.DrawString(this.string_0, font, brush, new PointF(0f, 14f));
		}

		// Token: 0x060000CB RID: 203 RVA: 0x00002B88 File Offset: 0x00000D88
		static Graphics smethod_0(PaintEventArgs paintEventArgs_0)
		{
			return paintEventArgs_0.Graphics;
		}

		// Token: 0x060000CC RID: 204 RVA: 0x000029FF File Offset: 0x00000BFF
		static int smethod_1(Control control_0)
		{
			return control_0.Width;
		}

		// Token: 0x0400005C RID: 92
		public string string_0;

		// Token: 0x0400005D RID: 93
		public About about_0;
	}

	// Token: 0x02000016 RID: 22
	[CompilerGenerated]
	private sealed class Class8
	{
		// Token: 0x060000DF RID: 223 RVA: 0x0000DFC4 File Offset: 0x0000C1C4
		internal void method_0(object sender, PaintEventArgs e)
		{
			LinearGradientBrush linearGradientBrush = new LinearGradientBrush(this.about_0.HeaderPanel.ClientRectangle, Color.Empty, Color.Empty, 90f);
			ColorBlend interpolationColors = new ColorBlend(5)
			{
				Colors = new Color[]
				{
					this.color_0,
					this.color_0,
					this.color_1,
					this.color_2,
					this.color_2
				},
				Positions = new float[]
				{
					0f,
					0.82f,
					0.82f,
					1f,
					1f
				}
			};
			linearGradientBrush.InterpolationColors = interpolationColors;
			e.Graphics.FillRectangle(linearGradientBrush, this.about_0.HeaderPanel.ClientRectangle);
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x00002BCC File Offset: 0x00000DCC
		static Rectangle smethod_0(Control control_0)
		{
			return control_0.ClientRectangle;
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x00002BD4 File Offset: 0x00000DD4
		static LinearGradientBrush smethod_1(Rectangle rectangle_0, Color color_3, Color color_4, float float_0)
		{
			return new LinearGradientBrush(rectangle_0, color_3, color_4, float_0);
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x00002BDF File Offset: 0x00000DDF
		static ColorBlend smethod_2(int int_0)
		{
			return new ColorBlend(int_0);
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x00002BE7 File Offset: 0x00000DE7
		static void smethod_3(ColorBlend colorBlend_0, Color[] color_3)
		{
			colorBlend_0.Colors = color_3;
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x00002BF0 File Offset: 0x00000DF0
		static void smethod_4(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x00002BF9 File Offset: 0x00000DF9
		static void smethod_5(ColorBlend colorBlend_0, float[] float_0)
		{
			colorBlend_0.Positions = float_0;
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x00002C02 File Offset: 0x00000E02
		static void smethod_6(LinearGradientBrush linearGradientBrush_0, ColorBlend colorBlend_0)
		{
			linearGradientBrush_0.InterpolationColors = colorBlend_0;
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x00002B88 File Offset: 0x00000D88
		static Graphics smethod_7(PaintEventArgs paintEventArgs_0)
		{
			return paintEventArgs_0.Graphics;
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x00002C0B File Offset: 0x00000E0B
		static void smethod_8(Graphics graphics_0, Brush brush_0, Rectangle rectangle_0)
		{
			graphics_0.FillRectangle(brush_0, rectangle_0);
		}

		// Token: 0x0400006D RID: 109
		public About about_0;

		// Token: 0x0400006E RID: 110
		public Color color_0;

		// Token: 0x0400006F RID: 111
		public Color color_1;

		// Token: 0x04000070 RID: 112
		public Color color_2;
	}

	// Token: 0x02000018 RID: 24
	[CompilerGenerated]
	private sealed class Class9
	{
		// Token: 0x060000EF RID: 239 RVA: 0x0000E4B0 File Offset: 0x0000C6B0
		internal void method_0(object sender, EventArgs e)
		{
			About.Class9.Struct11 @struct;
			@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
			@struct.class9_0 = this;
			@struct.int_0 = -1;
			@struct.asyncVoidMethodBuilder_0.Start<About.Class9.Struct11>(ref @struct);
		}

		// Token: 0x04000076 RID: 118
		public About about_0;

		// Token: 0x04000077 RID: 119
		public string string_0;

		// Token: 0x02000019 RID: 25
		[StructLayout(LayoutKind.Auto)]
		private struct Struct11 : IAsyncStateMachine
		{
			// Token: 0x060000F0 RID: 240 RVA: 0x0000E4E8 File Offset: 0x0000C6E8
			void IAsyncStateMachine.MoveNext()
			{
				int num = this.int_0;
				About.Class9 @class = this.class9_0;
				try
				{
					TaskAwaiter<string> awaiter;
					if (num != 0)
					{
						awaiter = GClass6.GClass6_0.method_8(string.Concat(new string[]
						{
							"https://win10tweaker.com/Reactivator.php?old=",
							@class.about_0.TextBoxMain.Text,
							"&new=",
							Infobase.pcid,
							"&email=",
							@class.string_0,
							"&WindowsDate=",
							GClass6.GClass6_0.method_4()
						})).GetAwaiter();
						if (!awaiter.IsCompleted)
						{
							this.int_0 = 0;
							this.taskAwaiter_0 = awaiter;
							this.asyncVoidMethodBuilder_0.AwaitUnsafeOnCompleted<TaskAwaiter<string>, About.Class9.Struct11>(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.taskAwaiter_0;
						this.taskAwaiter_0 = default(TaskAwaiter<string>);
						this.int_0 = -1;
					}
					if (!(awaiter.GetResult() == "Ok"))
					{
						if (WMessageBox.smethod_3(@class.about_0.method_4("WrongEmailPcid"), "", WMessageBox.GEnum2.YesNo, false, "", null) != DialogResult.Yes)
						{
							@class.about_0.Close();
						}
						else
						{
							GClass2.GClass2_0.RegistryKey_0.SetValue("email", @class.about_0.TextBoxMain.Text);
							@class.about_0.Close();
							@class.about_0.form1_0.MakeOffer(true);
						}
					}
					else
					{
						@class.about_0.Close();
						@class.about_0.form1_0.Purchase();
					}
				}
				catch (Exception exception)
				{
					this.int_0 = -2;
					this.asyncVoidMethodBuilder_0.SetException(exception);
					return;
				}
				this.int_0 = -2;
				this.asyncVoidMethodBuilder_0.SetResult();
			}

			// Token: 0x060000F1 RID: 241 RVA: 0x00002C2B File Offset: 0x00000E2B
			[DebuggerHidden]
			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
			{
				this.asyncVoidMethodBuilder_0.SetStateMachine(stateMachine);
			}

			// Token: 0x060000F2 RID: 242 RVA: 0x00002A18 File Offset: 0x00000C18
			static string smethod_0(Control control_0)
			{
				return control_0.Text;
			}

			// Token: 0x060000F3 RID: 243 RVA: 0x0000298C File Offset: 0x00000B8C
			static string smethod_1(string[] string_0)
			{
				return string.Concat(string_0);
			}

			// Token: 0x060000F4 RID: 244 RVA: 0x00002B59 File Offset: 0x00000D59
			static bool smethod_2(string string_0, string string_1)
			{
				return string_0 == string_1;
			}

			// Token: 0x060000F5 RID: 245 RVA: 0x00002C39 File Offset: 0x00000E39
			static void smethod_3(Form form_0)
			{
				form_0.Close();
			}

			// Token: 0x060000F6 RID: 246 RVA: 0x00002C41 File Offset: 0x00000E41
			static void smethod_4(RegistryKey registryKey_0, string string_0, object object_0)
			{
				registryKey_0.SetValue(string_0, object_0);
			}

			// Token: 0x04000078 RID: 120
			public int int_0;

			// Token: 0x04000079 RID: 121
			public AsyncVoidMethodBuilder asyncVoidMethodBuilder_0;

			// Token: 0x0400007A RID: 122
			public About.Class9 class9_0;

			// Token: 0x0400007B RID: 123
			private TaskAwaiter<string> taskAwaiter_0;
		}
	}

	// Token: 0x0200001A RID: 26
	[CompilerGenerated]
	private sealed class Class10
	{
		// Token: 0x060000F8 RID: 248 RVA: 0x00002C4B File Offset: 0x00000E4B
		internal bool method_0(string string_1)
		{
			return string_1.EndsWith(this.string_0);
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x00002A29 File Offset: 0x00000C29
		static bool smethod_0(string string_1, string string_2)
		{
			return string_1.EndsWith(string_2);
		}

		// Token: 0x0400007C RID: 124
		public string string_0;
	}
}
