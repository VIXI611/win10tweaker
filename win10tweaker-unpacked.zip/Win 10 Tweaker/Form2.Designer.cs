﻿// Token: 0x0200004A RID: 74
internal partial class Form2 : global::Win_10_Tweaker.Form1
{
}
