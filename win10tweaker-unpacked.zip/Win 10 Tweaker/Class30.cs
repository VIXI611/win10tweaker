﻿using System;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x02000067 RID: 103
internal class Class30
{
	// Token: 0x060004F9 RID: 1273 RVA: 0x00003FFB File Offset: 0x000021FB
	public static void smethod_0()
	{
		Class30.smethod_1();
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x00019ADC File Offset: 0x00017CDC
	private static void smethod_1()
	{
		if (GClass2.GClass2_0.RegistryKey_0.GetValue("email") != null)
		{
			GClass6.GClass6_0.method_14("sc config seclogon start=disabled");
			Class30.form1_0.NewCheckResult(GClass2.GClass2_0.RegistryKey_0.GetValue("email").ToString());
		}
		string text = "w10t\\shell\\open\\command";
		string text2 = "\"" + GClass2.GClass2_0.String_11 + "\" buyknow";
		using (RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey(text, true))
		{
			if (registryKey != null)
			{
				using (RegistryKey registryKey2 = Registry.ClassesRoot.OpenSubKey(text, true))
				{
					if (registryKey2.GetValue("").ToString() != text2)
					{
						registryKey2.SetValue("", text2);
					}
					return;
				}
			}
			Registry.ClassesRoot.CreateSubKey("w10t").SetValue("URL protocol", "");
			Registry.ClassesRoot.CreateSubKey(text).SetValue("", text2);
		}
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x060004FB RID: 1275 RVA: 0x00004002 File Offset: 0x00002202
	public static string String_0
	{
		get
		{
			return "<RSAKeyValue><Modulus>v9t0cRkgjLtC0dc9lEKJBhbdi+b4AdHDhTw9fHAi11jwnBRG6leoYuwrHJF415lUdCOIFrwOKlYq3P1+hJHEOYMFFlcT/r8ha0o/b6J22utwnGcxLuilpvHRzjQafjmjnc2EyWXbKW+oxoY7BNNETUP7vm1o1JtwNtp4pi1xo3wUWhUOc76DzWDuHOtu/W0K7KMrkt4bbW0PCopCCyXY4vuhRBzL/ZiC1QV/Ie8QWwvsyx7KT67tX9ag63YN8t6oiJX8U2f1o260pEwLPLWhtxKDf72dI9Z/VFK6i3nlJDkES2hERf1sqQ/oqEu38Dzusx/28pNriPh9iz6ToZKd4Q==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
		}
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_2(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x060004FF RID: 1279 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_3(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x06000500 RID: 1280 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_4(string string_0, string string_1, string string_2)
	{
		return string_0 + string_1 + string_2;
	}

	// Token: 0x06000501 RID: 1281 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_5(RegistryKey registryKey_0, string string_0, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_0, bool_0);
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_6(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_7(RegistryKey registryKey_0, string string_0, object object_0)
	{
		registryKey_0.SetValue(string_0, object_0);
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x00002917 File Offset: 0x00000B17
	static bool smethod_8(string string_0, string string_1)
	{
		return string_0 != string_1;
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_9(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x0400022F RID: 559
	private static readonly Form1 form1_0 = new Form1();
}
