﻿using System;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;

// Token: 0x02000063 RID: 99
public static class GClass8
{
	// Token: 0x060004DD RID: 1245 RVA: 0x00019950 File Offset: 0x00017B50
	public static void smethod_0(this string string_0)
	{
		try
		{
			if (Directory.Exists(string_0))
			{
				DirectorySecurity accessControl = Directory.GetAccessControl(string_0);
				SecurityIdentifier user = WindowsIdentity.GetCurrent().User;
				accessControl.SetOwner(user);
				accessControl.SetAccessRule(new FileSystemAccessRule(user, FileSystemRights.FullControl, AccessControlType.Allow));
				Directory.SetAccessControl(string_0, accessControl);
			}
			else if (File.Exists(string_0))
			{
				FileSecurity accessControl2 = File.GetAccessControl(string_0);
				SecurityIdentifier user2 = WindowsIdentity.GetCurrent().User;
				accessControl2.SetOwner(user2);
				accessControl2.SetAccessRule(new FileSystemAccessRule(user2, FileSystemRights.FullControl, AccessControlType.Allow));
				File.SetAccessControl(string_0, accessControl2);
			}
		}
		catch
		{
		}
	}

	// Token: 0x060004DE RID: 1246 RVA: 0x00002EE5 File Offset: 0x000010E5
	static bool smethod_1(string string_0)
	{
		return Directory.Exists(string_0);
	}

	// Token: 0x060004DF RID: 1247 RVA: 0x00003F17 File Offset: 0x00002117
	static DirectorySecurity smethod_2(string string_0)
	{
		return Directory.GetAccessControl(string_0);
	}

	// Token: 0x060004E0 RID: 1248 RVA: 0x00003F1F File Offset: 0x0000211F
	static WindowsIdentity smethod_3()
	{
		return WindowsIdentity.GetCurrent();
	}

	// Token: 0x060004E1 RID: 1249 RVA: 0x00003F26 File Offset: 0x00002126
	static SecurityIdentifier smethod_4(WindowsIdentity windowsIdentity_0)
	{
		return windowsIdentity_0.User;
	}

	// Token: 0x060004E2 RID: 1250 RVA: 0x00003D80 File Offset: 0x00001F80
	static void smethod_5(ObjectSecurity objectSecurity_0, IdentityReference identityReference_0)
	{
		objectSecurity_0.SetOwner(identityReference_0);
	}

	// Token: 0x060004E3 RID: 1251 RVA: 0x00003F2E File Offset: 0x0000212E
	static FileSystemAccessRule smethod_6(IdentityReference identityReference_0, FileSystemRights fileSystemRights_0, AccessControlType accessControlType_0)
	{
		return new FileSystemAccessRule(identityReference_0, fileSystemRights_0, accessControlType_0);
	}

	// Token: 0x060004E4 RID: 1252 RVA: 0x00003F38 File Offset: 0x00002138
	static void smethod_7(FileSystemSecurity fileSystemSecurity_0, FileSystemAccessRule fileSystemAccessRule_0)
	{
		fileSystemSecurity_0.SetAccessRule(fileSystemAccessRule_0);
	}

	// Token: 0x060004E5 RID: 1253 RVA: 0x00003F41 File Offset: 0x00002141
	static void smethod_8(string string_0, DirectorySecurity directorySecurity_0)
	{
		Directory.SetAccessControl(string_0, directorySecurity_0);
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_9(string string_0)
	{
		return File.Exists(string_0);
	}

	// Token: 0x060004E7 RID: 1255 RVA: 0x00003F4A File Offset: 0x0000214A
	static FileSecurity smethod_10(string string_0)
	{
		return File.GetAccessControl(string_0);
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x00003F52 File Offset: 0x00002152
	static void smethod_11(string string_0, FileSecurity fileSecurity_0)
	{
		File.SetAccessControl(string_0, fileSecurity_0);
	}
}
