﻿using System;
using System.IO;
using System.Threading;
using Microsoft.Win32;

// Token: 0x020000E4 RID: 228
internal class Class75
{
	// Token: 0x17000096 RID: 150
	// (get) Token: 0x06000B54 RID: 2900 RVA: 0x00038DEC File Offset: 0x00036FEC
	public static Class75 Class75_0
	{
		get
		{
			if (Class75.class75_0 == null)
			{
				object obj = Class75.object_0;
				lock (obj)
				{
					if (Class75.class75_0 == null)
					{
						Class75.class75_0 = new Class75();
					}
				}
			}
			return Class75.class75_0;
		}
	}

	// Token: 0x06000B55 RID: 2901 RVA: 0x00038E4C File Offset: 0x0003704C
	public void method_0()
	{
		File.WriteAllText(GClass13.string_6 + "\\ShowHideSysFldrs.vbs", Class89.String_1);
		Registry.ClassesRoot.CreateSubKey(this.string_1).SetValue("", GClass2.GClass2_0.method_1("ShowHideSysFldrs"));
		Registry.ClassesRoot.CreateSubKey(this.string_1 + "\\command").SetValue("", "WScript.exe C:\\Windows\\ShowHideSysFldrs.vbs");
		Registry.ClassesRoot.CreateSubKey(this.string_1).SetValue("Icon", GClass2.GClass2_0.String_3.Contains("10") ? "imageres.dll,266" : "SHELL32.dll,4");
		try
		{
			Registry.ClassesRoot.OpenSubKey(this.string_1, true).DeleteValue("Extended");
		}
		catch
		{
		}
	}

	// Token: 0x06000B56 RID: 2902 RVA: 0x00006764 File Offset: 0x00004964
	public void method_1()
	{
		Registry.ClassesRoot.CreateSubKey(this.string_1).SetValue("Extended", "");
	}

	// Token: 0x06000B57 RID: 2903 RVA: 0x00038F30 File Offset: 0x00037130
	public void method_2()
	{
		try
		{
			Registry.ClassesRoot.DeleteSubKeyTree(this.string_1);
		}
		catch
		{
		}
		if (File.Exists(this.string_0))
		{
			File.Delete(this.string_0);
		}
	}

	// Token: 0x06000B5A RID: 2906 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000B5B RID: 2907 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000B5C RID: 2908 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_2(string string_2, string string_3)
	{
		return string_2 + string_3;
	}

	// Token: 0x06000B5D RID: 2909 RVA: 0x00003D00 File Offset: 0x00001F00
	static void smethod_3(string string_2, string string_3)
	{
		File.WriteAllText(string_2, string_3);
	}

	// Token: 0x06000B5E RID: 2910 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_4(RegistryKey registryKey_0, string string_2)
	{
		return registryKey_0.CreateSubKey(string_2);
	}

	// Token: 0x06000B5F RID: 2911 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_5(RegistryKey registryKey_0, string string_2, object object_1)
	{
		registryKey_0.SetValue(string_2, object_1);
	}

	// Token: 0x06000B60 RID: 2912 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_6(string string_2, string string_3)
	{
		return string_2.Contains(string_3);
	}

	// Token: 0x06000B61 RID: 2913 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_7(RegistryKey registryKey_0, string string_2, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_2, bool_0);
	}

	// Token: 0x06000B62 RID: 2914 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_8(RegistryKey registryKey_0, string string_2)
	{
		registryKey_0.DeleteValue(string_2);
	}

	// Token: 0x06000B63 RID: 2915 RVA: 0x00003021 File Offset: 0x00001221
	static void smethod_9(RegistryKey registryKey_0, string string_2)
	{
		registryKey_0.DeleteSubKeyTree(string_2);
	}

	// Token: 0x06000B64 RID: 2916 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_10(string string_2)
	{
		return File.Exists(string_2);
	}

	// Token: 0x06000B65 RID: 2917 RVA: 0x00002F15 File Offset: 0x00001115
	static void smethod_11(string string_2)
	{
		File.Delete(string_2);
	}

	// Token: 0x06000B66 RID: 2918 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_12()
	{
		return new object();
	}

	// Token: 0x04000490 RID: 1168
	private static volatile Class75 class75_0;

	// Token: 0x04000491 RID: 1169
	private static readonly object object_0 = new object();

	// Token: 0x04000492 RID: 1170
	private readonly string string_0 = GClass13.string_6 + "\\ShowHideSysFldrs.vbs";

	// Token: 0x04000493 RID: 1171
	private readonly string string_1 = "Directory\\shell\\SuperHidden";
}
