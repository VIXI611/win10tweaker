﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200003A RID: 58
[StructLayout(LayoutKind.Sequential, Pack = 1)]
internal struct Struct27
{
	// Token: 0x04000105 RID: 261
	public long long_0;

	// Token: 0x04000106 RID: 262
	public long long_1;

	// Token: 0x04000107 RID: 263
	public long long_2;

	// Token: 0x04000108 RID: 264
	public long long_3;

	// Token: 0x04000109 RID: 265
	public long long_4;
}
