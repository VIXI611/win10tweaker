﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;

// Token: 0x02000195 RID: 405
[CompilerGenerated]
[DebuggerNonUserCode]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
internal class Class89
{
	// Token: 0x060013D6 RID: 5078 RVA: 0x000026FB File Offset: 0x000008FB
	internal Class89()
	{
	}

	// Token: 0x170000A7 RID: 167
	// (get) Token: 0x060013D7 RID: 5079 RVA: 0x000093EA File Offset: 0x000075EA
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager_0
	{
		get
		{
			if (Class89.resourceManager_0 == null)
			{
				Class89.resourceManager_0 = new ResourceManager("Vr1slkG-$\"(=;r{<yl'=0b:e\"", typeof(Class89).Assembly);
			}
			return Class89.resourceManager_0;
		}
	}

	// Token: 0x170000A8 RID: 168
	// (set) Token: 0x060013D8 RID: 5080 RVA: 0x00009416 File Offset: 0x00007616
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo CultureInfo_0
	{
		set
		{
			Class89.cultureInfo_0 = value;
		}
	}

	// Token: 0x170000A9 RID: 169
	// (get) Token: 0x060013D9 RID: 5081 RVA: 0x0000941E File Offset: 0x0000761E
	internal static Bitmap Bitmap_0
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_1 BackupSystemIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000AA RID: 170
	// (get) Token: 0x060013DA RID: 5082 RVA: 0x00009439 File Offset: 0x00007639
	internal static Bitmap Bitmap_1
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_10 TraytIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000AB RID: 171
	// (get) Token: 0x060013DB RID: 5083 RVA: 0x00009454 File Offset: 0x00007654
	internal static Bitmap Bitmap_2
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_2 RestoreSystemIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000AC RID: 172
	// (get) Token: 0x060013DC RID: 5084 RVA: 0x0000946F File Offset: 0x0000766F
	internal static Bitmap Bitmap_3
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_3 ExportTweaksIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000AD RID: 173
	// (get) Token: 0x060013DD RID: 5085 RVA: 0x0000948A File Offset: 0x0000768A
	internal static Bitmap Bitmap_4
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_4 ImportTweaksIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000AE RID: 174
	// (get) Token: 0x060013DE RID: 5086 RVA: 0x000094A5 File Offset: 0x000076A5
	internal static Bitmap Bitmap_5
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_5 ExportExts", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000AF RID: 175
	// (get) Token: 0x060013DF RID: 5087 RVA: 0x000094C0 File Offset: 0x000076C0
	internal static Bitmap Bitmap_6
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_6 ImportExts", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B0 RID: 176
	// (get) Token: 0x060013E0 RID: 5088 RVA: 0x000094DB File Offset: 0x000076DB
	internal static Bitmap Bitmap_7
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_7 ExportDriversIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B1 RID: 177
	// (get) Token: 0x060013E1 RID: 5089 RVA: 0x000094F6 File Offset: 0x000076F6
	internal static Bitmap Bitmap_8
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_8 ImportDriversIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B2 RID: 178
	// (get) Token: 0x060013E2 RID: 5090 RVA: 0x00009511 File Offset: 0x00007711
	internal static Bitmap Bitmap_9
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("_9 WidgetIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B3 RID: 179
	// (get) Token: 0x060013E3 RID: 5091 RVA: 0x0000952C File Offset: 0x0000772C
	internal static Bitmap Bitmap_10
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("about", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B4 RID: 180
	// (get) Token: 0x060013E4 RID: 5092 RVA: 0x00009547 File Offset: 0x00007747
	internal static Bitmap Bitmap_11
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("BingWeather_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B5 RID: 181
	// (get) Token: 0x060013E5 RID: 5093 RVA: 0x00009562 File Offset: 0x00007762
	internal static Icon Icon_0
	{
		get
		{
			return (Icon)Class89.ResourceManager_0.GetObject("Blank", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B6 RID: 182
	// (get) Token: 0x060013E6 RID: 5094 RVA: 0x0000957D File Offset: 0x0000777D
	internal static Bitmap Bitmap_12
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("BlockerList", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B7 RID: 183
	// (get) Token: 0x060013E7 RID: 5095 RVA: 0x00009598 File Offset: 0x00007798
	internal static Bitmap Bitmap_13
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Blockexe", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B8 RID: 184
	// (get) Token: 0x060013E8 RID: 5096 RVA: 0x000095B3 File Offset: 0x000077B3
	internal static Bitmap Bitmap_14
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Borderexe", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000B9 RID: 185
	// (get) Token: 0x060013E9 RID: 5097 RVA: 0x000095CE File Offset: 0x000077CE
	internal static Bitmap Bitmap_15
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("btc", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000BA RID: 186
	// (get) Token: 0x060013EA RID: 5098 RVA: 0x000095E9 File Offset: 0x000077E9
	internal static Bitmap Bitmap_16
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("clean", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000BB RID: 187
	// (get) Token: 0x060013EB RID: 5099 RVA: 0x00009604 File Offset: 0x00007804
	internal static Bitmap Bitmap_17
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("close", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000BC RID: 188
	// (get) Token: 0x060013EC RID: 5100 RVA: 0x0000961F File Offset: 0x0000781F
	internal static Bitmap Bitmap_18
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Communications_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000BD RID: 189
	// (get) Token: 0x060013ED RID: 5101 RVA: 0x0000963A File Offset: 0x0000783A
	internal static Bitmap Bitmap_19
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("copy", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000BE RID: 190
	// (get) Token: 0x060013EE RID: 5102 RVA: 0x00009655 File Offset: 0x00007855
	internal static byte[] Byte_0
	{
		get
		{
			return (byte[])Class89.ResourceManager_0.GetObject("Cursors", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000BF RID: 191
	// (get) Token: 0x060013EF RID: 5103 RVA: 0x00009670 File Offset: 0x00007870
	internal static Bitmap Bitmap_20
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("delete", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C0 RID: 192
	// (get) Token: 0x060013F0 RID: 5104 RVA: 0x0000968B File Offset: 0x0000788B
	internal static Bitmap Bitmap_21
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("DonationBack", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C1 RID: 193
	// (get) Token: 0x060013F1 RID: 5105 RVA: 0x000096A6 File Offset: 0x000078A6
	internal static Bitmap Bitmap_22
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("DotDark", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C2 RID: 194
	// (get) Token: 0x060013F2 RID: 5106 RVA: 0x000096C1 File Offset: 0x000078C1
	internal static Bitmap Bitmap_23
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("DotSea", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C3 RID: 195
	// (get) Token: 0x060013F3 RID: 5107 RVA: 0x000096DC File Offset: 0x000078DC
	internal static Bitmap Bitmap_24
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("DotSky", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C4 RID: 196
	// (get) Token: 0x060013F4 RID: 5108 RVA: 0x000096F7 File Offset: 0x000078F7
	internal static Bitmap Bitmap_25
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Feedback_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C5 RID: 197
	// (get) Token: 0x060013F5 RID: 5109 RVA: 0x00009712 File Offset: 0x00007912
	internal static Bitmap Bitmap_26
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("FlagDeutsch", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C6 RID: 198
	// (get) Token: 0x060013F6 RID: 5110 RVA: 0x0000972D File Offset: 0x0000792D
	internal static Bitmap Bitmap_27
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("FlagEnglish", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C7 RID: 199
	// (get) Token: 0x060013F7 RID: 5111 RVA: 0x00009748 File Offset: 0x00007948
	internal static Bitmap Bitmap_28
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("FlagRussian", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C8 RID: 200
	// (get) Token: 0x060013F8 RID: 5112 RVA: 0x00009763 File Offset: 0x00007963
	internal static Bitmap Bitmap_29
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("FlagUkrainian", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000C9 RID: 201
	// (get) Token: 0x060013F9 RID: 5113 RVA: 0x0000977E File Offset: 0x0000797E
	internal static Bitmap Bitmap_30
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Freezeexe", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000CA RID: 202
	// (get) Token: 0x060013FA RID: 5114 RVA: 0x00009799 File Offset: 0x00007999
	internal static Bitmap Bitmap_31
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("GetHelp_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000CB RID: 203
	// (get) Token: 0x060013FB RID: 5115 RVA: 0x000097B4 File Offset: 0x000079B4
	internal static Bitmap Bitmap_32
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Getstarted_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000CC RID: 204
	// (get) Token: 0x060013FC RID: 5116 RVA: 0x000097CF File Offset: 0x000079CF
	internal static Bitmap Bitmap_33
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("LangShortcut", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000CD RID: 205
	// (get) Token: 0x060013FD RID: 5117 RVA: 0x000097EA File Offset: 0x000079EA
	internal static Bitmap Bitmap_34
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("LangSky", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000CE RID: 206
	// (get) Token: 0x060013FE RID: 5118 RVA: 0x00009805 File Offset: 0x00007A05
	internal static Bitmap Bitmap_35
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("logo", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000CF RID: 207
	// (get) Token: 0x060013FF RID: 5119 RVA: 0x00009820 File Offset: 0x00007A20
	internal static Bitmap Bitmap_36
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("MenuHoverIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D0 RID: 208
	// (get) Token: 0x06001400 RID: 5120 RVA: 0x0000983B File Offset: 0x00007A3B
	internal static Bitmap Bitmap_37
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("MinimizeButton", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D1 RID: 209
	// (get) Token: 0x06001401 RID: 5121 RVA: 0x00009856 File Offset: 0x00007A56
	internal static Bitmap Bitmap_38
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("MixedReality_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D2 RID: 210
	// (get) Token: 0x06001402 RID: 5122 RVA: 0x00009871 File Offset: 0x00007A71
	internal static byte[] Byte_1
	{
		get
		{
			return (byte[])Class89.ResourceManager_0.GetObject("noty", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D3 RID: 211
	// (get) Token: 0x06001403 RID: 5123 RVA: 0x0000988C File Offset: 0x00007A8C
	internal static Bitmap Bitmap_39
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("OfficeHub_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D4 RID: 212
	// (get) Token: 0x06001404 RID: 5124 RVA: 0x000098A7 File Offset: 0x00007AA7
	internal static Bitmap Bitmap_40
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("OneNote_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D5 RID: 213
	// (get) Token: 0x06001405 RID: 5125 RVA: 0x000098C2 File Offset: 0x00007AC2
	internal static Bitmap Bitmap_41
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Paint_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D6 RID: 214
	// (get) Token: 0x06001406 RID: 5126 RVA: 0x000098DD File Offset: 0x00007ADD
	internal static Bitmap Bitmap_42
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("People_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D7 RID: 215
	// (get) Token: 0x06001407 RID: 5127 RVA: 0x000098F8 File Offset: 0x00007AF8
	internal static Bitmap Bitmap_43
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Photos_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D8 RID: 216
	// (get) Token: 0x06001408 RID: 5128 RVA: 0x00009913 File Offset: 0x00007B13
	internal static Bitmap Bitmap_44
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("PlayButton", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000D9 RID: 217
	// (get) Token: 0x06001409 RID: 5129 RVA: 0x0000992E File Offset: 0x00007B2E
	internal static Bitmap Bitmap_45
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("pp", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000DA RID: 218
	// (get) Token: 0x0600140A RID: 5130 RVA: 0x00009949 File Offset: 0x00007B49
	internal static Bitmap Bitmap_46
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("qr", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000DB RID: 219
	// (get) Token: 0x0600140B RID: 5131 RVA: 0x00009964 File Offset: 0x00007B64
	internal static Bitmap Bitmap_47
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("ram", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000DC RID: 220
	// (get) Token: 0x0600140C RID: 5132 RVA: 0x0000997F File Offset: 0x00007B7F
	internal static Icon Icon_1
	{
		get
		{
			return (Icon)Class89.ResourceManager_0.GetObject("Rebofresh", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000DD RID: 221
	// (get) Token: 0x0600140D RID: 5133 RVA: 0x0000999A File Offset: 0x00007B9A
	internal static string String_0
	{
		get
		{
			return Class89.ResourceManager_0.GetString("Rebofresh1", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000DE RID: 222
	// (get) Token: 0x0600140E RID: 5134 RVA: 0x000099B0 File Offset: 0x00007BB0
	internal static Bitmap Bitmap_48
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Recorder_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000DF RID: 223
	// (get) Token: 0x0600140F RID: 5135 RVA: 0x000099CB File Offset: 0x00007BCB
	internal static Bitmap Bitmap_49
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("restore", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E0 RID: 224
	// (get) Token: 0x06001410 RID: 5136 RVA: 0x000099E6 File Offset: 0x00007BE6
	internal static Bitmap Bitmap_50
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("restore2", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E1 RID: 225
	// (get) Token: 0x06001411 RID: 5137 RVA: 0x00009A01 File Offset: 0x00007C01
	internal static Bitmap Bitmap_51
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("restoreOpt", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E2 RID: 226
	// (get) Token: 0x06001412 RID: 5138 RVA: 0x00009A1C File Offset: 0x00007C1C
	internal static Bitmap Bitmap_52
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("RestoreServices", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E3 RID: 227
	// (get) Token: 0x06001413 RID: 5139 RVA: 0x00009A37 File Offset: 0x00007C37
	internal static Bitmap Bitmap_53
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("reupload", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E4 RID: 228
	// (get) Token: 0x06001414 RID: 5140 RVA: 0x00009A52 File Offset: 0x00007C52
	internal static Bitmap Bitmap_54
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("saveCleaner", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E5 RID: 229
	// (get) Token: 0x06001415 RID: 5141 RVA: 0x00009A6D File Offset: 0x00007C6D
	internal static Bitmap Bitmap_55
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("scanner", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E6 RID: 230
	// (get) Token: 0x06001416 RID: 5142 RVA: 0x00009A88 File Offset: 0x00007C88
	internal static Bitmap Bitmap_56
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("SettingsIcon", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E7 RID: 231
	// (get) Token: 0x06001417 RID: 5143 RVA: 0x00009AA3 File Offset: 0x00007CA3
	internal static Bitmap Bitmap_57
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("SettingsProgress", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E8 RID: 232
	// (get) Token: 0x06001418 RID: 5144 RVA: 0x00009ABE File Offset: 0x00007CBE
	internal static string String_1
	{
		get
		{
			return Class89.ResourceManager_0.GetString("ShowHideSysFldrs", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000E9 RID: 233
	// (get) Token: 0x06001419 RID: 5145 RVA: 0x00009AD4 File Offset: 0x00007CD4
	internal static Bitmap Bitmap_58
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Sketch_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000EA RID: 234
	// (get) Token: 0x0600141A RID: 5146 RVA: 0x00009AEF File Offset: 0x00007CEF
	internal static Bitmap Bitmap_59
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Skype_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000EB RID: 235
	// (get) Token: 0x0600141B RID: 5147 RVA: 0x00009B0A File Offset: 0x00007D0A
	internal static Bitmap Bitmap_60
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Solitaire_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000EC RID: 236
	// (get) Token: 0x0600141C RID: 5148 RVA: 0x00009B25 File Offset: 0x00007D25
	internal static Bitmap Bitmap_61
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("StickyNotes_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000ED RID: 237
	// (get) Token: 0x0600141D RID: 5149 RVA: 0x00009B40 File Offset: 0x00007D40
	internal static Bitmap Bitmap_62
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Superexe", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000EE RID: 238
	// (get) Token: 0x0600141E RID: 5150 RVA: 0x00009B5B File Offset: 0x00007D5B
	internal static Bitmap Bitmap_63
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("toggleOff", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000EF RID: 239
	// (get) Token: 0x0600141F RID: 5151 RVA: 0x00009B76 File Offset: 0x00007D76
	internal static Bitmap Bitmap_64
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("toggleOn", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F0 RID: 240
	// (get) Token: 0x06001420 RID: 5152 RVA: 0x00009B91 File Offset: 0x00007D91
	internal static Bitmap Bitmap_65
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("UploaderDarkSkin", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F1 RID: 241
	// (get) Token: 0x06001421 RID: 5153 RVA: 0x00009BAC File Offset: 0x00007DAC
	internal static Bitmap Bitmap_66
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("UploaderSeaSkin", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F2 RID: 242
	// (get) Token: 0x06001422 RID: 5154 RVA: 0x00009BC7 File Offset: 0x00007DC7
	internal static Bitmap Bitmap_67
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("UploaderSkySkin", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F3 RID: 243
	// (get) Token: 0x06001423 RID: 5155 RVA: 0x00009BE2 File Offset: 0x00007DE2
	internal static Bitmap Bitmap_68
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Viewer_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F4 RID: 244
	// (get) Token: 0x06001424 RID: 5156 RVA: 0x00009BFD File Offset: 0x00007DFD
	internal static Bitmap Bitmap_69
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("visa", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F5 RID: 245
	// (get) Token: 0x06001425 RID: 5157 RVA: 0x00009C18 File Offset: 0x00007E18
	internal static Bitmap Bitmap_70
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("WindowsAlarms_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F6 RID: 246
	// (get) Token: 0x06001426 RID: 5158 RVA: 0x00009C33 File Offset: 0x00007E33
	internal static Bitmap Bitmap_71
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("WindowsCamera_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F7 RID: 247
	// (get) Token: 0x06001427 RID: 5159 RVA: 0x00009C4E File Offset: 0x00007E4E
	internal static Bitmap Bitmap_72
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("WindowsMaps_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F8 RID: 248
	// (get) Token: 0x06001428 RID: 5160 RVA: 0x00009C69 File Offset: 0x00007E69
	internal static Bitmap Bitmap_73
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("WindowsStore_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000F9 RID: 249
	// (get) Token: 0x06001429 RID: 5161 RVA: 0x00009C84 File Offset: 0x00007E84
	internal static Bitmap Bitmap_74
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("Xbox_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000FA RID: 250
	// (get) Token: 0x0600142A RID: 5162 RVA: 0x00009C9F File Offset: 0x00007E9F
	internal static byte[] Byte_2
	{
		get
		{
			return (byte[])Class89.ResourceManager_0.GetObject("xml", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000FB RID: 251
	// (get) Token: 0x0600142B RID: 5163 RVA: 0x00009CBA File Offset: 0x00007EBA
	internal static Bitmap Bitmap_75
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("YouTube1", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000FC RID: 252
	// (get) Token: 0x0600142C RID: 5164 RVA: 0x00009CD5 File Offset: 0x00007ED5
	internal static Bitmap Bitmap_76
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("YouTube2", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000FD RID: 253
	// (get) Token: 0x0600142D RID: 5165 RVA: 0x00009CF0 File Offset: 0x00007EF0
	internal static Bitmap Bitmap_77
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("YouTube3", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000FE RID: 254
	// (get) Token: 0x0600142E RID: 5166 RVA: 0x00009D0B File Offset: 0x00007F0B
	internal static Bitmap Bitmap_78
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("YouTube4", Class89.cultureInfo_0);
		}
	}

	// Token: 0x170000FF RID: 255
	// (get) Token: 0x0600142F RID: 5167 RVA: 0x00009D26 File Offset: 0x00007F26
	internal static Bitmap Bitmap_79
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("ZuneMusic_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x17000100 RID: 256
	// (get) Token: 0x06001430 RID: 5168 RVA: 0x00009D41 File Offset: 0x00007F41
	internal static Bitmap Bitmap_80
	{
		get
		{
			return (Bitmap)Class89.ResourceManager_0.GetObject("ZuneVideo_", Class89.cultureInfo_0);
		}
	}

	// Token: 0x17000101 RID: 257
	// (get) Token: 0x06001431 RID: 5169 RVA: 0x00009D5C File Offset: 0x00007F5C
	internal static byte[] Byte_3
	{
		get
		{
			return (byte[])Class89.ResourceManager_0.GetObject("Обновить_оболочку", Class89.cultureInfo_0);
		}
	}

	// Token: 0x17000102 RID: 258
	// (get) Token: 0x06001432 RID: 5170 RVA: 0x00009D77 File Offset: 0x00007F77
	internal static byte[] Byte_4
	{
		get
		{
			return (byte[])Class89.ResourceManager_0.GetObject("Перезагрузка", Class89.cultureInfo_0);
		}
	}

	// Token: 0x06001433 RID: 5171 RVA: 0x000025CE File Offset: 0x000007CE
	static Type smethod_0(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x06001434 RID: 5172 RVA: 0x00009D92 File Offset: 0x00007F92
	static Assembly smethod_1(Type type_0)
	{
		return type_0.Assembly;
	}

	// Token: 0x06001435 RID: 5173 RVA: 0x00009D9A File Offset: 0x00007F9A
	static ResourceManager smethod_2(string string_0, Assembly assembly_0)
	{
		return new ResourceManager(string_0, assembly_0);
	}

	// Token: 0x06001436 RID: 5174 RVA: 0x00009DA3 File Offset: 0x00007FA3
	static object smethod_3(ResourceManager resourceManager_1, string string_0, CultureInfo cultureInfo_1)
	{
		return resourceManager_1.GetObject(string_0, cultureInfo_1);
	}

	// Token: 0x06001437 RID: 5175 RVA: 0x00009DAD File Offset: 0x00007FAD
	static string smethod_4(ResourceManager resourceManager_1, string string_0, CultureInfo cultureInfo_1)
	{
		return resourceManager_1.GetString(string_0, cultureInfo_1);
	}

	// Token: 0x04000971 RID: 2417
	private static ResourceManager resourceManager_0;

	// Token: 0x04000972 RID: 2418
	private static CultureInfo cultureInfo_0;
}
