﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A6 RID: 422
[TypeIdentifier]
[Guid("88A05C00-F000-11CE-8350-444553540000")]
[CompilerGenerated]
[ComImport]
public interface GInterface9
{
}
