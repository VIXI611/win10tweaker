﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x000025BC File Offset: 0x000007BC
	static <Module>()
	{
		<Module>.smethod_32();
		<Module>.smethod_2();
		<Module>.smethod_0();
	}

	// Token: 0x06000002 RID: 2 RVA: 0x00009DE4 File Offset: 0x00007FE4
	private static void smethod_0()
	{
		string str = "COR";
		MethodInfo method = typeof(Environment).GetMethod("GetEnvironmentVariable", new Type[]
		{
			typeof(string)
		});
		if (method != null && "1".Equals(method.Invoke(null, new object[]
		{
			str + "_ENABLE_PROFILING"
		})))
		{
			Environment.FailFast(null);
		}
		new Thread(new ParameterizedThreadStart(<Module>.smethod_1))
		{
			IsBackground = true
		}.Start(null);
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00009E70 File Offset: 0x00008070
	private static void smethod_1(object object_0)
	{
		Thread thread = object_0 as Thread;
		if (thread == null)
		{
			thread = new Thread(new ParameterizedThreadStart(<Module>.smethod_1));
			thread.IsBackground = true;
			thread.Start(Thread.CurrentThread);
			Thread.Sleep(500);
		}
		for (;;)
		{
			if (Debugger.IsAttached)
			{
				goto IL_41;
			}
			if (Debugger.IsLogging())
			{
				goto IL_41;
			}
			IL_47:
			if (!thread.IsAlive)
			{
				Environment.FailFast(null);
			}
			Thread.Sleep(1000);
			continue;
			IL_41:
			Environment.FailFast(null);
			goto IL_47;
		}
	}

	// Token: 0x06000004 RID: 4
	[DllImport("kernel32.dll")]
	internal unsafe static extern bool VirtualProtect(byte* pByte_0, int int_0, uint uint_0, ref uint uint_1);

	// Token: 0x06000005 RID: 5 RVA: 0x00009EE4 File Offset: 0x000080E4
	internal unsafe static void smethod_2()
	{
		Module module = typeof(<Module>).Module;
		byte* ptr = (byte*)((void*)Marshal.GetHINSTANCE(module));
		byte* ptr2 = ptr + 60;
		ptr2 = ptr + *(uint*)ptr2;
		ptr2 += 6;
		ushort num = *(ushort*)ptr2;
		ptr2 += 14;
		ushort num2 = *(ushort*)ptr2;
		ptr2 = ptr2 + 4 + num2;
		byte* ptr3 = stackalloc byte[(UIntPtr)11];
		uint num3;
		if (module.FullyQualifiedName[0] != '<')
		{
			byte* ptr4 = ptr + *(uint*)(ptr2 - 16);
			if (*(uint*)(ptr2 - 120) != 0U)
			{
				byte* ptr5 = ptr + *(uint*)(ptr2 - 120);
				byte* ptr6 = ptr + *(uint*)ptr5;
				byte* ptr7 = ptr + *(uint*)(ptr5 + 12);
				byte* ptr8 = ptr + *(uint*)ptr6 + 2;
				<Module>.VirtualProtect(ptr7, 11, 64U, ref num3);
				*(int*)ptr3 = 1818522734;
				*(int*)(ptr3 + 4) = 1818504812;
				*(short*)(ptr3 + (IntPtr)4 * 2) = 108;
				ptr3[10] = 0;
				for (int i = 0; i < 11; i++)
				{
					ptr7[i] = ptr3[i];
				}
				<Module>.VirtualProtect(ptr8, 11, 64U, ref num3);
				*(int*)ptr3 = 1866691662;
				*(int*)(ptr3 + 4) = 1852404846;
				*(short*)(ptr3 + (IntPtr)4 * 2) = 25973;
				ptr3[10] = 0;
				for (int j = 0; j < 11; j++)
				{
					ptr8[j] = ptr3[j];
				}
			}
			for (int k = 0; k < (int)num; k++)
			{
				<Module>.VirtualProtect(ptr2, 8, 64U, ref num3);
				Marshal.Copy(new byte[8], 0, (IntPtr)((void*)ptr2), 8);
				ptr2 += 40;
			}
			<Module>.VirtualProtect(ptr4, 72, 64U, ref num3);
			byte* ptr9 = ptr + *(uint*)(ptr4 + 8);
			*(int*)ptr4 = 0;
			*(int*)(ptr4 + 4) = 0;
			*(int*)(ptr4 + (IntPtr)2 * 4) = 0;
			*(int*)(ptr4 + (IntPtr)3 * 4) = 0;
			<Module>.VirtualProtect(ptr9, 4, 64U, ref num3);
			*(int*)ptr9 = 0;
			ptr9 += 12;
			ptr9 += *(uint*)ptr9;
			ptr9 = (ptr9 + 7L & -4L);
			ptr9 += 2;
			ushort num4 = (ushort)(*ptr9);
			ptr9 += 2;
			int l = 0;
			IL_279:
			while (l < (int)num4)
			{
				<Module>.VirtualProtect(ptr9, 8, 64U, ref num3);
				ptr9 += 4;
				ptr9 += 4;
				int m = 0;
				while (m < 8)
				{
					<Module>.VirtualProtect(ptr9, 4, 64U, ref num3);
					*ptr9 = 0;
					ptr9++;
					if (*ptr9 != 0)
					{
						*ptr9 = 0;
						ptr9++;
						if (*ptr9 != 0)
						{
							*ptr9 = 0;
							ptr9++;
							if (*ptr9 != 0)
							{
								*ptr9 = 0;
								ptr9++;
								m++;
								continue;
							}
							ptr9++;
						}
						else
						{
							ptr9 += 2;
						}
					}
					else
					{
						ptr9 += 3;
					}
					IL_273:
					l++;
					goto IL_279;
				}
				goto IL_273;
			}
			return;
		}
		uint num5 = *(uint*)(ptr2 - 16);
		uint num6 = *(uint*)(ptr2 - 120);
		uint[] array = new uint[(int)num];
		uint[] array2 = new uint[(int)num];
		uint[] array3 = new uint[(int)num];
		for (int n = 0; n < (int)num; n++)
		{
			<Module>.VirtualProtect(ptr2, 8, 64U, ref num3);
			Marshal.Copy(new byte[8], 0, (IntPtr)((void*)ptr2), 8);
			array[n] = *(uint*)(ptr2 + 12);
			array2[n] = *(uint*)(ptr2 + 8);
			array3[n] = *(uint*)(ptr2 + 20);
			ptr2 += 40;
		}
		if (num6 != 0U)
		{
			for (int num7 = 0; num7 < (int)num; num7++)
			{
				if (array[num7] <= num6 && num6 < array[num7] + array2[num7])
				{
					num6 = num6 - array[num7] + array3[num7];
					break;
				}
			}
			byte* ptr10 = ptr + num6;
			uint num8 = *(uint*)ptr10;
			for (int num9 = 0; num9 < (int)num; num9++)
			{
				if (array[num9] <= num8 && num8 < array[num9] + array2[num9])
				{
					num8 = num8 - array[num9] + array3[num9];
					break;
				}
			}
			byte* ptr11 = ptr + num8;
			uint num10 = *(uint*)(ptr10 + 12);
			for (int num11 = 0; num11 < (int)num; num11++)
			{
				if (array[num11] <= num10 && num10 < array[num11] + array2[num11])
				{
					num10 = num10 - array[num11] + array3[num11];
					break;
				}
			}
			uint num12 = *(uint*)ptr11 + 2U;
			for (int num13 = 0; num13 < (int)num; num13++)
			{
				if (array[num13] <= num12 && num12 < array[num13] + array2[num13])
				{
					num12 = num12 - array[num13] + array3[num13];
					break;
				}
			}
			<Module>.VirtualProtect(ptr + num10, 11, 64U, ref num3);
			*(int*)ptr3 = 1818522734;
			*(int*)(ptr3 + 4) = 1818504812;
			*(short*)(ptr3 + (IntPtr)4 * 2) = 108;
			ptr3[10] = 0;
			for (int num14 = 0; num14 < 11; num14++)
			{
				(ptr + num10)[num14] = ptr3[num14];
			}
			<Module>.VirtualProtect(ptr + num12, 11, 64U, ref num3);
			*(int*)ptr3 = 1866691662;
			*(int*)(ptr3 + 4) = 1852404846;
			*(short*)(ptr3 + (IntPtr)4 * 2) = 25973;
			ptr3[10] = 0;
			for (int num15 = 0; num15 < 11; num15++)
			{
				(ptr + num12)[num15] = ptr3[num15];
			}
		}
		for (int num16 = 0; num16 < (int)num; num16++)
		{
			if (array[num16] <= num5 && num5 < array[num16] + array2[num16])
			{
				num5 = num5 - array[num16] + array3[num16];
				IL_4F0:
				byte* ptr12 = ptr + num5;
				<Module>.VirtualProtect(ptr12, 72, 64U, ref num3);
				uint num17 = *(uint*)(ptr12 + 8);
				for (int num18 = 0; num18 < (int)num; num18++)
				{
					if (array[num18] <= num17 && num17 < array[num18] + array2[num18])
					{
						num17 = num17 - array[num18] + array3[num18];
						break;
					}
				}
				*(int*)ptr12 = 0;
				*(int*)(ptr12 + 4) = 0;
				*(int*)(ptr12 + (IntPtr)2 * 4) = 0;
				*(int*)(ptr12 + (IntPtr)3 * 4) = 0;
				byte* ptr13 = ptr + num17;
				<Module>.VirtualProtect(ptr13, 4, 64U, ref num3);
				*(int*)ptr13 = 0;
				ptr13 += 12;
				ptr13 += *(uint*)ptr13;
				ptr13 = (ptr13 + 7L & -4L);
				ptr13 += 2;
				ushort num19 = (ushort)(*ptr13);
				ptr13 += 2;
				int num20 = 0;
				IL_648:
				while (num20 < (int)num19)
				{
					<Module>.VirtualProtect(ptr13, 8, 64U, ref num3);
					ptr13 += 4;
					ptr13 += 4;
					int num21 = 0;
					while (num21 < 8)
					{
						<Module>.VirtualProtect(ptr13, 4, 64U, ref num3);
						*ptr13 = 0;
						ptr13++;
						if (*ptr13 != 0)
						{
							*ptr13 = 0;
							ptr13++;
							if (*ptr13 != 0)
							{
								*ptr13 = 0;
								ptr13++;
								if (*ptr13 != 0)
								{
									*ptr13 = 0;
									ptr13++;
									num21++;
									continue;
								}
								ptr13++;
							}
							else
							{
								ptr13 += 2;
							}
						}
						else
						{
							ptr13 += 3;
						}
						IL_642:
						num20++;
						goto IL_648;
					}
					goto IL_642;
				}
				return;
			}
		}
		goto IL_4F0;
	}

	// Token: 0x06000006 RID: 6 RVA: 0x000025CE File Offset: 0x000007CE
	static Type smethod_3(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x06000007 RID: 7 RVA: 0x000025CE File Offset: 0x000007CE
	static Type smethod_4(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x06000008 RID: 8 RVA: 0x000025D6 File Offset: 0x000007D6
	static MethodInfo smethod_5(Type type_0, string string_0, Type[] type_1)
	{
		return type_0.GetMethod(string_0, type_1);
	}

	// Token: 0x06000009 RID: 9 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_6(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x0600000A RID: 10 RVA: 0x000025E9 File Offset: 0x000007E9
	static object smethod_7(MethodBase methodBase_0, object object_0, object[] object_1)
	{
		return methodBase_0.Invoke(object_0, object_1);
	}

	// Token: 0x0600000B RID: 11 RVA: 0x000025F3 File Offset: 0x000007F3
	static bool smethod_8(object object_0, object object_1)
	{
		return object_0.Equals(object_1);
	}

	// Token: 0x0600000C RID: 12 RVA: 0x000025FC File Offset: 0x000007FC
	static void smethod_9(string string_0)
	{
		Environment.FailFast(string_0);
	}

	// Token: 0x0600000D RID: 13 RVA: 0x00002604 File Offset: 0x00000804
	static Thread smethod_10(ParameterizedThreadStart parameterizedThreadStart_0)
	{
		return new Thread(parameterizedThreadStart_0);
	}

	// Token: 0x0600000E RID: 14 RVA: 0x0000260C File Offset: 0x0000080C
	static void smethod_11(Thread thread_0, bool bool_0)
	{
		thread_0.IsBackground = bool_0;
	}

	// Token: 0x0600000F RID: 15 RVA: 0x00002615 File Offset: 0x00000815
	static void smethod_12(Thread thread_0, object object_0)
	{
		thread_0.Start(object_0);
	}

	// Token: 0x06000010 RID: 16 RVA: 0x00002604 File Offset: 0x00000804
	static Thread smethod_13(ParameterizedThreadStart parameterizedThreadStart_0)
	{
		return new Thread(parameterizedThreadStart_0);
	}

	// Token: 0x06000011 RID: 17 RVA: 0x0000260C File Offset: 0x0000080C
	static void smethod_14(Thread thread_0, bool bool_0)
	{
		thread_0.IsBackground = bool_0;
	}

	// Token: 0x06000012 RID: 18 RVA: 0x0000261E File Offset: 0x0000081E
	static Thread smethod_15()
	{
		return Thread.CurrentThread;
	}

	// Token: 0x06000013 RID: 19 RVA: 0x00002615 File Offset: 0x00000815
	static void smethod_16(Thread thread_0, object object_0)
	{
		thread_0.Start(object_0);
	}

	// Token: 0x06000014 RID: 20 RVA: 0x00002625 File Offset: 0x00000825
	static void smethod_17(int int_0)
	{
		Thread.Sleep(int_0);
	}

	// Token: 0x06000015 RID: 21 RVA: 0x0000262D File Offset: 0x0000082D
	static bool smethod_18()
	{
		return Debugger.IsAttached;
	}

	// Token: 0x06000016 RID: 22 RVA: 0x00002634 File Offset: 0x00000834
	static bool smethod_19()
	{
		return Debugger.IsLogging();
	}

	// Token: 0x06000017 RID: 23 RVA: 0x000025FC File Offset: 0x000007FC
	static void smethod_20(string string_0)
	{
		Environment.FailFast(string_0);
	}

	// Token: 0x06000018 RID: 24 RVA: 0x0000263B File Offset: 0x0000083B
	static bool smethod_21(Thread thread_0)
	{
		return thread_0.IsAlive;
	}

	// Token: 0x06000019 RID: 25 RVA: 0x000025FC File Offset: 0x000007FC
	static void smethod_22(string string_0)
	{
		Environment.FailFast(string_0);
	}

	// Token: 0x0600001A RID: 26 RVA: 0x00002625 File Offset: 0x00000825
	static void smethod_23(int int_0)
	{
		Thread.Sleep(int_0);
	}

	// Token: 0x0600001B RID: 27 RVA: 0x000025CE File Offset: 0x000007CE
	static Type smethod_24(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00002643 File Offset: 0x00000843
	static Module smethod_25(Type type_0)
	{
		return type_0.Module;
	}

	// Token: 0x0600001D RID: 29 RVA: 0x0000264B File Offset: 0x0000084B
	static IntPtr smethod_26(Module module_0)
	{
		return Marshal.GetHINSTANCE(module_0);
	}

	// Token: 0x0600001E RID: 30 RVA: 0x00002653 File Offset: 0x00000853
	static string smethod_27(Module module_0)
	{
		return module_0.FullyQualifiedName;
	}

	// Token: 0x0600001F RID: 31 RVA: 0x0000265B File Offset: 0x0000085B
	static char smethod_28(string string_0, int int_0)
	{
		return string_0[int_0];
	}

	// Token: 0x06000020 RID: 32 RVA: 0x00002664 File Offset: 0x00000864
	static void smethod_29(byte[] byte_0, int int_0, IntPtr intptr_0, int int_1)
	{
		Marshal.Copy(byte_0, int_0, intptr_0, int_1);
	}

	// Token: 0x06000021 RID: 33 RVA: 0x00002664 File Offset: 0x00000864
	static void smethod_30(byte[] byte_0, int int_0, IntPtr intptr_0, int int_1)
	{
		Marshal.Copy(byte_0, int_0, intptr_0, int_1);
	}

	// Token: 0x06000022 RID: 34 RVA: 0x0000A544 File Offset: 0x00008744
	internal static byte[] smethod_31(byte[] byte_0)
	{
		MemoryStream memoryStream = new MemoryStream(byte_0);
		<Module>.Class1 @class = new <Module>.Class1();
		byte[] array = new byte[5];
		memoryStream.Read(array, 0, 5);
		@class.method_5(array);
		long num = 0L;
		for (int i = 0; i < 8; i++)
		{
			int num2 = memoryStream.ReadByte();
			num |= (long)((long)((ulong)((byte)num2)) << 8 * i);
		}
		byte[] array2 = new byte[(int)num];
		MemoryStream stream_ = new MemoryStream(array2, true);
		long long_ = memoryStream.Length - 13L;
		@class.method_4(memoryStream, stream_, long_, num);
		return array2;
	}

	// Token: 0x06000023 RID: 35 RVA: 0x0000A5D8 File Offset: 0x000087D8
	internal static void smethod_32()
	{
		uint num = 192U;
		uint[] array = new uint[]
		{
			3125107139U,
			1380748222U,
			1715870102U,
			3160615843U,
			692324611U,
			3644876629U,
			3938020715U,
			4211164342U,
			632303589U,
			1799810982U,
			2693524075U,
			2864390006U,
			1069954539U,
			3628069463U,
			1017900520U,
			3227747744U,
			4253062834U,
			1890010005U,
			2617763795U,
			3471602192U,
			1187250183U,
			471731055U,
			1113942079U,
			2802537873U,
			2632032378U,
			1253476890U,
			4073848438U,
			2981679475U,
			1729669144U,
			4048733554U,
			2308642962U,
			3548100838U,
			2842556094U,
			254965920U,
			452123483U,
			2270975854U,
			294624606U,
			4273385468U,
			103261681U,
			3478795095U,
			759533378U,
			3699824775U,
			4054565672U,
			3003010379U,
			3934903931U,
			1855332020U,
			4139773413U,
			3645783519U,
			2340243740U,
			130867179U,
			2328604850U,
			71774847U,
			362915156U,
			3770761216U,
			2009327867U,
			3866914326U,
			2809080766U,
			1651361927U,
			1788052789U,
			3250011621U,
			2449872760U,
			1824734332U,
			2152624655U,
			1709635924U,
			1228168721U,
			3468583636U,
			3769366059U,
			3535351045U,
			3223912520U,
			4148656411U,
			3177782920U,
			2866338318U,
			103337394U,
			4172099305U,
			4073406381U,
			3691315852U,
			2218221499U,
			1968740535U,
			3821922795U,
			177928007U,
			2388407391U,
			254127154U,
			1483986038U,
			553609061U,
			1244765085U,
			2867506927U,
			1165489009U,
			1342139847U,
			62652351U,
			3970700837U,
			447847697U,
			3791496700U,
			1432489227U,
			2634505876U,
			158351213U,
			3456075415U,
			4052742795U,
			2621910245U,
			1098171965U,
			926021340U,
			3103808984U,
			1426256915U,
			2426867909U,
			870894937U,
			3091691393U,
			2751094514U,
			3667856707U,
			1672378628U,
			2862958624U,
			370946311U,
			4257995129U,
			3436696660U,
			2090156521U,
			816652672U,
			2210835329U,
			2001744989U,
			3658938841U,
			3118630710U,
			3452628850U,
			1233744315U,
			391007120U,
			906878521U,
			1686120497U,
			1737995913U,
			3159127722U,
			4212950581U,
			2296854016U,
			2879282430U,
			2028177264U,
			1932296750U,
			2790398047U,
			1855796605U,
			462799304U,
			3573444239U,
			3040037002U,
			1310343166U,
			1136858321U,
			1803516743U,
			1071452864U,
			1436582276U,
			1554595677U,
			1622784209U,
			1223568015U,
			3715173279U,
			957759671U,
			3679333253U,
			3826334916U,
			3190285581U,
			3991909756U,
			3230735861U,
			4163525906U,
			1664302089U,
			2963233719U,
			1934793885U,
			1428076658U,
			1272653335U,
			3771168894U,
			4198995922U,
			1016148729U,
			1348266878U,
			521237597U,
			3441232138U,
			1807704824U,
			285957575U,
			875671114U,
			2899519983U,
			1506443826U,
			725219237U,
			4174436531U,
			3567492348U,
			2628451440U,
			1660567958U,
			1986680645U,
			2275466590U,
			548896001U,
			1777308537U,
			1439282042U,
			770208179U,
			1304148751U,
			1351418933U,
			875671121U,
			2899519983U,
			1506443826U,
			725219237U,
			4174436531U,
			3567492348U,
			2628451440U,
			1660567958U,
			1986680645U,
			2275466590U,
			548896001U,
			1777308537U
		};
		uint[] array2 = new uint[16];
		uint num2 = 138746801U;
		for (int i = 0; i < 16; i++)
		{
			num2 ^= num2 >> 13;
			num2 ^= num2 << 25;
			num2 ^= num2 >> 27;
			array2[i] = num2;
		}
		int num3 = 0;
		int num4 = 0;
		uint[] array3 = new uint[16];
		byte[] array4 = new byte[num * 4U];
		while ((long)num3 < (long)((ulong)num))
		{
			for (int j = 0; j < 16; j++)
			{
				array3[j] = array[num3 + j];
			}
			array3[0] = (array3[0] ^ array2[0]);
			array3[1] = (array3[1] ^ array2[1]);
			array3[2] = (array3[2] ^ array2[2]);
			array3[3] = (array3[3] ^ array2[3]);
			array3[4] = (array3[4] ^ array2[4]);
			array3[5] = (array3[5] ^ array2[5]);
			array3[6] = (array3[6] ^ array2[6]);
			array3[7] = (array3[7] ^ array2[7]);
			array3[8] = (array3[8] ^ array2[8]);
			array3[9] = (array3[9] ^ array2[9]);
			array3[10] = (array3[10] ^ array2[10]);
			array3[11] = (array3[11] ^ array2[11]);
			array3[12] = (array3[12] ^ array2[12]);
			array3[13] = (array3[13] ^ array2[13]);
			array3[14] = (array3[14] ^ array2[14]);
			array3[15] = (array3[15] ^ array2[15]);
			for (int k = 0; k < 16; k++)
			{
				uint num5 = array3[k];
				array4[num4++] = (byte)num5;
				array4[num4++] = (byte)(num5 >> 8);
				array4[num4++] = (byte)(num5 >> 16);
				array4[num4++] = (byte)(num5 >> 24);
				array2[k] ^= num5;
			}
			num3 += 16;
		}
		<Module>.assembly_0 = Assembly.Load(<Module>.smethod_31(array4));
		AppDomain.CurrentDomain.ResourceResolve += <Module>.smethod_33;
	}

	// Token: 0x06000024 RID: 36 RVA: 0x0000266F File Offset: 0x0000086F
	internal static Assembly smethod_33(object object_0, ResolveEventArgs resolveEventArgs_0)
	{
		if (Array.IndexOf<string>(<Module>.assembly_0.GetManifestResourceNames(), resolveEventArgs_0.Name) != -1)
		{
			return <Module>.assembly_0;
		}
		return null;
	}

	// Token: 0x06000025 RID: 37
	[DllImport("kernel32.dll", EntryPoint = "VirtualProtect")]
	internal static extern bool VirtualProtect_1(IntPtr intptr_0, uint uint_0, uint uint_1, ref uint uint_2);

	// Token: 0x06000026 RID: 38 RVA: 0x0000A7E4 File Offset: 0x000089E4
	internal unsafe static void smethod_34()
	{
		Module module = typeof(<Module>).Module;
		string fullyQualifiedName = module.FullyQualifiedName;
		bool flag = fullyQualifiedName.Length > 0 && fullyQualifiedName[0] == '<';
		byte* ptr = (byte*)((void*)Marshal.GetHINSTANCE(module));
		byte* ptr2 = ptr + *(uint*)(ptr + 60);
		ushort num = *(ushort*)(ptr2 + 6);
		ushort num2 = *(ushort*)(ptr2 + 20);
		uint* ptr3 = null;
		uint num3 = 0U;
		uint* ptr4 = (uint*)(ptr2 + 24 + num2);
		uint num4 = 403027598U;
		uint num5 = 3538804575U;
		uint num6 = 1847990289U;
		uint num7 = 1611431972U;
		for (int i = 0; i < (int)num; i++)
		{
			uint num8 = *(ptr4++) * *(ptr4++);
			if (num8 != 2828791950U)
			{
				if (num8 != 0U)
				{
					uint* ptr5 = (uint*)(ptr + (UIntPtr)(flag ? ptr4[3] : ptr4[1]) / 4);
					uint num9 = ptr4[2] >> 2;
					for (uint num10 = 0U; num10 < num9; num10 += 1U)
					{
						uint num11 = (num4 ^ *(ptr5++)) + num5 + num6 * num7;
						num4 = num5;
						num5 = num7;
						num7 = num11;
					}
				}
			}
			else
			{
				ptr3 = (uint*)(ptr + (UIntPtr)(flag ? ptr4[3] : ptr4[1]) / 4);
				num3 = ((!flag) ? (*ptr4) : ptr4[2]) >> 2;
			}
			ptr4 += 8;
		}
		uint[] array = new uint[16];
		uint[] array2 = new uint[16];
		for (int j = 0; j < 16; j++)
		{
			array[j] = num7;
			array2[j] = num5;
			num4 = (num5 >> 5 | num5 << 27);
			num5 = (num6 >> 3 | num6 << 29);
			num6 = (num7 >> 7 | num7 << 25);
			num7 = (num4 >> 11 | num4 << 21);
		}
		array[0] = (array[0] ^ array2[0]);
		array[1] = array[1] * array2[1];
		array[2] = array[2] + array2[2];
		array[3] = (array[3] ^ array2[3]);
		array[4] = array[4] * array2[4];
		array[5] = array[5] + array2[5];
		array[6] = (array[6] ^ array2[6]);
		array[7] = array[7] * array2[7];
		array[8] = array[8] + array2[8];
		array[9] = (array[9] ^ array2[9]);
		array[10] = array[10] * array2[10];
		array[11] = array[11] + array2[11];
		array[12] = (array[12] ^ array2[12]);
		array[13] = array[13] * array2[13];
		array[14] = array[14] + array2[14];
		array[15] = (array[15] ^ array2[15]);
		uint num12 = 64U;
		<Module>.VirtualProtect_1((IntPtr)((void*)ptr3), num3 << 2, 64U, ref num12);
		if (num12 == 64U)
		{
			return;
		}
		uint num13 = 0U;
		for (uint num14 = 0U; num14 < num3; num14 += 1U)
		{
			*ptr3 ^= array[(int)(num13 & 15U)];
			array[(int)(num13 & 15U)] = (array[(int)(num13 & 15U)] ^ *(ptr3++)) + 1035675673U;
			num13 += 1U;
		}
	}

	// Token: 0x04000001 RID: 1
	internal static Assembly assembly_0;

	// Token: 0x04000002 RID: 2 RVA: 0x000020D0 File Offset: 0x000002D0
	internal static <Module>.Struct4 struct4_0;

	// Token: 0x02000002 RID: 2
	internal struct Struct0
	{
		// Token: 0x06000027 RID: 39 RVA: 0x00002690 File Offset: 0x00000890
		internal void method_0()
		{
			this.uint_0 = 1024U;
		}

		// Token: 0x06000028 RID: 40 RVA: 0x0000AADC File Offset: 0x00008CDC
		internal uint method_1(<Module>.Class0 class0_0)
		{
			uint num = (class0_0.uint_1 >> 11) * this.uint_0;
			if (class0_0.uint_0 < num)
			{
				class0_0.uint_1 = num;
				this.uint_0 += 2048U - this.uint_0 >> 5;
				if (class0_0.uint_1 < 16777216U)
				{
					class0_0.uint_0 = (class0_0.uint_0 << 8 | (uint)((byte)class0_0.stream_0.ReadByte()));
					class0_0.uint_1 <<= 8;
				}
				return 0U;
			}
			class0_0.uint_1 -= num;
			class0_0.uint_0 -= num;
			this.uint_0 -= this.uint_0 >> 5;
			if (class0_0.uint_1 < 16777216U)
			{
				class0_0.uint_0 = (class0_0.uint_0 << 8 | (uint)((byte)class0_0.stream_0.ReadByte()));
				class0_0.uint_1 <<= 8;
			}
			return 1U;
		}

		// Token: 0x04000003 RID: 3
		internal uint uint_0;
	}

	// Token: 0x02000003 RID: 3
	internal struct Struct1
	{
		// Token: 0x06000029 RID: 41 RVA: 0x0000269D File Offset: 0x0000089D
		internal Struct1(int int_1)
		{
			this.int_0 = int_1;
			this.struct0_0 = new <Module>.Struct0[1 << int_1];
		}

		// Token: 0x0600002A RID: 42 RVA: 0x0000ABC8 File Offset: 0x00008DC8
		internal void method_0()
		{
			uint num = 1U;
			while ((ulong)num < (ulong)(1L << (this.int_0 & 31)))
			{
				this.struct0_0[(int)num].method_0();
				num += 1U;
			}
		}

		// Token: 0x0600002B RID: 43 RVA: 0x0000AC00 File Offset: 0x00008E00
		internal uint method_1(<Module>.Class0 class0_0)
		{
			uint num = 1U;
			for (int i = this.int_0; i > 0; i--)
			{
				num = (num << 1) + this.struct0_0[(int)num].method_1(class0_0);
			}
			return num - (1U << this.int_0);
		}

		// Token: 0x0600002C RID: 44 RVA: 0x0000AC44 File Offset: 0x00008E44
		internal uint method_2(<Module>.Class0 class0_0)
		{
			uint num = 1U;
			uint num2 = 0U;
			for (int i = 0; i < this.int_0; i++)
			{
				uint num3 = this.struct0_0[(int)num].method_1(class0_0);
				num <<= 1;
				num += num3;
				num2 |= num3 << i;
			}
			return num2;
		}

		// Token: 0x0600002D RID: 45 RVA: 0x0000AC8C File Offset: 0x00008E8C
		internal static uint smethod_0(<Module>.Struct0[] struct0_1, uint uint_0, <Module>.Class0 class0_0, int int_1)
		{
			uint num = 1U;
			uint num2 = 0U;
			for (int i = 0; i < int_1; i++)
			{
				uint num3 = struct0_1[(int)(uint_0 + num)].method_1(class0_0);
				num <<= 1;
				num += num3;
				num2 |= num3 << i;
			}
			return num2;
		}

		// Token: 0x04000004 RID: 4
		internal readonly <Module>.Struct0[] struct0_0;

		// Token: 0x04000005 RID: 5
		internal readonly int int_0;
	}

	// Token: 0x02000004 RID: 4
	internal class Class0
	{
		// Token: 0x0600002E RID: 46 RVA: 0x0000ACCC File Offset: 0x00008ECC
		internal void method_0(Stream stream_1)
		{
			this.stream_0 = stream_1;
			this.uint_0 = 0U;
			this.uint_1 = uint.MaxValue;
			for (int i = 0; i < 5; i++)
			{
				this.uint_0 = (this.uint_0 << 8 | (uint)((byte)this.stream_0.ReadByte()));
			}
		}

		// Token: 0x0600002F RID: 47 RVA: 0x000026B7 File Offset: 0x000008B7
		internal void method_1()
		{
			this.stream_0 = null;
		}

		// Token: 0x06000030 RID: 48 RVA: 0x000026C0 File Offset: 0x000008C0
		internal void method_2()
		{
			while (this.uint_1 < 16777216U)
			{
				this.uint_0 = (this.uint_0 << 8 | (uint)((byte)this.stream_0.ReadByte()));
				this.uint_1 <<= 8;
			}
		}

		// Token: 0x06000031 RID: 49 RVA: 0x0000AD18 File Offset: 0x00008F18
		internal uint method_3(int int_0)
		{
			uint num = this.uint_1;
			uint num2 = this.uint_0;
			uint num3 = 0U;
			for (int i = int_0; i > 0; i--)
			{
				num >>= 1;
				uint num4 = num2 - num >> 31;
				num2 -= (num & num4 - 1U);
				num3 = (num3 << 1 | 1U - num4);
				if (num < 16777216U)
				{
					num2 = (num2 << 8 | (uint)((byte)this.stream_0.ReadByte()));
					num <<= 8;
				}
			}
			this.uint_1 = num;
			this.uint_0 = num2;
			return num3;
		}

		// Token: 0x06000032 RID: 50 RVA: 0x000026FB File Offset: 0x000008FB
		internal Class0()
		{
		}

		// Token: 0x04000006 RID: 6
		internal uint uint_0;

		// Token: 0x04000007 RID: 7
		internal uint uint_1;

		// Token: 0x04000008 RID: 8
		internal Stream stream_0;
	}

	// Token: 0x02000005 RID: 5
	internal class Class1
	{
		// Token: 0x06000033 RID: 51 RVA: 0x0000AD8C File Offset: 0x00008F8C
		internal Class1()
		{
			this.uint_0 = uint.MaxValue;
			int num = 0;
			while ((long)num < 4L)
			{
				this.struct1_0[num] = new <Module>.Struct1(6);
				num++;
			}
		}

		// Token: 0x06000034 RID: 52 RVA: 0x0000AE80 File Offset: 0x00009080
		internal void method_0(uint uint_3)
		{
			if (this.uint_0 != uint_3)
			{
				this.uint_0 = uint_3;
				this.uint_1 = Math.Max(this.uint_0, 1U);
				uint uint_4 = Math.Max(this.uint_1, 4096U);
				this.class4_0.method_0(uint_4);
			}
		}

		// Token: 0x06000035 RID: 53 RVA: 0x00002703 File Offset: 0x00000903
		internal void method_1(int int_0, int int_1)
		{
			this.class3_0.method_0(int_0, int_1);
		}

		// Token: 0x06000036 RID: 54 RVA: 0x0000AECC File Offset: 0x000090CC
		internal void method_2(int int_0)
		{
			uint num = 1U << int_0;
			this.class2_0.method_0(num);
			this.class2_1.method_0(num);
			this.uint_2 = num - 1U;
		}

		// Token: 0x06000037 RID: 55 RVA: 0x0000AF04 File Offset: 0x00009104
		internal void method_3(Stream stream_0, Stream stream_1)
		{
			this.class0_0.method_0(stream_0);
			this.class4_0.method_1(stream_1, this.bool_0);
			for (uint num = 0U; num < 12U; num += 1U)
			{
				for (uint num2 = 0U; num2 <= this.uint_2; num2 += 1U)
				{
					uint num3 = (num << 4) + num2;
					this.struct0_0[(int)num3].method_0();
					this.struct0_1[(int)num3].method_0();
				}
				this.struct0_2[(int)num].method_0();
				this.struct0_3[(int)num].method_0();
				this.struct0_4[(int)num].method_0();
				this.struct0_5[(int)num].method_0();
			}
			this.class3_0.method_1();
			for (uint num = 0U; num < 4U; num += 1U)
			{
				this.struct1_0[(int)num].method_0();
			}
			for (uint num = 0U; num < 114U; num += 1U)
			{
				this.struct0_6[(int)num].method_0();
			}
			this.class2_0.method_1();
			this.class2_1.method_1();
			this.struct1_1.method_0();
		}

		// Token: 0x06000038 RID: 56 RVA: 0x0000B028 File Offset: 0x00009228
		internal void method_4(Stream stream_0, Stream stream_1, long long_0, long long_1)
		{
			this.method_3(stream_0, stream_1);
			<Module>.Struct3 @struct = default(<Module>.Struct3);
			@struct.method_0();
			uint num = 0U;
			uint num2 = 0U;
			uint num3 = 0U;
			uint num4 = 0U;
			ulong num5 = 0UL;
			if (0L < long_1)
			{
				this.struct0_0[(int)((int)@struct.uint_0 << 4)].method_1(this.class0_0);
				@struct.method_1();
				byte byte_ = this.class3_0.method_3(this.class0_0, 0U, 0);
				this.class4_0.method_5(byte_);
				num5 += 1UL;
			}
			while (num5 < (ulong)long_1)
			{
				uint num6 = (uint)num5 & this.uint_2;
				if (this.struct0_0[(int)((@struct.uint_0 << 4) + num6)].method_1(this.class0_0) != 0U)
				{
					uint num8;
					if (this.struct0_2[(int)@struct.uint_0].method_1(this.class0_0) == 1U)
					{
						if (this.struct0_3[(int)@struct.uint_0].method_1(this.class0_0) != 0U)
						{
							uint num7;
							if (this.struct0_4[(int)@struct.uint_0].method_1(this.class0_0) == 0U)
							{
								num7 = num2;
							}
							else
							{
								if (this.struct0_5[(int)@struct.uint_0].method_1(this.class0_0) != 0U)
								{
									num7 = num4;
									num4 = num3;
								}
								else
								{
									num7 = num3;
								}
								num3 = num2;
							}
							num2 = num;
							num = num7;
						}
						else if (this.struct0_1[(int)((@struct.uint_0 << 4) + num6)].method_1(this.class0_0) == 0U)
						{
							@struct.method_4();
							this.class4_0.method_5(this.class4_0.method_6(num));
							num5 += 1UL;
							continue;
						}
						num8 = this.class2_1.method_2(this.class0_0, num6) + 2U;
						@struct.method_3();
					}
					else
					{
						num4 = num3;
						num3 = num2;
						num2 = num;
						num8 = 2U + this.class2_0.method_2(this.class0_0, num6);
						@struct.method_2();
						uint num9 = this.struct1_0[(int)<Module>.Class1.smethod_0(num8)].method_1(this.class0_0);
						if (num9 >= 4U)
						{
							int num10 = (int)((num9 >> 1) - 1U);
							num = (2U | (num9 & 1U)) << num10;
							if (num9 < 14U)
							{
								num += <Module>.Struct1.smethod_0(this.struct0_6, num - num9 - 1U, this.class0_0, num10);
							}
							else
							{
								num += this.class0_0.method_3(num10 - 4) << 4;
								num += this.struct1_1.method_2(this.class0_0);
							}
						}
						else
						{
							num = num9;
						}
					}
					if (((ulong)num >= num5 || num >= this.uint_1) && num == 4294967295U)
					{
						break;
					}
					this.class4_0.method_4(num, num8);
					num5 += (ulong)num8;
				}
				else
				{
					byte byte_2 = this.class4_0.method_6(0U);
					byte byte_3;
					if (@struct.method_5())
					{
						byte_3 = this.class3_0.method_3(this.class0_0, (uint)num5, byte_2);
					}
					else
					{
						byte_3 = this.class3_0.method_4(this.class0_0, (uint)num5, byte_2, this.class4_0.method_6(num));
					}
					this.class4_0.method_5(byte_3);
					@struct.method_1();
					num5 += 1UL;
				}
			}
			this.class4_0.method_3();
			this.class4_0.method_2();
			this.class0_0.method_1();
		}

		// Token: 0x06000039 RID: 57 RVA: 0x0000B390 File Offset: 0x00009590
		internal void method_5(byte[] byte_0)
		{
			int int_ = (int)(byte_0[0] % 9);
			byte b = byte_0[0] / 9;
			int int_2 = (int)(b % 5);
			int int_3 = (int)(b / 5);
			uint num = 0U;
			for (int i = 0; i < 4; i++)
			{
				num += (uint)((uint)byte_0[1 + i] << i * 8);
			}
			this.method_0(num);
			this.method_1(int_2, int_);
			this.method_2(int_3);
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00002712 File Offset: 0x00000912
		internal static uint smethod_0(uint uint_3)
		{
			uint_3 -= 2U;
			if (uint_3 < 4U)
			{
				return uint_3;
			}
			return 3U;
		}

		// Token: 0x04000009 RID: 9
		internal readonly <Module>.Struct0[] struct0_0 = new <Module>.Struct0[192];

		// Token: 0x0400000A RID: 10
		internal readonly <Module>.Struct0[] struct0_1 = new <Module>.Struct0[192];

		// Token: 0x0400000B RID: 11
		internal readonly <Module>.Struct0[] struct0_2 = new <Module>.Struct0[12];

		// Token: 0x0400000C RID: 12
		internal readonly <Module>.Struct0[] struct0_3 = new <Module>.Struct0[12];

		// Token: 0x0400000D RID: 13
		internal readonly <Module>.Struct0[] struct0_4 = new <Module>.Struct0[12];

		// Token: 0x0400000E RID: 14
		internal readonly <Module>.Struct0[] struct0_5 = new <Module>.Struct0[12];

		// Token: 0x0400000F RID: 15
		internal readonly <Module>.Class1.Class2 class2_0 = new <Module>.Class1.Class2();

		// Token: 0x04000010 RID: 16
		internal readonly <Module>.Class1.Class3 class3_0 = new <Module>.Class1.Class3();

		// Token: 0x04000011 RID: 17
		internal readonly <Module>.Class4 class4_0 = new <Module>.Class4();

		// Token: 0x04000012 RID: 18
		internal readonly <Module>.Struct0[] struct0_6 = new <Module>.Struct0[114];

		// Token: 0x04000013 RID: 19
		internal readonly <Module>.Struct1[] struct1_0 = new <Module>.Struct1[4];

		// Token: 0x04000014 RID: 20
		internal readonly <Module>.Class0 class0_0 = new <Module>.Class0();

		// Token: 0x04000015 RID: 21
		internal readonly <Module>.Class1.Class2 class2_1 = new <Module>.Class1.Class2();

		// Token: 0x04000016 RID: 22
		internal bool bool_0;

		// Token: 0x04000017 RID: 23
		internal uint uint_0;

		// Token: 0x04000018 RID: 24
		internal uint uint_1;

		// Token: 0x04000019 RID: 25
		internal <Module>.Struct1 struct1_1 = new <Module>.Struct1(4);

		// Token: 0x0400001A RID: 26
		internal uint uint_2;

		// Token: 0x02000006 RID: 6
		internal class Class2
		{
			// Token: 0x0600003B RID: 59 RVA: 0x0000B3EC File Offset: 0x000095EC
			internal void method_0(uint uint_1)
			{
				uint num = this.uint_0;
				if (num < uint_1)
				{
					this.struct1_0[(int)num] = new <Module>.Struct1(3);
					this.struct1_1[(int)num] = new <Module>.Struct1(3);
					num += 1U;
				}
				this.uint_0 = uint_1;
			}

			// Token: 0x0600003C RID: 60 RVA: 0x0000B434 File Offset: 0x00009634
			internal void method_1()
			{
				this.struct0_0.method_0();
				for (uint num = 0U; num < this.uint_0; num += 1U)
				{
					this.struct1_0[(int)num].method_0();
					this.struct1_1[(int)num].method_0();
				}
				this.struct0_1.method_0();
				this.struct1_2.method_0();
			}

			// Token: 0x0600003D RID: 61 RVA: 0x0000B498 File Offset: 0x00009698
			internal uint method_2(<Module>.Class0 class0_0, uint uint_1)
			{
				if (this.struct0_0.method_1(class0_0) == 0U)
				{
					return this.struct1_0[(int)uint_1].method_1(class0_0);
				}
				uint num = 8U;
				if (this.struct0_1.method_1(class0_0) == 0U)
				{
					num += this.struct1_1[(int)uint_1].method_1(class0_0);
				}
				else
				{
					num += 8U;
					num += this.struct1_2.method_1(class0_0);
				}
				return num;
			}

			// Token: 0x0600003E RID: 62 RVA: 0x00002720 File Offset: 0x00000920
			internal Class2()
			{
			}

			// Token: 0x0400001B RID: 27
			internal readonly <Module>.Struct1[] struct1_0 = new <Module>.Struct1[16];

			// Token: 0x0400001C RID: 28
			internal readonly <Module>.Struct1[] struct1_1 = new <Module>.Struct1[16];

			// Token: 0x0400001D RID: 29
			internal <Module>.Struct0 struct0_0;

			// Token: 0x0400001E RID: 30
			internal <Module>.Struct0 struct0_1;

			// Token: 0x0400001F RID: 31
			internal <Module>.Struct1 struct1_2 = new <Module>.Struct1(8);

			// Token: 0x04000020 RID: 32
			internal uint uint_0;
		}

		// Token: 0x02000007 RID: 7
		internal class Class3
		{
			// Token: 0x0600003F RID: 63 RVA: 0x0000B504 File Offset: 0x00009704
			internal void method_0(int int_2, int int_3)
			{
				if (this.struct2_0 != null)
				{
					if (this.int_1 == int_3)
					{
						if (this.int_0 == int_2)
						{
							return;
						}
					}
				}
				this.int_0 = int_2;
				this.uint_0 = (1U << int_2) - 1U;
				this.int_1 = int_3;
				uint num = 1U << this.int_1 + this.int_0;
				this.struct2_0 = new <Module>.Class1.Class3.Struct2[num];
				for (uint num2 = 0U; num2 < num; num2 += 1U)
				{
					this.struct2_0[(int)num2].method_0();
				}
			}

			// Token: 0x06000040 RID: 64 RVA: 0x0000B588 File Offset: 0x00009788
			internal void method_1()
			{
				uint num = 1U << this.int_1 + this.int_0;
				for (uint num2 = 0U; num2 < num; num2 += 1U)
				{
					this.struct2_0[(int)num2].method_1();
				}
			}

			// Token: 0x06000041 RID: 65 RVA: 0x0000274E File Offset: 0x0000094E
			internal uint method_2(uint uint_1, byte byte_0)
			{
				return ((uint_1 & this.uint_0) << this.int_1) + (uint)(byte_0 >> 8 - this.int_1);
			}

			// Token: 0x06000042 RID: 66 RVA: 0x00002770 File Offset: 0x00000970
			internal byte method_3(<Module>.Class0 class0_0, uint uint_1, byte byte_0)
			{
				return this.struct2_0[(int)this.method_2(uint_1, byte_0)].method_2(class0_0);
			}

			// Token: 0x06000043 RID: 67 RVA: 0x0000278B File Offset: 0x0000098B
			internal byte method_4(<Module>.Class0 class0_0, uint uint_1, byte byte_0, byte byte_1)
			{
				return this.struct2_0[(int)this.method_2(uint_1, byte_0)].method_3(class0_0, byte_1);
			}

			// Token: 0x06000044 RID: 68 RVA: 0x000026FB File Offset: 0x000008FB
			internal Class3()
			{
			}

			// Token: 0x04000021 RID: 33
			internal <Module>.Class1.Class3.Struct2[] struct2_0;

			// Token: 0x04000022 RID: 34
			internal int int_0;

			// Token: 0x04000023 RID: 35
			internal int int_1;

			// Token: 0x04000024 RID: 36
			internal uint uint_0;

			// Token: 0x02000008 RID: 8
			internal struct Struct2
			{
				// Token: 0x06000045 RID: 69 RVA: 0x000027A8 File Offset: 0x000009A8
				internal void method_0()
				{
					this.struct0_0 = new <Module>.Struct0[768];
				}

				// Token: 0x06000046 RID: 70 RVA: 0x0000B5C8 File Offset: 0x000097C8
				internal void method_1()
				{
					for (int i = 0; i < 768; i++)
					{
						this.struct0_0[i].method_0();
					}
				}

				// Token: 0x06000047 RID: 71 RVA: 0x0000B5F8 File Offset: 0x000097F8
				internal byte method_2(<Module>.Class0 class0_0)
				{
					uint num = 2U | this.struct0_0[1].method_1(class0_0);
					if (num < 256U)
					{
					}
					return (byte)num;
				}

				// Token: 0x06000048 RID: 72 RVA: 0x0000B628 File Offset: 0x00009828
				internal byte method_3(<Module>.Class0 class0_0, byte byte_0)
				{
					uint num = 1U;
					for (;;)
					{
						uint num2 = (uint)(byte_0 >> 7 & 1);
						byte_0 = (byte)(byte_0 << 1);
						uint num3 = this.struct0_0[(int)((1U + num2 << 8) + num)].method_1(class0_0);
						num = (num << 1 | num3);
						if (num2 != num3)
						{
							break;
						}
						if (num >= 256U)
						{
							goto IL_5C;
						}
					}
					while (num < 256U)
					{
						num = (num << 1 | this.struct0_0[(int)num].method_1(class0_0));
					}
					IL_5C:
					return (byte)num;
				}

				// Token: 0x04000025 RID: 37
				internal <Module>.Struct0[] struct0_0;
			}
		}
	}

	// Token: 0x02000009 RID: 9
	internal class Class4
	{
		// Token: 0x06000049 RID: 73 RVA: 0x000027BA File Offset: 0x000009BA
		internal void method_0(uint uint_3)
		{
			if (this.uint_2 != uint_3)
			{
				this.byte_0 = new byte[uint_3];
			}
			this.uint_2 = uint_3;
			this.uint_0 = 0U;
			this.uint_1 = 0U;
		}

		// Token: 0x0600004A RID: 74 RVA: 0x000027E6 File Offset: 0x000009E6
		internal void method_1(Stream stream_1, bool bool_0)
		{
			this.method_2();
			this.stream_0 = stream_1;
			if (!bool_0)
			{
				this.uint_1 = 0U;
				this.uint_0 = 0U;
			}
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00002806 File Offset: 0x00000A06
		internal void method_2()
		{
			this.method_3();
			this.stream_0 = null;
			Buffer.BlockCopy(new byte[this.byte_0.Length], 0, this.byte_0, 0, this.byte_0.Length);
		}

		// Token: 0x0600004C RID: 76 RVA: 0x0000B694 File Offset: 0x00009894
		internal void method_3()
		{
			uint num = this.uint_0 - this.uint_1;
			if (num != 0U)
			{
				this.stream_0.Write(this.byte_0, (int)this.uint_1, (int)num);
				if (this.uint_0 >= this.uint_2)
				{
					this.uint_0 = 0U;
				}
				this.uint_1 = this.uint_0;
				return;
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x0000B6EC File Offset: 0x000098EC
		internal void method_4(uint uint_3, uint uint_4)
		{
			uint num = this.uint_0 - uint_3 - 1U;
			if (num >= this.uint_2)
			{
				num += this.uint_2;
			}
			while (uint_4 > 0U)
			{
				if (num >= this.uint_2)
				{
					num = 0U;
				}
				byte[] array = this.byte_0;
				uint num2 = this.uint_0;
				this.uint_0 = num2 + 1U;
				array[(int)num2] = this.byte_0[(int)num++];
				if (this.uint_0 >= this.uint_2)
				{
					this.method_3();
				}
				uint_4 -= 1U;
			}
		}

		// Token: 0x0600004E RID: 78 RVA: 0x0000B764 File Offset: 0x00009964
		internal void method_5(byte byte_1)
		{
			byte[] array = this.byte_0;
			uint num = this.uint_0;
			this.uint_0 = num + 1U;
			array[(int)num] = byte_1;
			if (this.uint_0 >= this.uint_2)
			{
				this.method_3();
			}
		}

		// Token: 0x0600004F RID: 79 RVA: 0x0000B7A0 File Offset: 0x000099A0
		internal byte method_6(uint uint_3)
		{
			uint num = this.uint_0 - uint_3 - 1U;
			if (num >= this.uint_2)
			{
				num += this.uint_2;
			}
			return this.byte_0[(int)num];
		}

		// Token: 0x06000050 RID: 80 RVA: 0x000026FB File Offset: 0x000008FB
		internal Class4()
		{
		}

		// Token: 0x04000026 RID: 38
		internal byte[] byte_0;

		// Token: 0x04000027 RID: 39
		internal uint uint_0;

		// Token: 0x04000028 RID: 40
		internal Stream stream_0;

		// Token: 0x04000029 RID: 41
		internal uint uint_1;

		// Token: 0x0400002A RID: 42
		internal uint uint_2;
	}

	// Token: 0x0200000A RID: 10
	internal struct Struct3
	{
		// Token: 0x06000051 RID: 81 RVA: 0x00002837 File Offset: 0x00000A37
		internal void method_0()
		{
			this.uint_0 = 0U;
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00002840 File Offset: 0x00000A40
		internal void method_1()
		{
			if (this.uint_0 < 4U)
			{
				this.uint_0 = 0U;
				return;
			}
			if (this.uint_0 < 10U)
			{
				this.uint_0 -= 3U;
				return;
			}
			this.uint_0 -= 6U;
		}

		// Token: 0x06000053 RID: 83 RVA: 0x0000287A File Offset: 0x00000A7A
		internal void method_2()
		{
			this.uint_0 = ((this.uint_0 < 7U) ? 7U : 10U);
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00002890 File Offset: 0x00000A90
		internal void method_3()
		{
			this.uint_0 = ((this.uint_0 < 7U) ? 8U : 11U);
		}

		// Token: 0x06000055 RID: 85 RVA: 0x000028A6 File Offset: 0x00000AA6
		internal void method_4()
		{
			this.uint_0 = ((this.uint_0 < 7U) ? 9U : 11U);
		}

		// Token: 0x06000056 RID: 86 RVA: 0x000028BD File Offset: 0x00000ABD
		internal bool method_5()
		{
			return this.uint_0 < 7U;
		}

		// Token: 0x0400002B RID: 43
		internal uint uint_0;
	}

	// Token: 0x0200000B RID: 11
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 768)]
	internal struct Struct4
	{
	}
}
