﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x02000021 RID: 33
public partial class Agreement : GForm0
{
	// Token: 0x06000124 RID: 292 RVA: 0x00002CF0 File Offset: 0x00000EF0
	private void method_1()
	{
		new Form1().ForceClose();
	}

	// Token: 0x06000125 RID: 293 RVA: 0x0000F3A0 File Offset: 0x0000D5A0
	public Agreement(Form1 form1_1)
	{
		this.InitializeComponent();
		this.form1_0 = form1_1;
		this.CloseIcon.Click += this.method_3;
		this.DisagreeButton.Click += this.method_4;
		this.AgreementText.LinkClicked += Agreement.<>c.<>9.method_0;
		base.Controls.OfType<PictureBox>().ToList<PictureBox>().ForEach(new Action<PictureBox>(this.method_5));
	}

	// Token: 0x06000126 RID: 294 RVA: 0x0000F43C File Offset: 0x0000D63C
	private void Agreement_Load(object sender, EventArgs e)
	{
		Agreement.Struct18 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.agreement_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Agreement.Struct18>(ref @struct);
	}

	// Token: 0x06000127 RID: 295 RVA: 0x0000F474 File Offset: 0x0000D674
	private void method_2()
	{
		this.Header.Text = GClass2.GClass2_0.method_1("AgreementHeader");
		this.AgreementText.Text = GClass2.GClass2_0.method_1(this.AgreementText.Name);
		this.AgreeButton.Text = GClass2.GClass2_0.method_1(this.AgreeButton.Name);
		this.DisagreeButton.Text = GClass2.GClass2_0.method_1(this.DisagreeButton.Name);
	}

	// Token: 0x06000128 RID: 296 RVA: 0x00002CFC File Offset: 0x00000EFC
	private void AgreeButton_MouseUp(object sender, MouseEventArgs e)
	{
		GClass2.GClass2_0.RegistryKey_0.SetValue("First Run Agreement", (e.Button == MouseButtons.Right) ? "true" : "false");
		base.Close();
	}

	// Token: 0x06000129 RID: 297 RVA: 0x00002D31 File Offset: 0x00000F31
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600012B RID: 299 RVA: 0x00002D50 File Offset: 0x00000F50
	[CompilerGenerated]
	private void method_3(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x0600012C RID: 300 RVA: 0x00002D50 File Offset: 0x00000F50
	[CompilerGenerated]
	private void method_4(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x0600012D RID: 301 RVA: 0x00002D58 File Offset: 0x00000F58
	[CompilerGenerated]
	private void method_5(PictureBox pictureBox_0)
	{
		pictureBox_0.Click += this.method_6;
	}

	// Token: 0x0600012E RID: 302 RVA: 0x0000FC98 File Offset: 0x0000DE98
	[CompilerGenerated]
	private void method_6(object sender, EventArgs e)
	{
		GClass2.GClass2_0.string_13 = ((PictureBox)sender).Name;
		GClass2.GClass2_0.RegistryKey_0.SetValue("Language", ((PictureBox)sender).Name);
		this.method_2();
		this.form1_0.Translate();
	}

	// Token: 0x0600012F RID: 303 RVA: 0x00002951 File Offset: 0x00000B51
	static void smethod_3(Control control_0, EventHandler eventHandler_0)
	{
		control_0.Click += eventHandler_0;
	}

	// Token: 0x06000130 RID: 304 RVA: 0x00002D6C File Offset: 0x00000F6C
	static void smethod_4(RichTextBox richTextBox_0, LinkClickedEventHandler linkClickedEventHandler_0)
	{
		richTextBox_0.LinkClicked += linkClickedEventHandler_0;
	}

	// Token: 0x06000131 RID: 305 RVA: 0x00002984 File Offset: 0x00000B84
	static Control.ControlCollection smethod_5(Control control_0)
	{
		return control_0.Controls;
	}

	// Token: 0x06000132 RID: 306 RVA: 0x00002920 File Offset: 0x00000B20
	static void smethod_6(Control control_0, string string_0)
	{
		control_0.Text = string_0;
	}

	// Token: 0x06000133 RID: 307 RVA: 0x00002C23 File Offset: 0x00000E23
	static string smethod_7(Control control_0)
	{
		return control_0.Name;
	}

	// Token: 0x06000134 RID: 308 RVA: 0x00002D75 File Offset: 0x00000F75
	static MouseButtons smethod_8(MouseEventArgs mouseEventArgs_0)
	{
		return mouseEventArgs_0.Button;
	}

	// Token: 0x06000135 RID: 309 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_9(RegistryKey registryKey_0, string string_0, object object_0)
	{
		registryKey_0.SetValue(string_0, object_0);
	}

	// Token: 0x06000136 RID: 310 RVA: 0x00002C39 File Offset: 0x00000E39
	static void smethod_10(Form form_0)
	{
		form_0.Close();
	}

	// Token: 0x06000137 RID: 311 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_11(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000138 RID: 312 RVA: 0x00002D7D File Offset: 0x00000F7D
	static RichTextBox smethod_12()
	{
		return new RichTextBox();
	}

	// Token: 0x06000139 RID: 313 RVA: 0x00002A5A File Offset: 0x00000C5A
	static PictureBox smethod_13()
	{
		return new PictureBox();
	}

	// Token: 0x0600013A RID: 314 RVA: 0x00002A69 File Offset: 0x00000C69
	static Button smethod_14()
	{
		return new Button();
	}

	// Token: 0x0600013B RID: 315 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_15()
	{
		return new Label();
	}

	// Token: 0x0600013C RID: 316 RVA: 0x00002A85 File Offset: 0x00000C85
	static void smethod_16(ISupportInitialize isupportInitialize_0)
	{
		isupportInitialize_0.BeginInit();
	}

	// Token: 0x0600013D RID: 317 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_17(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x0600013E RID: 318 RVA: 0x00002D84 File Offset: 0x00000F84
	static void smethod_18(TextBoxBase textBoxBase_0, BorderStyle borderStyle_0)
	{
		textBoxBase_0.BorderStyle = borderStyle_0;
	}

	// Token: 0x0600013F RID: 319 RVA: 0x00002D8D File Offset: 0x00000F8D
	static Cursor smethod_19()
	{
		return Cursors.Default;
	}

	// Token: 0x06000140 RID: 320 RVA: 0x00002D94 File Offset: 0x00000F94
	static void smethod_20(Control control_0, Cursor cursor_0)
	{
		control_0.Cursor = cursor_0;
	}

	// Token: 0x06000141 RID: 321 RVA: 0x00002B7F File Offset: 0x00000D7F
	static void smethod_21(Control control_0, Color color_0)
	{
		control_0.ForeColor = color_0;
	}

	// Token: 0x0400009E RID: 158
	private readonly Form1 form1_0;

	// Token: 0x0400009F RID: 159
	private IContainer icontainer_0;
}
