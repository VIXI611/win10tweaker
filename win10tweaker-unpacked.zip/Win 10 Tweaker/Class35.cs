﻿using System;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000076 RID: 118
internal class Class35
{
	// Token: 0x1700002B RID: 43
	// (get) Token: 0x060005B1 RID: 1457 RVA: 0x0001BC40 File Offset: 0x00019E40
	public static Class35 Class35_0
	{
		get
		{
			if (Class35.class35_0 == null)
			{
				object obj = Class35.object_0;
				lock (obj)
				{
					if (Class35.class35_0 == null)
					{
						Class35.class35_0 = new Class35();
					}
				}
			}
			return Class35.class35_0;
		}
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x0001BCA0 File Offset: 0x00019EA0
	public void method_0()
	{
		string text = "DesktopBackground\\Shell\\cmd";
		RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey(text);
		registryKey.SetValue("", GClass2.GClass2_0.method_1("CommandWindow"));
		registryKey.SetValue("Position", "bottom");
		Registry.ClassesRoot.CreateSubKey(text + "\\command").SetValue("", "cmd.exe");
		Registry.ClassesRoot.CreateSubKey(text).SetValue("Icon", (GClass2.GClass2_0.String_3.Contains("7") | GClass2.GClass2_0.String_3.Contains("8")) ? "cmd.exe" : "imageres.dll,311");
	}

	// Token: 0x060005B3 RID: 1459 RVA: 0x000042AF File Offset: 0x000024AF
	public void method_1()
	{
		Registry.ClassesRoot.DeleteSubKeyTree(Class35.string_0, false);
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_3(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_4(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_5(string string_1, string string_2)
	{
		return string_1.Contains(string_2);
	}

	// Token: 0x060005BC RID: 1468 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_6(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_1, bool_0);
	}

	// Token: 0x060005BD RID: 1469 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_7()
	{
		return new object();
	}

	// Token: 0x04000268 RID: 616
	private static volatile Class35 class35_0;

	// Token: 0x04000269 RID: 617
	private static readonly object object_0 = new object();

	// Token: 0x0400026A RID: 618
	private static readonly string string_0 = "DesktopBackground\\Shell\\cmd";
}
