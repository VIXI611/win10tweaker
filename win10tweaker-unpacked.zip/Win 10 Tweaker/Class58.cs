﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000097 RID: 151
internal class Class58
{
	// Token: 0x17000046 RID: 70
	// (get) Token: 0x0600077D RID: 1917 RVA: 0x00020794 File Offset: 0x0001E994
	public static Class58 Class58_0
	{
		get
		{
			if (Class58.class58_0 == null)
			{
				object obj = Class58.object_0;
				lock (obj)
				{
					if (Class58.class58_0 == null)
					{
						Class58.class58_0 = new Class58();
					}
				}
			}
			return Class58.class58_0;
		}
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x00004B5A File Offset: 0x00002D5A
	public void method_0(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Classes\\.bmp\\ShellNew", false);
		}
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x00004B6F File Offset: 0x00002D6F
	public void method_1(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Classes\\.contact\\ShellNew", false);
		}
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x00004B84 File Offset: 0x00002D84
	public void method_2(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Classes\\.rtf\\ShellNew", false);
		}
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x00004B99 File Offset: 0x00002D99
	public void method_3(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Classes\\.zip\\CompressedFolder\\ShellNew", false);
		}
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x00004BAE File Offset: 0x00002DAE
	public void method_4(bool bool_0)
	{
		if (bool_0)
		{
			Registry.LocalMachine.DeleteSubKeyTree("SOFTWARE\\Classes\\Briefcase\\ShellNew", false);
		}
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x000207F4 File Offset: 0x0001E9F4
	public void method_5()
	{
		RegistryKey registryKey = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Classes\\.bmp\\ShellNew");
		registryKey.SetValue("ItemName", "@%systemroot%\\system32\\mspaint.exe,-59414", RegistryValueKind.ExpandString);
		registryKey.SetValue("NullFile", "");
		RegistryKey registryKey2 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Classes\\.contact\\ShellNew");
		registryKey2.SetValue("command", "\"%programFiles%\\Windows Mail\\Wab.exe\" /CreateContact \"%1\"", RegistryValueKind.ExpandString);
		registryKey2.SetValue("iconpath", "%ProgramFiles%\\Windows Mail\\wab.exe,1", RegistryValueKind.ExpandString);
		registryKey2.SetValue("MenuText", "@%CommonProgramFiles%\\system\\wab32res.dll,-10203", RegistryValueKind.ExpandString);
		Registry.LocalMachine.CreateSubKey("SOFTWARE\\Classes\\.rtf\\ShellNew");
		registryKey2.SetValue("Data", "{\\rtf1}");
		registryKey2.SetValue("ItemName", "@%ProgramFiles%\\Windows NT\\Accessories\\WORDPAD.EXE,-213", RegistryValueKind.ExpandString);
		byte[] value = new byte[]
		{
			80,
			75,
			5,
			6,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0
		};
		RegistryKey registryKey3 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Classes\\.zip\\CompressedFolder\\ShellNew");
		registryKey3.SetValue("Data", value, RegistryValueKind.Binary);
		registryKey3.SetValue("ItemName", "@%SystemRoot%\\system32\\zipfldr.dll,-10194", RegistryValueKind.ExpandString);
	}

	// Token: 0x06000786 RID: 1926 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000787 RID: 1927 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000788 RID: 1928 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_2(RegistryKey registryKey_0, string string_0, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_0, bool_0);
	}

	// Token: 0x06000789 RID: 1929 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_3(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x0600078A RID: 1930 RVA: 0x00002EED File Offset: 0x000010ED
	static void smethod_4(RegistryKey registryKey_0, string string_0, object object_1, RegistryValueKind registryValueKind_0)
	{
		registryKey_0.SetValue(string_0, object_1, registryValueKind_0);
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_5(RegistryKey registryKey_0, string string_0, object object_1)
	{
		registryKey_0.SetValue(string_0, object_1);
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x00002BF0 File Offset: 0x00000DF0
	static void smethod_6(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
	{
		RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_7()
	{
		return new object();
	}

	// Token: 0x040002D1 RID: 721
	private static volatile Class58 class58_0;

	// Token: 0x040002D2 RID: 722
	private static readonly object object_0 = new object();
}
