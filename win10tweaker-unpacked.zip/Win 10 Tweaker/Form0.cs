﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Management.Automation;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading.Tasks;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x0200003B RID: 59
internal partial class Form0 : Form1
{
	// Token: 0x06000242 RID: 578
	[DllImport("ntdll.dll")]
	public static extern uint NtSetSystemInformation(int int_1, IntPtr intptr_0, int int_2);

	// Token: 0x06000243 RID: 579
	[DllImport("psapi.dll")]
	private static extern int EmptyWorkingSet(IntPtr intptr_0);

	// Token: 0x06000244 RID: 580 RVA: 0x00012904 File Offset: 0x00010B04
	public static void smethod_303()
	{
		foreach (Process process in Process.GetProcesses())
		{
			try
			{
				Form0.EmptyWorkingSet(process.Handle);
			}
			catch
			{
			}
		}
		try
		{
			if (Form0.smethod_304("SeIncreaseQuotaPrivilege"))
			{
				Struct27 @struct = new Struct27
				{
					long_3 = (GClass2.GClass2_0.Boolean_0 ? -1L : 4294967295L),
					long_4 = (GClass2.GClass2_0.Boolean_0 ? -1L : 4294967295L)
				};
				int int_ = Marshal.SizeOf<Struct27>(@struct);
				GCHandle gchandle = GCHandle.Alloc(@struct, GCHandleType.Pinned);
				Form0.NtSetSystemInformation(21, gchandle.AddrOfPinnedObject(), int_);
				gchandle.Free();
			}
			if (Form0.smethod_304("SeProfileSingleProcessPrivilege"))
			{
				int int_2 = Marshal.SizeOf<int>(4);
				GCHandle gchandle2 = GCHandle.Alloc(4, GCHandleType.Pinned);
				Form0.NtSetSystemInformation(80, gchandle2.AddrOfPinnedObject(), int_2);
				gchandle2.Free();
			}
		}
		catch
		{
		}
	}

	// Token: 0x06000245 RID: 581 RVA: 0x00012A2C File Offset: 0x00010C2C
	private static bool smethod_304(string string_0)
	{
		bool result;
		using (WindowsIdentity current = WindowsIdentity.GetCurrent(TokenAccessLevels.Query | TokenAccessLevels.AdjustPrivileges))
		{
			GClass6.GStruct2 gstruct;
			gstruct.int_0 = 1;
			gstruct.long_0 = 0L;
			gstruct.int_1 = 2;
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("RAM Cache Cleaner") != null && GClass2.GClass2_0.RegistryKey_0.GetValue("RAM Cache Cleaner").ToString() == "true" && !GClass6.LookupPrivilegeValue(null, string_0, ref gstruct.long_0))
			{
				throw new Exception("Error in LookupPrivilegeValue: ", new Win32Exception(Marshal.GetLastWin32Error()));
			}
			int num = (!GClass6.AdjustTokenPrivileges(current.Token, false, ref gstruct, 0, IntPtr.Zero, IntPtr.Zero)) ? 0 : 1;
			if (GClass2.GClass2_0.RegistryKey_0.GetValue("RAM Cache Cleaner") != null && GClass2.GClass2_0.RegistryKey_0.GetValue("RAM Cache Cleaner").ToString() == "true" && num == 0)
			{
				throw new Exception("Error in AdjustTokenPrivileges: ", new Win32Exception(Marshal.GetLastWin32Error()));
			}
			result = (num != 0);
		}
		return result;
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x06000246 RID: 582 RVA: 0x00003320 File Offset: 0x00001520
	// (set) Token: 0x06000247 RID: 583 RVA: 0x00003327 File Offset: 0x00001527
	public static Form0.Delegate0 Delegate0_0 { get; set; }

	// Token: 0x06000248 RID: 584 RVA: 0x00012B58 File Offset: 0x00010D58
	public static List<string> smethod_305(string string_0, string string_1, bool bool_1)
	{
		List<string> list = new List<string>();
		string[] array = null;
		try
		{
			array = Directory.GetFiles(string_0, string_1);
			list.AddRange(array);
		}
		catch
		{
		}
		if (array != null)
		{
			foreach (string string_2 in Directory.GetDirectories(string_0))
			{
				list.AddRange(Form0.smethod_305(string_2, string_1, bool_1));
			}
		}
		list = list.Where(new Func<string, bool>(Form0.<>c.<>9.method_0)).Select(new Func<string, string>(Form0.<>c.<>9.method_1)).ToList<string>();
		if (bool_1)
		{
			Form0.list_0 = Form0.list_0.Union(list).ToList<string>();
		}
		else
		{
			Form0.list_1 = Form0.list_1.Union(list).ToList<string>();
		}
		return list;
	}

	// Token: 0x06000249 RID: 585 RVA: 0x00012C3C File Offset: 0x00010E3C
	private static void smethod_306()
	{
		Form0.list_2.Clear();
		Form0.list_2 = Form0.list_0.Except(Form0.list_1).ToList<string>();
		Form0.Delegate0 @delegate = Form0.delegate0_0;
		if (@delegate != null)
		{
			@delegate(Form0.list_2);
		}
		Form0.list_0.Clear();
		Form0.list_1.Clear();
	}

	// Token: 0x0600024A RID: 586 RVA: 0x00012C98 File Offset: 0x00010E98
	public static void smethod_307(bool bool_1 = false)
	{
		Form0.Struct28 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.bool_0 = bool_1;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Form0.Struct28>(ref @struct);
	}

	// Token: 0x0600024B RID: 587 RVA: 0x00012CD0 File Offset: 0x00010ED0
	public static void smethod_308()
	{
		string[] array = new string[]
		{
			GClass13.string_12 + "\\NVIDIA\\GLCache",
			GClass13.string_2 + "\\AppData\\Roaming\\NVIDIA\\ComputeCache",
			GClass13.string_11 + "\\NVIDIA Corporation\\NV_Cache",
			GClass13.string_11 + "\\NVIDIA Corporation\\umdlogs",
			GClass13.string_12 + "\\AMD\\DxCache",
			GClass13.string_12 + "\\AMD\\GLCache",
			GClass13.string_12 + "\\Steam\\htmlcache",
			GClass13.string_10 + "\\Steam\\appcache",
			GClass13.string_10 + "\\Steam\\depotcache",
			GClass13.string_10 + "\\Steam\\dumps",
			GClass13.string_10 + "\\Steam\\logs",
			GClass13.string_10 + "\\Steam\\tenfoot\\config\\images\\web",
			GClass13.string_10 + "\\Origin\\support",
			GClass13.string_12 + "\\Origin\\Web Cache",
			GClass13.string_2 + "\\AppData\\Roaming\\Origin\\CatalogCache",
			GClass13.string_2 + "\\AppData\\Roaming\\Origin\\ConsolidatedCache",
			GClass13.string_2 + "\\AppData\\Roaming\\Origin\\NucleusCache",
			GClass13.string_12 + "\\D3DSCache",
			GClass13.string_12 + "\\CEF"
		};
		string[] array2 = new string[]
		{
			GClass13.string_12 + "\\NVIDIA Corporation",
			GClass13.string_11 + "\\NVIDIA",
			GClass13.string_11 + "\\NVIDIA Corporation\\NvProfileUpdaterPlugin"
		};
		string str = "discord";
		string[] array3 = new string[]
		{
			GClass13.string_3 + "\\" + str + "\\Cache",
			GClass13.string_3 + "\\" + str + "\\Code Cache",
			GClass13.string_3 + "\\" + str + "\\Crashpad",
			GClass13.string_3 + "\\" + str + "\\GPUCache",
			GClass13.string_3 + "\\" + str + "\\Session Storage"
		};
		string[] source = new string[0];
		List<string> list = new List<string>();
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Valve\\Steam"))
		{
			if (registryKey != null && registryKey.GetValue("SteamPath") != null && File.Exists(string.Format("{0}\\steamapps\\libraryfolders.vdf", registryKey.GetValue("SteamPath"))))
			{
				string path = string.Format("{0}\\steamapps\\common\\Steamworks Shared\\_CommonRedist", registryKey.GetValue("SteamPath")).Replace("/", "\\");
				if (Directory.Exists(path))
				{
					list.AddRange(Directory.GetFiles(path, "*", SearchOption.AllDirectories));
				}
				string path2 = string.Format("{0}\\steamapps\\temp", registryKey.GetValue("SteamPath")).Replace("/", "\\");
				if (Directory.Exists(path2))
				{
					list.AddRange(Directory.GetFiles(path2, "*", SearchOption.AllDirectories));
				}
				Form0.Class17 @class = new Form0.Class17();
				List<string> list2 = File.ReadAllLines(string.Format("{0}\\steamapps\\libraryfolders.vdf", registryKey.GetValue("SteamPath"))).ToList<string>().Where(new Func<string, bool>(Form0.<>c.<>9.method_4)).ToList<string>();
				@class.list_0 = new List<string>();
				list2.ForEach(new Action<string>(@class.method_0));
				@class.list_0 = @class.list_0.Select(new Func<string, string>(Form0.<>c.<>9.method_5)).Where(new Func<string, bool>(Form0.<>c.<>9.method_6)).ToList<string>();
				@class.list_1 = new List<string>();
				@class.list_0.ForEach(new Action<string>(@class.method_1));
				@class.list_1 = @class.list_1.Where(new Func<string, bool>(Form0.<>c.<>9.method_7)).ToList<string>();
				@class.list_2 = new List<string>();
				@class.list_1.ForEach(new Action<string>(@class.method_2));
				@class.list_3 = new List<string>();
				list2.ForEach(new Action<string>(@class.method_3));
				@class.list_3 = @class.list_3.Select(new Func<string, string>(Form0.<>c.<>9.method_9)).Where(new Func<string, bool>(Form0.<>c.<>9.method_10)).ToList<string>();
				@class.list_3.ForEach(new Action<string>(@class.method_4));
				list.AddRange(@class.list_2);
				source = list.Distinct<string>().ToArray<string>();
			}
		}
		array.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_11));
		array2.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_12));
		array2.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_13));
		array3.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_14));
		Form0.list_0.AddRange(source.Where(new Func<string, bool>(Form0.<>c.<>9.method_15)).Select(new Func<string, string>(Form0.<>c.<>9.method_16)));
		Form0.smethod_326(array, "*");
		Form0.smethod_326(array2, "*.log");
		Form0.smethod_326(array2, "*.bak");
		Form0.smethod_326(array3, "*");
		source.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_17));
		array.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_18));
		array2.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_19));
		array2.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_20));
		array3.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_21));
		Form0.list_1.AddRange(source.Where(new Func<string, bool>(Form0.<>c.<>9.method_22)).Select(new Func<string, string>(Form0.<>c.<>9.method_23)));
		Form0.smethod_306();
	}

	// Token: 0x0600024C RID: 588 RVA: 0x00013460 File Offset: 0x00011660
	public static void smethod_309()
	{
		string path = GClass13.string_0 + "\\MSOCache";
		string path2 = GClass13.string_9 + "\\NVIDIA Corporation\\Installer2";
		List<string> list = new List<string>();
		if (!Directory.Exists(path) && !Directory.Exists(path2))
		{
			return;
		}
		if (Directory.Exists(path2))
		{
			list.Add(GClass13.string_0 + "\\MSOCache");
			list.AddRange(Directory.GetDirectories(path2, "*").Where(new Func<string, bool>(Form0.<>c.<>9.method_24)));
		}
		string[] array = list.ToArray();
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_25));
		Form0.smethod_326(array, "*");
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_26));
		Form0.smethod_306();
	}

	// Token: 0x0600024D RID: 589 RVA: 0x00013560 File Offset: 0x00011760
	public static void smethod_310()
	{
		Form0.Struct29 @struct;
		@struct.list_0 = new List<string>();
		string text = GClass13.string_12 + "\\Chromium\\User Data";
		if (Directory.Exists(text) && Process.GetProcessesByName("chrome").Length == 0)
		{
			Form0.smethod_327(text, ref @struct);
		}
		string text2 = GClass13.string_12 + "\\Google\\Chrome\\User Data";
		if (Directory.Exists(text2) && Process.GetProcessesByName("chrome").Length == 0)
		{
			Form0.smethod_327(text2, ref @struct);
		}
		string text3 = GClass13.string_12 + "\\CentBrowser\\User Data";
		if (Directory.Exists(text3) && Process.GetProcessesByName("chrome").Length == 0)
		{
			Form0.smethod_327(text3, ref @struct);
		}
		Process process = Process.GetProcessesByName("chrome").FirstOrDefault<Process>();
		if (process != null)
		{
			string text4 = process.MainModule.FileName.Replace("chrome.exe", "User Data");
			if (Directory.Exists(text4))
			{
				@struct.list_0.Add(text4 + "\\Crashpad\\reports");
				@struct.list_0.Add(text4 + "\\PnaclTranslationCache");
				@struct.list_0.Add(text4 + "\\ShaderCache\\GPUCache");
				@struct.list_0.Add(text4 + "\\Default\\Application Cache");
				@struct.list_0.Add(text4 + "\\Default\\Cache");
				@struct.list_0.Add(text4 + "\\Default\\Code Cache\\js");
				@struct.list_0.Add(text4 + "\\Default\\Service Worker");
			}
		}
		string text5 = GClass13.string_12 + "\\Yandex\\YandexBrowser\\User Data";
		if (Directory.Exists(text5))
		{
			Form0.smethod_327(text5, ref @struct);
		}
		string text6 = GClass13.string_12 + "\\Opera Software\\Opera Stable\\Cache";
		if (Directory.Exists(text6))
		{
			@struct.list_0.Add(text6);
			@struct.list_0.Add(GClass13.string_2 + "\\Roaming\\Opera Software\\Opera Stable\\Code Cache\\js");
			@struct.list_0.Add(GClass13.string_2 + "\\Roaming\\Opera Software\\Opera Stable\\Crash Reports\\reports");
			@struct.list_0.Add(GClass13.string_2 + "\\Roaming\\Opera Software\\Opera Stable\\ShaderCache\\GPUCache");
		}
		string text7 = GClass13.string_12 + "\\BraveSoftware\\Brave-Browser\\User Data";
		if (Directory.Exists(text7))
		{
			Form0.smethod_327(text7, ref @struct);
		}
		string text8 = GClass13.string_12 + "\\Vivaldi\\User Data";
		if (Directory.Exists(text8))
		{
			Form0.smethod_327(text8, ref @struct);
		}
		string text9 = GClass13.string_12 + "\\Microsoft\\Edge\\User Data";
		if (Directory.Exists(text9))
		{
			@struct.list_0.Add(text9 + "\\Default\\Service Worker");
			Form0.smethod_327(text9, ref @struct);
		}
		text9 = GClass13.string_7 + "\\config\\systemprofile\\AppData\\Local\\Microsoft\\Windows\\WebCache";
		if (Directory.Exists(text9))
		{
			@struct.list_0.Add(text9);
		}
		try
		{
			string path = GClass13.string_2 + "\\AppData\\Roaming\\Mozilla\\Firefox\\profiles.ini";
			if (File.Exists(path))
			{
				string str = File.ReadAllLines(path).ToList<string>().FirstOrDefault(new Func<string, bool>(Form0.<>c.<>9.method_27)).Replace("Default=Profiles/", "");
				@struct.list_0.Add(GClass13.string_12 + "\\Mozilla\\Firefox\\Profiles\\" + str + "\\cache2\\entries");
				@struct.list_0.Add(GClass13.string_10 + "\\Mozilla Maintenance Service\\logs");
			}
		}
		catch
		{
		}
		@struct.list_0.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_28));
		Form0.smethod_326(@struct.list_0.ToArray(), "*");
		@struct.list_0.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_29));
		Form0.smethod_306();
	}

	// Token: 0x0600024E RID: 590 RVA: 0x00013948 File Offset: 0x00011B48
	public static void smethod_311()
	{
		string[] array = new string[]
		{
			GClass13.string_12 + "\\Microsoft\\Windows\\Explorer"
		};
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_30));
		Form0.smethod_326(array, "*");
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_31));
		string text = GClass13.string_12 + "\\IconCache.db";
		if (File.Exists(text))
		{
			Form0.list_0.Add(string.Format("{0}>{1}", text, new FileInfo(text).Length));
		}
		if (File.Exists(text))
		{
			try
			{
				File.Delete(text);
			}
			catch
			{
			}
		}
		Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\ImmersiveShell\\StateStore").SetValue("ResetCache", 1);
		if (File.Exists(text))
		{
			Form0.list_1.Add(string.Format("{0}>{1}", text, new FileInfo(text).Length));
		}
		Form0.smethod_306();
	}

	// Token: 0x0600024F RID: 591 RVA: 0x00013A8C File Offset: 0x00011C8C
	public static void smethod_312()
	{
		string text = GClass13.string_11 + "\\Microsoft\\Windows Defender\\Scans\\History\\Results\\Resource";
		string text2 = GClass13.string_11 + "\\Windows Defender\\Definition Updates";
		string text3 = GClass13.string_11 + "\\Windows Defender\\Scans";
		string[] array = new string[]
		{
			text,
			text2,
			text3
		};
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_32));
		Form0.smethod_326(array, "*");
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_33));
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_34));
		Form0.smethod_306();
	}

	// Token: 0x06000250 RID: 592 RVA: 0x00013B68 File Offset: 0x00011D68
	public static void smethod_313()
	{
		List<string> list = new List<string>();
		list.Add(GClass13.string_0 + "\\Recovery");
		list.Add(GClass13.string_11 + "\\Package Cache");
		list.Add(GClass13.string_6 + "\\Installer\\$PatchCache$");
		list.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_35));
		list.ForEach(new Action<string>(Form0.<>c.<>9.method_36));
		list.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_37));
		Form0.smethod_306();
	}

	// Token: 0x06000251 RID: 593 RVA: 0x00013C38 File Offset: 0x00011E38
	public static void smethod_314()
	{
		string text = GClass13.string_0 + "\\$Windows.~BT";
		string text2 = GClass13.string_0 + "\\$Windows.~WS";
		string text3 = GClass13.string_6 + "\\SoftwareDistribution\\SLS";
		string[] array = new string[]
		{
			text,
			text2,
			text3
		};
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_38));
		Form0.smethod_326(array, "*");
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_39));
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_40));
		Form0.smethod_306();
	}

	// Token: 0x06000252 RID: 594 RVA: 0x00013D14 File Offset: 0x00011F14
	public static void smethod_315()
	{
		Form0.Class18 @class = new Form0.Class18();
		string[] array = new string[]
		{
			GClass13.string_6 + "\\Logs",
			GClass13.string_6 + "\\SoftwareDistribution",
			GClass13.string_7 + "\\config\\systemprofile\\AppData\\Local\\Microsoft\\CLR_v4.0\\UsageLogs",
			GClass13.string_8 + "\\config\\systemprofile\\AppData\\Local\\Microsoft\\CLR_v4.0\\UsageLogs",
			GClass13.string_7 + "\\config\\systemprofile\\AppData\\Local\\Microsoft\\CLR_v4.0_32\\UsageLogs",
			GClass13.string_8 + "\\config\\systemprofile\\AppData\\Local\\Microsoft\\CLR_v4.0_32\\UsageLogs"
		};
		string[] array2 = new string[]
		{
			GClass13.string_12 + "\\Microsoft\\CLR_v4.0",
			GClass13.string_12 + "\\Microsoft\\CLR_v4.0\\UsageLogs",
			GClass13.string_12 + "\\Microsoft\\CLR_v4.0_32",
			GClass13.string_12 + "\\Microsoft\\CLR_v4.0_32\\UsageLogs",
			GClass13.string_11 + "\\Microsoft\\Windows\\wfp",
			GClass13.string_7 + "\\LogFiles\\WMI\\RtBackup",
			GClass13.string_7 + "\\winevt\\Logs"
		};
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_41));
		array2.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_42));
		Form0.smethod_326(array, "*.log");
		Form0.smethod_326(array2, "*");
		List<string> list = new List<string>();
		@class.registryKey_0 = Registry.CurrentUser.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\TypedPaths");
		foreach (string item in @class.registryKey_0.GetValueNames())
		{
			list.Add(item);
		}
		list.AsParallel<string>().ForAll(new Action<string>(@class.method_0));
		try
		{
			EventLog.GetEventLogs().ToList<EventLog>().ForEach(new Action<EventLog>(Form0.<>c.<>9.method_43));
			Form0.Class19 class2 = new Form0.Class19();
			class2.eventLogSession_0 = new EventLogSession();
			try
			{
				EventLogSession.GlobalSession.GetLogNames().AsParallel<string>().ForAll(new Action<string>(class2.method_0));
			}
			finally
			{
				if (class2.eventLogSession_0 != null)
				{
					((IDisposable)class2.eventLogSession_0).Dispose();
				}
			}
		}
		catch
		{
		}
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_44));
		array2.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_45));
		Form0.smethod_306();
	}

	// Token: 0x06000253 RID: 595 RVA: 0x00013FF0 File Offset: 0x000121F0
	public static void smethod_316()
	{
		new string[]
		{
			GClass2.GClass2_0.String_0 + "\\Explorer\\RunMRU",
			GClass2.GClass2_0.String_0 + "\\Explorer\\ComDlg32",
			GClass2.GClass2_0.String_0 + "\\Explorer\\CIDOpen",
			GClass2.GClass2_0.String_0 + "\\Explorer\\CIDSave",
			GClass2.GClass2_0.String_0 + "\\Explorer\\RecentDocs",
			GClass2.GClass2_0.String_0 + "\\Explorer\\WordWheelQuery",
			GClass2.GClass2_0.String_0 + "\\Explorer\\UserAssist\\{CEBFF5CD-ACE2-4F4F-9178-9926F41749EA}\\Count",
			GClass2.GClass2_0.String_0 + "\\Explorer\\UserAssist\\{F4E57C4B-2036-45F0-A9AB-443BCFE33D9F}\\Count",
			"Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache",
			"Software\\Classes\\Local Settings\\MuiCache",
			GClass2.GClass2_0.String_0 + "\\Explorer\\StreamMRU",
			"Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Compatibility Assistant\\Store"
		}.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_46));
	}

	// Token: 0x06000254 RID: 596 RVA: 0x00014118 File Offset: 0x00012318
	public static void smethod_317()
	{
		try
		{
			new List<string>();
			string subkey = "SYSTEM\\CurrentControlSet\\Enum\\USBSTOR";
			GClass6.GClass6_0.method_17(Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Enum"), false);
			GClass6.GClass6_0.method_17(Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Enum\\USBSTOR"), false);
			RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(subkey);
			List<string> list;
			if (registryKey == null)
			{
				list = null;
			}
			else
			{
				list = registryKey.GetSubKeyNames().ToList<string>().Where(new Func<string, bool>(Form0.<>c.<>9.method_47)).ToList<string>();
			}
			list.ForEach(new Action<string>(Form0.<>c.<>9.method_48));
		}
		catch
		{
		}
	}

	// Token: 0x06000255 RID: 597 RVA: 0x000141E4 File Offset: 0x000123E4
	public static void smethod_318()
	{
		Form0.Class20 @class = new Form0.Class20();
		string path = GClass13.string_2 + "\\AppData\\Local\\Temp";
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Environment"))
		{
			if (!registryKey.GetValue("TMP").ToString().Contains("AppData\\Local") && Directory.Exists(path))
			{
				try
				{
					Directory.Delete(path);
				}
				catch
				{
				}
			}
		}
		string[] array = new string[]
		{
			GClass13.string_2 + "\\Tracing",
			GClass13.string_12 + "\\CEF",
			GClass13.string_12 + "\\ConnectedDevicesPlatform",
			GClass13.string_12 + "\\CrashRpt",
			GClass13.string_12 + "\\DBG",
			GClass13.string_12 + "\\Icaros",
			GClass13.string_12 + "\\Microsoft\\input",
			GClass13.string_12 + "\\PeerDistRepub",
			GClass13.string_2 + "\\AppData\\LocalLow\\uTorrent",
			GClass13.string_0 + "\\AMD",
			GClass13.string_0 + "\\NVIDIA",
			GClass13.string_0 + "\\Config.Msi",
			GClass13.string_0 + "\\Intel",
			GClass13.string_0 + "\\PerfLogs",
			GClass13.string_0 + "\\$WinREAgent",
			GClass13.string_9 + "\\Uninstall Information",
			GClass13.string_9 + "\\WindowsUpdate",
			GClass13.string_6 + "\\bcastdvr",
			GClass13.string_6 + "\\BitLockerDiscoveryVolumeContents",
			GClass13.string_6 + "\\CbsTemp",
			GClass13.string_6 + "\\DeliveryOptimization",
			GClass13.string_6 + "\\DiagTrack",
			GClass13.string_6 + "\\Downloaded Installations",
			GClass13.string_6 + "\\Downloaded Program Files",
			GClass13.string_6 + "\\LastGood.Tmp",
			GClass13.string_6 + "\\LiveKernelReports",
			GClass13.string_6 + "\\Minidump",
			GClass13.string_6 + "\\ModemLogs",
			GClass13.string_6 + "\\msdownld.tmp",
			GClass13.string_6 + "\\rescache",
			GClass13.string_6 + "\\RemotePackages",
			GClass13.string_6 + "\\SchCache",
			GClass13.string_6 + "\\servicing\\LCU",
			GClass13.string_6 + "\\Speech\\Engines\\Lexicon",
			GClass13.string_6 + "\\Speech\\Engines\\SR",
			GClass13.string_6 + "\\Speech_OneCore\\Engines\\Lexicon",
			GClass13.string_6 + "\\Speech_OneCore\\Engines\\SR",
			GClass13.string_6 + "\\tracing",
			GClass13.string_7 + "\\wbem\\Logs",
			GClass13.string_8 + "\\wbem\\Logs"
		};
		array.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_49));
		@class.string_0 = GClass13.string_6 + "\\servicing\\LCU";
		if (Directory.Exists(@class.string_0))
		{
			GClass14.smethod_0("cmd.exe /c rd %systemroot%\\servicing\\LCU /s /q", false);
			@class.method_0();
		}
		Form0.smethod_326(array, "*");
		array.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_50));
		array.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_51));
		Form0.smethod_306();
	}

	// Token: 0x06000256 RID: 598 RVA: 0x0000332F File Offset: 0x0000152F
	public static void smethod_319()
	{
		GClass6.GClass6_0.method_14("powercfg -h off");
	}

	// Token: 0x06000257 RID: 599 RVA: 0x00014624 File Offset: 0x00012824
	public static void smethod_320()
	{
		Form0.Class21 @class = new Form0.Class21();
		@class.registryKey_0 = Registry.CurrentUser.OpenSubKey("Software\\Classes\\Local Settings\\" + GClass2.GClass2_0.String_0 + "\\TrayNotify", true);
		try
		{
			new List<string>
			{
				"IconStreams",
				"PastIconsStream",
				"PromotedIconCache"
			}.ForEach(new Action<string>(@class.method_1));
		}
		finally
		{
			if (@class.registryKey_0 != null)
			{
				((IDisposable)@class.registryKey_0).Dispose();
			}
		}
		FileInfo fileInfo = new FileInfo(GClass13.string_0 + "\\BOOTSECT.BAK");
		string text = GClass13.string_12 + "\\DCBC2A71-70D8-4DAN-EHR8-E0D61DEA3FDF.ini";
		string[] array = new string[]
		{
			GClass13.string_6 + "\\WinSxS\\Temp",
			GClass13.string_6 + "\\WinSxS\\Backup",
			GClass13.string_6 + "\\WinSxS\\InstallTemp",
			GClass13.string_6 + "\\WinSxS\\ManifestCache"
		};
		string[] array2 = new string[]
		{
			GClass13.string_6 + "\\ServiceProfiles\\LocalService\\AppData\\Local"
		};
		string[] array3 = new string[]
		{
			GClass13.string_6 + "\\Prefetch"
		};
		string str = "AppData";
		string[] array4 = new string[]
		{
			GClass13.string_1 ?? "",
			GClass13.string_12 + "\\Apple Computer\\iTunes\\SubscriptionPlayCache",
			GClass13.string_12 + "\\Comms",
			GClass13.string_12 + "\\Microsoft\\Terminal Server Client\\Cache",
			GClass13.string_12 + "\\Microsoft\\Terminal Server Client\\Cache2",
			GClass13.string_12 + "\\Microsoft\\Windows\\PowerShell",
			GClass13.string_12 + "\\Microsoft\\Windows\\Notifications",
			GClass13.string_12 + "\\Microsoft\\Windows\\PRICache",
			GClass13.string_12 + "\\Microsoft\\Windows\\Caches",
			GClass13.string_12 + "\\Microsoft\\Windows\\WebCache",
			GClass13.string_12 + "\\Microsoft\\Windows\\WebCache.old",
			GClass13.string_12 + "\\Packages\\Microsoft.YourPhone_8wekyb3d8bbwe\\LocalCache\\Indexed",
			GClass13.string_12 + "\\Spotify\\Data",
			GClass13.string_12 + "\\Temp",
			GClass13.string_2 + "\\.nuget",
			GClass13.string_2 + "\\" + str + "\\Adobe\\Flash Player\\AssetCache",
			GClass13.string_2 + "\\" + str + "\\Adobe\\Flash Player\\NativeCache",
			GClass13.string_2 + "\\" + str + "\\LocalLow\\Microsoft\\CryptnetUrlCache",
			GClass13.string_2 + "\\" + str + "\\LocalLow\\Microsoft\\Windows\\AppCache",
			GClass13.string_2 + "\\" + str + "\\LocalLow\\Temp",
			GClass13.string_2 + "\\" + str + "\\Macromedia\\Flash Player\\AssetCache",
			GClass13.string_2 + "\\" + str + "\\Macromedia\\Flash Player\\NativeCache",
			GClass13.string_2 + "\\" + str + "\\Roaming\\Microsoft\\Windows\\Recent\\CustomDestinations",
			GClass13.string_2 + "\\Music\\iTunes\\Album Artwork\\Cache",
			GClass13.string_2 + "\\Music\\iTunes\\Album Artwork\\Cloud",
			GClass13.string_11 + "\\Microsoft\\Windows\\RetailDemo\\OfflineContent",
			GClass13.string_6 + "\\assembly\\temp",
			GClass13.string_6 + "\\Minidump",
			GClass13.string_6 + "\\Temp",
			GClass13.string_6 + "\\WinSxS\\Temp",
			GClass13.string_6 + "\\ServiceProfiles\\LocalService\\winhttp",
			GClass13.string_6 + "\\ServiceProfiles\\LocalService\\AppData\\Local\\FontCache",
			GClass13.string_6 + "\\ServiceProfiles\\NetworkService\\AppData\\Local\\Temp",
			GClass13.string_6 + "\\ServiceProfiles\\LocalService\\AppData\\LocalLow\\Microsoft\\CryptnetUrlCache\\Content",
			GClass13.string_6 + "\\ServiceProfiles\\LocalService\\AppData\\LocalLow\\Microsoft\\CryptnetUrlCache\\MetaData",
			GClass13.string_6 + "\\ServiceProfiles\\LocalService\\winhttp",
			GClass13.string_7 + "\\DriverStore\\Temp",
			GClass13.string_7 + "\\config\\systemprofile\\AppData\\LocalLow\\Microsoft\\CryptnetUrlCache\\Content",
			GClass13.string_7 + "\\config\\systemprofile\\AppData\\LocalLow\\Microsoft\\CryptnetUrlCache\\MetaData"
		};
		string[] source = new string[]
		{
			GClass13.string_12 + "\\Microsoft\\Windows\\INetCache",
			GClass13.string_12 + "\\Microsoft\\Windows\\Temporary Internet Files",
			GClass13.string_12 + "\\Microsoft\\Internet Explorer\\Recovery\\High\\Active",
			GClass13.string_12 + "\\Microsoft\\Internet Explorer\\Recovery\\High\\Last Active",
			GClass13.string_12 + "\\Microsoft\\Internet Explorer\\Recovery\\Active",
			GClass13.string_12 + "\\Microsoft\\Internet Explorer\\Recovery\\Last Active"
		};
		string[] array5 = new string[]
		{
			GClass13.string_6 + "\\ServiceProfiles\\LocalService",
			GClass13.string_6 + "\\ServiceProfiles\\NetworkService"
		};
		string[] array6 = new string[]
		{
			GClass13.string_12 + "\\Microsoft\\Internet Explorer",
			GClass13.string_11 + "\\Microsoft\\Search\\Data\\Applications\\Windows",
			GClass13.string_11 + "\\VirtualBox",
			GClass13.string_11 + "\\Locktime\\NetLimiter\\4\\logs"
		};
		string[] source2 = new string[]
		{
			GClass13.string_7 + "\\FNTCACHE.DAT",
			GClass13.string_12 + "\\Microsoft\\Internet Explorer\\MSIMGSIZ.DAT"
		};
		string[] array7 = new string[]
		{
			GClass13.string_12 + "\\Microsoft\\Internet Explorer"
		};
		string[] source3 = new string[]
		{
			GClass13.string_11 + "\\Locktime\\NetLimiter\\4\\Stats\\nlstatsV4.db",
			GClass13.string_11 + "\\Locktime\\NetLimiter\\4\\Stats\\nlstatsV6.db"
		};
		if (File.Exists(fileInfo.FullName))
		{
			Form0.list_0.Add(string.Format("{0}>{1}", fileInfo.FullName, new FileInfo(fileInfo.FullName).Length));
		}
		if (File.Exists(text))
		{
			Form0.list_0.Add(string.Format("{0}>{1}", text, new FileInfo(text).Length));
		}
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_52));
		if (Directory.Exists(array2[0]))
		{
			Form0.list_0.AddRange(Directory.GetFiles(array2[0], "*.dat").Select(new Func<string, string>(Form0.<>c.<>9.method_53)));
		}
		if (GClass2.GClass2_0.Boolean_1)
		{
			array3.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_54));
		}
		array4.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_55));
		source.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_56));
		if (Directory.Exists(array5[0]))
		{
			Form0.list_0.AddRange(Directory.GetFiles(array5[0], "*.blf").Select(new Func<string, string>(Form0.<>c.<>9.method_57)));
		}
		if (Directory.Exists(array5[0]))
		{
			Form0.list_0.AddRange(Directory.GetFiles(array5[0], "*.regtrans-ms").Select(new Func<string, string>(Form0.<>c.<>9.method_58)));
		}
		if (Directory.Exists(array5[1]))
		{
			Form0.list_0.AddRange(Directory.GetFiles(array5[1], "*.blf").Select(new Func<string, string>(Form0.<>c.<>9.method_59)));
		}
		if (Directory.Exists(array5[1]))
		{
			Form0.list_0.AddRange(Directory.GetFiles(array5[1], "*.regtrans-ms").Select(new Func<string, string>(Form0.<>c.<>9.method_60)));
		}
		array6.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_61));
		Form0.list_0.AddRange(source2.Where(new Func<string, bool>(Form0.<>c.<>9.method_62)).Select(new Func<string, string>(Form0.<>c.<>9.method_63)));
		array7.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_64));
		Form0.list_0.AddRange(source3.Where(new Func<string, bool>(Form0.<>c.<>9.method_65)).Select(new Func<string, string>(Form0.<>c.<>9.method_66)));
		try
		{
			try
			{
				fileInfo.Attributes = FileAttributes.Normal;
				File.Delete(fileInfo.FullName);
			}
			catch
			{
			}
			try
			{
				File.Delete(text);
			}
			catch
			{
			}
			array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_67));
			Form0.smethod_326(array, "*");
			if (!Directory.Exists(GClass13.string_6 + "\\WinSxS\\InstallTemp"))
			{
				GClass14.smethod_0("cmd.exe /c md %systemroot%\\WinSxS\\InstallTemp & takeown /f %systemroot%\\WinSxS\\InstallTemp /r /d y && icacls %systemroot%\\WinSxS\\InstallTemp /grant:r \"SYSTEM\":(OI)(CI)F /t", true);
			}
			try
			{
				Directory.GetFiles(array2[0], "*.dat").ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_68));
			}
			catch
			{
			}
			if (GClass2.GClass2_0.Boolean_1)
			{
				Form0.smethod_326(array3, "*");
			}
			Form0.smethod_326(array4, "*");
			source.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_69));
			try
			{
				Directory.GetFiles(array5[0], "*.blf").AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_70));
			}
			catch
			{
			}
			try
			{
				Directory.GetFiles(array5[0], "*.regtrans-ms").AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_71));
			}
			catch
			{
			}
			try
			{
				Directory.GetFiles(array5[1], "*.blf").AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_72));
			}
			catch
			{
			}
			try
			{
				Directory.GetFiles(array5[1], "*.regtrans-ms").AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_73));
			}
			catch
			{
			}
			Form0.smethod_326(array6, "*.log");
			source2.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_74));
			Form0.smethod_326(array7, "*.txt");
			source3.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_75));
			if (GClass2.GClass2_0.String_3.Contains("10"))
			{
				Form0.smethod_328();
			}
		}
		catch
		{
		}
		if (File.Exists(fileInfo.FullName))
		{
			Form0.list_1.Add(string.Format("{0}>{1}", fileInfo.FullName, new FileInfo(fileInfo.FullName).Length));
		}
		if (File.Exists(text))
		{
			Form0.list_1.Add(string.Format("{0}>{1}", text, new FileInfo(text).Length));
		}
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_76));
		if (Directory.Exists(array2[0]))
		{
			Form0.list_1.AddRange(Directory.GetFiles(array2[0], "*.dat").Select(new Func<string, string>(Form0.<>c.<>9.method_77)));
		}
		if (GClass2.GClass2_0.Boolean_1)
		{
			array3.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_78));
		}
		array4.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_79));
		source.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_80));
		if (Directory.Exists(array5[0]))
		{
			Form0.list_1.AddRange(Directory.GetFiles(array5[0], "*.blf").Select(new Func<string, string>(Form0.<>c.<>9.method_81)));
		}
		if (Directory.Exists(array5[0]))
		{
			Form0.list_1.AddRange(Directory.GetFiles(array5[0], "*.regtrans-ms").Select(new Func<string, string>(Form0.<>c.<>9.method_82)));
		}
		if (Directory.Exists(array5[1]))
		{
			Form0.list_1.AddRange(Directory.GetFiles(array5[1], "*.blf").Select(new Func<string, string>(Form0.<>c.<>9.method_83)));
		}
		if (Directory.Exists(array5[1]))
		{
			Form0.list_1.AddRange(Directory.GetFiles(array5[1], "*.regtrans-ms").Select(new Func<string, string>(Form0.<>c.<>9.method_84)));
		}
		array6.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_85));
		Form0.list_1.AddRange(source2.Where(new Func<string, bool>(Form0.<>c.<>9.method_86)).Select(new Func<string, string>(Form0.<>c.<>9.method_87)));
		array7.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_88));
		Form0.list_1.AddRange(source3.Where(new Func<string, bool>(Form0.<>c.<>9.method_89)).Select(new Func<string, string>(Form0.<>c.<>9.method_90)));
		Form0.smethod_306();
	}

	// Token: 0x06000258 RID: 600 RVA: 0x00015648 File Offset: 0x00013848
	public static void smethod_321()
	{
		string[] array = new string[]
		{
			GClass13.string_11 + "\\Microsoft\\Diagnosis\\ETLLogs",
			GClass13.string_11 + "\\Microsoft\\DiagnosticLogCSP\\Collectors",
			GClass13.string_12 + "\\ElevatedDiagnostics",
			GClass13.string_7 + "\\WDI\\{86432a0b-3c7d-4ddf-a89c-172faa90485d}"
		};
		string[] source = new string[]
		{
			GClass13.string_7 + "\\WDI\\BootPerformanceDiagnostics_SystemData.bin",
			GClass13.string_7 + "\\WDI\\ShutdownPerformanceDiagnostics_SystemData.bin"
		};
		string[] array2 = new string[]
		{
			GClass13.string_11 + "\\Microsoft\\Windows\\Power Efficiency Diagnostics"
		};
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_91));
		Form0.list_0.AddRange(source.Where(new Func<string, bool>(Form0.<>c.<>9.method_92)).Select(new Func<string, string>(Form0.<>c.<>9.method_93)));
		if (Directory.Exists(array2[0]))
		{
			Form0.list_0.AddRange(Directory.GetFiles(array2[0], "*.xml").Where(new Func<string, bool>(Form0.<>c.<>9.method_94)).Select(new Func<string, string>(Form0.<>c.<>9.method_95)));
		}
		Form0.smethod_326(array, "*");
		array.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_96));
		source.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_97));
		Directory.GetFiles(array2[0], "*.xml").Where(new Func<string, bool>(Form0.<>c.<>9.method_98)).ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_99));
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_100));
		Form0.list_1.AddRange(source.Where(new Func<string, bool>(Form0.<>c.<>9.method_101)).Select(new Func<string, string>(Form0.<>c.<>9.method_102)));
		if (Directory.Exists(array2[0]))
		{
			Form0.list_0.AddRange(Directory.GetFiles(array2[0], "*.xml").Where(new Func<string, bool>(Form0.<>c.<>9.method_103)).Select(new Func<string, string>(Form0.<>c.<>9.method_104)));
		}
		Form0.smethod_306();
	}

	// Token: 0x06000259 RID: 601 RVA: 0x00015974 File Offset: 0x00013B74
	public static void smethod_322()
	{
		Form0.Class22 @class = new Form0.Class22();
		string[] array = new string[]
		{
			GClass13.string_2 + "\\.VirtualBox",
			GClass13.string_12 + "\\Microsoft\\Windows Mail",
			GClass13.string_11 + "\\Acronis\\TrueImageHome\\Logs",
			GClass13.string_11 + "\\Microsoft\\SmsRouter\\MessageStore",
			GClass13.string_6 + "\\debug",
			GClass13.string_6 + "\\Microsoft.NET",
			GClass13.string_6 + "\\Performance",
			GClass13.string_6 + "\\Panther"
		};
		string[] array2 = new string[]
		{
			GClass13.string_2 + "\\AppData\\Roaming\\Opera Software\\Opera Stable\\Crash Reports",
			GClass13.string_12 + "\\Microsoft\\OneDrive\\setup\\logs",
			GClass13.string_11 + "\\Microsoft\\Network\\Downloader",
			GClass13.string_11 + "\\Microsoft\\Search\\Data\\Applications\\Windows\\GatherLogs\\SystemIndex",
			GClass13.string_11 + "\\Microsoft\\Windows\\WER",
			GClass13.string_11 + "\\Microsoft\\Windows Security Health\\Logs",
			GClass13.string_11 + "\\Microsoft\\Windows Defender\\Support",
			GClass13.string_11 + "\\USOShared\\Logs",
			GClass13.string_7 + "\\LogFiles\\Scm",
			GClass13.string_7 + "\\SleepStudy",
			GClass13.string_7 + "\\sysprep\\Panther\\IE",
			GClass13.string_7 + "\\WDI\\LogFiles",
			GClass13.string_6 + "\\Performance\\WinSAT",
			GClass13.string_6 + "\\security\\logs",
			GClass13.string_6 + "\\Logs"
		};
		string[] array3 = new string[]
		{
			GClass13.string_6 + "\\SoftwareDistribution\\DataStore\\Logs",
			GClass13.string_11 + "\\Microsoft\\Windows\\WER\\ReportArchive",
			GClass13.string_11 + "\\Microsoft\\Windows\\WER\\ReportQueue",
			GClass13.string_6 + "\\LiveKernelReports",
			GClass13.string_11 + "\\Acronis\\TrueImageHome\\Logs"
		};
		string[] array4 = new string[]
		{
			GClass13.string_7 + "\\LogFiles"
		};
		@class.string_0 = new string[]
		{
			GClass13.string_7 + "\\LogFiles\\WMI",
			GClass13.string_7 + "\\LogFiles\\WMI\\RtBackup"
		};
		string[] array5 = new string[]
		{
			GClass13.string_11 + "\\Acronis\\ActiveProtection\\Logs",
			GClass13.string_11 + "\\Acronis\\FileProtectorLogs",
			GClass13.string_11 + "\\Acronis\\MMS",
			GClass13.string_11 + "\\Acronis\\Schedule2",
			GClass13.string_11 + "\\Acronis\\SnapAPILogs",
			GClass13.string_11 + "\\Acronis\\SyncAgent\\logs",
			GClass13.string_11 + "\\Acronis\\VolumeTrackerLogs",
			GClass13.string_11 + "\\Acronis\\VssRequestorLogs",
			GClass13.string_11 + "\\Acronis\\TrueImageHome\\Logs",
			GClass13.string_11 + "\\Acronis\\ActiveProtection\\Logs"
		};
		string[] array6 = new string[]
		{
			GClass13.string_12 + "\\Packages",
			GClass13.string_6 + "\\ServiceProfiles\\NetworkService\\AppData\\Local\\Microsoft\\Windows\\DeliveryOptimization\\Logs",
			GClass13.string_6 + "\\appcompat\\appraiser\\Telemetry"
		};
		string[] source = new string[]
		{
			GClass13.string_11 + "\\Microsoft\\Windows Defender\\Network Inspection System\\Support\\NisLog.txt",
			GClass13.string_6 + "\\INF\\setupapi.setup.log",
			GClass13.string_6 + "\\INF\\setupapi.offline.log",
			GClass13.string_6 + "\\INF\\setupapi.app.log",
			GClass13.string_6 + "\\INF\\setupapi.dev.log",
			GClass13.string_11 + "\\Microsoft\\Windows Defender\\Network Inspection System\\Support\\NisLog.txt",
			GClass13.string_7 + "\\catroot2\\dberr.txt",
			GClass13.string_7 + "\\catroot2\\edb.chk",
			GClass13.string_7 + "\\catroot2\\edbres00001.jrs",
			GClass13.string_7 + "\\catroot2\\edbres00002.jrs",
			GClass13.string_6 + "\\SoftwareDistribution\\DataStore\\DataStore.jfm",
			GClass13.string_6 + "\\SoftwareDistribution\\DataStore\\DataStore.edb"
		};
		string[] array7 = new string[]
		{
			GClass13.string_6 + "\\Installer"
		};
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_105));
		array2.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_106));
		array3.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_107));
		array4.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_108));
		@class.string_0.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_109));
		array5.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_110));
		array6.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_111));
		Form0.list_0.AddRange(source.Where(new Func<string, bool>(Form0.<>c.<>9.method_112)).Select(new Func<string, string>(Form0.<>c.<>9.method_113)));
		array7.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_114));
		Form0.list_0.AddRange(Directory.GetFiles(GClass13.string_11, "*.log").Where(new Func<string, bool>(Form0.<>c.<>9.method_115)).Select(new Func<string, string>(Form0.<>c.<>9.method_116)));
		Form0.list_0.AddRange(Directory.GetFiles(GClass13.string_11, "*.log_backup1").Where(new Func<string, bool>(Form0.<>c.<>9.method_117)).Select(new Func<string, string>(Form0.<>c.<>9.method_118)));
		Form0.list_0.AddRange(Directory.GetFiles(GClass13.string_6, "*.log").Where(new Func<string, bool>(Form0.<>c.<>9.method_119)).Select(new Func<string, string>(Form0.<>c.<>9.method_120)));
		try
		{
			Form0.smethod_326(array, "*.log");
			Form0.smethod_326(array2, "*");
			Form0.smethod_326(array3, "*");
			array3.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_121));
			Form0.smethod_326(array4, "*.log");
			@class.string_0.AsParallel<string>().ForAll(new Action<string>(@class.method_0));
			Form0.smethod_326(array5, "*.log");
			Form0.smethod_326(array6, "*.etl");
			source.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_122));
			Form0.smethod_326(array7, "SourceHash*");
			Directory.GetFiles(GClass13.string_11, "*.log").AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_123));
			Directory.GetFiles(GClass13.string_11, "*.log_backup1").AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_124));
			Directory.GetFiles(GClass13.string_6, "*.log").AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_125));
		}
		catch
		{
		}
		try
		{
			array3.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_126));
		}
		catch
		{
		}
		array.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_127));
		array2.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_128));
		array3.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_129));
		array4.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_130));
		@class.string_0.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_131));
		array5.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_132));
		array6.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_133));
		Form0.list_1.AddRange(source.Where(new Func<string, bool>(Form0.<>c.<>9.method_134)).Select(new Func<string, string>(Form0.<>c.<>9.method_135)));
		array7.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_136));
		Form0.list_1.AddRange(Directory.GetFiles(GClass13.string_11, "*.log").Where(new Func<string, bool>(Form0.<>c.<>9.method_137)).Select(new Func<string, string>(Form0.<>c.<>9.method_138)));
		Form0.list_1.AddRange(Directory.GetFiles(GClass13.string_11, "*.log_backup1").Where(new Func<string, bool>(Form0.<>c.<>9.method_139)).Select(new Func<string, string>(Form0.<>c.<>9.method_140)));
		Form0.list_1.AddRange(Directory.GetFiles(GClass13.string_6, "*.log").Where(new Func<string, bool>(Form0.<>c.<>9.method_141)).Select(new Func<string, string>(Form0.<>c.<>9.method_142)));
		Form0.smethod_306();
	}

	// Token: 0x0600025A RID: 602 RVA: 0x00016558 File Offset: 0x00014758
	public static void smethod_323()
	{
		Form0.Class23 @class = new Form0.Class23();
		@class.list_0 = new List<string>();
		new List<string>
		{
			GClass13.string_0 + "\\Boot",
			GClass13.string_9 + "\\Common Files\\microsoft shared\\ink",
			GClass13.string_6 + "\\Boot\\EFI",
			GClass13.string_6 + "\\Boot\\PCAT",
			GClass13.string_7 ?? "",
			GClass13.string_8 ?? ""
		}.ForEach(new Action<string>(@class.method_0));
		@class.list_0.ForEach(new Action<string>(Form0.<>c.<>9.method_145));
		@class.list_0.ToList<string>().ForEach(new Action<string>(Form0.<>c.<>9.method_146));
		Form0.smethod_306();
	}

	// Token: 0x0600025B RID: 603 RVA: 0x00016668 File Offset: 0x00014868
	public static void smethod_324()
	{
		new string[]
		{
			GClass13.string_6 + "\\bcastdvr",
			GClass13.string_6 + "\\DeliveryOptimization",
			GClass13.string_6 + "\\BitLockerDiscoveryVolumeContents",
			GClass13.string_6 + "\\Logs",
			GClass13.string_6 + "\\rescache",
			GClass13.string_7 + "\\DriverStore\\Temp",
			GClass13.string_7 + "\\LogFiles\\WMI",
			GClass13.string_11 + "\\Microsoft\\Diagnosis\\ETLLogs"
		}.AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_147));
	}

	// Token: 0x0600025C RID: 604 RVA: 0x00016734 File Offset: 0x00014934
	public static void smethod_325()
	{
		Form0.Struct31 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Form0.Struct31>(ref @struct);
	}

	// Token: 0x0600025D RID: 605 RVA: 0x00016764 File Offset: 0x00014964
	public static void smethod_326(string[] string_0, string string_1)
	{
		foreach (string path in string_0)
		{
			if (Directory.Exists(path))
			{
				try
				{
					Directory.GetFiles(path, string_1, SearchOption.AllDirectories).AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_149));
					Directory.GetDirectories(path, string_1, SearchOption.AllDirectories).AsParallel<string>().ForAll(new Action<string>(Form0.<>c.<>9.method_150));
				}
				catch
				{
				}
			}
		}
	}

	// Token: 0x06000260 RID: 608 RVA: 0x00016804 File Offset: 0x00014A04
	[CompilerGenerated]
	internal static void smethod_327(string string_0, ref Form0.Struct29 struct29_0)
	{
		struct29_0.list_0.Add(string_0 + "\\Crashpad\\reports");
		struct29_0.list_0.Add(string_0 + "\\ShaderCache\\GPUCache");
		struct29_0.list_0.Add(string_0 + "\\Default\\Cache");
		struct29_0.list_0.Add(string_0 + "\\Default\\Code Cache\\js");
		struct29_0.list_0.Add(string_0 + "\\Default\\Session Storage");
		struct29_0.list_0.Add(string_0 + "\\Default\\Service Worker");
	}

	// Token: 0x06000261 RID: 609 RVA: 0x0000336E File Offset: 0x0000156E
	[CompilerGenerated]
	internal static void smethod_328()
	{
		PowerShell.Create().AddScript("Clear-RecycleBin -Force").Invoke();
	}

	// Token: 0x06000262 RID: 610 RVA: 0x000030F1 File Offset: 0x000012F1
	static Process[] smethod_329()
	{
		return Process.GetProcesses();
	}

	// Token: 0x06000263 RID: 611 RVA: 0x00003385 File Offset: 0x00001585
	static IntPtr smethod_330(Process process_0)
	{
		return process_0.Handle;
	}

	// Token: 0x06000264 RID: 612 RVA: 0x0000338D File Offset: 0x0000158D
	static WindowsIdentity smethod_331(TokenAccessLevels tokenAccessLevels_0)
	{
		return WindowsIdentity.GetCurrent(tokenAccessLevels_0);
	}

	// Token: 0x06000265 RID: 613 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_332(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x06000266 RID: 614 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_333(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x06000267 RID: 615 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_334(string string_0, string string_1)
	{
		return string_0 == string_1;
	}

	// Token: 0x06000268 RID: 616 RVA: 0x00003395 File Offset: 0x00001595
	static int smethod_335()
	{
		return Marshal.GetLastWin32Error();
	}

	// Token: 0x06000269 RID: 617 RVA: 0x0000339C File Offset: 0x0000159C
	static Win32Exception smethod_336(int int_1)
	{
		return new Win32Exception(int_1);
	}

	// Token: 0x0600026A RID: 618 RVA: 0x000033A4 File Offset: 0x000015A4
	static Exception smethod_337(string string_0, Exception exception_0)
	{
		return new Exception(string_0, exception_0);
	}

	// Token: 0x0600026B RID: 619 RVA: 0x000033AD File Offset: 0x000015AD
	static IntPtr smethod_338(WindowsIdentity windowsIdentity_0)
	{
		return windowsIdentity_0.Token;
	}

	// Token: 0x0600026C RID: 620 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_339(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x0600026D RID: 621 RVA: 0x000031B0 File Offset: 0x000013B0
	static string[] smethod_340(string string_0, string string_1)
	{
		return Directory.GetFiles(string_0, string_1);
	}

	// Token: 0x0600026E RID: 622 RVA: 0x000033B5 File Offset: 0x000015B5
	static string[] smethod_341(string string_0)
	{
		return Directory.GetDirectories(string_0);
	}

	// Token: 0x0600026F RID: 623 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_342(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x06000270 RID: 624 RVA: 0x000033BD File Offset: 0x000015BD
	static string smethod_343(string string_0, string string_1, string string_2, string string_3)
	{
		return string_0 + string_1 + string_2 + string_3;
	}

	// Token: 0x06000271 RID: 625 RVA: 0x0000307B File Offset: 0x0000127B
	static RegistryKey smethod_344(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.OpenSubKey(string_0);
	}

	// Token: 0x06000272 RID: 626 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_345(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.GetValue(string_0);
	}

	// Token: 0x06000273 RID: 627 RVA: 0x000033C8 File Offset: 0x000015C8
	static string smethod_346(string string_0, object object_0)
	{
		return string.Format(string_0, object_0);
	}

	// Token: 0x06000274 RID: 628 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_347(string string_0)
	{
		return File.Exists(string_0);
	}

	// Token: 0x06000275 RID: 629 RVA: 0x000033D1 File Offset: 0x000015D1
	static string smethod_348(string string_0, string string_1, string string_2)
	{
		return string_0.Replace(string_1, string_2);
	}

	// Token: 0x06000276 RID: 630 RVA: 0x00002EE5 File Offset: 0x000010E5
	static bool smethod_349(string string_0)
	{
		return Directory.Exists(string_0);
	}

	// Token: 0x06000277 RID: 631 RVA: 0x000031B9 File Offset: 0x000013B9
	static string[] smethod_350(string string_0, string string_1, SearchOption searchOption_0)
	{
		return Directory.GetFiles(string_0, string_1, searchOption_0);
	}

	// Token: 0x06000278 RID: 632 RVA: 0x000033DB File Offset: 0x000015DB
	static string[] smethod_351(string string_0)
	{
		return File.ReadAllLines(string_0);
	}

	// Token: 0x06000279 RID: 633 RVA: 0x000033E3 File Offset: 0x000015E3
	static string[] smethod_352(string string_0, string string_1)
	{
		return Directory.GetDirectories(string_0, string_1);
	}

	// Token: 0x0600027A RID: 634 RVA: 0x000033EC File Offset: 0x000015EC
	static Process[] smethod_353(string string_0)
	{
		return Process.GetProcessesByName(string_0);
	}

	// Token: 0x0600027B RID: 635 RVA: 0x000033F4 File Offset: 0x000015F4
	static ProcessModule smethod_354(Process process_0)
	{
		return process_0.MainModule;
	}

	// Token: 0x0600027C RID: 636 RVA: 0x000033FC File Offset: 0x000015FC
	static string smethod_355(ProcessModule processModule_0)
	{
		return processModule_0.FileName;
	}

	// Token: 0x0600027D RID: 637 RVA: 0x0000316F File Offset: 0x0000136F
	static FileInfo smethod_356(string string_0)
	{
		return new FileInfo(string_0);
	}

	// Token: 0x0600027E RID: 638 RVA: 0x00003404 File Offset: 0x00001604
	static long smethod_357(FileInfo fileInfo_0)
	{
		return fileInfo_0.Length;
	}

	// Token: 0x0600027F RID: 639 RVA: 0x00002FFC File Offset: 0x000011FC
	static string smethod_358(string string_0, object object_0, object object_1)
	{
		return string.Format(string_0, object_0, object_1);
	}

	// Token: 0x06000280 RID: 640 RVA: 0x00002F15 File Offset: 0x00001115
	static void smethod_359(string string_0)
	{
		File.Delete(string_0);
	}

	// Token: 0x06000281 RID: 641 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_360(RegistryKey registryKey_0, string string_0)
	{
		return registryKey_0.CreateSubKey(string_0);
	}

	// Token: 0x06000282 RID: 642 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_361(RegistryKey registryKey_0, string string_0, object object_0)
	{
		registryKey_0.SetValue(string_0, object_0);
	}

	// Token: 0x06000283 RID: 643 RVA: 0x00003019 File Offset: 0x00001219
	static string[] smethod_362(RegistryKey registryKey_0)
	{
		return registryKey_0.GetValueNames();
	}

	// Token: 0x06000284 RID: 644 RVA: 0x0000340C File Offset: 0x0000160C
	static EventLog[] smethod_363()
	{
		return EventLog.GetEventLogs();
	}

	// Token: 0x06000285 RID: 645 RVA: 0x00003413 File Offset: 0x00001613
	static EventLogSession smethod_364()
	{
		return new EventLogSession();
	}

	// Token: 0x06000286 RID: 646 RVA: 0x0000341A File Offset: 0x0000161A
	static EventLogSession smethod_365()
	{
		return EventLogSession.GlobalSession;
	}

	// Token: 0x06000287 RID: 647 RVA: 0x00003421 File Offset: 0x00001621
	static IEnumerable<string> smethod_366(EventLogSession eventLogSession_0)
	{
		return eventLogSession_0.GetLogNames();
	}

	// Token: 0x06000288 RID: 648 RVA: 0x00003429 File Offset: 0x00001629
	static string[] smethod_367(RegistryKey registryKey_0)
	{
		return registryKey_0.GetSubKeyNames();
	}

	// Token: 0x06000289 RID: 649 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_368(string string_0, string string_1)
	{
		return string_0.Contains(string_1);
	}

	// Token: 0x0600028A RID: 650 RVA: 0x00003431 File Offset: 0x00001631
	static void smethod_369(string string_0)
	{
		Directory.Delete(string_0);
	}

	// Token: 0x0600028B RID: 651 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_370(string string_0, string string_1, string string_2)
	{
		return string_0 + string_1 + string_2;
	}

	// Token: 0x0600028C RID: 652 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_371(RegistryKey registryKey_0, string string_0, bool bool_1)
	{
		return registryKey_0.OpenSubKey(string_0, bool_1);
	}

	// Token: 0x0600028D RID: 653 RVA: 0x00003439 File Offset: 0x00001639
	static string smethod_372(FileSystemInfo fileSystemInfo_0)
	{
		return fileSystemInfo_0.FullName;
	}

	// Token: 0x0600028E RID: 654 RVA: 0x00003441 File Offset: 0x00001641
	static void smethod_373(FileSystemInfo fileSystemInfo_0, FileAttributes fileAttributes_0)
	{
		fileSystemInfo_0.Attributes = fileAttributes_0;
	}

	// Token: 0x0600028F RID: 655 RVA: 0x0000344A File Offset: 0x0000164A
	static string[] smethod_374(string string_0, string string_1, SearchOption searchOption_0)
	{
		return Directory.GetDirectories(string_0, string_1, searchOption_0);
	}

	// Token: 0x06000290 RID: 656 RVA: 0x00003454 File Offset: 0x00001654
	static PowerShell smethod_375()
	{
		return PowerShell.Create();
	}

	// Token: 0x06000291 RID: 657 RVA: 0x0000345B File Offset: 0x0000165B
	static PowerShell smethod_376(PowerShell powerShell_0, string string_0)
	{
		return powerShell_0.AddScript(string_0);
	}

	// Token: 0x06000292 RID: 658 RVA: 0x00003464 File Offset: 0x00001664
	static Collection<PSObject> smethod_377(PowerShell powerShell_0)
	{
		return powerShell_0.Invoke();
	}

	// Token: 0x0400010A RID: 266
	[CompilerGenerated]
	private static Form0.Delegate0 delegate0_0;

	// Token: 0x0400010B RID: 267
	public static List<string> list_0 = new List<string>();

	// Token: 0x0400010C RID: 268
	public static List<string> list_1 = new List<string>();

	// Token: 0x0400010D RID: 269
	public static List<string> list_2 = new List<string>();

	// Token: 0x0400010E RID: 270
	public static int int_0 = 0;

	// Token: 0x0200003C RID: 60
	// (Invoke) Token: 0x06000294 RID: 660
	public delegate void Delegate0(List<string> rows);

	// Token: 0x02000040 RID: 64
	[CompilerGenerated]
	private sealed class Class17
	{
		// Token: 0x0600034F RID: 847 RVA: 0x00003705 File Offset: 0x00001905
		internal void method_0(string string_0)
		{
			this.list_0.Add(string_0.Substring(string_0.LastIndexOf(":\\\\") - 1).Replace("\\\\", "\\"));
		}

		// Token: 0x06000350 RID: 848 RVA: 0x00003734 File Offset: 0x00001934
		internal void method_1(string string_0)
		{
			this.list_1.AddRange(Directory.GetDirectories(string_0, "*", SearchOption.AllDirectories));
		}

		// Token: 0x06000351 RID: 849 RVA: 0x0000374D File Offset: 0x0000194D
		internal void method_2(string string_0)
		{
			this.list_2.AddRange(Directory.GetFiles(string_0, "*", SearchOption.AllDirectories).Where(new Func<string, bool>(Form0.<>c.<>9.method_8)));
		}

		// Token: 0x06000352 RID: 850 RVA: 0x0000378A File Offset: 0x0000198A
		internal void method_3(string string_0)
		{
			this.list_3.Add(string_0.Substring(string_0.LastIndexOf(":\\\\") - 1).Replace("\\\\", "\\"));
		}

		// Token: 0x06000353 RID: 851 RVA: 0x000037B9 File Offset: 0x000019B9
		internal void method_4(string string_0)
		{
			this.list_2.AddRange(Directory.GetFiles(string_0, "*", SearchOption.AllDirectories));
		}

		// Token: 0x06000354 RID: 852 RVA: 0x000037D2 File Offset: 0x000019D2
		static int smethod_0(string string_0, string string_1)
		{
			return string_0.LastIndexOf(string_1);
		}

		// Token: 0x06000355 RID: 853 RVA: 0x00002C7A File Offset: 0x00000E7A
		static string smethod_1(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x06000356 RID: 854 RVA: 0x000033D1 File Offset: 0x000015D1
		static string smethod_2(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000357 RID: 855 RVA: 0x0000344A File Offset: 0x0000164A
		static string[] smethod_3(string string_0, string string_1, SearchOption searchOption_0)
		{
			return Directory.GetDirectories(string_0, string_1, searchOption_0);
		}

		// Token: 0x06000358 RID: 856 RVA: 0x000031B9 File Offset: 0x000013B9
		static string[] smethod_4(string string_0, string string_1, SearchOption searchOption_0)
		{
			return Directory.GetFiles(string_0, string_1, searchOption_0);
		}

		// Token: 0x040001AE RID: 430
		public List<string> list_0;

		// Token: 0x040001AF RID: 431
		public List<string> list_1;

		// Token: 0x040001B0 RID: 432
		public List<string> list_2;

		// Token: 0x040001B1 RID: 433
		public List<string> list_3;
	}

	// Token: 0x02000041 RID: 65
	[CompilerGenerated]
	[StructLayout(LayoutKind.Auto)]
	private struct Struct29
	{
		// Token: 0x040001B2 RID: 434
		public List<string> list_0;
	}

	// Token: 0x02000042 RID: 66
	[CompilerGenerated]
	private sealed class Class18
	{
		// Token: 0x0600035A RID: 858 RVA: 0x000037DB File Offset: 0x000019DB
		internal void method_0(string string_0)
		{
			if (!this.registryKey_0.GetValue(string_0).ToString().Contains("ftp://"))
			{
				this.registryKey_0.DeleteValue(string_0);
			}
		}

		// Token: 0x0600035B RID: 859 RVA: 0x000029DD File Offset: 0x00000BDD
		static object smethod_0(RegistryKey registryKey_1, string string_0)
		{
			return registryKey_1.GetValue(string_0);
		}

		// Token: 0x0600035C RID: 860 RVA: 0x000029E6 File Offset: 0x00000BE6
		static string smethod_1(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600035D RID: 861 RVA: 0x00002A20 File Offset: 0x00000C20
		static bool smethod_2(string string_0, string string_1)
		{
			return string_0.Contains(string_1);
		}

		// Token: 0x0600035E RID: 862 RVA: 0x00003010 File Offset: 0x00001210
		static void smethod_3(RegistryKey registryKey_1, string string_0)
		{
			registryKey_1.DeleteValue(string_0);
		}

		// Token: 0x040001B3 RID: 435
		public RegistryKey registryKey_0;
	}

	// Token: 0x02000043 RID: 67
	[CompilerGenerated]
	private sealed class Class19
	{
		// Token: 0x06000360 RID: 864 RVA: 0x00016FA8 File Offset: 0x000151A8
		internal void method_0(string string_0)
		{
			try
			{
				this.eventLogSession_0.ClearLog(string_0);
			}
			catch
			{
			}
		}

		// Token: 0x06000361 RID: 865 RVA: 0x00003806 File Offset: 0x00001A06
		static void smethod_0(EventLogSession eventLogSession_1, string string_0)
		{
			eventLogSession_1.ClearLog(string_0);
		}

		// Token: 0x040001B4 RID: 436
		public EventLogSession eventLogSession_0;
	}

	// Token: 0x02000044 RID: 68
	[CompilerGenerated]
	private sealed class Class20
	{
		// Token: 0x06000363 RID: 867 RVA: 0x00016FD8 File Offset: 0x000151D8
		internal void method_0()
		{
			Form0.Class20.Struct30 @struct;
			@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
			@struct.class20_0 = this;
			@struct.int_0 = -1;
			@struct.asyncVoidMethodBuilder_0.Start<Form0.Class20.Struct30>(ref @struct);
		}

		// Token: 0x040001B5 RID: 437
		public string string_0;

		// Token: 0x02000045 RID: 69
		[StructLayout(LayoutKind.Auto)]
		private struct Struct30 : IAsyncStateMachine
		{
			// Token: 0x06000364 RID: 868 RVA: 0x00017010 File Offset: 0x00015210
			void IAsyncStateMachine.MoveNext()
			{
				int num = this.int_0;
				Form0.Class20 @class = this.class20_0;
				try
				{
					if (num != 0)
					{
						goto IL_4F;
					}
					TaskAwaiter awaiter = this.taskAwaiter_0;
					this.taskAwaiter_0 = default(TaskAwaiter);
					this.int_0 = -1;
					IL_48:
					awaiter.GetResult();
					IL_4F:
					if (Directory.Exists(@class.string_0))
					{
						awaiter = Task.Delay(700).GetAwaiter();
						if (awaiter.IsCompleted)
						{
							goto IL_48;
						}
						this.int_0 = 0;
						this.taskAwaiter_0 = awaiter;
						this.asyncVoidMethodBuilder_0.AwaitUnsafeOnCompleted<TaskAwaiter, Form0.Class20.Struct30>(ref awaiter, ref this);
						return;
					}
				}
				catch (Exception exception)
				{
					this.int_0 = -2;
					this.asyncVoidMethodBuilder_0.SetException(exception);
					return;
				}
				this.int_0 = -2;
				this.asyncVoidMethodBuilder_0.SetResult();
			}

			// Token: 0x06000365 RID: 869 RVA: 0x0000380F File Offset: 0x00001A0F
			[DebuggerHidden]
			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
			{
				this.asyncVoidMethodBuilder_0.SetStateMachine(stateMachine);
			}

			// Token: 0x06000366 RID: 870 RVA: 0x00002AE5 File Offset: 0x00000CE5
			static Task smethod_0(int int_1)
			{
				return Task.Delay(int_1);
			}

			// Token: 0x06000367 RID: 871 RVA: 0x00002AED File Offset: 0x00000CED
			static TaskAwaiter smethod_1(Task task_0)
			{
				return task_0.GetAwaiter();
			}

			// Token: 0x040001B6 RID: 438
			public int int_0;

			// Token: 0x040001B7 RID: 439
			public AsyncVoidMethodBuilder asyncVoidMethodBuilder_0;

			// Token: 0x040001B8 RID: 440
			public Form0.Class20 class20_0;

			// Token: 0x040001B9 RID: 441
			private TaskAwaiter taskAwaiter_0;
		}
	}

	// Token: 0x02000046 RID: 70
	[CompilerGenerated]
	private sealed class Class21
	{
		// Token: 0x06000369 RID: 873 RVA: 0x0000381D File Offset: 0x00001A1D
		internal void method_0(string string_0)
		{
			if (this.registryKey_0 != null && this.registryKey_0.GetValue(string_0) != null)
			{
				this.registryKey_0.DeleteValue(string_0);
			}
		}

		// Token: 0x0600036A RID: 874 RVA: 0x00003841 File Offset: 0x00001A41
		internal void method_1(string string_0)
		{
			this.method_0(string_0);
		}

		// Token: 0x0600036B RID: 875 RVA: 0x000029DD File Offset: 0x00000BDD
		static object smethod_0(RegistryKey registryKey_1, string string_0)
		{
			return registryKey_1.GetValue(string_0);
		}

		// Token: 0x0600036C RID: 876 RVA: 0x00003010 File Offset: 0x00001210
		static void smethod_1(RegistryKey registryKey_1, string string_0)
		{
			registryKey_1.DeleteValue(string_0);
		}

		// Token: 0x040001BA RID: 442
		public RegistryKey registryKey_0;
	}

	// Token: 0x02000047 RID: 71
	[CompilerGenerated]
	private sealed class Class22
	{
		// Token: 0x0600036E RID: 878 RVA: 0x000170D8 File Offset: 0x000152D8
		internal void method_0(string string_1)
		{
			try
			{
				string_1.smethod_0();
				Form0.smethod_326(this.string_0, "*");
			}
			catch
			{
			}
		}

		// Token: 0x040001BB RID: 443
		public string[] string_0;
	}

	// Token: 0x02000048 RID: 72
	[CompilerGenerated]
	private sealed class Class23
	{
		// Token: 0x06000370 RID: 880 RVA: 0x0000384A File Offset: 0x00001A4A
		internal void method_0(string string_0)
		{
			if (Directory.Exists(string_0))
			{
				this.list_0.AddRange(Directory.GetDirectories(string_0, "*-*"));
			}
		}

		// Token: 0x06000371 RID: 881 RVA: 0x00002EE5 File Offset: 0x000010E5
		static bool smethod_0(string string_0)
		{
			return Directory.Exists(string_0);
		}

		// Token: 0x06000372 RID: 882 RVA: 0x000033E3 File Offset: 0x000015E3
		static string[] smethod_1(string string_0, string string_1)
		{
			return Directory.GetDirectories(string_0, string_1);
		}

		// Token: 0x040001BC RID: 444
		public List<string> list_0;
	}
}
