﻿using System;

// Token: 0x020000C1 RID: 193
public static class GClass13
{
	// Token: 0x060009D2 RID: 2514 RVA: 0x000056CE File Offset: 0x000038CE
	static string smethod_0(string string_13)
	{
		return Environment.ExpandEnvironmentVariables(string_13);
	}

	// Token: 0x060009D3 RID: 2515 RVA: 0x00003935 File Offset: 0x00001B35
	static string smethod_1(Environment.SpecialFolder specialFolder_0)
	{
		return Environment.GetFolderPath(specialFolder_0);
	}

	// Token: 0x060009D4 RID: 2516 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_2(string string_13, string string_14)
	{
		return string_13 + string_14;
	}

	// Token: 0x040003D5 RID: 981
	public static string string_0 = Environment.ExpandEnvironmentVariables("%systemdrive%");

	// Token: 0x040003D6 RID: 982
	public static string string_1 = Environment.ExpandEnvironmentVariables("%temp%");

	// Token: 0x040003D7 RID: 983
	public static string string_2 = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

	// Token: 0x040003D8 RID: 984
	public static string string_3 = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\AppData\\Roaming";

	// Token: 0x040003D9 RID: 985
	public static string string_4 = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\AppData\\Local";

	// Token: 0x040003DA RID: 986
	public static string string_5 = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

	// Token: 0x040003DB RID: 987
	public static string string_6 = Environment.GetFolderPath(Environment.SpecialFolder.Windows);

	// Token: 0x040003DC RID: 988
	public static string string_7 = Environment.GetFolderPath(Environment.SpecialFolder.System);

	// Token: 0x040003DD RID: 989
	public static string string_8 = Environment.GetFolderPath(Environment.SpecialFolder.SystemX86);

	// Token: 0x040003DE RID: 990
	public static string string_9 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);

	// Token: 0x040003DF RID: 991
	public static string string_10 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);

	// Token: 0x040003E0 RID: 992
	public static string string_11 = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

	// Token: 0x040003E1 RID: 993
	public static string string_12 = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
}
