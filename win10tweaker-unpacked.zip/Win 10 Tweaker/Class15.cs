﻿using System;
using System.Runtime.CompilerServices;
using Win_10_Tweaker;

// Token: 0x02000034 RID: 52
internal class Class15
{
	// Token: 0x060001F7 RID: 503 RVA: 0x00011CBC File Offset: 0x0000FEBC
	public static void smethod_0()
	{
		Class15.Struct25 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Class15.Struct25>(ref @struct);
	}

	// Token: 0x040000EF RID: 239
	private static readonly Form1 form1_0 = new Form1();

	// Token: 0x02000035 RID: 53
	[CompilerGenerated]
	private static class Class16
	{
		// Token: 0x040000F0 RID: 240
		public static CallSite<Func<CallSite, object, GInterface12>> callSite_0;
	}
}
