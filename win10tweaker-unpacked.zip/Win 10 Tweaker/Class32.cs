﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Microsoft.Win32;

// Token: 0x02000071 RID: 113
internal class Class32
{
	// Token: 0x17000028 RID: 40
	// (get) Token: 0x0600056E RID: 1390 RVA: 0x0001B1FC File Offset: 0x000193FC
	public static Class32 Class32_0
	{
		get
		{
			if (Class32.class32_0 == null)
			{
				object obj = Class32.object_0;
				lock (obj)
				{
					if (Class32.class32_0 == null)
					{
						Class32.class32_0 = new Class32();
					}
				}
			}
			return Class32.class32_0;
		}
	}

	// Token: 0x0600056F RID: 1391 RVA: 0x0001B25C File Offset: 0x0001945C
	public void method_0(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\AdministrativeTools");
			registryKey.SetValue("", GClass2.GClass2_0.method_1("Check1"), RegistryValueKind.ExpandString);
			registryKey.SetValue("Icon", "Imageres.dll,109", RegistryValueKind.ExpandString);
			registryKey.CreateSubKey("command").SetValue("", "control.exe /name Microsoft.AdministrativeTools");
		}
	}

	// Token: 0x06000570 RID: 1392 RVA: 0x0001B2C0 File Offset: 0x000194C0
	public void method_1(bool bool_0)
	{
		if (bool_0)
		{
			this.method_10();
			File.WriteAllText(this.string_0, "if Wscript.Arguments.Count = 0 then\r\n\tWscript.Quit\r\nend if\r\n\r\nset arg = Wscript.Arguments\r\nset run = WScript.CreateObject(\"WScript.Shell\")\r\n\r\nif arg(0) = \"reboot\" then\r\n\trun.Run \"cmd /c bcdedit /deletevalue {current} safeboot & shutdown -r -f -t 0\", 0, true\r\nelseif arg(0) = \"safemode\" then\r\n\trun.Run \"cmd /c bcdedit /set {current} safeboot minimal & shutdown -r -f -t 0\", 0, true\r\nelseif arg(0) = \"cmd\" then\r\n\trun.Run \"cmd /c bcdedit /set {current} safeboot minimal & bcdedit /set {current} safebootalternateshell yes & shutdown -r -f -t 0\", 0, true\r\nelseif arg(0) = \"network\" then\r\n\trun.Run \"cmd /c bcdedit /set {current} safeboot network & shutdown -r -f -t 0\", 0, true\r\nend if");
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\SafeMode");
			registryKey.SetValue("Icon", "Imageres.dll,184");
			registryKey.SetValue("MUIVerb", GClass2.GClass2_0.method_1("Check2"));
			registryKey.SetValue("SubCommands", "NormalReboot;SafeMode;SafeModeCMD;SafeModeNetwork");
			RegistryKey registryKey2 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\CommandStore\\shell\\NormalReboot");
			registryKey2.SetValue("", GClass2.GClass2_0.method_1("NormalReboot"));
			registryKey2.SetValue("Icon", "Imageres.dll,184");
			registryKey2.CreateSubKey("command").SetValue("", "wscript C:\\Windows\\SafeMode.vbs reboot");
			RegistryKey registryKey3 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\CommandStore\\shell\\SafeMode");
			registryKey3.SetValue("", GClass2.GClass2_0.method_1("Check2"));
			registryKey3.SetValue("Icon", "Imageres.dll,184");
			registryKey3.CreateSubKey("command").SetValue("", "wscript C:\\Windows\\SafeMode.vbs safemode");
			RegistryKey registryKey4 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\CommandStore\\shell\\SafeModeCMD");
			registryKey4.SetValue("", GClass2.GClass2_0.method_1("SafeModeCMD"));
			registryKey4.SetValue("Icon", "Imageres.dll,184");
			registryKey4.CreateSubKey("command").SetValue("", "wscript C:\\Windows\\SafeMode.vbs cmd");
			RegistryKey registryKey5 = Registry.LocalMachine.CreateSubKey(GClass2.GClass2_0.String_0 + "\\Explorer\\CommandStore\\shell\\SafeModeNetwork");
			registryKey5.SetValue("", GClass2.GClass2_0.method_1("SafeModeNetwork"));
			registryKey5.SetValue("Icon", "Imageres.dll,184");
			registryKey5.CreateSubKey("command").SetValue("", "wscript C:\\Windows\\SafeMode.vbs network");
		}
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x0001B4B8 File Offset: 0x000196B8
	public void method_2(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\DeviceManager");
			registryKey.SetValue("", "@%SystemRoot%\\system32\\devmgr.dll,-4", RegistryValueKind.ExpandString);
			registryKey.SetValue("HasLUAShield", "");
			registryKey.SetValue("Icon", "devmgr.dll,5");
			registryKey.SetValue("SuppressionPolicy", 1073741884);
			registryKey.CreateSubKey("command").SetValue("", "%SystemRoot%\\system32\\mmc.exe /s %SystemRoot%\\system32\\devmgmt.msc", RegistryValueKind.ExpandString);
		}
	}

	// Token: 0x06000572 RID: 1394 RVA: 0x0001B538 File Offset: 0x00019738
	public void method_3(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\ControlPanel");
			registryKey.SetValue("", "@%SystemRoot%\\system32\\shell32.dll,-4161", RegistryValueKind.ExpandString);
			registryKey.SetValue("Icon", "control.exe", RegistryValueKind.ExpandString);
			registryKey.CreateSubKey("command").SetValue("", "rundll32.exe shell32.dll,Control_RunDLL");
		}
	}

	// Token: 0x06000573 RID: 1395 RVA: 0x0001B594 File Offset: 0x00019794
	public void method_4(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\ProgramsAndFeatures");
			registryKey.SetValue("", GClass2.GClass2_0.method_1("ProgramsAndFeatures"), RegistryValueKind.ExpandString);
			registryKey.SetValue("Icon", "appwiz.cpl,4", RegistryValueKind.ExpandString);
			registryKey.CreateSubKey("command").SetValue("", "rundll32.exe shell32.dll,Control_RunDLL appwiz.cpl");
		}
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x0001B5F8 File Offset: 0x000197F8
	public void method_5(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\LocalGroupPolicyEditor");
			registryKey.SetValue("", GClass2.GClass2_0.method_1("LocalGroupPolicyEditor"), RegistryValueKind.ExpandString);
			registryKey.SetValue("Icon", "gpedit.dll", RegistryValueKind.ExpandString);
			registryKey.CreateSubKey("command").SetValue("", "mmc.exe /s gpedit.msc");
		}
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x0001B65C File Offset: 0x0001985C
	public void method_6(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\RegRegistry");
			registryKey.SetValue("", GClass2.GClass2_0.method_1("RegRegistry"), RegistryValueKind.ExpandString);
			registryKey.SetValue("HasLUAShield", "");
			registryKey.SetValue("Icon", "regedit.exe", RegistryValueKind.ExpandString);
			registryKey.CreateSubKey("command").SetValue("", "%systemroot%\\regedit.exe", RegistryValueKind.ExpandString);
		}
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x0001B6D4 File Offset: 0x000198D4
	public void method_7(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\SerServices");
			registryKey.SetValue("", "@%SystemRoot%\\system32\\shell32.dll,-22059", RegistryValueKind.ExpandString);
			registryKey.SetValue("HasLUAShield", "");
			registryKey.SetValue("Icon", "filemgmt.dll", RegistryValueKind.ExpandString);
			registryKey.SetValue("SuppressionPolicy", 1073741884);
			registryKey.CreateSubKey("command").SetValue("", "%SystemRoot%\\system32\\mmc.exe /s %SystemRoot%\\system32\\services.msc", RegistryValueKind.ExpandString);
		}
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x0001B754 File Offset: 0x00019954
	public void method_8(bool bool_0)
	{
		if (bool_0)
		{
			RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\shell\\DiskManagement");
			registryKey.SetValue("", GClass2.GClass2_0.method_1("DiskManagement"));
			registryKey.SetValue("Icon", "dmdskres.dll");
			registryKey.CreateSubKey("command").SetValue("", "mmc.exe /s diskmgmt.msc");
		}
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x0001B7B8 File Offset: 0x000199B8
	public void method_9()
	{
		this.method_10();
		Registry.CurrentUser.DeleteSubKeyTree("Software\\Classes\\CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}", false);
		string str = GClass2.GClass2_0.String_0 + "\\Explorer\\CommandStore\\shell";
		List<string> list = new List<string>();
		list.Add(str + "\\NormalReboot");
		list.Add(str + "\\SafeMode");
		list.Add(str + "\\SafeModeCMD");
		list.Add(str + "\\SafeModeNetwork");
		list.ForEach(new Action<string>(Class32.<>c.<>9.method_0));
		if (File.Exists(this.string_0))
		{
			File.Delete(this.string_0);
		}
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x0001B878 File Offset: 0x00019A78
	private void method_10()
	{
		string path = GClass13.string_6 + "\\SafeMode";
		if (Directory.Exists(path))
		{
			Directory.Delete(path, true);
		}
	}

	// Token: 0x0600057C RID: 1404 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x0600057D RID: 1405 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x0600057E RID: 1406 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_2(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x00002EED File Offset: 0x000010ED
	static void smethod_3(RegistryKey registryKey_0, string string_1, object object_1, RegistryValueKind registryValueKind_0)
	{
		registryKey_0.SetValue(string_1, object_1, registryValueKind_0);
	}

	// Token: 0x06000580 RID: 1408 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_4(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x06000581 RID: 1409 RVA: 0x00003D00 File Offset: 0x00001F00
	static void smethod_5(string string_1, string string_2)
	{
		File.WriteAllText(string_1, string_2);
	}

	// Token: 0x06000582 RID: 1410 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_6(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x06000583 RID: 1411 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_7(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_1, bool_0);
	}

	// Token: 0x06000584 RID: 1412 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_8(string string_1)
	{
		return File.Exists(string_1);
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x00002F15 File Offset: 0x00001115
	static void smethod_9(string string_1)
	{
		File.Delete(string_1);
	}

	// Token: 0x06000586 RID: 1414 RVA: 0x00002EE5 File Offset: 0x000010E5
	static bool smethod_10(string string_1)
	{
		return Directory.Exists(string_1);
	}

	// Token: 0x06000587 RID: 1415 RVA: 0x000036B7 File Offset: 0x000018B7
	static void smethod_11(string string_1, bool bool_0)
	{
		Directory.Delete(string_1, bool_0);
	}

	// Token: 0x06000588 RID: 1416 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_12()
	{
		return new object();
	}

	// Token: 0x04000256 RID: 598
	private static volatile Class32 class32_0;

	// Token: 0x04000257 RID: 599
	private static readonly object object_0 = new object();

	// Token: 0x04000258 RID: 600
	private readonly string string_0 = GClass13.string_6 + "\\SafeMode.vbs";
}
