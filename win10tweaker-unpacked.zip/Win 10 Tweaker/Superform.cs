﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x020000C4 RID: 196
public partial class Superform : GForm0
{
	// Token: 0x060009DE RID: 2526 RVA: 0x0002B2A4 File Offset: 0x000294A4
	private void method_1()
	{
		Superform.Struct63 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.superform_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Superform.Struct63>(ref @struct);
	}

	// Token: 0x060009DF RID: 2527 RVA: 0x0002B2DC File Offset: 0x000294DC
	public Superform(Form1 form1_1)
	{
		this.form1_0 = form1_1;
		this.InitializeComponent();
		this.CloseIcon.Click += this.method_3;
		this.BackgroundImage = (Image)Class89.ResourceManager_0.GetObject(GClass2.GClass2_0.RegistryKey_0.GetValue("Skin").ToString() + "2");
		Rectangle bounds = Screen.PrimaryScreen.Bounds;
		base.Location = new Point((bounds.Width - base.Width) / 2, (bounds.Height - (this.MainPanel.Location.Y + this.MainPanel.Height + this.MainPanel.Location.X)) / 2);
		this.MainPanel.Controls.OfType<PictureBox>().ToList<PictureBox>().ForEach(new Action<PictureBox>(this.method_4));
		base.Size = new Size(base.Width, this.Description.Location.Y + this.MainPanel.Location.Y);
		this.CommandLine.TextChanged += this.CommandLine_TextChanged;
	}

	// Token: 0x060009E0 RID: 2528 RVA: 0x0002B434 File Offset: 0x00029634
	private void Superform_Load(object sender, EventArgs e)
	{
		Superform.Struct65 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.superform_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Superform.Struct65>(ref @struct);
	}

	// Token: 0x060009E1 RID: 2529 RVA: 0x0002B46C File Offset: 0x0002966C
	private void SuperButton1_Click(object sender, EventArgs e)
	{
		bool flag = false;
		if (this.CommandLine.Text.Length > 0)
		{
			foreach (string name in GClass2.GClass2_0.RegistryKey_0.GetValueNames())
			{
				if (GClass2.GClass2_0.RegistryKey_0.GetValue(name).ToString() == this.CommandLine.Text)
				{
					flag = true;
				}
			}
			if (!flag)
			{
				GClass2.GClass2_0.RegistryKey_0.SetValue(string.Format("Recent Command {0}", GClass2.GClass2_0.RegistryKey_0.GetValueNames().ToList<string>().Where(new Func<string, bool>(Superform.<>c.<>9.method_2)).Count<string>() + 1), this.CommandLine.Text);
				this.CommandLine.Items.Clear();
				GClass2.GClass2_0.RegistryKey_0.GetValueNames().ToList<string>().Where(new Func<string, bool>(Superform.<>c.<>9.method_3)).ToList<string>().ForEach(new Action<string>(this.method_6));
			}
		}
		object tag = base.Tag;
		if (((tag != null) ? tag.ToString() : null) == this.Freezeexe.Name && this.CommandLine.Text.Length > 0)
		{
			this.CommandLine.Text.Replace(".exe", "").smethod_0();
			this.SuperButton1.Enabled = false;
			this.SuperButton2.Enabled = true;
			return;
		}
		object tag2 = base.Tag;
		if (((tag2 != null) ? tag2.ToString() : null) == this.Blockexe.Name && this.CommandLine.Text.Length > 0)
		{
			string text = this.string_1 + "\\" + this.CommandLine.Text;
			string text2 = GClass13.string_7 + "\\systray.exe";
			if (this.CommandLine.Text.EndsWith(".exe") && !this.CommandLine.Text.Contains("\""))
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(text, true))
				{
					if (registryKey != null && registryKey.GetValue(Superform.string_0) != null)
					{
						if (registryKey != null)
						{
							string a;
							if (registryKey == null)
							{
								a = null;
							}
							else
							{
								object value = registryKey.GetValue(Superform.string_0);
								a = ((value != null) ? value.ToString() : null);
							}
							if (a == text2)
							{
								WMessageBox.smethod_3(this.method_2("BlockexeAlreadyExists"), this.Text, WMessageBox.GEnum2.OK, false, "", null);
							}
						}
					}
					else
					{
						try
						{
							Registry.LocalMachine.CreateSubKey(text).SetValue(Superform.string_0, text2);
							WMessageBox.smethod_3(this.method_2("BlockexeSuccessCreated"), this.Text, WMessageBox.GEnum2.OK, false, "", null);
						}
						catch
						{
							WMessageBox.smethod_3(this.method_2("BlockexeDenied"), this.Text, WMessageBox.GEnum2.OK, false, "", null);
						}
					}
					return;
				}
			}
			WMessageBox.smethod_3(this.method_2("BlockexeErrorSyntax"), this.Text, WMessageBox.GEnum2.OK, false, "", null);
			return;
		}
		object tag3 = base.Tag;
		if (((tag3 != null) ? tag3.ToString() : null) == this.Superexe.Name && this.CommandLine.Text.Length > 0)
		{
			GClass14.smethod_0(this.CommandLine.Text, true);
		}
	}

	// Token: 0x060009E2 RID: 2530 RVA: 0x0002B81C File Offset: 0x00029A1C
	private void SuperButton2_Click(object sender, EventArgs e)
	{
		object tag = base.Tag;
		if (((tag != null) ? tag.ToString() : null) == this.Freezeexe.Name && this.CommandLine.Text.Length > 0)
		{
			this.CommandLine.Text.Replace(".exe", "").smethod_1();
			this.SuperButton1.Enabled = true;
			return;
		}
		object tag2 = base.Tag;
		if (((tag2 == null) ? null : tag2.ToString()) == this.Blockexe.Name && this.CommandLine.Text.Length > 0)
		{
			string text = this.string_1 + "\\" + this.CommandLine.Text;
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(text, true))
			{
				if (registryKey != null && registryKey.GetValue(Superform.string_0) != null)
				{
					registryKey.DeleteValue(Superform.string_0);
					if (registryKey.GetValueNames().Length == 0)
					{
						Registry.LocalMachine.DeleteSubKeyTree(text);
					}
					WMessageBox.smethod_3(this.method_2("BlockexeSuccessDeleted"), this.Text, WMessageBox.GEnum2.OK, false, "", null);
					return;
				}
				WMessageBox.smethod_3(this.method_2("BlockexeDoesntExists"), this.Text, WMessageBox.GEnum2.OK, false, "", null);
				return;
			}
		}
		object tag3 = base.Tag;
		if (((tag3 != null) ? tag3.ToString() : null) == this.Superexe.Name && this.CommandLine.Text.Length > 0)
		{
			Process.GetProcessesByName(this.CommandLine.Text).ToList<Process>().ForEach(new Action<Process>(Superform.<>c.<>9.method_4));
		}
	}

	// Token: 0x060009E3 RID: 2531 RVA: 0x000056EA File Offset: 0x000038EA
	private void Freezeexe_Click(object sender, EventArgs e)
	{
		Superform.int_0 = 1;
	}

	// Token: 0x060009E4 RID: 2532 RVA: 0x000056F2 File Offset: 0x000038F2
	private void Blockexe_Click(object sender, EventArgs e)
	{
		Superform.int_0 = 2;
	}

	// Token: 0x060009E5 RID: 2533 RVA: 0x000056FA File Offset: 0x000038FA
	private void Superexe_Click(object sender, EventArgs e)
	{
		Superform.int_0 = 3;
	}

	// Token: 0x060009E6 RID: 2534 RVA: 0x00005702 File Offset: 0x00003902
	private void BlockerMenu_Click(object sender, EventArgs e)
	{
		if (Application.OpenForms["BlockerMenu"] == null)
		{
			new BlockerMenu(this).ShowDialog();
		}
	}

	// Token: 0x060009E7 RID: 2535 RVA: 0x000028C8 File Offset: 0x00000AC8
	private string method_2(string string_2)
	{
		return GClass2.GClass2_0.method_1(string_2);
	}

	// Token: 0x060009E8 RID: 2536 RVA: 0x0002B9F0 File Offset: 0x00029BF0
	private static Bitmap smethod_3(Bitmap bitmap_0, int int_1)
	{
		Bitmap bitmap = new Bitmap(bitmap_0.Width, bitmap_0.Height);
		float num = (float)int_1 / 255f;
		Rectangle destRect = new Rectangle(0, 0, bitmap_0.Width, bitmap_0.Height);
		float[][] array = new float[5][];
		int num2 = 0;
		float[] array2 = new float[5];
		array2[0] = 1f;
		array[num2] = array2;
		int num3 = 1;
		float[] array3 = new float[5];
		array3[1] = 1f;
		array[num3] = array3;
		int num4 = 2;
		float[] array4 = new float[5];
		array4[2] = 1f;
		array[num4] = array4;
		int num5 = 3;
		float[] array5 = new float[5];
		array5[3] = num;
		array[num5] = array5;
		array[4] = new float[]
		{
			0f,
			0f,
			0f,
			0f,
			1f
		};
		ColorMatrix newColorMatrix = new ColorMatrix(array);
		ImageAttributes imageAttributes = new ImageAttributes();
		imageAttributes.SetColorMatrix(newColorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
		using (Graphics graphics = Graphics.FromImage(bitmap))
		{
			graphics.DrawImage(bitmap_0, destRect, destRect.X, destRect.Y, destRect.Width, destRect.Height, GraphicsUnit.Pixel, imageAttributes);
		}
		return bitmap;
	}

	// Token: 0x060009E9 RID: 2537 RVA: 0x0002BAEC File Offset: 0x00029CEC
	private void CleanHistoryButton_Click(object sender, EventArgs e)
	{
		this.CommandLine.Text = "";
		this.CommandLine.Items.Clear();
		GClass2.GClass2_0.RegistryKey_0.GetValueNames().Where(new Func<string, bool>(Superform.<>c.<>9.method_5)).ToList<string>().ForEach(new Action<string>(Superform.<>c.<>9.method_6));
	}

	// Token: 0x060009EA RID: 2538 RVA: 0x00005721 File Offset: 0x00003921
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060009ED RID: 2541 RVA: 0x00005758 File Offset: 0x00003958
	[CompilerGenerated]
	private void method_3(object sender, EventArgs e)
	{
		this.method_1();
		this.form1_0.WindowState = FormWindowState.Normal;
	}

	// Token: 0x060009EE RID: 2542 RVA: 0x0002C634 File Offset: 0x0002A834
	[CompilerGenerated]
	private void method_4(PictureBox pictureBox_0)
	{
		Superform.Class71 @class = new Superform.Class71();
		@class.superform_0 = this;
		@class.pictureBox_0 = pictureBox_0;
		@class.pictureBox_0.MouseEnter += @class.method_0;
		@class.pictureBox_0.MouseLeave += @class.method_1;
		@class.pictureBox_0.Click += @class.method_2;
	}

	// Token: 0x060009EF RID: 2543 RVA: 0x0000576C File Offset: 0x0000396C
	[CompilerGenerated]
	private void CommandLine_TextChanged(object sender, EventArgs e)
	{
		if (!this.SuperButton1.Enabled)
		{
			this.SuperButton1.Enabled = true;
		}
	}

	// Token: 0x060009F0 RID: 2544 RVA: 0x00005787 File Offset: 0x00003987
	[CompilerGenerated]
	private void method_5(string string_2)
	{
		this.CommandLine.Items.Add(GClass2.GClass2_0.RegistryKey_0.GetValue(string_2));
	}

	// Token: 0x060009F1 RID: 2545 RVA: 0x00005787 File Offset: 0x00003987
	[CompilerGenerated]
	private void method_6(string string_2)
	{
		this.CommandLine.Items.Add(GClass2.GClass2_0.RegistryKey_0.GetValue(string_2));
	}

	// Token: 0x060009F2 RID: 2546 RVA: 0x00002951 File Offset: 0x00000B51
	static void smethod_4(Control control_0, EventHandler eventHandler_0)
	{
		control_0.Click += eventHandler_0;
	}

	// Token: 0x060009F3 RID: 2547 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_5(RegistryKey registryKey_0, string string_2)
	{
		return registryKey_0.GetValue(string_2);
	}

	// Token: 0x060009F4 RID: 2548 RVA: 0x000029E6 File Offset: 0x00000BE6
	static string smethod_6(object object_0)
	{
		return object_0.ToString();
	}

	// Token: 0x060009F5 RID: 2549 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_7(string string_2, string string_3)
	{
		return string_2 + string_3;
	}

	// Token: 0x060009F6 RID: 2550 RVA: 0x00005314 File Offset: 0x00003514
	static object smethod_8(ResourceManager resourceManager_0, string string_2)
	{
		return resourceManager_0.GetObject(string_2);
	}

	// Token: 0x060009F7 RID: 2551 RVA: 0x00002B2F File Offset: 0x00000D2F
	static void smethod_9(Control control_0, Image image_0)
	{
		control_0.BackgroundImage = image_0;
	}

	// Token: 0x060009F8 RID: 2552 RVA: 0x000040DF File Offset: 0x000022DF
	static Screen smethod_10()
	{
		return Screen.PrimaryScreen;
	}

	// Token: 0x060009F9 RID: 2553 RVA: 0x000040E6 File Offset: 0x000022E6
	static Rectangle smethod_11(Screen screen_0)
	{
		return screen_0.Bounds;
	}

	// Token: 0x060009FA RID: 2554 RVA: 0x00002A18 File Offset: 0x00000C18
	static string smethod_12(Control control_0)
	{
		return control_0.Text;
	}

	// Token: 0x060009FB RID: 2555 RVA: 0x00002A44 File Offset: 0x00000C44
	static int smethod_13(string string_2)
	{
		return string_2.Length;
	}

	// Token: 0x060009FC RID: 2556 RVA: 0x00003019 File Offset: 0x00001219
	static string[] smethod_14(RegistryKey registryKey_0)
	{
		return registryKey_0.GetValueNames();
	}

	// Token: 0x060009FD RID: 2557 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_15(string string_2, string string_3)
	{
		return string_2 == string_3;
	}

	// Token: 0x060009FE RID: 2558 RVA: 0x000033C8 File Offset: 0x000015C8
	static string smethod_16(string string_2, object object_0)
	{
		return string.Format(string_2, object_0);
	}

	// Token: 0x060009FF RID: 2559 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_17(RegistryKey registryKey_0, string string_2, object object_0)
	{
		registryKey_0.SetValue(string_2, object_0);
	}

	// Token: 0x06000A00 RID: 2560 RVA: 0x000057AA File Offset: 0x000039AA
	static ComboBox.ObjectCollection smethod_18(ComboBox comboBox_0)
	{
		return comboBox_0.Items;
	}

	// Token: 0x06000A01 RID: 2561 RVA: 0x000057B2 File Offset: 0x000039B2
	static void smethod_19(ComboBox.ObjectCollection objectCollection_0)
	{
		objectCollection_0.Clear();
	}

	// Token: 0x06000A02 RID: 2562 RVA: 0x000057BA File Offset: 0x000039BA
	static object smethod_20(Control control_0)
	{
		return control_0.Tag;
	}

	// Token: 0x06000A03 RID: 2563 RVA: 0x00002C23 File Offset: 0x00000E23
	static string smethod_21(Control control_0)
	{
		return control_0.Name;
	}

	// Token: 0x06000A04 RID: 2564 RVA: 0x000033D1 File Offset: 0x000015D1
	static string smethod_22(string string_2, string string_3, string string_4)
	{
		return string_2.Replace(string_3, string_4);
	}

	// Token: 0x06000A05 RID: 2565 RVA: 0x00002C67 File Offset: 0x00000E67
	static void smethod_23(Control control_0, bool bool_2)
	{
		control_0.Enabled = bool_2;
	}

	// Token: 0x06000A06 RID: 2566 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_24(string string_2, string string_3, string string_4)
	{
		return string_2 + string_3 + string_4;
	}

	// Token: 0x06000A07 RID: 2567 RVA: 0x00002A29 File Offset: 0x00000C29
	static bool smethod_25(string string_2, string string_3)
	{
		return string_2.EndsWith(string_3);
	}

	// Token: 0x06000A08 RID: 2568 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_26(string string_2, string string_3)
	{
		return string_2.Contains(string_3);
	}

	// Token: 0x06000A09 RID: 2569 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_27(RegistryKey registryKey_0, string string_2, bool bool_2)
	{
		return registryKey_0.OpenSubKey(string_2, bool_2);
	}

	// Token: 0x06000A0A RID: 2570 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_28(RegistryKey registryKey_0, string string_2)
	{
		return registryKey_0.CreateSubKey(string_2);
	}

	// Token: 0x06000A0B RID: 2571 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_29(RegistryKey registryKey_0, string string_2)
	{
		return registryKey_0.GetValue(string_2);
	}

	// Token: 0x06000A0C RID: 2572 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_30(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000A0D RID: 2573 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_31(RegistryKey registryKey_0, string string_2)
	{
		registryKey_0.DeleteValue(string_2);
	}

	// Token: 0x06000A0E RID: 2574 RVA: 0x00003021 File Offset: 0x00001221
	static void smethod_32(RegistryKey registryKey_0, string string_2)
	{
		registryKey_0.DeleteSubKeyTree(string_2);
	}

	// Token: 0x06000A0F RID: 2575 RVA: 0x000033EC File Offset: 0x000015EC
	static Process[] smethod_33(string string_2)
	{
		return Process.GetProcessesByName(string_2);
	}

	// Token: 0x06000A10 RID: 2576 RVA: 0x000029CD File Offset: 0x00000BCD
	static FormCollection smethod_34()
	{
		return Application.OpenForms;
	}

	// Token: 0x06000A11 RID: 2577 RVA: 0x000057C2 File Offset: 0x000039C2
	static Form smethod_35(FormCollection formCollection_0, string string_2)
	{
		return formCollection_0[string_2];
	}

	// Token: 0x06000A12 RID: 2578 RVA: 0x000057CB File Offset: 0x000039CB
	static DialogResult smethod_36(Form form_0)
	{
		return form_0.ShowDialog();
	}

	// Token: 0x06000A13 RID: 2579 RVA: 0x000057D3 File Offset: 0x000039D3
	static int smethod_37(Image image_0)
	{
		return image_0.Width;
	}

	// Token: 0x06000A14 RID: 2580 RVA: 0x000057DB File Offset: 0x000039DB
	static int smethod_38(Image image_0)
	{
		return image_0.Height;
	}

	// Token: 0x06000A15 RID: 2581 RVA: 0x000057E3 File Offset: 0x000039E3
	static Bitmap smethod_39(int int_1, int int_2)
	{
		return new Bitmap(int_1, int_2);
	}

	// Token: 0x06000A16 RID: 2582 RVA: 0x000057EC File Offset: 0x000039EC
	static ColorMatrix smethod_40(float[][] float_0)
	{
		return new ColorMatrix(float_0);
	}

	// Token: 0x06000A17 RID: 2583 RVA: 0x000057F4 File Offset: 0x000039F4
	static ImageAttributes smethod_41()
	{
		return new ImageAttributes();
	}

	// Token: 0x06000A18 RID: 2584 RVA: 0x000057FB File Offset: 0x000039FB
	static void smethod_42(ImageAttributes imageAttributes_0, ColorMatrix colorMatrix_0, ColorMatrixFlag colorMatrixFlag_0, ColorAdjustType colorAdjustType_0)
	{
		imageAttributes_0.SetColorMatrix(colorMatrix_0, colorMatrixFlag_0, colorAdjustType_0);
	}

	// Token: 0x06000A19 RID: 2585 RVA: 0x00005806 File Offset: 0x00003A06
	static Graphics smethod_43(Image image_0)
	{
		return Graphics.FromImage(image_0);
	}

	// Token: 0x06000A1A RID: 2586 RVA: 0x00002920 File Offset: 0x00000B20
	static void smethod_44(Control control_0, string string_2)
	{
		control_0.Text = string_2;
	}

	// Token: 0x06000A1B RID: 2587 RVA: 0x00002A69 File Offset: 0x00000C69
	static Button smethod_45()
	{
		return new Button();
	}

	// Token: 0x06000A1C RID: 2588 RVA: 0x00002A77 File Offset: 0x00000C77
	static Panel smethod_46()
	{
		return new Panel();
	}

	// Token: 0x06000A1D RID: 2589 RVA: 0x0000580E File Offset: 0x00003A0E
	static ComboBox smethod_47()
	{
		return new ComboBox();
	}

	// Token: 0x06000A1E RID: 2590 RVA: 0x00002A5A File Offset: 0x00000C5A
	static PictureBox smethod_48()
	{
		return new PictureBox();
	}

	// Token: 0x06000A1F RID: 2591 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_49()
	{
		return new Label();
	}

	// Token: 0x06000A20 RID: 2592 RVA: 0x00002A8D File Offset: 0x00000C8D
	static void smethod_50(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x06000A21 RID: 2593 RVA: 0x00002A85 File Offset: 0x00000C85
	static void smethod_51(ISupportInitialize isupportInitialize_0)
	{
		isupportInitialize_0.BeginInit();
	}

	// Token: 0x06000A22 RID: 2594 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_52(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x06000A23 RID: 2595 RVA: 0x00002BA7 File Offset: 0x00000DA7
	static void smethod_53(Control control_0, Color color_0)
	{
		control_0.BackColor = color_0;
	}

	// Token: 0x06000A24 RID: 2596 RVA: 0x00002E61 File Offset: 0x00001061
	static void smethod_54(Control control_0, ImageLayout imageLayout_0)
	{
		control_0.BackgroundImageLayout = imageLayout_0;
	}

	// Token: 0x06000A25 RID: 2597 RVA: 0x00005815 File Offset: 0x00003A15
	static FlatButtonAppearance smethod_55(ButtonBase buttonBase_0)
	{
		return buttonBase_0.FlatAppearance;
	}

	// Token: 0x06000A26 RID: 2598 RVA: 0x0000581D File Offset: 0x00003A1D
	static void smethod_56(FlatButtonAppearance flatButtonAppearance_0, Color color_0)
	{
		flatButtonAppearance_0.BorderColor = color_0;
	}

	// Token: 0x06000A27 RID: 2599 RVA: 0x00005826 File Offset: 0x00003A26
	static void smethod_57(FlatButtonAppearance flatButtonAppearance_0, int int_1)
	{
		flatButtonAppearance_0.BorderSize = int_1;
	}

	// Token: 0x06000A28 RID: 2600 RVA: 0x0000582F File Offset: 0x00003A2F
	static void smethod_58(FlatButtonAppearance flatButtonAppearance_0, Color color_0)
	{
		flatButtonAppearance_0.MouseDownBackColor = color_0;
	}

	// Token: 0x06000A29 RID: 2601 RVA: 0x00005838 File Offset: 0x00003A38
	static void smethod_59(FlatButtonAppearance flatButtonAppearance_0, Color color_0)
	{
		flatButtonAppearance_0.MouseOverBackColor = color_0;
	}

	// Token: 0x06000A2A RID: 2602 RVA: 0x00005841 File Offset: 0x00003A41
	static void smethod_60(ButtonBase buttonBase_0, FlatStyle flatStyle_0)
	{
		buttonBase_0.FlatStyle = flatStyle_0;
	}

	// Token: 0x06000A2B RID: 2603 RVA: 0x00003064 File Offset: 0x00001264
	static void smethod_61(Form form_0, FormWindowState formWindowState_0)
	{
		form_0.WindowState = formWindowState_0;
	}

	// Token: 0x06000A2C RID: 2604 RVA: 0x00002962 File Offset: 0x00000B62
	static void smethod_62(Control control_0, EventHandler eventHandler_0)
	{
		control_0.MouseEnter += eventHandler_0;
	}

	// Token: 0x06000A2D RID: 2605 RVA: 0x0000296B File Offset: 0x00000B6B
	static void smethod_63(Control control_0, EventHandler eventHandler_0)
	{
		control_0.MouseLeave += eventHandler_0;
	}

	// Token: 0x06000A2E RID: 2606 RVA: 0x0000584A File Offset: 0x00003A4A
	static bool smethod_64(Control control_0)
	{
		return control_0.Enabled;
	}

	// Token: 0x06000A2F RID: 2607 RVA: 0x00005852 File Offset: 0x00003A52
	static int smethod_65(ComboBox.ObjectCollection objectCollection_0, object object_0)
	{
		return objectCollection_0.Add(object_0);
	}

	// Token: 0x040003E7 RID: 999
	private readonly Form1 form1_0;

	// Token: 0x040003E8 RID: 1000
	private static int int_0 = 0;

	// Token: 0x040003E9 RID: 1001
	private static readonly string string_0 = "Debugger";

	// Token: 0x040003EA RID: 1002
	private readonly string string_1 = GClass2.GClass2_0.string_12;

	// Token: 0x040003EB RID: 1003
	private static readonly bool bool_1 = false;

	// Token: 0x040003EC RID: 1004
	private IContainer icontainer_0;

	// Token: 0x020000C6 RID: 198
	[CompilerGenerated]
	private sealed class Class71
	{
		// Token: 0x06000A36 RID: 2614 RVA: 0x00005869 File Offset: 0x00003A69
		internal void method_0(object sender, EventArgs e)
		{
			this.pictureBox_0.BackgroundImage = Class89.Bitmap_14;
		}

		// Token: 0x06000A37 RID: 2615 RVA: 0x0000587B File Offset: 0x00003A7B
		internal void method_1(object sender, EventArgs e)
		{
			this.pictureBox_0.BackgroundImage = null;
		}

		// Token: 0x06000A38 RID: 2616 RVA: 0x0002C790 File Offset: 0x0002A990
		internal void method_2(object sender, EventArgs e)
		{
			Superform.Class71.Struct64 @struct;
			@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
			@struct.class71_0 = this;
			@struct.int_0 = -1;
			@struct.asyncVoidMethodBuilder_0.Start<Superform.Class71.Struct64>(ref @struct);
		}

		// Token: 0x06000A39 RID: 2617 RVA: 0x00002B2F File Offset: 0x00000D2F
		static void smethod_0(Control control_0, Image image_0)
		{
			control_0.BackgroundImage = image_0;
		}

		// Token: 0x040003FD RID: 1021
		public PictureBox pictureBox_0;

		// Token: 0x040003FE RID: 1022
		public Superform superform_0;

		// Token: 0x020000C7 RID: 199
		[StructLayout(LayoutKind.Auto)]
		private struct Struct64 : IAsyncStateMachine
		{
			// Token: 0x06000A3A RID: 2618 RVA: 0x0002C7C8 File Offset: 0x0002A9C8
			void IAsyncStateMachine.MoveNext()
			{
				int num = this.int_0;
				Superform.Class71 @class = this.class71_0;
				try
				{
					TaskAwaiter awaiter;
					if (num == 0)
					{
						awaiter = this.taskAwaiter_0;
						this.taskAwaiter_0 = default(TaskAwaiter);
						this.int_0 = -1;
						goto IL_108;
					}
					if (Superform.bool_1)
					{
						goto IL_137;
					}
					IL_3E:
					if (@class.superform_0.Height >= @class.superform_0.MainPanel.Location.Y + @class.superform_0.MainPanel.Height + @class.superform_0.MainPanel.Location.X)
					{
						goto IL_137;
					}
					@class.superform_0.Size = new Size(@class.superform_0.Width, @class.superform_0.Height + (@class.superform_0.Freezeexe.Location.X + @class.superform_0.Freezeexe.Height / 2) * 100 / @class.superform_0.Height / 3);
					awaiter = Task.Delay(3).GetAwaiter();
					if (!awaiter.IsCompleted)
					{
						this.int_0 = 0;
						this.taskAwaiter_0 = awaiter;
						this.asyncVoidMethodBuilder_0.AwaitUnsafeOnCompleted<TaskAwaiter, Superform.Class71.Struct64>(ref awaiter, ref this);
						return;
					}
					IL_108:
					awaiter.GetResult();
					goto IL_3E;
					IL_137:
					@class.superform_0.Height = @class.superform_0.MainPanel.Location.Y + @class.superform_0.MainPanel.Height + @class.superform_0.MainPanel.Location.X;
					@class.superform_0.MainPanel.Controls.OfType<PictureBox>().ToList<PictureBox>().ForEach(new Action<PictureBox>(Superform.<>c.<>9.method_0));
					@class.superform_0.Tag = @class.pictureBox_0.Name;
					@class.pictureBox_0.Image = Superform.smethod_3((Bitmap)Class89.ResourceManager_0.GetObject(@class.pictureBox_0.Name), 500);
					@class.superform_0.Description.Text = @class.superform_0.method_2(@class.superform_0.Description.Name + @class.pictureBox_0.Name);
					if (Superform.int_0 != 1)
					{
						if (Superform.int_0 == 2)
						{
							@class.superform_0.SuperButton1.Text = @class.superform_0.method_2("SuperButtonBlock");
							@class.superform_0.SuperButton2.Text = @class.superform_0.method_2("SuperButtonUnblock");
							@class.superform_0.BlockerMenu.Visible = true;
						}
						else if (Superform.int_0 == 3)
						{
							@class.superform_0.SuperButton1.Text = @class.superform_0.method_2("SuperButtonRun");
							@class.superform_0.SuperButton2.Text = @class.superform_0.method_2("SuperButtonClose");
							@class.superform_0.BlockerMenu.Visible = false;
						}
					}
					else
					{
						@class.superform_0.SuperButton1.Text = @class.superform_0.method_2("SuperButtonFreeze");
						@class.superform_0.SuperButton2.Text = @class.superform_0.method_2("SuperButtonUnfreeze");
						@class.superform_0.BlockerMenu.Visible = false;
					}
				}
				catch (Exception exception)
				{
					this.int_0 = -2;
					this.asyncVoidMethodBuilder_0.SetException(exception);
					return;
				}
				this.int_0 = -2;
				this.asyncVoidMethodBuilder_0.SetResult();
			}

			// Token: 0x06000A3B RID: 2619 RVA: 0x00005889 File Offset: 0x00003A89
			[DebuggerHidden]
			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
			{
				this.asyncVoidMethodBuilder_0.SetStateMachine(stateMachine);
			}

			// Token: 0x06000A3C RID: 2620 RVA: 0x0000328B File Offset: 0x0000148B
			static int smethod_0(Control control_0)
			{
				return control_0.Width;
			}

			// Token: 0x06000A3D RID: 2621 RVA: 0x00003293 File Offset: 0x00001493
			static int smethod_1(Control control_0)
			{
				return control_0.Height;
			}

			// Token: 0x06000A3E RID: 2622 RVA: 0x00002A07 File Offset: 0x00000C07
			static Point smethod_2(Control control_0)
			{
				return control_0.Location;
			}

			// Token: 0x040003FF RID: 1023
			public int int_0;

			// Token: 0x04000400 RID: 1024
			public AsyncVoidMethodBuilder asyncVoidMethodBuilder_0;

			// Token: 0x04000401 RID: 1025
			public Superform.Class71 class71_0;

			// Token: 0x04000402 RID: 1026
			private TaskAwaiter taskAwaiter_0;
		}
	}
}
