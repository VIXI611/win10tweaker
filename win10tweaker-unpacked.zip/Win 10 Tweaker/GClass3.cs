﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

// Token: 0x02000054 RID: 84
public abstract class GClass3
{
	// Token: 0x06000401 RID: 1025 RVA: 0x00018554 File Offset: 0x00016754
	private static T smethod_0<T>(ICustomAttributeProvider icustomAttributeProvider_0) where T : Attribute
	{
		object[] customAttributes = icustomAttributeProvider_0.GetCustomAttributes(typeof(T), true);
		if (customAttributes.Length == 0)
		{
			return default(T);
		}
		return (T)((object)customAttributes[0]);
	}

	// Token: 0x06000402 RID: 1026 RVA: 0x00003A38 File Offset: 0x00001C38
	internal GClass3()
	{
		this.ginterface0_0 = GClass3.smethod_1();
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x00003A4B File Offset: 0x00001C4B
	public void method_0()
	{
		this.ginterface0_0.Save(true, true, GClass3.guid_0, GClass3.guid_1);
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x0001858C File Offset: 0x0001678C
	public RegistryKey method_1(GEnum0 genum0_0)
	{
		IntPtr preexistingHandle;
		if (this.ginterface0_0.GetRegistryKey((uint)genum0_0, out preexistingHandle) != 0U)
		{
			throw new Exception(string.Format("Unable to get section '{0}'", Enum.GetName(typeof(GEnum0), genum0_0)));
		}
		return RegistryKey.FromHandle(new SafeRegistryHandle(preexistingHandle, true), RegistryView.Default);
	}

	// Token: 0x06000405 RID: 1029
	public abstract string \u206F\u206B\u206B\u202B\u202E\u206B\u200C\u200B\u202B\u206C\u202D\u202C\u206A\u200F\u202A\u200C\u200C\u206E\u200C\u206C\u200D\u202E\u202B\u200C\u200E\u206C\u206D\u200D\u200C\u200D\u200F\u200D\u200D\u200C\u202B\u206A\u200F\u200E\u206E\u206E\u202E(GEnum0 genum0_0);

	// Token: 0x06000406 RID: 1030 RVA: 0x00003A65 File Offset: 0x00001C65
	protected static GInterface0 smethod_1()
	{
		return (GInterface0)new Class25();
	}

	// Token: 0x06000408 RID: 1032 RVA: 0x000025CE File Offset: 0x000007CE
	static Type smethod_2(RuntimeTypeHandle runtimeTypeHandle_0)
	{
		return Type.GetTypeFromHandle(runtimeTypeHandle_0);
	}

	// Token: 0x06000409 RID: 1033 RVA: 0x00003A71 File Offset: 0x00001C71
	static object[] smethod_3(ICustomAttributeProvider icustomAttributeProvider_0, Type type_0, bool bool_0)
	{
		return icustomAttributeProvider_0.GetCustomAttributes(type_0, bool_0);
	}

	// Token: 0x0600040A RID: 1034 RVA: 0x00003A7B File Offset: 0x00001C7B
	static string smethod_4(Type type_0, object object_0)
	{
		return Enum.GetName(type_0, object_0);
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x000033C8 File Offset: 0x000015C8
	static string smethod_5(string string_0, object object_0)
	{
		return string.Format(string_0, object_0);
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x00003A84 File Offset: 0x00001C84
	static Exception smethod_6(string string_0)
	{
		return new Exception(string_0);
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x00003A8C File Offset: 0x00001C8C
	static SafeRegistryHandle smethod_7(IntPtr intptr_0, bool bool_0)
	{
		return new SafeRegistryHandle(intptr_0, bool_0);
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x00003A95 File Offset: 0x00001C95
	static RegistryKey smethod_8(SafeRegistryHandle safeRegistryHandle_0, RegistryView registryView_0)
	{
		return RegistryKey.FromHandle(safeRegistryHandle_0, registryView_0);
	}

	// Token: 0x040001FA RID: 506
	private static readonly Guid guid_0 = new Guid(892833452, 26687, 4562, 168, 154, 0, 192, 79, 187, 207, 162);

	// Token: 0x040001FB RID: 507
	private static readonly Guid guid_1 = new Guid(GClass3.smethod_0<GuidAttribute>(Assembly.GetExecutingAssembly()).Value);

	// Token: 0x040001FC RID: 508
	protected GInterface0 ginterface0_0;
}
