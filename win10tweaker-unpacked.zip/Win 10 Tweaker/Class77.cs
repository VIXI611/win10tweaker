﻿using System;
using System.Deps;
using System.IO;
using System.Net;
using System.Threading;
using Microsoft.Win32;

// Token: 0x020000E7 RID: 231
internal class Class77
{
	// Token: 0x17000098 RID: 152
	// (get) Token: 0x06000B7F RID: 2943 RVA: 0x0003926C File Offset: 0x0003746C
	public static Class77 Class77_0
	{
		get
		{
			if (Class77.class77_0 == null)
			{
				object obj = Class77.object_0;
				lock (obj)
				{
					if (Class77.class77_0 == null)
					{
						Class77.class77_0 = new Class77();
					}
				}
			}
			return Class77.class77_0;
		}
	}

	// Token: 0x06000B80 RID: 2944 RVA: 0x000392CC File Offset: 0x000374CC
	public void method_0()
	{
		if (Class26.smethod_0())
		{
			if (!File.Exists(GClass13.string_6 + "\\Uploadee.exe"))
			{
				using (WebClient webClient = new WebClient())
				{
					webClient.DownloadFile("https://win10tweaker.pro/files/Uploadee.jpg", GClass13.string_6 + "\\Uploadee.exe");
				}
				Uploadeee.Set();
				RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey("*\\Shell\\" + Class77.string_0);
				registryKey.SetValue("", GClass2.GClass2_0.method_1("Upload.ee"));
				registryKey.SetValue("Icon", GClass13.string_6 + "\\Uploadee.exe");
				Registry.ClassesRoot.CreateSubKey("*\\Shell\\" + Class77.string_0 + "\\command").SetValue("", "\"" + GClass13.string_6 + "\\Uploadee.exe\" \"%1\"");
				using (RegistryKey registryKey2 = Registry.ClassesRoot.OpenSubKey("*\\Shell\\" + Class77.string_0, true))
				{
					if (registryKey2 != null && registryKey2.GetValue("Extended") != null)
					{
						registryKey2.DeleteValue("Extended");
					}
					return;
				}
			}
			return;
		}
		GClass6.GClass6_0.method_9();
	}

	// Token: 0x06000B81 RID: 2945 RVA: 0x000068C0 File Offset: 0x00004AC0
	public void method_1()
	{
		Registry.ClassesRoot.CreateSubKey("*\\Shell\\" + Class77.string_0).SetValue("Extended", "");
	}

	// Token: 0x06000B82 RID: 2946 RVA: 0x000068EA File Offset: 0x00004AEA
	public void method_2()
	{
		File.Delete(GClass13.string_6 + "\\Uploadee.exe");
		Registry.ClassesRoot.DeleteSubKeyTree("*\\Shell\\" + Class77.string_0, false);
	}

	// Token: 0x06000B85 RID: 2949 RVA: 0x00002EAD File Offset: 0x000010AD
	static void smethod_0(object object_1, ref bool bool_0)
	{
		Monitor.Enter(object_1, ref bool_0);
	}

	// Token: 0x06000B86 RID: 2950 RVA: 0x00002EB6 File Offset: 0x000010B6
	static void smethod_1(object object_1)
	{
		Monitor.Exit(object_1);
	}

	// Token: 0x06000B87 RID: 2951 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_2(string string_1, string string_2)
	{
		return string_1 + string_2;
	}

	// Token: 0x06000B88 RID: 2952 RVA: 0x00002F0D File Offset: 0x0000110D
	static bool smethod_3(string string_1)
	{
		return File.Exists(string_1);
	}

	// Token: 0x06000B89 RID: 2953 RVA: 0x00002994 File Offset: 0x00000B94
	static WebClient smethod_4()
	{
		return new WebClient();
	}

	// Token: 0x06000B8A RID: 2954 RVA: 0x000029C3 File Offset: 0x00000BC3
	static void smethod_5(WebClient webClient_0, string string_1, string string_2)
	{
		webClient_0.DownloadFile(string_1, string_2);
	}

	// Token: 0x06000B8B RID: 2955 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_6(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000B8C RID: 2956 RVA: 0x00006930 File Offset: 0x00004B30
	static void smethod_7()
	{
		Uploadeee.Set();
	}

	// Token: 0x06000B8D RID: 2957 RVA: 0x00002EBE File Offset: 0x000010BE
	static RegistryKey smethod_8(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.CreateSubKey(string_1);
	}

	// Token: 0x06000B8E RID: 2958 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_9(RegistryKey registryKey_0, string string_1, object object_1)
	{
		registryKey_0.SetValue(string_1, object_1);
	}

	// Token: 0x06000B8F RID: 2959 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_10(string string_1, string string_2, string string_3)
	{
		return string_1 + string_2 + string_3;
	}

	// Token: 0x06000B90 RID: 2960 RVA: 0x00003006 File Offset: 0x00001206
	static RegistryKey smethod_11(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		return registryKey_0.OpenSubKey(string_1, bool_0);
	}

	// Token: 0x06000B91 RID: 2961 RVA: 0x00002EDC File Offset: 0x000010DC
	static object smethod_12(RegistryKey registryKey_0, string string_1)
	{
		return registryKey_0.GetValue(string_1);
	}

	// Token: 0x06000B92 RID: 2962 RVA: 0x00003010 File Offset: 0x00001210
	static void smethod_13(RegistryKey registryKey_0, string string_1)
	{
		registryKey_0.DeleteValue(string_1);
	}

	// Token: 0x06000B93 RID: 2963 RVA: 0x00002F15 File Offset: 0x00001115
	static void smethod_14(string string_1)
	{
		File.Delete(string_1);
	}

	// Token: 0x06000B94 RID: 2964 RVA: 0x00003A2E File Offset: 0x00001C2E
	static void smethod_15(RegistryKey registryKey_0, string string_1, bool bool_0)
	{
		registryKey_0.DeleteSubKeyTree(string_1, bool_0);
	}

	// Token: 0x06000B95 RID: 2965 RVA: 0x00002EC7 File Offset: 0x000010C7
	static object smethod_16()
	{
		return new object();
	}

	// Token: 0x0400049C RID: 1180
	private static volatile Class77 class77_0;

	// Token: 0x0400049D RID: 1181
	private static readonly object object_0 = new object();

	// Token: 0x0400049E RID: 1182
	private static readonly string string_0 = "Upload.ee";
}
