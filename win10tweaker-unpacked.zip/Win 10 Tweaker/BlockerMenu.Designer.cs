﻿// Token: 0x0200002B RID: 43
public partial class BlockerMenu : global::System.Windows.Forms.Form
{
	// Token: 0x06000189 RID: 393 RVA: 0x00010E44 File Offset: 0x0000F044
	private void InitializeComponent()
	{
		global::System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new global::System.Windows.Forms.DataGridViewCellStyle();
		this.BlockerPanel = new global::System.Windows.Forms.Panel();
		this.Table = new global::System.Windows.Forms.DataGridView();
		this.Column1 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column2 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
		this.CloseIcon = new global::System.Windows.Forms.Button();
		this.BlockerPanel.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.Table).BeginInit();
		base.SuspendLayout();
		this.BlockerPanel.AutoScroll = true;
		this.BlockerPanel.Controls.Add(this.Table);
		this.BlockerPanel.Location = new global::System.Drawing.Point(12, 32);
		this.BlockerPanel.Name = "BlockerPanel";
		this.BlockerPanel.Size = new global::System.Drawing.Size(386, 182);
		this.BlockerPanel.TabIndex = 0;
		this.Table.AllowUserToAddRows = false;
		this.Table.AllowUserToDeleteRows = false;
		this.Table.AllowUserToOrderColumns = true;
		this.Table.AllowUserToResizeColumns = false;
		this.Table.AllowUserToResizeRows = false;
		this.Table.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.Table.ColumnHeadersBorderStyle = global::System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
		this.Table.ColumnHeadersVisible = false;
		this.Table.Columns.AddRange(new global::System.Windows.Forms.DataGridViewColumn[]
		{
			this.Column1,
			this.Column2
		});
		dataGridViewCellStyle.Alignment = global::System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
		dataGridViewCellStyle.BackColor = global::System.Drawing.SystemColors.Window;
		dataGridViewCellStyle.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		dataGridViewCellStyle.ForeColor = global::System.Drawing.SystemColors.ControlText;
		dataGridViewCellStyle.SelectionBackColor = global::System.Drawing.Color.FromArgb(52, 98, 137);
		dataGridViewCellStyle.SelectionForeColor = global::System.Drawing.SystemColors.HighlightText;
		dataGridViewCellStyle.WrapMode = global::System.Windows.Forms.DataGridViewTriState.False;
		this.Table.DefaultCellStyle = dataGridViewCellStyle;
		this.Table.EnableHeadersVisualStyles = false;
		this.Table.GridColor = global::System.Drawing.Color.FromArgb(41, 67, 85);
		this.Table.Location = new global::System.Drawing.Point(0, 0);
		this.Table.Name = "Table";
		this.Table.ReadOnly = true;
		this.Table.RowHeadersVisible = false;
		this.Table.RowTemplate.DefaultCellStyle.Alignment = global::System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
		this.Table.RowTemplate.DefaultCellStyle.BackColor = global::System.Drawing.Color.Red;
		this.Table.RowTemplate.DefaultCellStyle.ForeColor = global::System.Drawing.Color.FromArgb(178, 198, 211);
		this.Table.ScrollBars = global::System.Windows.Forms.ScrollBars.Vertical;
		this.Table.Size = new global::System.Drawing.Size(386, 182);
		this.Table.TabIndex = 0;
		this.Table.CellClick += new global::System.Windows.Forms.DataGridViewCellEventHandler(this.Table_CellClick);
		this.Column1.HeaderText = "";
		this.Column1.Name = "Column1";
		this.Column1.ReadOnly = true;
		this.Column1.Width = 191;
		this.Column2.HeaderText = "";
		this.Column2.Name = "Column2";
		this.Column2.ReadOnly = true;
		this.Column2.Width = 191;
		this.CloseIcon.BackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.BackgroundImage = global::Class89.Bitmap_17;
		this.CloseIcon.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
		this.CloseIcon.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(23, 28, 42);
		this.CloseIcon.FlatAppearance.BorderSize = 0;
		this.CloseIcon.FlatAppearance.MouseDownBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatAppearance.MouseOverBackColor = global::System.Drawing.Color.Transparent;
		this.CloseIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.CloseIcon.Location = new global::System.Drawing.Point(377, 4);
		this.CloseIcon.Name = "CloseIcon";
		this.CloseIcon.Size = new global::System.Drawing.Size(22, 22);
		this.CloseIcon.TabIndex = 19;
		this.CloseIcon.UseVisualStyleBackColor = false;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
		base.ClientSize = new global::System.Drawing.Size(410, 226);
		base.Controls.Add(this.CloseIcon);
		base.Controls.Add(this.BlockerPanel);
		this.DoubleBuffered = true;
		this.Font = new global::System.Drawing.Font("Tahoma", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 204);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		this.MaximumSize = new global::System.Drawing.Size(410, 226);
		base.Name = "BlockerMenu";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Blocker Menu";
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.BlockerMenu_Load);
		this.BlockerPanel.ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.Table).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x040000CA RID: 202
	private global::System.Windows.Forms.Panel BlockerPanel;

	// Token: 0x040000CB RID: 203
	private global::System.Windows.Forms.Button CloseIcon;

	// Token: 0x040000CC RID: 204
	private global::System.Windows.Forms.DataGridView Table;

	// Token: 0x040000CD RID: 205
	private global::System.Windows.Forms.DataGridViewTextBoxColumn Column1;

	// Token: 0x040000CE RID: 206
	private global::System.Windows.Forms.DataGridViewTextBoxColumn Column2;
}
