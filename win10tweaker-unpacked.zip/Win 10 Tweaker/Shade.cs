﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// Token: 0x020000DB RID: 219
public partial class Shade : Form
{
	// Token: 0x17000094 RID: 148
	// (get) Token: 0x06000B1A RID: 2842 RVA: 0x000065E1 File Offset: 0x000047E1
	protected virtual CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ExStyle |= 524288;
			createParams.ExStyle |= 128;
			return createParams;
		}
	}

	// Token: 0x06000B1B RID: 2843 RVA: 0x0000660D File Offset: 0x0000480D
	public Shade()
	{
		base.Location = Application.OpenForms["Widget"].Location;
		this.InitializeComponent();
	}

	// Token: 0x06000B1C RID: 2844 RVA: 0x00006635 File Offset: 0x00004835
	private void Shade_Load(object sender, EventArgs e)
	{
		base.Width = 80;
		base.Height = 80;
		this.BackgroundImage = this.method_0(Class89.Bitmap_47);
	}

	// Token: 0x06000B1D RID: 2845 RVA: 0x00038A84 File Offset: 0x00036C84
	public Bitmap method_0(Bitmap bitmap_0)
	{
		IntPtr intPtr = Shade.Class73.CreateCompatibleDC(Shade.Class73.GetDC(IntPtr.Zero));
		Shade.Class73.SelectObject(intPtr, bitmap_0.GetHbitmap(Color.FromArgb(0)));
		Shade.Class73.Struct72 @struct = new Shade.Class73.Struct72(bitmap_0.Width, bitmap_0.Height);
		Shade.Class73.Struct71 struct2 = new Shade.Class73.Struct71(0, 0);
		Shade.Class73.Struct71 struct3 = new Shade.Class73.Struct71(base.Left, base.Top);
		Shade.Class73.Struct74 struct4 = new Shade.Class73.Struct74
		{
			byte_2 = byte.MaxValue,
			byte_3 = 1
		};
		Shade.Class73.UpdateLayeredWindow(this.method_1(), Shade.Class73.GetDC(IntPtr.Zero), ref struct3, ref @struct, intPtr, ref struct2, 0, ref struct4, 2);
		return bitmap_0;
	}

	// Token: 0x06000B1E RID: 2846 RVA: 0x00006658 File Offset: 0x00004858
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06000B20 RID: 2848 RVA: 0x0000414F File Offset: 0x0000234F
	static int smethod_0(CreateParams createParams_0)
	{
		return createParams_0.ExStyle;
	}

	// Token: 0x06000B21 RID: 2849 RVA: 0x00004157 File Offset: 0x00002357
	static void smethod_1(CreateParams createParams_0, int int_0)
	{
		createParams_0.ExStyle = int_0;
	}

	// Token: 0x06000B22 RID: 2850 RVA: 0x000029CD File Offset: 0x00000BCD
	static FormCollection smethod_2()
	{
		return Application.OpenForms;
	}

	// Token: 0x06000B23 RID: 2851 RVA: 0x000057C2 File Offset: 0x000039C2
	static Form smethod_3(FormCollection formCollection_0, string string_0)
	{
		return formCollection_0[string_0];
	}

	// Token: 0x06000B24 RID: 2852 RVA: 0x00006677 File Offset: 0x00004877
	static Point smethod_4(Form form_0)
	{
		return form_0.Location;
	}

	// Token: 0x06000B25 RID: 2853 RVA: 0x0000667F File Offset: 0x0000487F
	static void smethod_5(Form form_0, Point point_0)
	{
		form_0.Location = point_0;
	}

	// Token: 0x06000B26 RID: 2854 RVA: 0x00006688 File Offset: 0x00004888
	static void smethod_6(Control control_0, int int_0)
	{
		control_0.Width = int_0;
	}

	// Token: 0x06000B27 RID: 2855 RVA: 0x00006691 File Offset: 0x00004891
	static void smethod_7(Control control_0, int int_0)
	{
		control_0.Height = int_0;
	}

	// Token: 0x06000B28 RID: 2856 RVA: 0x00002B2F File Offset: 0x00000D2F
	static void smethod_8(Control control_0, Image image_0)
	{
		control_0.BackgroundImage = image_0;
	}

	// Token: 0x06000B29 RID: 2857 RVA: 0x0000669A File Offset: 0x0000489A
	static IntPtr smethod_9(Bitmap bitmap_0, Color color_0)
	{
		return bitmap_0.GetHbitmap(color_0);
	}

	// Token: 0x06000B2A RID: 2858 RVA: 0x000057D3 File Offset: 0x000039D3
	static int smethod_10(Image image_0)
	{
		return image_0.Width;
	}

	// Token: 0x06000B2B RID: 2859 RVA: 0x000057DB File Offset: 0x000039DB
	static int smethod_11(Image image_0)
	{
		return image_0.Height;
	}

	// Token: 0x06000B2C RID: 2860 RVA: 0x000066A3 File Offset: 0x000048A3
	static int smethod_12(Control control_0)
	{
		return control_0.Left;
	}

	// Token: 0x06000B2D RID: 2861 RVA: 0x000066AB File Offset: 0x000048AB
	static int smethod_13(Control control_0)
	{
		return control_0.Top;
	}

	// Token: 0x06000B2E RID: 2862 RVA: 0x00002B07 File Offset: 0x00000D07
	IntPtr method_1()
	{
		return base.Handle;
	}

	// Token: 0x06000B2F RID: 2863 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_14(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x06000B30 RID: 2864 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_15(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x04000473 RID: 1139
	private IContainer icontainer_0;

	// Token: 0x020000DC RID: 220
	private class Class73
	{
		// Token: 0x06000B31 RID: 2865
		[DllImport("user32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern Shade.Class73.Enum8 UpdateLayeredWindow(IntPtr intptr_0, IntPtr intptr_1, ref Shade.Class73.Struct71 struct71_0, ref Shade.Class73.Struct72 struct72_0, IntPtr intptr_2, ref Shade.Class73.Struct71 struct71_1, int int_1, ref Shade.Class73.Struct74 struct74_0, int int_2);

		// Token: 0x06000B32 RID: 2866
		[DllImport("user32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern IntPtr GetDC(IntPtr intptr_0);

		// Token: 0x06000B33 RID: 2867
		[DllImport("gdi32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern IntPtr CreateCompatibleDC(IntPtr intptr_0);

		// Token: 0x06000B34 RID: 2868
		[DllImport("gdi32.dll", ExactSpelling = true)]
		public static extern IntPtr SelectObject(IntPtr intptr_0, IntPtr intptr_1);

		// Token: 0x04000474 RID: 1140
		public const int int_0 = 2;

		// Token: 0x04000475 RID: 1141
		public const byte byte_0 = 0;

		// Token: 0x04000476 RID: 1142
		public const byte byte_1 = 1;

		// Token: 0x020000DD RID: 221
		public enum Enum8
		{
			// Token: 0x04000478 RID: 1144
			False,
			// Token: 0x04000479 RID: 1145
			True
		}

		// Token: 0x020000DE RID: 222
		public struct Struct71
		{
			// Token: 0x06000B36 RID: 2870 RVA: 0x000066B3 File Offset: 0x000048B3
			public Struct71(int int_2, int int_3)
			{
				this.int_0 = int_2;
				this.int_1 = int_3;
			}

			// Token: 0x0400047A RID: 1146
			public int int_0;

			// Token: 0x0400047B RID: 1147
			public int int_1;
		}

		// Token: 0x020000DF RID: 223
		public struct Struct72
		{
			// Token: 0x06000B37 RID: 2871 RVA: 0x000066C3 File Offset: 0x000048C3
			public Struct72(int int_2, int int_3)
			{
				this.int_0 = int_2;
				this.int_1 = int_3;
			}

			// Token: 0x0400047C RID: 1148
			public int int_0;

			// Token: 0x0400047D RID: 1149
			public int int_1;
		}

		// Token: 0x020000E0 RID: 224
		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		private struct Struct73
		{
			// Token: 0x0400047E RID: 1150
			public byte byte_0;

			// Token: 0x0400047F RID: 1151
			public byte byte_1;

			// Token: 0x04000480 RID: 1152
			public byte byte_2;

			// Token: 0x04000481 RID: 1153
			public byte byte_3;
		}

		// Token: 0x020000E1 RID: 225
		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct Struct74
		{
			// Token: 0x04000482 RID: 1154
			public byte byte_0;

			// Token: 0x04000483 RID: 1155
			public byte byte_1;

			// Token: 0x04000484 RID: 1156
			public byte byte_2;

			// Token: 0x04000485 RID: 1157
			public byte byte_3;
		}
	}
}
