﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.Win32;
using Win_10_Tweaker;

// Token: 0x0200006B RID: 107
public partial class Popup : Form
{
	// Token: 0x17000025 RID: 37
	// (get) Token: 0x0600052A RID: 1322 RVA: 0x0000407B File Offset: 0x0000227B
	protected virtual CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ClassStyle |= 131072;
			return createParams;
		}
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x0600052B RID: 1323 RVA: 0x00004095 File Offset: 0x00002295
	// (set) Token: 0x0600052C RID: 1324 RVA: 0x0000409D File Offset: 0x0000229D
	public string String_0 { get; set; }

	// Token: 0x0600052D RID: 1325 RVA: 0x0001A530 File Offset: 0x00018730
	public Popup(Form1 form1_1)
	{
		this.InitializeComponent();
		this.form1_0 = form1_1;
		this.CloseIcon.Click += this.method_1;
		this.MainPanel.Click += this.method_2;
		this.BackColor = GClass2.GClass2_0.color_3;
	}

	// Token: 0x0600052E RID: 1326 RVA: 0x0001A590 File Offset: 0x00018790
	private void Popup_Load(object sender, EventArgs e)
	{
		Popup.Struct37 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.popup_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Popup.Struct37>(ref @struct);
	}

	// Token: 0x0600052F RID: 1327 RVA: 0x0001A5C8 File Offset: 0x000187C8
	private void Message_MouseDown(object sender, MouseEventArgs e)
	{
		Popup.Struct38 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.popup_0 = this;
		@struct.mouseEventArgs_0 = e;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Popup.Struct38>(ref @struct);
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x0001A608 File Offset: 0x00018808
	public void method_0()
	{
		Popup.Struct39 @struct;
		@struct.asyncVoidMethodBuilder_0 = AsyncVoidMethodBuilder.Create();
		@struct.popup_0 = this;
		@struct.int_0 = -1;
		@struct.asyncVoidMethodBuilder_0.Start<Popup.Struct39>(ref @struct);
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x000040A6 File Offset: 0x000022A6
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x0001A978 File Offset: 0x00018B78
	[CompilerGenerated]
	private void method_1(object sender, EventArgs e)
	{
		if (this.Message.Text.Contains(Popup.string_1))
		{
			if (GClass2.GClass2_0.RegistryKey_0.GetValue(Popup.string_1) != null)
			{
				GClass2.GClass2_0.RegistryKey_0.SetValue(Popup.string_1, "true");
			}
			else
			{
				GClass2.GClass2_0.RegistryKey_0.SetValue(Popup.string_1, "false");
			}
		}
		this.method_0();
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x0001A9EC File Offset: 0x00018BEC
	[CompilerGenerated]
	private void method_2(object sender, EventArgs e)
	{
		if (this.Message.Text == GClass2.GClass2_0.String_6 + "\n" + GClass2.GClass2_0.method_1("RestartRequired") && WMessageBox.smethod_3(GClass2.GClass2_0.method_1("PopupReboot"), "", WMessageBox.GEnum2.YesNo, false, "", null) == DialogResult.Yes)
		{
			GClass6.GClass6_0.method_14("shutdown /r /t 0");
			this.form1_0.ForceClose();
		}
		this.method_0();
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x0001AA74 File Offset: 0x00018C74
	[CompilerGenerated]
	private void method_3()
	{
		using (WebClient webClient = new WebClient())
		{
			string fileName = GClass13.string_1 + "\\DirectX.exe";
			base.Close();
			webClient.DownloadFile("https://download.microsoft.com/download/1/7/1/1718CCC4-6315-4D8E-9543-8E28A4E18C4C/dxwebsetup.exe", fileName);
			Process.Start(fileName);
		}
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x0001AACC File Offset: 0x00018CCC
	[CompilerGenerated]
	private void method_4()
	{
		using (WebClient webClient = new WebClient())
		{
			string fileName = GClass13.string_1 + "\\NetFramework.exe";
			base.Close();
			webClient.DownloadFile("https://download.microsoft.com/download/0/5/C/05C1EC0E-D5EE-463B-BFE3-9311376A6809/NDP472-KB4054531-Web.exe", fileName);
			Process.Start(fileName);
		}
	}

	// Token: 0x06000538 RID: 1336 RVA: 0x00002F78 File Offset: 0x00001178
	static int smethod_0(CreateParams createParams_0)
	{
		return createParams_0.ClassStyle;
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x00002F80 File Offset: 0x00001180
	static void smethod_1(CreateParams createParams_0, int int_0)
	{
		createParams_0.ClassStyle = int_0;
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x00002951 File Offset: 0x00000B51
	static void smethod_2(Control control_0, EventHandler eventHandler_0)
	{
		control_0.Click += eventHandler_0;
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x00002BA7 File Offset: 0x00000DA7
	static void smethod_3(Control control_0, Color color_0)
	{
		control_0.BackColor = color_0;
	}

	// Token: 0x0600053C RID: 1340 RVA: 0x0000297C File Offset: 0x00000B7C
	static void smethod_4(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	// Token: 0x0600053D RID: 1341 RVA: 0x00002A53 File Offset: 0x00000C53
	static Label smethod_5()
	{
		return new Label();
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x00002A5A File Offset: 0x00000C5A
	static PictureBox smethod_6()
	{
		return new PictureBox();
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x00002A77 File Offset: 0x00000C77
	static Panel smethod_7()
	{
		return new Panel();
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x00002A85 File Offset: 0x00000C85
	static void smethod_8(ISupportInitialize isupportInitialize_0)
	{
		isupportInitialize_0.BeginInit();
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x00002A8D File Offset: 0x00000C8D
	static void smethod_9(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x00002A95 File Offset: 0x00000C95
	static void smethod_10(Control control_0)
	{
		control_0.SuspendLayout();
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x00002A9D File Offset: 0x00000C9D
	static void smethod_11(Control control_0, bool bool_0)
	{
		control_0.AutoSize = bool_0;
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x000039A9 File Offset: 0x00001BA9
	static Font smethod_12(string string_2, float float_0, FontStyle fontStyle_0, GraphicsUnit graphicsUnit_0, byte byte_0)
	{
		return new Font(string_2, float_0, fontStyle_0, graphicsUnit_0, byte_0);
	}

	// Token: 0x06000545 RID: 1349 RVA: 0x000039B6 File Offset: 0x00001BB6
	static void smethod_13(Control control_0, Font font_0)
	{
		control_0.Font = font_0;
	}

	// Token: 0x06000546 RID: 1350 RVA: 0x00002B7F File Offset: 0x00000D7F
	static void smethod_14(Control control_0, Color color_0)
	{
		control_0.ForeColor = color_0;
	}

	// Token: 0x06000547 RID: 1351 RVA: 0x00002A18 File Offset: 0x00000C18
	static string smethod_15(Control control_0)
	{
		return control_0.Text;
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x00002A20 File Offset: 0x00000C20
	static bool smethod_16(string string_2, string string_3)
	{
		return string_2.Contains(string_3);
	}

	// Token: 0x06000549 RID: 1353 RVA: 0x000029DD File Offset: 0x00000BDD
	static object smethod_17(RegistryKey registryKey_0, string string_2)
	{
		return registryKey_0.GetValue(string_2);
	}

	// Token: 0x0600054A RID: 1354 RVA: 0x00002C41 File Offset: 0x00000E41
	static void smethod_18(RegistryKey registryKey_0, string string_2, object object_0)
	{
		registryKey_0.SetValue(string_2, object_0);
	}

	// Token: 0x0600054B RID: 1355 RVA: 0x00003033 File Offset: 0x00001233
	static string smethod_19(string string_2, string string_3, string string_4)
	{
		return string_2 + string_3 + string_4;
	}

	// Token: 0x0600054C RID: 1356 RVA: 0x00002B59 File Offset: 0x00000D59
	static bool smethod_20(string string_2, string string_3)
	{
		return string_2 == string_3;
	}

	// Token: 0x0600054D RID: 1357 RVA: 0x00002994 File Offset: 0x00000B94
	static WebClient smethod_21()
	{
		return new WebClient();
	}

	// Token: 0x0600054E RID: 1358 RVA: 0x000025E0 File Offset: 0x000007E0
	static string smethod_22(string string_2, string string_3)
	{
		return string_2 + string_3;
	}

	// Token: 0x0600054F RID: 1359 RVA: 0x00002C39 File Offset: 0x00000E39
	static void smethod_23(Form form_0)
	{
		form_0.Close();
	}

	// Token: 0x06000550 RID: 1360 RVA: 0x000029C3 File Offset: 0x00000BC3
	static void smethod_24(WebClient webClient_0, string string_2, string string_3)
	{
		webClient_0.DownloadFile(string_2, string_3);
	}

	// Token: 0x06000551 RID: 1361 RVA: 0x00002AA6 File Offset: 0x00000CA6
	static Process smethod_25(string string_2)
	{
		return Process.Start(string_2);
	}

	// Token: 0x0400023E RID: 574
	[CompilerGenerated]
	private string string_0;

	// Token: 0x0400023F RID: 575
	private static readonly string string_1 = "DirectX";

	// Token: 0x04000240 RID: 576
	private readonly Form1 form1_0;

	// Token: 0x04000241 RID: 577
	private IContainer icontainer_0;
}
