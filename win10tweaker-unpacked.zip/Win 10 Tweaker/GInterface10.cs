﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x020001A7 RID: 423
[TypeIdentifier]
[Guid("317EE249-F12E-11D2-B1E4-00C04F8EEB3E")]
[CompilerGenerated]
[ComImport]
public interface GInterface10 : GInterface9
{
	// Token: 0x17000107 RID: 263
	// (get) Token: 0x06001446 RID: 5190
	// (set) Token: 0x06001447 RID: 5191
	[DispId(1610743808)]
	string String_0 { [DispId(1610743808)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.BStr)] get; [DispId(1610743808)] [MethodImpl(MethodImplOptions.InternalCall)] [param: MarshalAs(UnmanagedType.BStr)] [param: In] set; }
}
