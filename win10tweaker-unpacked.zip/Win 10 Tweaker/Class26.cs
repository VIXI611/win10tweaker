﻿using System;
using System.Net;

// Token: 0x02000057 RID: 87
internal class Class26
{
	// Token: 0x06000422 RID: 1058 RVA: 0x000187C8 File Offset: 0x000169C8
	public static bool smethod_0()
	{
		bool result;
		try
		{
			Dns.GetHostEntry("win10tweaker.pro");
			result = true;
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000424 RID: 1060 RVA: 0x00003B1D File Offset: 0x00001D1D
	static IPHostEntry smethod_1(string string_0)
	{
		return Dns.GetHostEntry(string_0);
	}
}
